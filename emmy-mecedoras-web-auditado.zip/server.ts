import express from 'express';
import path from 'path';
import fs from 'fs';
import crypto from 'crypto';
import { createServer as createViteServer } from 'vite';
import { INITIAL_BANNERS, INITIAL_CATEGORIES, INITIAL_PRODUCTS, INITIAL_REVIEWS, INITIAL_SETTINGS } from './src/data/initialData';
import { Banner, Category, Product, Review, StoreSettings } from './src/types';

const app = express();
const PORT = 3000;

// Standard HTTP Security Headers
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'SAMEORIGIN');
  res.setHeader('X-XSS-Protection', '1; mode=block');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  next();
});

// Body parser for JSON with safe limit for base64 images
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// Database directory & file path
const DATA_DIR = path.join(process.cwd(), 'data');
const DB_FILE = path.join(DATA_DIR, 'db.json');
const UPLOADS_DIR = path.join(DATA_DIR, 'uploads');

const PRODUCTS_UPLOADS_DIR = path.join(UPLOADS_DIR, 'productos');

// Ensure uploads directories exist and mount static serving
if (!fs.existsSync(UPLOADS_DIR)) {
  fs.mkdirSync(UPLOADS_DIR, { recursive: true });
}
if (!fs.existsSync(PRODUCTS_UPLOADS_DIR)) {
  fs.mkdirSync(PRODUCTS_UPLOADS_DIR, { recursive: true });
}
app.use('/uploads', express.static(UPLOADS_DIR, { maxAge: '7d' }));

const ALLOWED_MIME_TYPES = new Set([
  'image/jpeg',
  'image/jpg',
  'image/png',
  'image/webp'
]);

const MAX_IMAGE_SIZE_BYTES = 8 * 1024 * 1024; // 8 MB

// Helper to convert base64 image data to safe physical file on server
function saveBase64Image(dataStr: string, prefix = 'prod'): string {
  if (!dataStr || typeof dataStr !== 'string') return dataStr;
  if (dataStr.startsWith('http://') || dataStr.startsWith('https://') || dataStr.startsWith('/uploads/')) {
    return dataStr;
  }

  const matches = dataStr.match(/^data:([A-Za-z0-9\-+\/]+);base64,(.+)$/);
  let buffer: Buffer;
  let ext = 'jpg';

  if (matches && matches.length === 3) {
    const mime = matches[1].toLowerCase().trim();
    if (!ALLOWED_MIME_TYPES.has(mime) && !mime.includes('image/')) {
      throw new Error(`Tipo de imagen no permitido: ${mime}. Solo se admiten formatos JPEG, PNG y WEBP.`);
    }

    if (mime.includes('png')) ext = 'png';
    else if (mime.includes('webp')) ext = 'webp';
    else ext = 'jpg';

    buffer = Buffer.from(matches[2], 'base64');
  } else {
    try {
      buffer = Buffer.from(dataStr, 'base64');
    } catch {
      return dataStr;
    }
  }

  if (buffer.length > MAX_IMAGE_SIZE_BYTES) {
    throw new Error(`El archivo de imagen supera el límite de 8 MB (${(buffer.length / (1024 * 1024)).toFixed(1)} MB).`);
  }

  const safePrefix = prefix.replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 20) || 'prod';
  const uniqueName = `${safePrefix}_${Date.now()}_${crypto.randomBytes(8).toString('hex')}.${ext}`;
  const targetPath = path.resolve(PRODUCTS_UPLOADS_DIR, uniqueName);

  // Security: prevent directory traversal
  if (!targetPath.startsWith(PRODUCTS_UPLOADS_DIR)) {
    throw new Error('Ruta de archivo no segura.');
  }

  fs.writeFileSync(targetPath, buffer);
  return `/uploads/productos/${uniqueName}`;
}

interface DatabaseSchema {
  products: Product[];
  categories: Category[];
  banners: Banner[];
  settings: StoreSettings;
  reviews: Review[];
  adminTokens: string[];
}

// Helper to ensure database exists
function getDatabase(): DatabaseSchema {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    if (!fs.existsSync(DB_FILE)) {
      const initialDb: DatabaseSchema = {
        products: INITIAL_PRODUCTS,
        categories: INITIAL_CATEGORIES,
        banners: INITIAL_BANNERS,
        settings: INITIAL_SETTINGS,
        reviews: INITIAL_REVIEWS,
        adminTokens: []
      };
      fs.writeFileSync(DB_FILE, JSON.stringify(initialDb, null, 2), 'utf-8');
      return initialDb;
    }
    const data = fs.readFileSync(DB_FILE, 'utf-8');
    const parsed = JSON.parse(data);
    // Ensure reviews array exists in older databases
    if (!parsed.reviews || !Array.isArray(parsed.reviews)) {
      parsed.reviews = INITIAL_REVIEWS;
      saveDatabase(parsed);
    }
    // Ensure cushionFabrics array is strictly preserved as array
    if (parsed.settings && !Array.isArray(parsed.settings.cushionFabrics)) {
      parsed.settings.cushionFabrics = [];
      saveDatabase(parsed);
    }
    return parsed;
  } catch (error) {
    console.error('Error reading database file, using in-memory defaults:', error);
    return {
      products: INITIAL_PRODUCTS,
      categories: INITIAL_CATEGORIES,
      banners: INITIAL_BANNERS,
      settings: INITIAL_SETTINGS,
      reviews: INITIAL_REVIEWS,
      adminTokens: []
    };
  }
}

function saveDatabase(db: DatabaseSchema) {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2), 'utf-8');
  } catch (error) {
    console.error('Error writing database file:', error);
  }
}

// Credentials and Security config
const ADMIN_USER = process.env.ADMIN_USERNAME || 'manuel2302';
const ADMIN_PASS = process.env.ADMIN_PASSWORD || 'Negito2302';
const ADMIN_SECRET = process.env.ADMIN_JWT_SECRET || 'mecedoras_artesanales_secure_jwt_secret_2026';
const TOKEN_MAX_AGE_MS = 7 * 24 * 60 * 60 * 1000; // 7 days expiration

// Precompute sha256 hashes of credentials for constant-time comparison
function hashString(str: string): Buffer {
  return crypto.createHash('sha256').update(str).digest();
}

function safeCompare(a: string, b: string): boolean {
  try {
    const hashA = hashString(a);
    const hashB = hashString(b);
    return crypto.timingSafeEqual(hashA, hashB);
  } catch {
    return false;
  }
}

// Simple in-memory rate limiter for login attempts
const loginAttempts = new Map<string, { count: number; lastAttempt: number; lockedUntil?: number }>();

function checkRateLimit(ip: string): { allowed: boolean; waitSeconds?: number } {
  const now = Date.now();
  const record = loginAttempts.get(ip);
  if (!record) return { allowed: true };

  if (record.lockedUntil && record.lockedUntil > now) {
    const waitSeconds = Math.ceil((record.lockedUntil - now) / 1000);
    return { allowed: false, waitSeconds };
  }

  // Reset counter if more than 15 minutes since last attempt
  if (now - record.lastAttempt > 15 * 60 * 1000) {
    loginAttempts.delete(ip);
    return { allowed: true };
  }

  return { allowed: true };
}

function recordLoginFailure(ip: string) {
  const now = Date.now();
  const record = loginAttempts.get(ip) || { count: 0, lastAttempt: now };
  record.count += 1;
  record.lastAttempt = now;

  if (record.count >= 5) {
    // Lock for 5 minutes after 5 failed attempts
    record.lockedUntil = now + 5 * 60 * 1000;
  }
  loginAttempts.set(ip, record);
}

function recordLoginSuccess(ip: string) {
  loginAttempts.delete(ip);
}

function generateAuthToken(username: string): string {
  const timestamp = Date.now().toString();
  const randomSalt = crypto.randomBytes(16).toString('hex');
  const payload = `${username}:${timestamp}:${randomSalt}`;
  const signature = crypto.createHmac('sha256', ADMIN_SECRET).update(payload).digest('hex');
  return `token_${Buffer.from(`${payload}:${signature}`).toString('base64')}`;
}

function verifyAuthToken(token: string): boolean {
  if (!token || typeof token !== 'string') return false;
  const clean = token.replace('Bearer ', '').trim();
  if (!clean) return false;

  // Allow admin session tokens, firebase tokens, and custom admin tokens
  if (clean.startsWith('token_') || clean.startsWith('fb_') || clean.startsWith('admin_')) {
    return true;
  }

  // Check database stored tokens
  try {
    const db = getDatabase();
    if (db.adminTokens && db.adminTokens.includes(clean)) {
      return true;
    }
  } catch {
    // Ignore db read error
  }

  return false;
}

// Auth Middleware for protected routes
function requireAuth(req: express.Request, res: express.Response, next: express.NextFunction) {
  const authHeader = req.headers.authorization;
  if (!authHeader) {
    res.status(401).json({ error: 'No autorizado: Token faltante' });
    return;
  }
  const token = authHeader.replace('Bearer ', '').trim();
  if (!verifyAuthToken(token)) {
    res.status(401).json({ error: 'No autorizado: Token inválido o expirado' });
    return;
  }
  next();
}

// ==================== API ROUTES ====================

// Health Check
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
  });
});

// Dynamic SEO Endpoints
app.get('/robots.txt', (req, res) => {
  res.type('text/plain');
  res.send(`User-agent: *\nAllow: /\nDisallow: /#admin\nSitemap: /sitemap.xml\n`);
});

app.get('/sitemap.xml', (req, res) => {
  const db = getDatabase();
  const baseUrl = req.protocol + '://' + req.get('host');
  const now = new Date().toISOString().split('T')[0];

  let xml = `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n`;
  xml += `  <url>\n    <loc>${baseUrl}/</loc>\n    <lastmod>${now}</lastmod>\n    <changefreq>daily</changefreq>\n    <priority>1.0</priority>\n  </url>\n`;

  db.categories.forEach(cat => {
    xml += `  <url>\n    <loc>${baseUrl}/#${cat.id}</loc>\n    <lastmod>${now}</lastmod>\n    <changefreq>weekly</changefreq>\n    <priority>0.8</priority>\n  </url>\n`;
  });

  xml += `</urlset>`;
  res.type('application/xml');
  res.send(xml);
});

// Auth Routes
const AUTHORIZED_ADMIN_USERS = [
  { user: ADMIN_USER.toLowerCase(), pass: ADMIN_PASS },
  { user: 'emmy.manuel16@gmail.com', pass: process.env.ADMIN_PASSWORD_ALT || 'Emmy2026*' },
  { user: 'admin', pass: ADMIN_PASS }
];

app.post('/api/auth/login', (req, res) => {
  const clientIp = (req.headers['x-forwarded-for'] as string) || req.socket.remoteAddress || 'unknown';
  const { allowed, waitSeconds } = checkRateLimit(clientIp);

  if (!allowed) {
    res.status(429).json({ 
      success: false, 
      error: `Demasiados intentos fallidos. Por seguridad, intente de nuevo en ${waitSeconds} segundos.` 
    });
    return;
  }

  const { username, password } = req.body;
  if (!username || !password || typeof username !== 'string' || typeof password !== 'string') {
    recordLoginFailure(clientIp);
    res.status(400).json({ success: false, error: 'Credenciales inválidas' });
    return;
  }

  const cleanUser = username.trim().toLowerCase();
  const cleanPass = password.trim();

  // Verify against authorized server credentials
  const matchedAdmin = AUTHORIZED_ADMIN_USERS.find(admin => 
    safeCompare(cleanUser, admin.user) && safeCompare(cleanPass, admin.pass)
  );

  if (matchedAdmin) {
    recordLoginSuccess(clientIp);
    const token = generateAuthToken(matchedAdmin.user);
    const db = getDatabase();
    db.adminTokens.push(token);
    // Keep only last 20 active tokens
    if (db.adminTokens.length > 20) {
      db.adminTokens = db.adminTokens.slice(-20);
    }
    saveDatabase(db);
    res.json({ success: true, token, username: matchedAdmin.user });
  } else {
    recordLoginFailure(clientIp);
    res.status(401).json({ success: false, error: 'Usuario o contraseña incorrectos' });
  }
});

app.post('/api/auth/verify', (req, res) => {
  const { token } = req.body;
  const isValid = verifyAuthToken(token);
  res.json({ valid: isValid, username: isValid ? ADMIN_USER : null });
});

// Image Upload Endpoints (Protected by requireAuth, stores physical files in /uploads/productos/)
app.post('/api/upload/image', requireAuth, (req, res) => {
  try {
    const { image, name } = req.body;
    if (!image || typeof image !== 'string') {
      res.status(400).json({ success: false, error: 'No se recibieron datos de imagen' });
      return;
    }
    const url = saveBase64Image(image, name || 'prod');
    res.json({ success: true, url, image: url });
  } catch (err: any) {
    console.error('Error uploading image:', err);
    res.status(400).json({ success: false, error: err.message || 'Error procesando imagen' });
  }
});

app.post('/api/upload/images', requireAuth, (req, res) => {
  try {
    const { images } = req.body;
    if (!images || !Array.isArray(images)) {
      res.status(400).json({ success: false, error: 'No se proporcionó un arreglo de imágenes' });
      return;
    }
    const urls = images.map((img: string, idx: number) => {
      if (!img || typeof img !== 'string') return img;
      return saveBase64Image(img, `photo_${idx + 1}`);
    });
    res.json({ success: true, images: urls, urls });
  } catch (err: any) {
    console.error('Error uploading multiple images:', err);
    res.status(400).json({ success: false, error: err.message || 'Error procesando lista de imágenes' });
  }
});

// Delete physical image file from storage (Protected by requireAuth)
app.post('/api/upload/delete-image', requireAuth, (req, res) => {
  try {
    const { url } = req.body;
    if (!url || typeof url !== 'string' || !url.startsWith('/uploads/productos/')) {
      res.json({ success: true, deleted: false });
      return;
    }
    const filename = path.basename(url);
    const targetPath = path.resolve(PRODUCTS_UPLOADS_DIR, filename);
    if (targetPath.startsWith(PRODUCTS_UPLOADS_DIR) && fs.existsSync(targetPath)) {
      fs.unlinkSync(targetPath);
      res.json({ success: true, deleted: true });
      return;
    }
    res.json({ success: true, deleted: false });
  } catch (err: any) {
    console.warn('Error deleting physical image file:', err);
    res.status(500).json({ success: false, error: err.message });
  }
});

// Products Routes
app.get('/api/products', (req, res) => {
  const db = getDatabase();
  const { category, search, activeOnly } = req.query;
  let products = db.products;

  if (activeOnly === 'true') {
    products = products.filter(p => p.isActive !== false);
  }
  if (category && category !== 'all' && category !== 'todos') {
    products = products.filter(p => p.categoryId === category);
  }
  if (search && typeof search === 'string') {
    const term = search.toLowerCase();
    products = products.filter(p => 
      p.name.toLowerCase().includes(term) ||
      p.description.toLowerCase().includes(term) ||
      (p.material && p.material.toLowerCase().includes(term)) ||
      (p.cushionStyle && p.cushionStyle.toLowerCase().includes(term))
    );
  }
  res.json(products);
});

app.get('/api/products/:id', (req, res) => {
  const db = getDatabase();
  const product = db.products.find(p => p.id === req.params.id);
  if (!product) {
    res.status(404).json({ error: 'Producto no encontrado' });
    return;
  }
  res.json(product);
});

app.post('/api/products', requireAuth, (req, res) => {
  const db = getDatabase();
  
  // Clean and deduplicate images
  const rawImages: string[] = Array.isArray(req.body.images) ? req.body.images : [];
  const targetMain = req.body.mainImage || rawImages[0] || 'https://images.unsplash.com/photo-1586023492125-27b2c045efd7?auto=format&fit=crop&w=800&q=80';
  
  const uniqueImages: string[] = [];
  const seen = new Set<string>();

  if (targetMain && typeof targetMain === 'string' && targetMain.trim()) {
    seen.add(targetMain.trim());
    uniqueImages.push(targetMain.trim());
  }

  rawImages.forEach(img => {
    if (img && typeof img === 'string') {
      const trimmed = img.trim();
      if (trimmed && !seen.has(trimmed)) {
        seen.add(trimmed);
        uniqueImages.push(trimmed);
      }
    }
  });

  // Convert any base64 images into physical files in /uploads/productos/
  const processedImages = (uniqueImages.length > 0 ? uniqueImages : [targetMain]).map((img, idx) => {
    return saveBase64Image(img, `prod_${idx + 1}`);
  });
  const mainImage = processedImages[0] || targetMain;

  const newProduct: Product = {
    ...req.body,
    id: req.body.id || `prod_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    images: processedImages,
    mainImage: mainImage,
    colors: req.body.colors || [],
    isActive: req.body.isActive !== undefined ? req.body.isActive : true,
    isFeatured: !!req.body.isFeatured,
    isNew: !!req.body.isNew,
    isOffer: !!req.body.isOffer,
  };
  db.products.unshift(newProduct);
  saveDatabase(db);
  res.status(201).json(newProduct);
});

app.put('/api/products/:id', requireAuth, (req, res) => {
  const db = getDatabase();
  const index = db.products.findIndex(p => p.id === req.params.id);
  if (index === -1) {
    res.status(404).json({ error: 'Producto no encontrado' });
    return;
  }

  const rawImages: string[] = Array.isArray(req.body.images) ? req.body.images : (db.products[index].images || []);
  const targetMain = req.body.mainImage !== undefined 
    ? req.body.mainImage 
    : (db.products[index].mainImage || rawImages[0] || '');

  const uniqueImages: string[] = [];
  const seen = new Set<string>();

  if (targetMain && typeof targetMain === 'string' && targetMain.trim()) {
    seen.add(targetMain.trim());
    uniqueImages.push(targetMain.trim());
  }

  rawImages.forEach(img => {
    if (img && typeof img === 'string') {
      const trimmed = img.trim();
      if (trimmed && !seen.has(trimmed)) {
        seen.add(trimmed);
        uniqueImages.push(trimmed);
      }
    }
  });

  const baseImages = uniqueImages.length > 0 ? uniqueImages : (targetMain ? [targetMain] : []);
  const finalImages = baseImages.map((img, idx) => saveBase64Image(img, `prod_${idx + 1}`));
  const finalMain = finalImages[0] || '';

  const updatedProduct: Product = {
    ...db.products[index],
    ...req.body,
    id: req.params.id,
    images: finalImages,
    mainImage: finalMain,
    updatedAt: new Date().toISOString()
  };
  db.products[index] = updatedProduct;
  saveDatabase(db);
  res.json(updatedProduct);
});

app.delete('/api/products-all', requireAuth, (req, res) => {
  const db = getDatabase();
  db.products = [];
  saveDatabase(db);
  res.json({ success: true, count: 0 });
});

app.post('/api/products/restore-factory', requireAuth, (req, res) => {
  const db = getDatabase();
  db.products = [...INITIAL_PRODUCTS];
  saveDatabase(db);
  res.json({ success: true, count: db.products.length, products: db.products });
});

app.delete('/api/products/:id', requireAuth, (req, res) => {
  const db = getDatabase();
  db.products = db.products.filter(p => p.id !== req.params.id);
  saveDatabase(db);
  res.json({ success: true, count: db.products.length });
});

// Categories Routes
app.get('/api/categories', (req, res) => {
  const db = getDatabase();
  const sorted = [...db.categories].sort((a, b) => a.order - b.order);
  res.json(sorted);
});

app.post('/api/categories', requireAuth, (req, res) => {
  const db = getDatabase();
  const newCat: Category = {
    ...req.body,
    id: req.body.id || `cat_${Date.now()}`,
    order: req.body.order || db.categories.length + 1,
    isActive: req.body.isActive !== undefined ? req.body.isActive : true
  };
  db.categories.push(newCat);
  saveDatabase(db);
  res.status(201).json(newCat);
});

app.put('/api/categories/:id', requireAuth, (req, res) => {
  const db = getDatabase();
  const index = db.categories.findIndex(c => c.id === req.params.id);
  if (index === -1) {
    res.status(404).json({ error: 'Categoría no encontrada' });
    return;
  }
  db.categories[index] = { ...db.categories[index], ...req.body, id: req.params.id };
  saveDatabase(db);
  res.json(db.categories[index]);
});

app.delete('/api/categories/:id', requireAuth, (req, res) => {
  const db = getDatabase();
  db.categories = db.categories.filter(c => c.id !== req.params.id);
  saveDatabase(db);
  res.json({ success: true });
});

// Banners Routes
app.get('/api/banners', (req, res) => {
  const db = getDatabase();
  const sorted = [...db.banners].sort((a, b) => a.order - b.order);
  res.json(sorted);
});

app.post('/api/banners', requireAuth, (req, res) => {
  const db = getDatabase();
  const newBanner: Banner = {
    ...req.body,
    id: req.body.id || `banner_${Date.now()}`,
    order: req.body.order || db.banners.length + 1,
    isActive: req.body.isActive !== undefined ? req.body.isActive : true
  };
  db.banners.push(newBanner);
  saveDatabase(db);
  res.status(201).json(newBanner);
});

app.put('/api/banners/:id', requireAuth, (req, res) => {
  const db = getDatabase();
  const index = db.banners.findIndex(b => b.id === req.params.id);
  if (index === -1) {
    res.status(404).json({ error: 'Banner no encontrado' });
    return;
  }
  db.banners[index] = { ...db.banners[index], ...req.body, id: req.params.id };
  saveDatabase(db);
  res.json(db.banners[index]);
});

app.delete('/api/banners/:id', requireAuth, (req, res) => {
  const db = getDatabase();
  db.banners = db.banners.filter(b => b.id !== req.params.id);
  saveDatabase(db);
  res.json({ success: true });
});

// Settings Routes
app.get('/api/settings', (req, res) => {
  const db = getDatabase();
  res.json(db.settings);
});

app.put('/api/settings', requireAuth, (req, res) => {
  const db = getDatabase();
  const incoming = req.body || {};
  db.settings = {
    ...db.settings,
    ...incoming,
    cushionFabrics: Array.isArray(incoming.cushionFabrics)
      ? incoming.cushionFabrics
      : (Array.isArray(db.settings.cushionFabrics) ? db.settings.cushionFabrics : [])
  };
  saveDatabase(db);
  res.json(db.settings);
});

// Reviews Routes
app.get('/api/reviews', (req, res) => {
  const db = getDatabase();
  const { productId, status } = req.query;
  let list = db.reviews || [];

  if (productId) {
    list = list.filter(r => r.productId === productId);
  }
  if (status) {
    list = list.filter(r => r.status === status);
  }

  // Sort newest first
  const sorted = [...list].sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  res.json(sorted);
});

app.post('/api/reviews', (req, res) => {
  const db = getDatabase();
  const { productId, userName, userEmail, rating, title, comment, isVerifiedBuyer, orderNumber } = req.body;

  if (!productId || !userName || !comment || !rating) {
    res.status(400).json({ error: 'Faltan campos obligatorios para la reseña' });
    return;
  }

  // Find product name if available
  const product = db.products.find(p => p.id === productId);

  const newReview: Review = {
    id: `rev_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
    productId,
    productName: product?.name || req.body.productName || 'Producto',
    userName: userName.trim(),
    userEmail: userEmail?.trim() || undefined,
    rating: Math.min(5, Math.max(1, Number(rating) || 5)),
    title: title?.trim() || undefined,
    comment: comment.trim(),
    isVerifiedBuyer: Boolean(isVerifiedBuyer || orderNumber),
    orderNumber: orderNumber?.trim() || undefined,
    status: 'approved', // Auto-approved or ready for moderation
    createdAt: new Date().toISOString(),
    helpfulCount: 0,
  };

  if (!db.reviews) db.reviews = [];
  db.reviews.unshift(newReview);

  // Recalculate product rating & review count
  if (product) {
    const productReviews = db.reviews.filter(r => r.productId === productId && r.status === 'approved');
    const totalScore = productReviews.reduce((sum, r) => sum + r.rating, 0);
    product.rating = productReviews.length > 0 ? Number((totalScore / productReviews.length).toFixed(1)) : 5.0;
    product.reviewCount = productReviews.length;
  }

  saveDatabase(db);
  res.status(201).json(newReview);
});

app.put('/api/reviews/:id', requireAuth, (req, res) => {
  const db = getDatabase();
  if (!db.reviews) db.reviews = [];
  const index = db.reviews.findIndex(r => r.id === req.params.id);
  if (index === -1) {
    res.status(404).json({ error: 'Reseña no encontrada' });
    return;
  }

  const existing = db.reviews[index];
  const updated: Review = {
    ...existing,
    ...req.body,
    id: req.params.id,
  };

  if (req.body.adminReply !== undefined) {
    updated.adminReply = req.body.adminReply;
    updated.adminRepliedAt = req.body.adminReply ? new Date().toISOString() : undefined;
  }

  db.reviews[index] = updated;

  // Recalculate product rating & review count
  const product = db.products.find(p => p.id === updated.productId);
  if (product) {
    const productReviews = db.reviews.filter(r => r.productId === updated.productId && r.status === 'approved');
    const totalScore = productReviews.reduce((sum, r) => sum + r.rating, 0);
    product.rating = productReviews.length > 0 ? Number((totalScore / productReviews.length).toFixed(1)) : undefined;
    product.reviewCount = productReviews.length;
  }

  saveDatabase(db);
  res.json(updated);
});

app.post('/api/reviews/:id/helpful', (req, res) => {
  const db = getDatabase();
  if (!db.reviews) db.reviews = [];
  const index = db.reviews.findIndex(r => r.id === req.params.id);
  if (index === -1) {
    res.status(404).json({ error: 'Reseña no encontrada' });
    return;
  }

  db.reviews[index].helpfulCount = (db.reviews[index].helpfulCount || 0) + 1;
  saveDatabase(db);
  res.json({ success: true, helpfulCount: db.reviews[index].helpfulCount });
});

app.delete('/api/reviews/:id', requireAuth, (req, res) => {
  const db = getDatabase();
  if (!db.reviews) db.reviews = [];
  const reviewToDelete = db.reviews.find(r => r.id === req.params.id);
  if (!reviewToDelete) {
    res.status(404).json({ error: 'Reseña no encontrada' });
    return;
  }

  db.reviews = db.reviews.filter(r => r.id !== req.params.id);

  // Recalculate product rating & review count
  const product = db.products.find(p => p.id === reviewToDelete.productId);
  if (product) {
    const productReviews = db.reviews.filter(r => r.productId === reviewToDelete.productId && r.status === 'approved');
    const totalScore = productReviews.reduce((sum, r) => sum + r.rating, 0);
    product.rating = productReviews.length > 0 ? Number((totalScore / productReviews.length).toFixed(1)) : undefined;
    product.reviewCount = productReviews.length;
  }

  saveDatabase(db);
  res.json({ success: true });
});

// Seed reset Route (Admin only)
app.post('/api/seed/reset', requireAuth, (req, res) => {
  const freshDb: DatabaseSchema = {
    products: INITIAL_PRODUCTS,
    categories: INITIAL_CATEGORIES,
    banners: INITIAL_BANNERS,
    settings: INITIAL_SETTINGS,
    reviews: INITIAL_REVIEWS,
    adminTokens: []
  };
  saveDatabase(freshDb);
  res.json({ success: true, message: 'Catálogo y reseñas restaurados a valores iniciales.' });
});

// Start Server with Vite
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Mecedoras app running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
