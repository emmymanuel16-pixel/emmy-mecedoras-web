# Auditoría integral aplicada

Cambios principales aplicados a esta versión:
- Eliminaciones de categorías y banners ahora tienen manejo de error visible y estado de guardado.
- Eliminaciones del configurador (colores, telas/texturas, accesorios) se persisten inmediatamente; ya no dependen de pulsar Guardar después.
- `persistSettings` propaga errores: una escritura fallida ya no continúa como si hubiera funcionado.
- Se añadió normalización central de errores Firebase (`src/utils/errorReporting.ts`) con mensajes para permisos, sesión, red, cuota y Storage.
- Se añadió `ErrorBoundary` global para errores de render no controlados.
- Se eliminó el fallback base64 para texturas del configurador.
- Firebase Storage conserva el error técnico original al fallar una subida.
- La eliminación en Firestore ocurre antes de limpiar archivos físicos, evitando dejar documentos vivos con imágenes borradas.
- Reglas de Storage requieren un administrador activo en `/admins/{uid}` para mutaciones.
- Se eliminó el bypass de superadministrador por correo de las reglas Firestore.
- `analytics_daily` deja de aceptar escritura pública indiscriminada.

## Configuración externa necesaria
Publicar `firestore.rules` y `storage.rules` en Firebase. El usuario administrador debe existir en Authentication y tener `/admins/{UID}` con `role: "admin"` y `active: true`.

## Validación
Se intentó instalar dependencias para ejecutar `npm run lint` y `npm run build`, pero `npm install` excedió el tiempo disponible del entorno y no llegó a instalar TypeScript. AI Studio debe ejecutar ambos comandos al importar el proyecto.
