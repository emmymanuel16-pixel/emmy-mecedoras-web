/** Centralized, user-facing error normalization. Never silently swallow a failed user action. */
export function getErrorMessage(error: unknown, fallback = 'Ocurrió un error inesperado.'): string {
  if (error instanceof Error && error.message) return error.message;
  if (typeof error === 'string' && error.trim()) return error;
  if (error && typeof error === 'object') {
    const e = error as Record<string, unknown>;
    if (typeof e.message === 'string' && e.message) return e.message;
    if (typeof e.code === 'string' && e.code) return e.code;
  }
  return fallback;
}

export function describeFirebaseError(error: unknown): string {
  const raw = getErrorMessage(error);
  const code = (error && typeof error === 'object' && 'code' in error) ? String((error as any).code) : '';
  const value = `${code} ${raw}`.toLowerCase();
  if (value.includes('permission-denied') || value.includes('storage/unauthorized')) return 'Permiso denegado por Firebase. Verifica que tu usuario esté autorizado como administrador y que las reglas estén publicadas.';
  if (value.includes('unauthenticated') || value.includes('auth/user-token-expired')) return 'Tu sesión de administrador no es válida o expiró. Cierra sesión e inicia nuevamente.';
  if (value.includes('network') || value.includes('unavailable') || value.includes('failed to fetch')) return 'No se pudo conectar con Firebase. Verifica tu conexión a internet e inténtalo nuevamente.';
  if (value.includes('object-not-found')) return 'El archivo solicitado ya no existe en Firebase Storage.';
  if (value.includes('quota')) return 'Firebase rechazó la operación por límite o cuota del servicio.';
  return raw;
}

export function notifyError(operation: string, error: unknown): void {
  const detail = describeFirebaseError(error);
  console.error(`[${operation}]`, error);
  window.alert(`${operation}\n\n${detail}`);
}

export function reportNonBlockingError(operation: string, error: unknown): void {
  const detail = describeFirebaseError(error);
  console.error(`[${operation}]`, error);
  window.alert(`${operation} principal se completó, pero ocurrió un problema secundario:\n\n${detail}`);
}
