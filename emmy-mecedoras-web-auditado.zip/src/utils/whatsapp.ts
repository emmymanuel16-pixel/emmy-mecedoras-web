import { CartItem, Product, ProductCustomization, StoreSettings } from '../types';

export function formatPrice(price: number, currency: string = '$'): string {
  return `${currency} ${price.toLocaleString('es-DO', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

export function cleanPhoneNumber(phone: string): string {
  return phone.replace(/[^\d]/g, '');
}

/**
 * Universal WhatsApp link builder that safely handles:
 * - Phone numbers (e.g. "18093194707", "+1 (809) 319-4707")
 * - Direct WhatsApp links (e.g. "https://wa.me/message/BJFMRANCLPBCN1")
 * - Short wa.me links
 */
export function formatWhatsAppLink(rawTarget: string | undefined, message: string): string {
  const target = (rawTarget || '18093194707').trim();
  const encodedText = encodeURIComponent(message);

  if (target.includes('wa.me/message/') || target.includes('chat.whatsapp.com')) {
    const separator = target.includes('?') ? '&' : '?';
    return `${target}${separator}text=${encodedText}`;
  }

  if (target.startsWith('http://') || target.startsWith('https://')) {
    const separator = target.includes('?') ? '&' : '?';
    return `${target}${separator}text=${encodedText}`;
  }

  const phone = cleanPhoneNumber(target) || '18093194707';
  return `https://wa.me/${phone}?text=${encodedText}`;
}

export function generateCartWhatsAppUrl(
  items: CartItem[],
  settings: StoreSettings,
  customerNotes?: string
): string {
  const phone = cleanPhoneNumber(settings.whatsapp || '18095551234');
  const currency = settings.currency || '$';
  
  const total = items.reduce((sum, item) => sum + item.unitPrice * item.quantity, 0);

  let message = `🪑 *PEDIDO DE CATÁLOGO - ${settings.storeName.toUpperCase()}*\n`;
  message += `Hola, quiero realizar el siguiente pedido:\n\n`;

  items.forEach((item, index) => {
    const isCushionOnly = item.product.categoryId === 'cojines' || item.product.productType === 'cojin';
    message += `*${index + 1}. ${item.product.name}*\n`;
    message += `   • *Cantidad:* ${item.quantity}\n`;
    message += `   • *Precio unitario:* ${formatPrice(item.unitPrice, currency)}\n`;
    
    if (item.customization) {
      const cust = item.customization;
      message += `   • 🎨 *Configuración Personalizada:*\n`;
      message += `     - Color mecedora: *${cust.rockerColor.name}* (${cust.rockerColor.finish || 'Fibra de vidrio'})\n`;
      if (cust.hasCushion && cust.fabric) {
        message += `     - Cojín/Tela: *${cust.fabric.name}* (${cust.fabric.type})\n`;
      } else {
        message += `     - Cojines: *Sin cojín* (solo estructura)\n`;
      }
      if (cust.selectedAccessories && cust.selectedAccessories.length > 0) {
        message += `     - Accesorios/Extras: ${cust.selectedAccessories.map(a => a.name).join(', ')}\n`;
      }
      if (cust.customFinish) {
        message += `     - Acabado: ${cust.customFinish}\n`;
      }
    } else {
      if (isCushionOnly) {
        if (item.selectedFabricType) {
          message += `   • *Tipo de tela:* ${item.selectedFabricType}\n`;
        }
        if (item.selectedPatternName) {
          message += `   • *Diseño Estampado:* ${item.selectedPatternName}\n`;
        } else if (item.selectedCushionColor) {
          message += `   • *Color del cojín:* ${item.selectedCushionColor}\n`;
        }
      } else {
        message += `   • *Material:* ${item.product.material || 'Fibra de vidrio'}\n`;
        if (item.selectedColor) {
          message += `   • *Color de mecedora:* ${item.selectedColor}\n`;
        }
        if (item.selectedFabricType) {
          message += `   • *Tela de cojín incluido:* ${item.selectedFabricType}\n`;
        }
        if (item.selectedPatternName) {
          message += `   • *Estampado de cojín:* ${item.selectedPatternName}\n`;
        } else if (item.selectedCushionColor) {
          message += `   • *Color de cojín incluido:* ${item.selectedCushionColor}\n`;
        }
      }
      if (item.selectedBorderColor) {
        message += `   • *Color de bordes/ribete:* ${item.selectedBorderColor}\n`;
      }
      if (item.selectedBackrestStyle) {
        message += `   • *Estilo de espaldar:* ${item.selectedBackrestStyle === 'botones' ? 'Capitoneado (Con Botones)' : 'Con Costura'}\n`;
      }
      if (item.selectedSize) {
        message += `   • *Tamaño/Medida:* ${item.selectedSize}\n`;
      }
      if (item.selectedFinish) {
        message += `   • *Acabado:* ${item.selectedFinish}\n`;
      }
    }

    if (item.product.includedItems && item.product.includedItems.length > 0) {
      message += `   • _Incluye:_ ${item.product.includedItems.join(', ')}\n`;
    }
    message += `   • *Subtotal:* ${formatPrice(item.unitPrice * item.quantity, currency)}\n\n`;
  });

  message += `━━━━━━━━━━━━━━━━━━━━━\n`;
  message += `💰 *TOTAL A PAGAR: ${formatPrice(total, currency)}*\n`;
  
  if (customerNotes && customerNotes.trim()) {
    message += `📝 *Notas del cliente:* ${customerNotes.trim()}\n`;
  }
  
  message += `\n¿Me podrían confirmar disponibilidad y tiempo de entrega por favor?`;

  return formatWhatsAppLink(settings.whatsapp, message);
}

export function generateCustomizedProductWhatsAppUrl(
  product: Product,
  customization: ProductCustomization,
  quantity: number,
  settings: StoreSettings,
  notes?: string
): string {
  const currency = settings.currency || '$';
  const total = customization.totalUnitPrice * quantity;

  let message = `🎨 *PEDIDO DE COJÍN PERSONALIZADO A MEDIDA*\n`;
  message += `*${settings.storeName.toUpperCase()}*\n\n`;
  message += `Hola, configuré mi cojín ergonómico artesanal en el personalizador visual y deseo ordenar:\n\n`;
  message += `*Artículo Base:* ${product.name}\n`;
  message += `*Cantidad:* ${quantity} unidad(es)\n\n`;
  
  message += `✨ *ESPECIFICACIONES DE CONFECCIÓN:*\n`;
  if (customization.mainFabric) {
    message += `• *Superficie Principal (Asiento/Respaldo):* ${customization.mainFabric.name} (${customization.mainFabric.hex})\n`;
  } else if (customization.fabric) {
    message += `• *Superficie Principal:* ${customization.fabric.name}\n`;
  }

  if (customization.trimColor) {
    message += `• *Borde, Vivo y Laterales:* ${customization.trimColor.name} (${customization.trimColor.hex})\n`;
  } else if (customization.rockerColor) {
    message += `• *Borde y Ribete:* ${customization.rockerColor.name}\n`;
  }

  if (customization.fabricType) {
    message += `• *Tipo de Tejido:* ${customization.fabricType.toUpperCase()}\n`;
  }
  
  if (customization.selectedAccessories && customization.selectedAccessories.length > 0) {
    message += `• *Tratamientos & Extras:*\n`;
    customization.selectedAccessories.forEach(acc => {
      message += `  - ${acc.name} (+${formatPrice(acc.price, currency)})\n`;
    });
  }

  if (notes && notes.trim()) {
    message += `• *Instrucciones especiales:* ${notes.trim()}\n`;
  }

  message += `\n━━━━━━━━━━━━━━━━━━━━━\n`;
  message += `💵 *Precio unitario:* ${formatPrice(customization.totalUnitPrice, currency)}\n`;
  message += `💰 *PRECIO TOTAL (${quantity} unid.): ${formatPrice(total, currency)}*\n\n`;
  message += `¿Podrían confirmarme tiempo estimado de confección y envío?`;

  return formatWhatsAppLink(settings.whatsapp, message);
}

export function generateSingleProductWhatsAppUrl(
  product: Product,
  settings: StoreSettings,
  options?: {
    quantity?: number;
    color?: string; // Rocker color (Blanco, Negro, Caoba)
    cushionColor?: string; // Cushion color
    borderColor?: string; // Border color
    backrestStyle?: 'costura' | 'botones' | string; // 'costura' | 'botones'
    fabricType?: string; // Fabric type
    fabricPriceDiff?: number;
    patternName?: string; // Pattern design name
    patternImage?: string;
    finish?: string;
    upholstery?: string;
    size?: string;
    customization?: ProductCustomization;
  }
): string {
  if (options?.customization) {
    return generateCustomizedProductWhatsAppUrl(
      product,
      options.customization,
      options.quantity || 1,
      settings
    );
  }

  const currency = settings.currency || '$';
  const qty = options?.quantity || 1;
  const isCushionOnly = product.categoryId === 'cojines' || product.productType === 'cojin';
  const unitPrice = product.price + (options?.fabricPriceDiff || 0);
  const totalPrice = unitPrice * qty;

  let message = `🪑 *CONSULTA DIRECTA - ${settings.storeName.toUpperCase()}*\n`;
  message += `Hola, me interesa ordenar el siguiente artículo:\n\n`;
  message += `*Producto:* ${product.name}\n`;
  message += `*Categoría:* ${product.categoryId.replace('-', ' ').toUpperCase()}\n`;
  if (!isCushionOnly) {
    message += `*Material de fabricación:* ${product.material || 'Fibra de vidrio'}\n`;
  }
  message += `*Cantidad:* ${qty}\n`;
  message += `*Precio:* ${formatPrice(totalPrice, currency)}\n`;

  if (isCushionOnly) {
    if (options?.fabricType) {
      message += `*Tipo de tela:* ${options.fabricType}\n`;
    }
    if (options?.patternName) {
      message += `*Diseño de Estampado:* ${options.patternName}\n`;
    } else if (options?.cushionColor) {
      message += `*Color del cojín:* ${options.cushionColor}\n`;
    }
  } else {
    if (options?.color) {
      message += `*Color de mecedora:* ${options.color}\n`;
    }
    if (options?.fabricType) {
      message += `*Tela de cojín incluido:* ${options.fabricType}\n`;
    }
    if (options?.patternName) {
      message += `*Diseño de Estampado:* ${options.patternName}\n`;
    } else if (options?.cushionColor) {
      message += `*Color de cojín incluido:* ${options.cushionColor}\n`;
    }
  }

  if (options?.borderColor) {
    message += `*Color de bordes/ribete:* ${options.borderColor}\n`;
  }
  if (options?.backrestStyle) {
    message += `*Estilo de espaldar:* ${options.backrestStyle === 'botones' ? 'Capitoneado (Con Botones)' : 'Con Costura'}\n`;
  }

  if (options?.finish) {
    message += `*Acabado:* ${options.finish}\n`;
  }
  if (options?.size) {
    message += `*Tamaño:* ${options.size}\n`;
  }
  if (product.includedItems && product.includedItems.length > 0) {
    message += `*Contenido del juego:* ${product.includedItems.join(', ')}\n`;
  }

  message += `\n¿Tienen disponibilidad para entrega o fabricación inmediata?`;

  return formatWhatsAppLink(settings.whatsapp, message);
}

export function generateSupportWhatsAppUrl(settings: StoreSettings): string {
  const message = `Hola, me comunico desde el catálogo web de *${settings.storeName}*. Quisiera información sobre sus mecedoras en fibra de vidrio y juegos de sala.`;
  return formatWhatsAppLink(settings.whatsapp, message);
}
