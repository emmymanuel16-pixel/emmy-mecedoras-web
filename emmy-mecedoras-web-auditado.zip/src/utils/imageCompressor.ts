import { uploadToFirebaseStorage, deleteFromFirebaseStorage, isFirebaseStorageUrl } from '../services/firebaseStorageService';

/**
 * Image compression utility to optimize user uploads for web viewing,
 * instant Firestore persistence (under 1MB limit per document), and smooth rendering.
 */

export interface CompressionOptions {
  maxWidth?: number;
  maxHeight?: number;
  quality?: number;
  mimeType?: 'image/jpeg' | 'image/webp' | 'image/png';
}

const DEFAULT_OPTIONS: CompressionOptions = {
  maxWidth: 800,
  maxHeight: 800,
  quality: 0.68,
  mimeType: 'image/jpeg',
};

/**
 * Compresses a single File or Blob object into an optimized base64 data URL string.
 */
export async function compressImageFile(
  file: File | Blob,
  options: CompressionOptions = {}
): Promise<string> {
  const opts = { ...DEFAULT_OPTIONS, ...options };

  return new Promise((resolve, reject) => {
    // If it's an SVG, we don't compress with canvas
    if (file.type === 'image/svg+xml') {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = (e) => reject(e);
      reader.readAsDataURL(file);
      return;
    }

    const reader = new FileReader();
    reader.onerror = (err) => reject(new Error('Error al leer el archivo de imagen: ' + err));

    reader.onload = (readerEvent) => {
      const img = new Image();
      img.onerror = () => reject(new Error('No se pudo cargar la imagen para compresión'));
      
      img.onload = () => {
        try {
          let { width, height } = img;
          const maxW = opts.maxWidth || 1200;
          const maxH = opts.maxHeight || 1200;

          // Calculate new dimensions while preserving aspect ratio
          if (width > maxW || height > maxH) {
            const ratio = Math.min(maxW / width, maxH / height);
            width = Math.round(width * ratio);
            height = Math.round(height * ratio);
          }

          const canvas = document.createElement('canvas');
          canvas.width = width;
          canvas.height = height;

          const ctx = canvas.getContext('2d', { alpha: true });
          if (!ctx) {
            resolve(readerEvent.target?.result as string);
            return;
          }

          ctx.imageSmoothingEnabled = true;
          ctx.imageSmoothingQuality = 'high';

          if (opts.mimeType === 'image/jpeg') {
            ctx.fillStyle = '#FFFFFF';
            ctx.fillRect(0, 0, width, height);
          }

          ctx.drawImage(img, 0, 0, width, height);

          const compressedDataUrl = canvas.toDataURL(opts.mimeType, opts.quality);
          resolve(compressedDataUrl);
        } catch (e) {
          console.warn('Canvas compression error, using original:', e);
          resolve(readerEvent.target?.result as string);
        }
      };

      img.src = readerEvent.target?.result as string;
    };

    reader.readAsDataURL(file);
  });
}

/**
 * Compresses multiple image files in concurrent batches with progress updates.
 * Yields periodically to keep the browser UI responsive even with 30+ photos.
 */
export async function compressMultipleImageFiles(
  files: File[] | FileList,
  options: CompressionOptions = {},
  onProgress?: (processed: number, total: number, currentFileName: string) => void
): Promise<string[]> {
  const fileArray = Array.from(files);
  const total = fileArray.length;
  const results: string[] = [];
  const BATCH_SIZE = 3;

  let processedCount = 0;

  for (let i = 0; i < total; i += BATCH_SIZE) {
    const chunk = fileArray.slice(i, i + BATCH_SIZE);
    
    const chunkPromises = chunk.map(async (file) => {
      try {
        const compressed = await compressImageFile(file, options);
        processedCount++;
        if (onProgress) {
          onProgress(processedCount, total, file.name);
        }
        return compressed;
      } catch (err) {
        console.error(`Error optimizando imagen ${file.name}:`, err);
        processedCount++;
        if (onProgress) {
          onProgress(processedCount, total, file.name);
        }
        return null;
      }
    });

    const chunkResults = await Promise.all(chunkPromises);
    chunkResults.forEach((res) => {
      if (res) results.push(res);
    });

    // Small yield to let React render progress updates and prevent UI freeze
    await new Promise((resolve) => setTimeout(resolve, 15));
  }

  return results;
}

/**
 * Validates file format and size limits before processing.
 */
export function validateImageFile(file: File): { valid: boolean; error?: string } {
  const ALLOWED_TYPES = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp'];
  const MAX_SIZE = 8 * 1024 * 1024; // 8 MB

  const fileType = (file.type || '').toLowerCase();
  const fileName = (file.name || '').toLowerCase();

  const isAllowedType = ALLOWED_TYPES.includes(fileType) || fileName.match(/\.(jpe?g|png|webp)$/i);
  if (!isAllowedType) {
    return {
      valid: false,
      error: `El archivo "${file.name}" no es una imagen válida. Formatos admitidos: JPEG, PNG y WEBP.`
    };
  }

  if (file.size > MAX_SIZE) {
    const sizeMb = (file.size / (1024 * 1024)).toFixed(1);
    return {
      valid: false,
      error: `El archivo "${file.name}" supera el tamaño máximo permitido de 8 MB (${sizeMb} MB).`
    };
  }

  return { valid: true };
}

/**
 * Compresses an existing base64 string to tiny dimensions (< 30 KB) as an emergency fallback
 * to guarantee that Firestore's 1MB limit is never breached.
 */
export async function compressBase64String(
  base64: string,
  maxWidth = 600,
  quality = 0.55
): Promise<string> {
  if (!base64 || typeof base64 !== 'string' || !base64.startsWith('data:image/')) return base64;
  return new Promise((resolve) => {
    try {
      const img = new Image();
      img.onload = () => {
        try {
          let { width, height } = img;
          if (width > maxWidth || height > maxWidth) {
            const ratio = Math.min(maxWidth / width, maxWidth / height);
            width = Math.round(width * ratio);
            height = Math.round(height * ratio);
          }
          const canvas = document.createElement('canvas');
          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext('2d');
          if (!ctx) return resolve(base64);
          ctx.fillStyle = '#FFFFFF';
          ctx.fillRect(0, 0, width, height);
          ctx.drawImage(img, 0, 0, width, height);
          resolve(canvas.toDataURL('image/jpeg', quality));
        } catch {
          resolve(base64);
        }
      };
      img.onerror = () => resolve(base64);
      img.src = base64;
    } catch {
      resolve(base64);
    }
  });
}

/**
 * Uploads compressed images directly to Firebase Cloud Storage.
 * Firebase Storage is the mandatory source of truth for all catalog photographs.
 * If Firebase Storage upload fails, the operation is stopped and NO base64 fallback is used.
 */
export async function uploadImagesToServer(
  images: string[],
  onProgress?: (uploaded: number, total: number) => void
): Promise<string[]> {
  if (!images || images.length === 0) return [];
  const total = images.length;
  const finalUrls: string[] = [];

  for (let i = 0; i < total; i++) {
    const img = images[i];
    
    // If not a base64 string, it's already an external or permanent Storage URL
    if (!img || typeof img !== 'string' || !img.startsWith('data:image/')) {
      finalUrls.push(img);
      if (onProgress) onProgress(i + 1, total);
      continue;
    }

    // Direct Firebase Cloud Storage upload (Mandatory: No base64 fallback)
    try {
      const uploadedUrl = await uploadToFirebaseStorage(img, 'productos');
      finalUrls.push(uploadedUrl);
    } catch (fbErr: any) {
      console.error('Error subiendo imagen a Firebase Storage:', fbErr);
      throw new Error('No se pudo guardar la imagen en Firebase Storage. Inténtalo nuevamente.');
    }

    if (onProgress) onProgress(i + 1, total);
  }

  return finalUrls;
}

/**
 * Deletes physical image file from Firebase Storage (or server fallback) when removed from product gallery.
 */
export async function deleteUploadedImageFromServer(url: string): Promise<boolean> {
  if (!url || typeof url !== 'string') {
    return false;
  }

  // 1. Primary: If image is in Firebase Cloud Storage, delete it from storage bucket
  if (isFirebaseStorageUrl(url)) {
    return await deleteFromFirebaseStorage(url);
  }

  // 2. Legacy server upload cleanup
  if (url.startsWith('/uploads/productos/')) {
    const token = typeof window !== 'undefined' ? localStorage.getItem('mecedoras_admin_token') : null;
    try {
      const headers: Record<string, string> = { 'Content-Type': 'application/json' };
      if (token) headers['Authorization'] = `Bearer ${token}`;
      const res = await fetch('/api/upload/delete-image', {
        method: 'POST',
        headers,
        body: JSON.stringify({ url })
      });
      return res.ok;
    } catch {
      return false;
    }
  }

  return false;
}
