import { jsPDF } from 'jspdf';
import { Category, Product, StoreSettings } from '../types';
import { formatPrice } from './whatsapp';

/**
 * Loads an image from a URL and converts it to a base64 Data URL (JPEG)
 * with timeout, CORS proxy fallback, and canvas compression to ensure smooth PDF rendering.
 */
async function getBase64ImageFromUrl(url: string, timeoutMs: number = 5000): Promise<string | null> {
  if (!url || typeof url !== 'string' || !url.trim()) return null;

  return new Promise((resolve) => {
    const timer = setTimeout(() => {
      resolve(null);
    }, timeoutMs);

    const img = new Image();
    img.crossOrigin = 'Anonymous';

    img.onload = () => {
      clearTimeout(timer);
      try {
        const canvas = document.createElement('canvas');
        const maxDimension = 800; // Optimal for PDF print resolution and file size
        let width = img.naturalWidth || img.width;
        let height = img.naturalHeight || img.height;

        if (width > maxDimension || height > maxDimension) {
          if (width > height) {
            height = Math.round((height * maxDimension) / width);
            width = maxDimension;
          } else {
            width = Math.round((width * maxDimension) / height);
            height = maxDimension;
          }
        }

        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          resolve(null);
          return;
        }

        // Draw white background in case of PNG transparency
        ctx.fillStyle = '#FFFFFF';
        ctx.fillRect(0, 0, width, height);
        ctx.drawImage(img, 0, 0, width, height);

        const dataUrl = canvas.toDataURL('image/jpeg', 0.85);
        resolve(dataUrl);
      } catch (err) {
        console.warn('Canvas export failed for PDF image:', url, err);
        resolve(null);
      }
    };

    img.onerror = () => {
      clearTimeout(timer);
      resolve(null);
    };

    img.src = url;
  });
}

export interface PDFGenerationProgress {
  step: string;
  percentage: number;
}

/**
 * Generates and downloads a complete, highly structured catalog PDF:
 * 1. Cover page with store branding, contact info, and catalog summary.
 * 2. Categories in inventory order.
 * 3. Each category starts with a general category description and cover photos of all its models.
 * 4. Subsequent pages display additional photos with clear model badge identification.
 * 5. Clean footer on every page with page numbering and WhatsApp contact.
 */
export async function generateCatalogPDF(
  products: Product[],
  categories: Category[],
  settings: StoreSettings,
  onProgress?: (progress: PDFGenerationProgress) => void
): Promise<void> {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const pageWidth = 210;
  const pageHeight = 297;
  const margin = 14;
  const contentWidth = pageWidth - margin * 2;

  const activeCategories = [...categories]
    .filter((c) => c.isActive !== false)
    .sort((a, b) => (a.order ?? 0) - (b.order ?? 0));

  const activeProducts = products.filter((p) => p.isActive !== false);

  // Group products by category
  const productsByCategory: Record<string, Product[]> = {};
  activeCategories.forEach((cat) => {
    productsByCategory[cat.id] = activeProducts.filter((p) => p.categoryId === cat.id);
  });

  onProgress?.({ step: 'Iniciando generación de catálogo...', percentage: 5 });

  // --------------------------------------------------------------------------
  // 1. COVER PAGE
  // --------------------------------------------------------------------------
  doc.setFillColor(44, 24, 16); // #2C1810 Warm dark mahogany
  doc.rect(0, 0, pageWidth, pageHeight, 'F');

  // Decorative border
  doc.setDrawColor(212, 175, 55); // #D4AF37 Gold
  doc.setLineWidth(0.8);
  doc.rect(margin, margin, contentWidth, pageHeight - margin * 2);

  doc.setDrawColor(138, 83, 43); // #8A532B Accent line
  doc.setLineWidth(0.3);
  doc.rect(margin + 2, margin + 2, contentWidth - 4, pageHeight - margin * 2 - 4);

  // Cover Content
  let coverY = 60;

  // Small Top Tag
  doc.setTextColor(212, 175, 55);
  doc.setFontSize(11);
  doc.setFont('helvetica', 'bold');
  doc.text('CATÁLOGO OFICIAL & COLECCIÓN EXCLUSIVA', pageWidth / 2, coverY, { align: 'center' });

  coverY += 16;
  // Brand Name
  doc.setTextColor(253, 252, 251);
  doc.setFontSize(28);
  doc.setFont('helvetica', 'bold');
  const storeTitle = (settings.storeName || 'EMMY MECEDORAS').toUpperCase();
  doc.text(storeTitle, pageWidth / 2, coverY, { align: 'center' });

  coverY += 12;
  // Subtitle / Tagline
  doc.setTextColor(200, 185, 170);
  doc.setFontSize(12);
  doc.setFont('helvetica', 'normal');
  const tagline = settings.tagline || 'Mecedoras en Fibra de Vidrio de Alta Resistencia & Muebles Exclusivos';
  const splitTagline = doc.splitTextToSize(tagline, contentWidth - 20);
  doc.text(splitTagline, pageWidth / 2, coverY, { align: 'center' });

  // Decorative Golden Line
  coverY += splitTagline.length * 6 + 14;
  doc.setDrawColor(212, 175, 55);
  doc.setLineWidth(0.6);
  doc.line(pageWidth / 2 - 30, coverY, pageWidth / 2 + 30, coverY);

  // Summary Box in Cover
  coverY += 24;
  doc.setFillColor(58, 35, 25);
  doc.roundedRect(pageWidth / 2 - 65, coverY, 130, 48, 4, 4, 'F');
  doc.setDrawColor(212, 175, 55);
  doc.setLineWidth(0.3);
  doc.roundedRect(pageWidth / 2 - 65, coverY, 130, 48, 4, 4, 'S');

  doc.setTextColor(253, 252, 251);
  doc.setFontSize(10);
  doc.setFont('helvetica', 'bold');
  doc.text('RESUMEN DEL CATÁLOGO', pageWidth / 2, coverY + 10, { align: 'center' });

  doc.setFontSize(9);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(220, 210, 200);
  doc.text(`• Total de Modelos: ${activeProducts.length} productos`, pageWidth / 2 - 50, coverY + 20);
  doc.text(`• Categorías: ${activeCategories.length} colecciones`, pageWidth / 2 - 50, coverY + 28);
  doc.text(`• Material: Fibra de vidrio de alta resistencia & cojinería`, pageWidth / 2 - 50, coverY + 36);

  // Contact Footer on Cover
  const coverFooterY = pageHeight - margin - 25;
  doc.setTextColor(212, 175, 55);
  doc.setFontSize(10);
  doc.setFont('helvetica', 'bold');
  doc.text('PEDIDOS & ATENCIÓN DIRECTA POR WHATSAPP', pageWidth / 2, coverFooterY, { align: 'center' });

  doc.setTextColor(253, 252, 251);
  doc.setFontSize(11);
  doc.text(`WhatsApp: ${settings.contactInformation?.phone || settings.whatsapp || ''}`, pageWidth / 2, coverFooterY + 7, { align: 'center' });

  doc.setTextColor(180, 165, 150);
  doc.setFontSize(8);
  doc.text(
    `Generado: ${new Date().toLocaleDateString('es-DO', { year: 'numeric', month: 'long', day: 'numeric' })}`,
    pageWidth / 2,
    coverFooterY + 14,
    { align: 'center' }
  );

  // Helper function to draw page header & footer
  const drawPageLayout = (pageTitle: string, currentPg: number) => {
    // Top Bar
    doc.setFillColor(44, 24, 16);
    doc.rect(0, 0, pageWidth, 16, 'F');

    doc.setTextColor(253, 252, 251);
    doc.setFontSize(10);
    doc.setFont('helvetica', 'bold');
    doc.text(settings.storeName.toUpperCase(), margin, 11);

    doc.setTextColor(212, 175, 55);
    doc.setFontSize(9);
    doc.text(pageTitle.toUpperCase(), pageWidth - margin, 11, { align: 'right' });

    // Bottom Bar
    doc.setFillColor(250, 248, 245);
    doc.rect(0, pageHeight - 12, pageWidth, 12, 'F');
    doc.setDrawColor(230, 220, 210);
    doc.setLineWidth(0.3);
    doc.line(0, pageHeight - 12, pageWidth, pageHeight - 12);

    doc.setTextColor(120, 100, 90);
    doc.setFontSize(8);
    doc.setFont('helvetica', 'normal');
    doc.text(`WhatsApp: ${settings.contactInformation?.phone || settings.whatsapp || ''}`, margin, pageHeight - 4.5);

    doc.text(`Página ${currentPg}`, pageWidth - margin, pageHeight - 4.5, { align: 'right' });
  };

  let currentPageNumber = 1;
  const totalCategories = activeCategories.length;

  // Iterate categories
  for (let cIdx = 0; cIdx < totalCategories; cIdx++) {
    const category = activeCategories[cIdx];
    const catProducts = productsByCategory[category.id] || [];

    if (catProducts.length === 0) continue;

    const progressPct = 10 + Math.round(((cIdx + 1) / totalCategories) * 85);
    onProgress?.({
      step: `Procesando categoría: ${category.name}...`,
      percentage: progressPct,
    });

    // ------------------------------------------------------------------------
    // A. CATEGORY OVERVIEW & MAIN MODEL COVERS
    // ------------------------------------------------------------------------
    doc.addPage();
    currentPageNumber++;
    drawPageLayout(category.name, currentPageNumber);

    let currentY = 24;

    // Category Title Banner
    doc.setFillColor(245, 240, 235);
    doc.roundedRect(margin, currentY, contentWidth, 22, 3, 3, 'F');
    doc.setDrawColor(212, 175, 55);
    doc.setLineWidth(0.4);
    doc.roundedRect(margin, currentY, contentWidth, 22, 3, 3, 'S');

    doc.setTextColor(44, 24, 16);
    doc.setFontSize(14);
    doc.setFont('helvetica', 'bold');
    doc.text(category.name, margin + 5, currentY + 8);

    doc.setTextColor(110, 90, 80);
    doc.setFontSize(8.5);
    doc.setFont('helvetica', 'normal');
    const catDesc = category.description || 'Modelos fabricados en fibra de vidrio de alta resistencia con acabados y cojinería de primera calidad.';
    const splitDesc = doc.splitTextToSize(catDesc, contentWidth - 10);
    doc.text(splitDesc.slice(0, 2), margin + 5, currentY + 15);

    currentY += 28;

    // Models Grid (2 columns per row)
    const cardWidth = (contentWidth - 6) / 2; // ~88mm
    const cardHeight = 72; // Height for product cover card

    for (let pIdx = 0; pIdx < catProducts.length; pIdx++) {
      const prod = catProducts[pIdx];
      const col = pIdx % 2;
      const isNewRow = col === 0 && pIdx > 0;

      if (isNewRow) {
        currentY += cardHeight + 5;
      }

      // Check if card fits on current page (allow room for footer)
      if (currentY + cardHeight > pageHeight - 16) {
        doc.addPage();
        currentPageNumber++;
        drawPageLayout(category.name, currentPageNumber);
        currentY = 24;
      }

      const cardX = margin + col * (cardWidth + 6);

      // Card Background
      doc.setFillColor(255, 255, 255);
      doc.roundedRect(cardX, currentY, cardWidth, cardHeight, 2.5, 2.5, 'F');
      doc.setDrawColor(225, 218, 210);
      doc.setLineWidth(0.3);
      doc.roundedRect(cardX, currentY, cardWidth, cardHeight, 2.5, 2.5, 'S');

      // Product Cover Image
      const coverUrl = prod.images && prod.images.length > 0 ? prod.images[0] : '';
      const imgWidth = cardWidth - 6;
      const imgHeight = 42;
      const imgX = cardX + 3;
      const imgY = currentY + 3;

      if (coverUrl) {
        try {
          const base64 = await getBase64ImageFromUrl(coverUrl);
          if (base64) {
            doc.addImage(base64, 'JPEG', imgX, imgY, imgWidth, imgHeight, undefined, 'FAST');
          } else {
            // Fallback placeholder
            doc.setFillColor(240, 235, 230);
            doc.rect(imgX, imgY, imgWidth, imgHeight, 'F');
            doc.setTextColor(140, 120, 110);
            doc.setFontSize(8);
            doc.text('Foto de Modelo', imgX + imgWidth / 2, imgY + imgHeight / 2, { align: 'center' });
          }
        } catch {
          doc.setFillColor(240, 235, 230);
          doc.rect(imgX, imgY, imgWidth, imgHeight, 'F');
        }
      } else {
        doc.setFillColor(240, 235, 230);
        doc.rect(imgX, imgY, imgWidth, imgHeight, 'F');
      }

      // Model Name
      doc.setTextColor(44, 24, 16);
      doc.setFontSize(9.5);
      doc.setFont('helvetica', 'bold');
      const prodName = prod.name.length > 32 ? prod.name.substring(0, 30) + '...' : prod.name;
      doc.text(prodName, cardX + 3, currentY + 50);

      // Price & Badge
      doc.setTextColor(138, 83, 43);
      doc.setFontSize(10);
      doc.setFont('helvetica', 'bold');
      doc.text(formatPrice(prod.price, settings.currency), cardX + 3, currentY + 57);

      if (prod.isOffer && prod.previousPrice) {
        doc.setTextColor(150, 140, 130);
        doc.setFontSize(7.5);
        doc.setFont('helvetica', 'normal');
        doc.text(`Antes: ${formatPrice(prod.previousPrice, settings.currency)}`, cardX + 38, currentY + 57);
      }

      // Material / Details line
      doc.setTextColor(100, 90, 85);
      doc.setFontSize(7);
      doc.setFont('helvetica', 'normal');
      const matInfo = prod.material || 'Fibra de vidrio de alta resistencia';
      const colorsCount = prod.colors ? prod.colors.length : 3;
      doc.text(`${matInfo} • ${colorsCount} colores disponibles`, cardX + 3, currentY + 64);

      if (prod.images && prod.images.length > 1) {
        doc.setTextColor(138, 83, 43);
        doc.setFontSize(6.5);
        doc.setFont('helvetica', 'bold');
        doc.text(`+${prod.images.length - 1} fotos adicionales`, cardX + cardWidth - 3, currentY + 68, { align: 'right' });
      }
    }

    // ------------------------------------------------------------------------
    // B. ADDITIONAL GALLERY PHOTOS OF THIS CATEGORY (with Model identification)
    // ------------------------------------------------------------------------
    // Collect all additional photos
    const additionalPhotos: Array<{
      productName: string;
      productId: string;
      imageUrl: string;
      photoIndex: number;
      totalPhotos: number;
      price: number;
    }> = [];

    catProducts.forEach((p) => {
      if (p.images && p.images.length > 1) {
        p.images.slice(1).forEach((imgUrl, idx) => {
          additionalPhotos.push({
            productName: p.name,
            productId: p.id,
            imageUrl: imgUrl,
            photoIndex: idx + 2,
            totalPhotos: p.images.length,
            price: p.price,
          });
        });
      }
    });

    if (additionalPhotos.length > 0) {
      doc.addPage();
      currentPageNumber++;
      drawPageLayout(`${category.name} - Galería de Fotografías`, currentPageNumber);

      let galleryY = 24;

      // Gallery Subheader
      doc.setFillColor(245, 240, 235);
      doc.roundedRect(margin, galleryY, contentWidth, 14, 2.5, 2.5, 'F');
      doc.setTextColor(44, 24, 16);
      doc.setFontSize(10);
      doc.setFont('helvetica', 'bold');
      doc.text(`Fotografías Adicionales de la Colección: ${category.name}`, margin + 4, galleryY + 6);
      doc.setTextColor(120, 100, 90);
      doc.setFontSize(7.5);
      doc.setFont('helvetica', 'normal');
      doc.text('Detalles en diferentes ángulos, acabados y combinaciones de cojines.', margin + 4, galleryY + 11);

      galleryY += 19;

      // 4 photos per page grid (2 columns x 2 rows)
      const gCardWidth = (contentWidth - 6) / 2; // ~88mm
      const gCardHeight = 110; // High quality large photo preview

      for (let gIdx = 0; gIdx < additionalPhotos.length; gIdx++) {
        const item = additionalPhotos[gIdx];
        const col = gIdx % 2;
        const isNewRow = col === 0 && gIdx > 0;

        if (isNewRow) {
          galleryY += gCardHeight + 6;
        }

        if (galleryY + gCardHeight > pageHeight - 16) {
          doc.addPage();
          currentPageNumber++;
          drawPageLayout(`${category.name} - Galería (Cont.)`, currentPageNumber);
          galleryY = 24;
        }

        const gX = margin + col * (gCardWidth + 6);

        // Photo Card Container
        doc.setFillColor(255, 255, 255);
        doc.roundedRect(gX, galleryY, gCardWidth, gCardHeight, 3, 3, 'F');
        doc.setDrawColor(220, 212, 204);
        doc.setLineWidth(0.3);
        doc.roundedRect(gX, galleryY, gCardWidth, gCardHeight, 3, 3, 'S');

        // Image
        const gImgWidth = gCardWidth - 4;
        const gImgHeight = 88;
        const gImgX = gX + 2;
        const gImgY = galleryY + 2;

        try {
          const b64 = await getBase64ImageFromUrl(item.imageUrl);
          if (b64) {
            doc.addImage(b64, 'JPEG', gImgX, gImgY, gImgWidth, gImgHeight, undefined, 'FAST');
          } else {
            doc.setFillColor(240, 235, 230);
            doc.rect(gImgX, gImgY, gImgWidth, gImgHeight, 'F');
          }
        } catch {
          doc.setFillColor(240, 235, 230);
          doc.rect(gImgX, gImgY, gImgWidth, gImgHeight, 'F');
        }

        // Model Badge & Identification
        doc.setFillColor(44, 24, 16);
        doc.roundedRect(gX + 2, galleryY + 92, gCardWidth - 4, 15, 2, 2, 'F');

        doc.setTextColor(212, 175, 55);
        doc.setFontSize(7);
        doc.setFont('helvetica', 'bold');
        doc.text(`MODELO: ${item.productName.toUpperCase()}`, gX + 5, galleryY + 97);

        doc.setTextColor(253, 252, 251);
        doc.setFontSize(6.5);
        doc.setFont('helvetica', 'normal');
        doc.text(
          `Foto ${item.photoIndex} de ${item.totalPhotos} • Precio: ${formatPrice(item.price, settings.currency)}`,
          gX + 5,
          galleryY + 103
        );
      }
    }
  }

  onProgress?.({ step: 'Finalizando documento...', percentage: 98 });

  // Save the PDF
  const cleanName = (settings.storeName || 'Catalogo_Mecedoras')
    .replace(/[^a-zA-Z0-9]/g, '_')
    .toLowerCase();
  const dateStr = new Date().toISOString().split('T')[0];
  const filename = `${cleanName}_catalogo_${dateStr}.pdf`;

  doc.save(filename);
  onProgress?.({ step: '¡Catálogo descargado con éxito!', percentage: 100 });
}
