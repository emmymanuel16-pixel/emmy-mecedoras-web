import React, { useState, useEffect, useCallback, useMemo, Suspense } from 'react';
import { Banner, CartItem, CatalogFilterState, Category, Product, Review, StoreSettings } from './types';
import { api } from './services/api';
import { FirebaseService } from './services/firebaseService';
import { Header } from './components/Header';
import { HeroCarousel } from './components/HeroCarousel';
import { CategoryChips } from './components/CategoryChips';
import { CategoryCarouselSection } from './components/CategoryCarouselSection';
import { ProductCard } from './components/ProductCard';
import { ProductFilters } from './components/ProductFilters';
import { WhatsAppFloatingButton } from './components/WhatsAppFloatingButton';
import { Footer } from './components/Footer';
import { INITIAL_BANNERS, INITIAL_CATEGORIES, INITIAL_SETTINGS, INITIAL_REVIEWS } from './data/initialData';
import { Sparkles, Tag, Layers, ArrowLeft, SlidersHorizontal, Grid, RotateCcw, Loader2 } from 'lucide-react';

// Lazy loaded heavy modals and drawers for faster initial page load
const ProductDetailModal = React.lazy(() => import('./components/ProductDetailModal').then(m => ({ default: m.ProductDetailModal })));
const CartDrawer = React.lazy(() => import('./components/CartDrawer').then(m => ({ default: m.CartDrawer })));
const AdminDashboard = React.lazy(() => import('./components/admin/AdminDashboard').then(m => ({ default: m.AdminDashboard })));

const DEFAULT_FILTERS: CatalogFilterState = {
  categoryId: 'all',
  rockerColors: [],
  materials: [],
  cushionColors: [],
  cushionStyles: [],
  priceRange: [0, 100000],
  minRating: 0,
  onlyOffers: false,
  onlyInStock: false,
  sortBy: 'featured',
};

export default function App() {
  // App Data State: Firebase Firestore is the absolute source of truth
  // Products initialize to [] - an empty catalog is a completely valid state
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>(INITIAL_CATEGORIES);
  const [banners, setBanners] = useState<Banner[]>(INITIAL_BANNERS);
  const [settings, setSettings] = useState<StoreSettings>(INITIAL_SETTINGS);
  const [reviews, setReviews] = useState<Review[]>(INITIAL_REVIEWS);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  // Navigation & Filtering State
  const [filters, setFilters] = useState<CatalogFilterState>(DEFAULT_FILTERS);
  const [isMobileFilterOpen, setIsMobileFilterOpen] = useState<boolean>(false);
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Modals & Drawers State
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [isCartOpen, setIsCartOpen] = useState<boolean>(false);
  const [isAdminOpen, setIsAdminOpen] = useState<boolean>(false);

  // Cart State with LocalStorage Persistence
  const [cartItems, setCartItems] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem('mecedoras_cart');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Save Cart to LocalStorage
  useEffect(() => {
    try {
      localStorage.setItem('mecedoras_cart', JSON.stringify(cartItems));
    } catch (e) {
      console.warn('Could not save cart:', e);
    }
  }, [cartItems]);

  // Load all data with strict sequence:
  // 1. Check bootstrap marker (seed ONLY on fresh installation)
  // 2. Fetch authoritative snapshot from Firebase Firestore
  // 3. Update application state
  const loadData = useCallback(async () => {
    setIsLoading(true);
    try {
      // 1. First-time system check: only seeds if store_meta/bootstrap does NOT exist and collections are empty
      await FirebaseService.seedInitialDataIfEmpty();

      // 2. Fetch authoritative snapshot from Firebase Firestore (Source of Truth)
      const [prodsData, catsData, bansData, setsData, revsData] = await Promise.all([
        api.getProducts(),
        api.getCategories(),
        api.getBanners(),
        api.getSettings(),
        api.getReviews(),
      ]);

      // Array.isArray check: Even if data is empty [], we set it! An empty section is completely valid.
      if (Array.isArray(prodsData)) {
        setProducts(prodsData);
      }
      if (Array.isArray(catsData)) {
        const sortedCats = [...catsData].sort((a, b) => (a.order ?? 0) - (b.order ?? 0));
        setCategories(sortedCats);
      }
      if (Array.isArray(bansData)) {
        setBanners(bansData);
      }
      if (setsData) setSettings(setsData);
      if (Array.isArray(revsData)) {
        setReviews(revsData);
      }
    } catch (err) {
      console.error('Error cargando datos desde Firebase:', err);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    let isMounted = true;
    let unsubProducts: (() => void) | null = null;
    let unsubCategories: (() => void) | null = null;
    let unsubBanners: (() => void) | null = null;
    let unsubSettings: (() => void) | null = null;
    let unsubReviews: (() => void) | null = null;

    async function initializeAndSubscribe() {
      // Execute strict sequence: wait for initial loadData before attaching listeners
      await loadData();

      if (!isMounted) return;

      // Real-time synchronization with Firestore
      unsubProducts = FirebaseService.subscribeToProducts((newProds) => {
        if (Array.isArray(newProds)) {
          setProducts(newProds);
        }
      });

      unsubCategories = FirebaseService.subscribeToCategories((newCats) => {
        if (Array.isArray(newCats)) {
          const sortedCats = [...newCats].sort((a, b) => (a.order ?? 0) - (b.order ?? 0));
          setCategories(sortedCats);
        }
      });

      unsubBanners = FirebaseService.subscribeToBanners((newBans) => {
        if (Array.isArray(newBans)) {
          setBanners(newBans);
        }
      });

      unsubSettings = FirebaseService.subscribeToSettings((newSets) => {
        if (newSets) {
          setSettings(newSets);
        }
      });

      unsubReviews = FirebaseService.subscribeToReviews((newRevs) => {
        if (Array.isArray(newRevs)) {
          setReviews(newRevs);
        }
      });

      const unsubAuth = FirebaseService.onAuthChange(async (user) => {
        if (user) {
          try {
            await FirebaseService.verifyAdminStatus(user.uid);
          } catch (e) {
            console.warn('Admin status sync check:', e);
          }
        }
      });
      return unsubAuth;
    }

    let unsubAuthCleanup: (() => void) | undefined;
    initializeAndSubscribe().then((unsub) => {
      unsubAuthCleanup = unsub;
    });

    // Check for #admin in URL or /admin path
    if (window.location.hash === '#admin' || window.location.pathname.includes('/admin')) {
      setIsAdminOpen(true);
    }

    const handleHashChange = () => {
      if (window.location.hash === '#admin') {
        setIsAdminOpen(true);
      }
    };
    window.addEventListener('hashchange', handleHashChange);
    return () => {
      isMounted = false;
      window.removeEventListener('hashchange', handleHashChange);
      if (unsubAuthCleanup) unsubAuthCleanup();
      if (unsubProducts) unsubProducts();
      if (unsubCategories) unsubCategories();
      if (unsubBanners) unsubBanners();
      if (unsubSettings) unsubSettings();
      if (unsubReviews) unsubReviews();
    };
  }, [loadData]);

  // Cart Handlers
  const handleAddToCart = useCallback((
    product: Product,
    quantity: number,
    options: { 
      color?: string; 
      cushionColor?: string; 
      borderColor?: string;
      backrestStyle?: 'costura' | 'botones' | string;
      fabricType?: string;
      fabricPriceDiff?: number;
      patternName?: string;
      patternImage?: string;
      selectedTextalinaImage?: string;
      finish?: string; 
      upholstery?: string; 
      size?: string; 
      notes?: string;
      customization?: any;
    }
  ) => {
    setCartItems((prev) => {
      const unitPrice = options.customization 
        ? options.customization.totalUnitPrice 
        : product.price + (options.fabricPriceDiff || 0);

      const existingIdx = prev.findIndex(
        (item) =>
          !options.customization &&
          item.productId === product.id &&
          item.selectedColor === options.color &&
          item.selectedCushionColor === options.cushionColor &&
          item.selectedBorderColor === options.borderColor &&
          item.selectedBackrestStyle === options.backrestStyle &&
          item.selectedFabricType === options.fabricType &&
          item.selectedPatternName === options.patternName &&
          item.selectedTextalinaImage === options.selectedTextalinaImage &&
          item.selectedFinish === options.finish &&
          item.selectedSize === options.size
      );

      if (existingIdx > -1) {
        const updated = [...prev];
        updated[existingIdx].quantity += quantity;
        return updated;
      }

      const newItem: CartItem = {
        id: `cart_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
        productId: product.id,
        product,
        quantity,
        selectedColor: options.color,
        selectedCushionColor: options.cushionColor,
        selectedBorderColor: options.borderColor,
        selectedBackrestStyle: options.backrestStyle,
        selectedFabricType: options.fabricType,
        selectedFabricPriceDiff: options.fabricPriceDiff,
        selectedPatternName: options.patternName,
        selectedPatternImage: options.patternImage,
        selectedTextalinaImage: options.selectedTextalinaImage,
        selectedFinish: options.finish,
        selectedUpholstery: options.upholstery,
        selectedSize: options.size,
        customNotes: options.notes,
        unitPrice,
        customization: options.customization,
      };
      return [...prev, newItem];
    });
  }, []);

  const handleUpdateQuantity = useCallback((cartItemId: string, newQty: number) => {
    if (newQty <= 0) {
      setCartItems((prev) => prev.filter((item) => item.id !== cartItemId));
      return;
    }
    setCartItems((prev) =>
      prev.map((item) => (item.id === cartItemId ? { ...item, quantity: newQty } : item))
    );
  }, []);

  const handleRemoveFromCart = useCallback((cartItemId: string) => {
    setCartItems((prev) => prev.filter((item) => item.id !== cartItemId));
  }, []);

  const handleClearCart = useCallback(() => {
    setCartItems([]);
  }, []);

  // Filter Reset & Update
  const handleResetFilters = useCallback(() => {
    setFilters(DEFAULT_FILTERS);
    setSearchQuery('');
  }, []);

  // Category & Banner navigation
  const handleSelectCategory = useCallback((categoryId: string) => {
    setFilters((prev) => ({
      ...prev,
      categoryId,
      onlyOffers: false,
    }));
    setSearchQuery('');
    const el = document.getElementById('catalog-content');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  }, []);

  const handleToggleOffers = useCallback(() => {
    setFilters((prev) => ({
      ...prev,
      onlyOffers: !prev.onlyOffers,
      categoryId: 'all',
    }));
    setSearchQuery('');
  }, []);

  const handleBannerCtaClick = useCallback((link?: string) => {
    if (link && link.startsWith('#')) {
      const catId = link.replace('#', '');
      handleSelectCategory(catId);
    } else {
      handleSelectCategory('all');
    }
  }, [handleSelectCategory]);

  const handleReviewAdded = useCallback((newReview: Review) => {
    setReviews((prev) => [newReview, ...prev]);
    loadData();
  }, [loadData]);

  // Active products filter for single category / search mode
  const activeProducts = useMemo(() => products.filter((p) => p.isActive !== false), [products]);

  // Offers list for the dedicated offers section
  const offerProducts = useMemo(() => activeProducts.filter((p) => p.isOffer), [activeProducts]);

  // Group active products by category for O(1) carousel rendering
  const productsByCategory = useMemo(() => {
    const map: Record<string, Product[]> = {};
    for (const cat of categories) {
      map[cat.id] = [];
    }
    for (const prod of activeProducts) {
      if (!map[prod.categoryId]) {
        map[prod.categoryId] = [];
      }
      map[prod.categoryId].push(prod);
    }
    return map;
  }, [categories, activeProducts]);

  // Dynamic filter matching logic
  const displayedFilteredProducts = useMemo(() => {
    return activeProducts
      .filter((product) => {
        // Search Query
        if (searchQuery.trim()) {
          const term = searchQuery.toLowerCase();
          const matchName = product.name.toLowerCase().includes(term);
          const matchDesc = product.description.toLowerCase().includes(term);
          const matchMat = product.material?.toLowerCase().includes(term);
          const matchWood = product.woodType?.toLowerCase().includes(term);
          const matchCushion = product.cushionStyle?.toLowerCase().includes(term);
          if (!matchName && !matchDesc && !matchMat && !matchWood && !matchCushion) return false;
        }

        // Category Filter
        if (filters.categoryId !== 'all' && product.categoryId !== filters.categoryId) {
          return false;
        }

        // Rocker Colors Filter (Blanco, Negro, Caoba)
        if (filters.rockerColors && filters.rockerColors.length > 0) {
          const productColors = (product.colors || []).map((c) => c.name.toLowerCase());
          const hasRockerColor = filters.rockerColors.some((rc) =>
            productColors.includes(rc.toLowerCase())
          );
          if (product.categoryId !== 'cojines' && !hasRockerColor) return false;
        }

        // Cushion Style Filter
        if (filters.cushionStyles && filters.cushionStyles.length > 0) {
          if (!product.cushionStyle || !filters.cushionStyles.includes(product.cushionStyle)) {
            return false;
          }
        }

        // Price Range
        if (product.price < filters.priceRange[0] || product.price > filters.priceRange[1]) {
          return false;
        }

        // Minimum Rating
        if (filters.minRating > 0) {
          const r = product.rating || 5;
          if (r < filters.minRating) return false;
        }

        // Only Offers
        if (filters.onlyOffers && !product.isOffer) {
          return false;
        }

        // In Stock
        if (filters.onlyInStock && product.stock <= 0) {
          return false;
        }

        return true;
      })
      .sort((a, b) => {
        if (filters.sortBy === 'price-asc') return a.price - b.price;
        if (filters.sortBy === 'price-desc') return b.price - a.price;
        if (filters.sortBy === 'rating') return (b.rating || 5) - (a.rating || 5);
        if (filters.sortBy === 'newest') return (b.isNew ? 1 : 0) - (a.isNew ? 1 : 0);
        return 0; // featured default order
      });
  }, [activeProducts, filters, searchQuery]);

  // Count active non-default filters
  const activeFiltersCount = useMemo(() => {
    let count = 0;
    if (filters.categoryId && filters.categoryId !== 'all') count += 1;
    if (filters.rockerColors?.length) count += filters.rockerColors.length;
    if (filters.materials?.length) count += filters.materials.length;
    if (filters.cushionColors?.length) count += filters.cushionColors.length;
    if (filters.cushionStyles?.length) count += filters.cushionStyles.length;
    if (filters.priceRange && (filters.priceRange[0] > 0 || filters.priceRange[1] < 100000)) count += 1;
    if (filters.minRating && filters.minRating > 0) count += 1;
    if (filters.onlyOffers) count += 1;
    if (filters.onlyInStock) count += 1;
    return count;
  }, [filters]);

  // Check if we are viewing the multi-carousel homepage or a filtered list
  const isMultiCarouselView =
    filters.categoryId === 'all' &&
    !filters.onlyOffers &&
    searchQuery.trim() === '' &&
    activeFiltersCount === 0;

  return (
    <div className="min-h-screen bg-[#FDFCFB] text-[#2C1810] flex flex-col font-sans selection:bg-[#5C4033]/20 selection:text-[#2C1810]">
      
      {/* 1. APP HEADER */}
      <Header
        settings={settings}
        categories={categories}
        cartItems={cartItems}
        onOpenCart={() => setIsCartOpen(true)}
        onOpenAdmin={() => setIsAdminOpen(true)}
        onSelectCategory={handleSelectCategory}
        activeCategory={filters.categoryId}
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
      />

      {/* 2. HERO BANNER CAROUSEL */}
      {isMultiCarouselView && (
        <HeroCarousel
          banners={banners}
          onCtaClick={handleBannerCtaClick}
        />
      )}

      {/* 3. CATEGORY CHIPS (Horizontal swipe on mobile) */}
      <CategoryChips
        categories={categories}
        selectedCategory={filters.categoryId}
        onSelectCategory={handleSelectCategory}
        showOffersOnly={filters.onlyOffers}
        onToggleOffers={handleToggleOffers}
      />

      {/* 4. MAIN CONTENT CONTAINER */}
      <main id="catalog-content" className="flex-1 max-w-7xl mx-auto px-4 sm:px-6 py-6 sm:py-10 w-full">
        
        {/* VIEW A: MULTI-LEVEL INDEPENDENT CATEGORY CAROUSELS */}
        {isMultiCarouselView ? (
          <div className="space-y-4 sm:space-y-6">
            
            {/* Filter Trigger Bar for users wanting to filter from homepage */}
            <div className="flex items-center justify-between p-3.5 sm:p-4 rounded-2xl bg-white border border-[#E8E2DC] shadow-xs">
              <div className="flex items-center gap-2 text-xs sm:text-sm font-semibold text-[#5C4033]">
                <SlidersHorizontal className="w-4 h-4 text-[#8a532b]" />
                <span>¿Buscas un color de cojín, madera o medida específica?</span>
              </div>
              <button
                onClick={() => {
                  setFilters((prev) => ({ ...prev, categoryId: 'all' }));
                  setIsMobileFilterOpen(true);
                }}
                className="px-4 py-2 rounded-xl bg-[#2C1810] text-white hover:bg-[#3E2723] text-xs font-bold transition-all shadow-xs flex items-center gap-1.5 cursor-pointer shrink-0"
              >
                <SlidersHorizontal className="w-3.5 h-3.5" />
                <span>Abrir Filtros Avanzados</span>
              </button>
            </div>

            {/* Category Carousels */}
            {isLoading ? (
              <div className="py-24 flex flex-col items-center justify-center space-y-4">
                <Loader2 className="w-8 h-8 animate-spin text-[#8a532b]" />
                <p className="text-xs sm:text-sm text-[#7A6A60] font-medium">Cargando catálogo...</p>
              </div>
            ) : activeProducts.length === 0 ? (
              <div className="text-center py-16 px-6 bg-white rounded-3xl border border-[#E8E2DC] card-shadow space-y-4 max-w-xl mx-auto my-6">
                <div className="w-16 h-16 rounded-full bg-[#F5F2EB] flex items-center justify-center mx-auto text-[#8a532b]">
                  <Layers className="w-8 h-8" />
                </div>
                <h3 className="font-serif text-xl sm:text-2xl font-bold text-[#2C1810]">
                  Catálogo en actualización
                </h3>
                <p className="text-xs sm:text-sm text-[#7A6A60] leading-relaxed max-w-md mx-auto">
                  Actualmente estamos preparando y actualizando los modelos disponibles. Contáctanos por WhatsApp para consultar pedidos personalizados o disponibilidad inmediata.
                </p>
                <div className="pt-2 flex flex-wrap items-center justify-center gap-3">
                  <a
                    href={`https://wa.me/${(settings.whatsappNumber || '584120000000').replace(/\D/g, '')}?text=${encodeURIComponent('Hola, me gustaría información sobre los modelos de mecedoras disponibles.')}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-6 py-3 rounded-xl bg-[#25D366] hover:bg-[#20bd5a] text-white text-xs font-bold flex items-center gap-2 shadow-md transition-transform hover:scale-105"
                  >
                    <span>Consultar por WhatsApp</span>
                  </a>
                </div>
              </div>
            ) : (
              categories
                .filter((c) => c.isActive)
                .map((category) => {
                  const categoryProducts = productsByCategory[category.id] || [];
                  return (
                    <CategoryCarouselSection
                      key={category.id}
                      category={category}
                      products={categoryProducts}
                      settings={settings}
                      onSelectProduct={setSelectedProduct}
                      onViewAllCategory={handleSelectCategory}
                    />
                  );
                })
            )}

            {/* Special Section: Ofertas y Descuentos */}
            {offerProducts.length > 0 && (
              <CategoryCarouselSection
                category={{
                  id: 'ofertas',
                  name: 'Ofertas & Oportunidades Especiales',
                  description: 'Mecedoras y juegos con precios especiales por tiempo limitado.',
                  order: 99,
                  isActive: true,
                }}
                products={offerProducts}
                settings={settings}
                onSelectProduct={setSelectedProduct}
                onViewAllCategory={handleToggleOffers}
              />
            )}
          </div>
        ) : (
          /* VIEW B: FILTERED GRID VIEW WITH ADVANCED FILTER ACCORDION & SIDEBAR */
          <div className="space-y-6 animate-fadeIn">
            {/* Filter Breadcrumb / Header */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-[#F0EBE6]">
              <div className="flex items-center gap-3">
                <button
                  onClick={handleResetFilters}
                  className="p-2 rounded-xl bg-white hover:bg-[#F0EBE6] border border-[#E8E2DC] text-[#2C1810] transition-colors cursor-pointer"
                  title="Volver a todas las categorías"
                >
                  <ArrowLeft className="w-4 h-4" />
                </button>
                <div>
                  <h2 className="font-serif text-2xl sm:text-3xl font-bold text-[#2C1810]">
                    {filters.onlyOffers
                      ? 'Ofertas y Promociones'
                      : searchQuery
                      ? `Búsqueda: "${searchQuery}"`
                      : categories.find((c) => c.id === filters.categoryId)?.name || 'Catálogo de Mecedoras'}
                  </h2>
                  <p className="text-xs sm:text-sm text-[#7A6A60]">
                    Mostrando {displayedFilteredProducts.length} {displayedFilteredProducts.length === 1 ? 'artículo' : 'artículos'}
                    {activeFiltersCount > 0 && ` con ${activeFiltersCount} filtros aplicados`}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                {/* Mobile Filter Button */}
                <button
                  onClick={() => setIsMobileFilterOpen(true)}
                  className="lg:hidden px-3.5 py-2 rounded-xl bg-[#2C1810] text-white text-xs font-bold flex items-center gap-2 shadow-xs cursor-pointer"
                >
                  <SlidersHorizontal className="w-3.5 h-3.5" />
                  <span>Filtros {activeFiltersCount > 0 ? `(${activeFiltersCount})` : ''}</span>
                </button>

                {activeFiltersCount > 0 && (
                  <button
                    onClick={handleResetFilters}
                    className="px-3 py-2 rounded-xl bg-[#F0EBE6] hover:bg-[#E8E2DC] text-[#2C1810] text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    <span>Limpiar filtros</span>
                  </button>
                )}

                <button
                  onClick={handleResetFilters}
                  className="text-xs font-bold text-[#5C4033] hover:text-[#2C1810] underline hidden sm:block ml-2 cursor-pointer"
                >
                  Ver carruseles
                </button>
              </div>
            </div>

            {/* Layout with Filters Sidebar on Desktop */}
            <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 items-start">
              
              {/* Desktop Filters Column */}
              <div className="hidden lg:block lg:col-span-1">
                <ProductFilters
                  categories={categories}
                  allProducts={activeProducts}
                  filterState={filters}
                  onFilterChange={setFilters}
                  onResetFilters={handleResetFilters}
                  isMobileDrawerOpen={false}
                  onCloseMobileDrawer={() => {}}
                  filteredCount={displayedFilteredProducts.length}
                  settings={settings}
                />
              </div>

              {/* Product Grid Column */}
              <div className="lg:col-span-3">
                {isLoading ? (
                  <div className="py-24 flex flex-col items-center justify-center space-y-4">
                    <Loader2 className="w-8 h-8 animate-spin text-[#8a532b]" />
                    <p className="text-xs sm:text-sm text-[#7A6A60] font-medium">Cargando artículos...</p>
                  </div>
                ) : displayedFilteredProducts.length === 0 ? (
                  <div className="text-center py-16 px-4 bg-white rounded-3xl border border-[#F0EBE6] card-shadow space-y-3">
                    <div className="w-16 h-16 rounded-full bg-[#F0EBE6]/60 flex items-center justify-center mx-auto text-[#7A6A60]">
                      <Layers className="w-8 h-8" />
                    </div>
                    <h3 className="font-serif text-lg font-bold text-[#2C1810]">
                      No encontramos productos con los filtros seleccionados
                    </h3>
                    <p className="text-xs text-[#7A6A60] max-w-sm mx-auto">
                      Prueba desmarcando algunos colores de cojines, estilos o maderas para ver más opciones disponibles.
                    </p>
                    <button
                      onClick={handleResetFilters}
                      className="px-5 py-2.5 rounded-xl bg-[#5C4033] hover:bg-[#3E2723] text-white text-xs font-bold uppercase tracking-wider transition-colors cursor-pointer"
                    >
                      Restablecer Todos los Filtros
                    </button>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 xs:grid-cols-2 md:grid-cols-3 gap-4 sm:gap-6">
                    {displayedFilteredProducts.map((product) => (
                      <div key={product.id} className="h-full">
                        <ProductCard
                          product={product}
                          settings={settings}
                          onSelectProduct={setSelectedProduct}
                        />
                      </div>
                    ))}
                  </div>
                )}
              </div>

            </div>
          </div>
        )}

      </main>

      {/* 5. FOOTER */}
      <Footer
        settings={settings}
        categories={categories}
        onSelectCategory={handleSelectCategory}
        onOpenAdmin={() => setIsAdminOpen(true)}
      />

      {/* Floating WhatsApp Button */}
      <WhatsAppFloatingButton settings={settings} />

      {/* 8. PRODUCT DETAIL MODAL (WITH COMPLETE REVIEWS INTEGRATION) */}
      {selectedProduct && (
        <Suspense fallback={
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-xs">
            <Loader2 className="w-8 h-8 animate-spin text-white" />
          </div>
        }>
          <ProductDetailModal
            product={selectedProduct}
            allProducts={products}
            reviews={reviews}
            settings={settings}
            onClose={() => setSelectedProduct(null)}
            onAddToCart={handleAddToCart}
            onSelectProduct={setSelectedProduct}
            onReviewAdded={handleReviewAdded}
          />
        </Suspense>
      )}

      {/* 9. MOBILE FILTERS DRAWER */}
      <ProductFilters
        categories={categories}
        allProducts={activeProducts}
        filterState={filters}
        onFilterChange={setFilters}
        onResetFilters={handleResetFilters}
        isMobileDrawerOpen={isMobileFilterOpen}
        onCloseMobileDrawer={() => setIsMobileFilterOpen(false)}
        filteredCount={displayedFilteredProducts.length}
        settings={settings}
      />

      {/* 10. CART DRAWER (Slide-over with WhatsApp Order Action) */}
      {isCartOpen && (
        <Suspense fallback={null}>
          <CartDrawer
            isOpen={isCartOpen}
            onClose={() => setIsCartOpen(false)}
            items={cartItems}
            settings={settings}
            onUpdateQuantity={handleUpdateQuantity}
            onRemoveItem={handleRemoveFromCart}
            onClearCart={handleClearCart}
          />
        </Suspense>
      )}

      {/* 11. COMPLETE ADMIN PANEL (/admin) WITH REVIEWS MODERATION */}
      {isAdminOpen && (
        <Suspense fallback={
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-stone-900/80 backdrop-blur-sm">
            <div className="flex flex-col items-center gap-3 text-white">
              <Loader2 className="w-8 h-8 animate-spin text-[#d4af37]" />
              <p className="text-sm font-semibold">Cargando panel de administración...</p>
            </div>
          </div>
        }>
          <AdminDashboard
            isOpen={isAdminOpen}
            onClose={() => {
              setIsAdminOpen(false);
              if (window.location.hash === '#admin') {
                history.pushState('', document.title, window.location.pathname);
              }
            }}
            products={products}
            categories={categories}
            banners={banners}
            settings={settings}
            onDataRefresh={loadData}
          />
        </Suspense>
      )}

    </div>
  );
}
