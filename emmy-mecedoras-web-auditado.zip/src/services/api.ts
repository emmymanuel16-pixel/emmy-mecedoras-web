import { AnalyticsEvent, Banner, Category, DailyAnalyticsPoint, Product, Review, StoreSettings } from '../types';
import { INITIAL_BANNERS, INITIAL_CATEGORIES, INITIAL_PRODUCTS, INITIAL_REVIEWS, INITIAL_SETTINGS } from '../data/initialData';
import { FirebaseService, ensureImagesInCloudStorage } from './firebaseService';
import { uploadToFirebaseStorage, deleteFromFirebaseStorage, isFirebaseStorageUrl } from './firebaseStorageService';

const TOKEN_STORAGE_KEY = 'mecedoras_admin_token';
const USERNAME_STORAGE_KEY = 'mecedoras_admin_user';
const LOCAL_PRODUCTS_KEY = 'mecedoras_local_products';
const LOCAL_CATEGORIES_KEY = 'mecedoras_local_categories';
const LOCAL_BANNERS_KEY = 'mecedoras_local_banners';
const LOCAL_SETTINGS_KEY = 'mecedoras_local_settings';
const LOCAL_REVIEWS_KEY = 'mecedoras_local_reviews';

function getLocalItem<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    if (raw) return JSON.parse(raw);
  } catch (e) {
    console.warn(`Failed to read local storage key ${key}:`, e);
  }
  return fallback;
}

function saveLocalItem<T>(key: string, value: T): void {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (e) {
    console.warn(`Failed to save local storage key ${key}:`, e);
  }
}

function getLocalReviews(): Review[] {
  return getLocalItem<Review[]>(LOCAL_REVIEWS_KEY, []);
}

function saveLocalReviews(reviews: Review[]) {
  saveLocalItem(LOCAL_REVIEWS_KEY, reviews);
}

export const api = {
  // Auth helpers
  getToken(): string | null {
    try {
      if (typeof window !== 'undefined' && typeof localStorage !== 'undefined') {
        return localStorage.getItem(TOKEN_STORAGE_KEY);
      }
    } catch {
      // Ignore
    }
    return null;
  },
  setAuth(token: string, username: string) {
    try {
      if (typeof window !== 'undefined' && typeof localStorage !== 'undefined') {
        localStorage.setItem(TOKEN_STORAGE_KEY, token);
        localStorage.setItem(USERNAME_STORAGE_KEY, username);
      }
    } catch {
      // Ignore
    }
  },
  clearAuth() {
    try {
      if (typeof window !== 'undefined' && typeof localStorage !== 'undefined') {
        localStorage.removeItem(TOKEN_STORAGE_KEY);
        localStorage.removeItem(USERNAME_STORAGE_KEY);
      }
    } catch {
      // Ignore
    }
    FirebaseService.logout();
  },
  getUsername(): string | null {
    try {
      if (typeof window !== 'undefined' && typeof localStorage !== 'undefined') {
        return localStorage.getItem(USERNAME_STORAGE_KEY);
      }
    } catch {
      // Ignore
    }
    return null;
  },

  async login(username: string, password: string): Promise<{ success: boolean; token?: string; error?: string }> {
    const cleanUser = username.trim();
    const cleanPass = password.trim();

    // Direct Firebase Auth (Primary Source of Truth)
    // Supports either email directly or administrative username mapped to domain
    const emailToUse = cleanUser.includes('@')
      ? cleanUser
      : `${cleanUser}@emmymecedoras.com`;

    try {
      const fbResult = await FirebaseService.loginWithEmail(emailToUse, cleanPass);
      if (fbResult.success && fbResult.user) {
        const token = `fb_token_${fbResult.user.uid}`;
        this.setAuth(token, fbResult.user.email || cleanUser);
        return { success: true, token };
      } else if (fbResult.error) {
        return { success: false, error: fbResult.error };
      }
    } catch (err: any) {
      console.warn('Firebase email auth attempt failed:', err);
    }

    return { 
      success: false, 
      error: 'Correo o contraseña incorrectos.' 
    };
  },

  async loginWithGoogle(): Promise<{ success: boolean; token?: string; error?: string; username?: string }> {
    const res = await FirebaseService.loginWithGoogle();
    if (res.success && res.user) {
      const token = `fb_google_${res.user.uid}`;
      const name = res.user.displayName || res.user.email || 'Admin';
      this.setAuth(token, name);
      return { success: true, token, username: name };
    }

    let errMsg = res.error || 'No se pudo iniciar sesión con Google';
    if (typeof errMsg === 'string' && (errMsg.includes('auth/unauthorized-domain') || errMsg.includes('unauthorized domain'))) {
      errMsg = 'El dominio actual no está agregado en Firebase Auth. Añade el dominio en Firebase Console > Authentication > Settings > Authorized domains.';
    }

    return { success: false, error: errMsg };
  },

  async verifyToken(): Promise<boolean> {
    const token = this.getToken();
    if (!token) return false;
    
    // Validate that current Firebase session has active admin rights
    const currentUser = FirebaseService.getCurrentUser();
    if (currentUser) {
      return await FirebaseService.verifyAdminStatus(currentUser.uid);
    }

    return token.startsWith('fb_');
  },

  // Products
  async getProducts(params?: { category?: string; search?: string; activeOnly?: boolean }): Promise<Product[]> {
    let products: Product[] | null = null;

    // 1. Primary Source of Truth: Firebase Firestore
    try {
      const fbProducts = await FirebaseService.getProducts();
      // If Firestore returned a valid array (even an empty one []), we honor it as the absolute source of truth!
      if (Array.isArray(fbProducts)) {
        products = fbProducts;
        saveLocalItem(LOCAL_PRODUCTS_KEY, products);
      }
    } catch (e) {
      console.warn('Error al obtener productos de Firestore:', e);
    }

    // 2. Only if Firestore was unreachable (e.g., offline cache fallback)
    if (products === null) {
      if (typeof window !== 'undefined' && localStorage.getItem(LOCAL_PRODUCTS_KEY) !== null) {
        products = getLocalItem<Product[]>(LOCAL_PRODUCTS_KEY, []);
      }
    }

    // 3. Fallback to empty array - NEVER automatically insert INITIAL_PRODUCTS
    // An empty catalog (0 products) is a completely valid state.
    if (products === null) {
      products = [];
    }

    // Apply client filters if requested
    if (params?.category && params.category !== 'all' && params.category !== 'todos') {
      products = products.filter(p => p.categoryId === params.category);
    }
    if (params?.search) {
      const t = params.search.toLowerCase();
      products = products.filter(p => p.name.toLowerCase().includes(t) || p.description.toLowerCase().includes(t));
    }
    if (params?.activeOnly) {
      products = products.filter(p => p.isActive !== false);
    }

    return products;
  },

  async uploadImages(images: string[], folder = 'productos'): Promise<string[]> {
    if (!images || images.length === 0) return [];
    const results: string[] = [];
    for (const img of images) {
      if (img && typeof img === 'string' && img.startsWith('data:image/')) {
        const url = await uploadToFirebaseStorage(img, folder);
        results.push(url);
      } else if (img && typeof img === 'string') {
        results.push(img);
      }
    }
    return results;
  },

  async uploadSingleImage(image: string, folder = 'productos'): Promise<string> {
    if (!image || typeof image !== 'string' || !image.startsWith('data:image/')) return image;
    return await uploadToFirebaseStorage(image, folder);
  },

  async deleteUploadedImage(url: string): Promise<boolean> {
    if (!url || typeof url !== 'string') return false;
    if (isFirebaseStorageUrl(url)) {
      return await deleteFromFirebaseStorage(url);
    }
    if (url.startsWith('/uploads/productos/')) {
      try {
        const token = this.getToken();
        const headers: Record<string, string> = { 'Content-Type': 'application/json' };
        if (token) headers['Authorization'] = `Bearer ${token}`;

        const res = await fetch('/api/upload/delete-image', {
          method: 'POST',
          headers,
          body: JSON.stringify({ url })
        });
        return res.ok;
      } catch {
        return false;
      }
    }
    return false;
  },

  async getProductById(id: string): Promise<Product | null> {
    if (!id) return null;
    try {
      const fbProduct = await FirebaseService.getProductById(id);
      if (fbProduct) return fbProduct;
    } catch {
      // Fallback
    }
    const list = await this.getProducts();
    return list.find(p => p.id === id) || null;
  },

  async createProduct(product: Partial<Product>): Promise<Product> {
    const defaultImage = 'https://images.unsplash.com/photo-1586023492125-27b2c045efd7?auto=format&fit=crop&w=800&q=80';
    
    // Clean, deduplicate and validate images
    const rawImages = (product.images || []).filter(img => img && typeof img === 'string' && img.trim().length > 0);
    const uniqueImages: string[] = [];
    const seen = new Set<string>();

    const targetMain = (product.mainImage && product.mainImage.trim().length > 0)
      ? product.mainImage.trim()
      : rawImages[0];

    if (targetMain) {
      seen.add(targetMain);
      uniqueImages.push(targetMain);
    }

    rawImages.forEach(img => {
      const trimmed = img.trim();
      if (trimmed && !seen.has(trimmed)) {
        seen.add(trimmed);
        uniqueImages.push(trimmed);
      }
    });

    const imagesList = uniqueImages.length > 0 ? uniqueImages : [defaultImage];
    let resolvedImages = imagesList;
    try {
      resolvedImages = await this.uploadImages(imagesList);
    } catch (e) {
      console.warn('Could not pre-upload images to server:', e);
    }
    const mainImg = resolvedImages[0] || defaultImage;

    const safeId = (product.id && product.id.trim()) 
      ? product.id.trim().replace(/\//g, '_') 
      : `prod_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;

    const newProduct: Product = {
      ...product,
      id: safeId,
      name: (product.name || 'Nueva Mecedora').trim(),
      description: (product.description || '').trim(),
      price: Number(product.price) || 0,
      previousPrice: product.previousPrice ? Number(product.previousPrice) : undefined,
      categoryId: product.categoryId || 'mecedoras-grandes',
      productType: (product.productType || product.categoryId || 'mecedora-grande') as any,
      stock: product.stock !== undefined ? Number(product.stock) : 0,
      material: product.material || 'Fibra de vidrio',
      colors: Array.isArray(product.colors) ? product.colors : [],
      images: resolvedImages,
      mainImage: mainImg,
      isActive: product.isActive !== undefined ? Boolean(product.isActive) : true,
      isFeatured: Boolean(product.isFeatured),
      isNew: product.isNew !== undefined ? Boolean(product.isNew) : true,
      isOffer: Boolean(product.isOffer),
      rating: product.rating !== undefined ? Number(product.rating) : 5.0,
      reviewCount: product.reviewCount !== undefined ? Number(product.reviewCount) : 0,
      createdAt: product.createdAt || new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    // 1. Primary Source of Truth: Firebase Firestore
    try {
      await FirebaseService.saveProduct(newProduct);
    } catch (e: any) {
      console.error('Error al guardar producto en Firestore:', e);
      throw new Error(`No se pudo guardar el producto en Firebase: ${e.message || e}`);
    }

    // 2. Secondary update to local cache
    const localList = getLocalItem<Product[]>(LOCAL_PRODUCTS_KEY, []);
    const updatedLocal = [newProduct, ...localList.filter(p => p.id !== newProduct.id)];
    saveLocalItem(LOCAL_PRODUCTS_KEY, updatedLocal);

    // 3. Optional Backend API notification (non-blocking)
    try {
      const token = this.getToken();
      await fetch('/api/products', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { 'Authorization': `Bearer ${token}` } : {})
        },
        body: JSON.stringify(newProduct)
      });
    } catch {
      // Backend optional (Netlify static deployment)
    }

    return newProduct;
  },

  async updateProduct(id: string, product: Partial<Product>): Promise<Product> {
    if (!id) throw new Error('ID de producto no válido para actualización.');

    let existing: Product | null = null;
    try {
      existing = await this.getProductById(id);
    } catch (e) {
      console.warn('Could not load existing product by ID:', e);
    }
    
    const rawImages = (product.images !== undefined ? product.images : (existing?.images || []))
      .filter((img): img is string => typeof img === 'string' && img.trim().length > 0);
    
    const uniqueImages: string[] = [];
    const seen = new Set<string>();

    const targetMain = (product.mainImage !== undefined && product.mainImage.trim().length > 0)
      ? product.mainImage.trim()
      : (existing?.mainImage || rawImages[0] || '');

    if (targetMain) {
      seen.add(targetMain);
      uniqueImages.push(targetMain);
    }

    rawImages.forEach(img => {
      const trimmed = img.trim();
      if (trimmed && !seen.has(trimmed)) {
        seen.add(trimmed);
        uniqueImages.push(trimmed);
      }
    });

    const finalImages = uniqueImages.length > 0 ? uniqueImages : (targetMain ? [targetMain] : []);
    let resolvedImages = finalImages;
    try {
      resolvedImages = await this.uploadImages(finalImages);
    } catch (e) {
      console.warn('Could not pre-upload images to server:', e);
    }
    const mainImg = resolvedImages[0] || targetMain || '';

    const fullProduct: Product = {
      ...(existing || {} as Product),
      ...product,
      id,
      images: resolvedImages,
      mainImage: mainImg,
      updatedAt: new Date().toISOString()
    } as Product;

    // 1. Primary Source of Truth: Firebase Firestore
    try {
      await FirebaseService.saveProduct(fullProduct);
    } catch (e: any) {
      console.error('Error al actualizar producto en Firestore:', e);
      throw new Error(`No se pudo actualizar el producto en Firebase: ${e.message || e}`);
    }

    // 2. Secondary update to local cache
    const localList = getLocalItem<Product[]>(LOCAL_PRODUCTS_KEY, []);
    const updatedLocal = localList.map(p => p.id === id ? fullProduct : p);
    if (!localList.some(p => p.id === id)) {
      updatedLocal.unshift(fullProduct);
    }
    saveLocalItem(LOCAL_PRODUCTS_KEY, updatedLocal);

    // 3. Optional Backend API notification (non-blocking)
    try {
      const token = this.getToken();
      await fetch(`/api/products/${id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { 'Authorization': `Bearer ${token}` } : {})
        },
        body: JSON.stringify(fullProduct)
      });
    } catch {
      // Backend optional
    }

    return fullProduct;
  },

  async deleteProduct(id: string): Promise<boolean> {
    if (!id) throw new Error('ID de producto no válido para eliminación.');

    // 1. Primary Source of Truth: Firebase Firestore
    try {
      await FirebaseService.deleteProduct(id);
    } catch (e: any) {
      console.error('Error crítico al eliminar producto en Firestore:', e);
      throw new Error(`No se pudo eliminar el producto en Firebase: ${e.message || e}`);
    }

    // 2. Sync Local Cache only after successful Firestore deletion
    const localList = getLocalItem<Product[]>(LOCAL_PRODUCTS_KEY, []);
    const updatedList = localList.filter(p => p.id !== id);
    saveLocalItem(LOCAL_PRODUCTS_KEY, updatedList);

    // 3. Optional Backend API notification
    try {
      const token = this.getToken();
      await fetch(`/api/products/${id}`, {
        method: 'DELETE',
        headers: { ...(token ? { 'Authorization': `Bearer ${token}` } : {}) }
      });
    } catch {
      // Backend optional
    }

    return true;
  },

  async deleteAllProducts(): Promise<boolean> {
    // 1. Primary Source of Truth: Firebase Firestore
    try {
      await FirebaseService.deleteAllProducts();
    } catch (e: any) {
      console.error('Error crítico al vaciar productos en Firestore:', e);
      throw new Error(`No se pudo vaciar el catálogo en Firebase: ${e.message || e}`);
    }

    // 2. Clear Local Cache only after successful Firestore deletion
    saveLocalItem(LOCAL_PRODUCTS_KEY, []);

    // 3. Optional Backend API notification
    try {
      const token = this.getToken();
      await fetch('/api/products-all', {
        method: 'DELETE',
        headers: { ...(token ? { 'Authorization': `Bearer ${token}` } : {}) }
      });
    } catch {
      // Backend optional
    }

    return true;
  },

  async restoreFactoryProducts(): Promise<Product[]> {
    // 1. Primary Source of Truth: Firebase Firestore
    try {
      await FirebaseService.restoreFactoryProducts();
    } catch (e: any) {
      console.error('Error al restaurar catálogo en Firestore:', e);
      throw new Error(`No se pudieron restaurar los productos en Firebase: ${e.message || e}`);
    }

    // 2. Update Local Cache
    const factoryProducts = [...INITIAL_PRODUCTS];
    saveLocalItem(LOCAL_PRODUCTS_KEY, factoryProducts);

    // 3. Optional Backend API notification
    try {
      const token = this.getToken();
      await fetch('/api/products/restore-factory', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { 'Authorization': `Bearer ${token}` } : {})
        }
      });
    } catch {
      // Backend optional
    }

    return factoryProducts;
  },

  // Categories
  async getCategories(): Promise<Category[]> {
    // 1. Try Firebase Firestore (Primary source of truth)
    try {
      const fbCats = await FirebaseService.getCategories();
      if (Array.isArray(fbCats)) {
        saveLocalItem(LOCAL_CATEGORIES_KEY, fbCats);
        return fbCats.sort((a, b) => (a.order ?? 0) - (b.order ?? 0));
      }
    } catch (e) {
      console.warn('Firestore categories fetch error:', e);
    }

    // 2. Try Backend API
    try {
      const res = await fetch('/api/categories');
      if (res.ok) {
        const apiCats = await res.json();
        if (Array.isArray(apiCats)) {
          saveLocalItem(LOCAL_CATEGORIES_KEY, apiCats);
          return apiCats.sort((a, b) => (a.order ?? 0) - (b.order ?? 0));
        }
      }
    } catch {
      // Backend offline
    }

    // 3. Try Local Cache
    const localCats = getLocalItem<Category[] | null>(LOCAL_CATEGORIES_KEY, null);
    if (Array.isArray(localCats)) {
      return localCats.sort((a, b) => (a.order ?? 0) - (b.order ?? 0));
    }

    // 4. Default if brand new
    return INITIAL_CATEGORIES;
  },

  async createCategory(cat: Partial<Category>): Promise<Category> {
    let finalImage = cat.image;
    if (finalImage && typeof finalImage === 'string' && finalImage.startsWith('data:image/')) {
      try {
        finalImage = await this.uploadSingleImage(finalImage, 'category');
      } catch (e) {
        console.warn('Could not upload category image to cloud storage:', e);
      }
    }

    const newCategory: Category = {
      id: cat.id || `cat_${Date.now()}`,
      name: cat.name || 'Nueva Categoría',
      description: cat.description || '',
      image: finalImage,
      order: cat.order || 99,
      isActive: cat.isActive ?? true
    };

    // 1. Primary Source of Truth: Firebase Firestore
    try {
      await FirebaseService.saveCategory(newCategory);
    } catch (e: any) {
      console.error('Error crítico al guardar categoría en Firestore:', e);
      throw new Error(`No se pudo guardar la categoría en Firebase: ${e.message || e}`);
    }

    // 2. Secondary update to local cache ONLY after Firestore confirms
    const localList = getLocalItem<Category[]>(LOCAL_CATEGORIES_KEY, []);
    const updatedLocal = [...localList.filter(c => c.id !== newCategory.id), newCategory];
    saveLocalItem(LOCAL_CATEGORIES_KEY, updatedLocal);

    // 3. Optional Backend API notification (non-blocking)
    const token = this.getToken();
    try {
      await fetch('/api/categories', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { 'Authorization': `Bearer ${token}` } : {})
        },
        body: JSON.stringify(newCategory)
      });
    } catch {
      // Static fallback
    }

    return newCategory;
  },

  async updateCategory(id: string, cat: Partial<Category>): Promise<Category> {
    let finalImage = cat.image;
    if (finalImage && typeof finalImage === 'string' && finalImage.startsWith('data:image/')) {
      try {
        finalImage = await this.uploadSingleImage(finalImage, 'category');
      } catch (e) {
        console.warn('Could not upload category image to cloud storage:', e);
      }
    }

    const updated = { ...cat, image: finalImage, id } as Category;

    // 1. Primary Source of Truth: Firebase Firestore
    try {
      await FirebaseService.saveCategory(updated);
    } catch (e: any) {
      console.error('Error crítico al actualizar categoría en Firestore:', e);
      throw new Error(`No se pudo actualizar la categoría en Firebase: ${e.message || e}`);
    }

    // 2. Secondary update to local cache ONLY after Firestore confirms
    const localList = getLocalItem<Category[]>(LOCAL_CATEGORIES_KEY, []);
    const updatedLocal = localList.map(c => c.id === id ? updated : c);
    if (!localList.some(c => c.id === id)) {
      updatedLocal.push(updated);
    }
    saveLocalItem(LOCAL_CATEGORIES_KEY, updatedLocal);

    // 3. Optional Backend API notification (non-blocking)
    const token = this.getToken();
    try {
      await fetch(`/api/categories/${id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { 'Authorization': `Bearer ${token}` } : {})
        },
        body: JSON.stringify(updated)
      });
    } catch {
      // Static fallback
    }

    return updated;
  },

  async deleteCategory(id: string): Promise<boolean> {
    if (!id) throw new Error('ID de categoría no válido para eliminación.');

    // 1. Primary Source of Truth: Firebase Firestore
    try {
      await FirebaseService.deleteCategory(id);
    } catch (e: any) {
      console.error('Error crítico al eliminar categoría en Firestore:', e);
      throw new Error(`No se pudo eliminar la categoría en Firebase: ${e.message || e}`);
    }

    // 2. Sync Local Cache only after successful Firestore deletion
    const localList = getLocalItem<Category[]>(LOCAL_CATEGORIES_KEY, []);
    saveLocalItem(LOCAL_CATEGORIES_KEY, localList.filter(c => c.id !== id));

    // 3. Optional Backend notification (non-blocking)
    const token = this.getToken();
    try {
      await fetch(`/api/categories/${id}`, {
        method: 'DELETE',
        headers: { ...(token ? { 'Authorization': `Bearer ${token}` } : {}) }
      });
    } catch {
      // Static fallback
    }

    return true;
  },

  // Banners
  async getBanners(): Promise<Banner[]> {
    // 1. Try Firebase Firestore
    try {
      const fbBanners = await FirebaseService.getBanners();
      if (Array.isArray(fbBanners)) {
        saveLocalItem(LOCAL_BANNERS_KEY, fbBanners);
        return fbBanners.sort((a, b) => (a.order ?? 0) - (b.order ?? 0));
      }
    } catch (e) {
      console.warn('Firestore banners fetch error:', e);
    }

    // 2. Try Backend API
    try {
      const res = await fetch('/api/banners');
      if (res.ok) {
        const apiBanners = await res.json();
        if (Array.isArray(apiBanners)) {
          saveLocalItem(LOCAL_BANNERS_KEY, apiBanners);
          return apiBanners.sort((a, b) => (a.order ?? 0) - (b.order ?? 0));
        }
      }
    } catch {
      // Backend offline
    }

    // 3. Try Local Cache
    const localBanners = getLocalItem<Banner[] | null>(LOCAL_BANNERS_KEY, null);
    if (Array.isArray(localBanners)) {
      return localBanners.sort((a, b) => (a.order ?? 0) - (b.order ?? 0));
    }

    // 4. Default if brand new
    return INITIAL_BANNERS;
  },

  async createBanner(banner: Partial<Banner>): Promise<Banner> {
    let finalImage = banner.image;
    if (finalImage && typeof finalImage === 'string' && finalImage.startsWith('data:image/')) {
      try {
        finalImage = await this.uploadSingleImage(finalImage, 'banners');
      } catch (e) {
        console.warn('Could not upload banner image to cloud storage:', e);
      }
    }

    const newBanner: Banner = {
      id: banner.id || `banner_${Date.now()}`,
      title: banner.title || 'Nuevo Banner',
      subtitle: banner.subtitle || '',
      buttonText: banner.buttonText || 'VER MÁS',
      image: finalImage || '',
      link: banner.link || '#',
      order: banner.order || 99,
      isActive: banner.isActive ?? true
    };

    // 1. Primary Source of Truth: Firebase Firestore
    try {
      await FirebaseService.saveBanner(newBanner);
    } catch (e: any) {
      console.error('Error crítico al guardar banner en Firestore:', e);
      throw new Error(`No se pudo guardar el banner en Firebase: ${e.message || e}`);
    }

    // 2. Secondary update to local cache ONLY after Firestore confirms
    const localList = getLocalItem<Banner[]>(LOCAL_BANNERS_KEY, []);
    saveLocalItem(LOCAL_BANNERS_KEY, [...localList.filter(b => b.id !== newBanner.id), newBanner]);

    // 3. Optional Backend API notification (non-blocking)
    const token = this.getToken();
    try {
      await fetch('/api/banners', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { 'Authorization': `Bearer ${token}` } : {})
        },
        body: JSON.stringify(newBanner)
      });
    } catch {
      // Static fallback
    }

    return newBanner;
  },

  async updateBanner(id: string, banner: Partial<Banner>): Promise<Banner> {
    let finalImage = banner.image;
    if (finalImage && typeof finalImage === 'string' && finalImage.startsWith('data:image/')) {
      try {
        finalImage = await this.uploadSingleImage(finalImage, 'banners');
      } catch (e) {
        console.warn('Could not upload banner image to cloud storage:', e);
      }
    }

    const updated = { ...banner, image: finalImage, id } as Banner;

    // 1. Primary Source of Truth: Firebase Firestore
    try {
      await FirebaseService.saveBanner(updated);
    } catch (e: any) {
      console.error('Error crítico al actualizar banner en Firestore:', e);
      throw new Error(`No se pudo actualizar el banner en Firebase: ${e.message || e}`);
    }

    // 2. Secondary update to local cache ONLY after Firestore confirms
    const localList = getLocalItem<Banner[]>(LOCAL_BANNERS_KEY, []);
    saveLocalItem(LOCAL_BANNERS_KEY, localList.map(b => b.id === id ? updated : b));

    // 3. Optional Backend API notification (non-blocking)
    const token = this.getToken();
    try {
      await fetch(`/api/banners/${id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { 'Authorization': `Bearer ${token}` } : {})
        },
        body: JSON.stringify(updated)
      });
    } catch {
      // Static fallback
    }

    return updated;
  },

  async deleteBanner(id: string): Promise<boolean> {
    if (!id) throw new Error('ID de banner no válido para eliminación.');

    // 1. Primary Source of Truth: Firebase Firestore
    try {
      await FirebaseService.deleteBanner(id);
    } catch (e: any) {
      console.error('Error crítico al eliminar banner en Firestore:', e);
      throw new Error(`No se pudo eliminar el banner en Firebase: ${e.message || e}`);
    }

    // 2. Sync Local Cache only after successful Firestore deletion
    const localList = getLocalItem<Banner[]>(LOCAL_BANNERS_KEY, []);
    saveLocalItem(LOCAL_BANNERS_KEY, localList.filter(b => b.id !== id));

    // 3. Optional Backend notification (non-blocking)
    const token = this.getToken();
    try {
      await fetch(`/api/banners/${id}`, {
        method: 'DELETE',
        headers: { ...(token ? { 'Authorization': `Bearer ${token}` } : {}) }
      });
    } catch {
      // Static fallback
    }

    return true;
  },

  // Settings
  async getSettings(): Promise<StoreSettings> {
    try {
      const fbSettings = await FirebaseService.getSettings();
      if (fbSettings) {
        const normalized: StoreSettings = {
          ...INITIAL_SETTINGS,
          ...fbSettings,
          cushionFabrics: Array.isArray(fbSettings.cushionFabrics) ? fbSettings.cushionFabrics : [],
          cushionPatterns: Array.isArray(fbSettings.cushionPatterns) ? fbSettings.cushionPatterns : [],
          cushionTextalinaOptions: Array.isArray(fbSettings.cushionTextalinaOptions) ? fbSettings.cushionTextalinaOptions : [],
          cushionBorderColors: Array.isArray(fbSettings.cushionBorderColors) ? fbSettings.cushionBorderColors : [],
        };
        saveLocalItem(LOCAL_SETTINGS_KEY, normalized);
        return normalized;
      }
    } catch (e) {
      console.warn('Firestore settings fetch error:', e);
    }

    try {
      const res = await fetch('/api/settings');
      if (res.ok) {
        const apiSettings = await res.json();
        if (apiSettings) {
          const normalized: StoreSettings = {
            ...INITIAL_SETTINGS,
            ...apiSettings,
            cushionFabrics: Array.isArray(apiSettings.cushionFabrics) ? apiSettings.cushionFabrics : [],
            cushionPatterns: Array.isArray(apiSettings.cushionPatterns) ? apiSettings.cushionPatterns : [],
            cushionTextalinaOptions: Array.isArray(apiSettings.cushionTextalinaOptions) ? apiSettings.cushionTextalinaOptions : [],
            cushionBorderColors: Array.isArray(apiSettings.cushionBorderColors) ? apiSettings.cushionBorderColors : [],
          };
          saveLocalItem(LOCAL_SETTINGS_KEY, normalized);
          return normalized;
        }
      }
    } catch {
      // Backend offline
    }

    const localSettings = getLocalItem<StoreSettings | null>(LOCAL_SETTINGS_KEY, null);
    if (localSettings) {
      return {
        ...INITIAL_SETTINGS,
        ...localSettings,
        cushionFabrics: Array.isArray(localSettings.cushionFabrics) ? localSettings.cushionFabrics : [],
        cushionPatterns: Array.isArray(localSettings.cushionPatterns) ? localSettings.cushionPatterns : [],
        cushionTextalinaOptions: Array.isArray(localSettings.cushionTextalinaOptions) ? localSettings.cushionTextalinaOptions : [],
        cushionBorderColors: Array.isArray(localSettings.cushionBorderColors) ? localSettings.cushionBorderColors : [],
      };
    }

    return INITIAL_SETTINGS;
  },

  async updateSettings(settings: Partial<StoreSettings>): Promise<StoreSettings> {
    const current = await this.getSettings();
    const updated: StoreSettings = {
      ...current,
      ...settings,
      cushionFabrics: Array.isArray(settings.cushionFabrics)
        ? settings.cushionFabrics
        : (Array.isArray(current.cushionFabrics) ? current.cushionFabrics : []),
      cushionPatterns: Array.isArray(settings.cushionPatterns)
        ? settings.cushionPatterns
        : (Array.isArray(current.cushionPatterns) ? current.cushionPatterns : []),
      cushionTextalinaOptions: Array.isArray(settings.cushionTextalinaOptions)
        ? settings.cushionTextalinaOptions
        : (Array.isArray(current.cushionTextalinaOptions) ? current.cushionTextalinaOptions : []),
      cushionBorderColors: Array.isArray(settings.cushionBorderColors)
        ? settings.cushionBorderColors
        : (Array.isArray(current.cushionBorderColors) ? current.cushionBorderColors : []),
    };

    // Ensure all nested images (fabrics, patterns, textalinas, styles, 3D textures, logo) are in Cloud Storage
    const cloudSettings = await ensureImagesInCloudStorage(updated, 'configuracion');

    // 1. Primary Source of Truth: Firebase Firestore FIRST
    try {
      await FirebaseService.saveSettings(cloudSettings);
    } catch (e: any) {
      console.error('Error crítico al guardar configuración en Firestore:', e);
      throw new Error(`No se pudo persistir la configuración en Firebase: ${e.message || e}`);
    }

    // 2. Secondary update to local cache ONLY after Firestore confirms write
    saveLocalItem(LOCAL_SETTINGS_KEY, cloudSettings);

    // 3. Optional Backend notification (non-blocking, keeps db.json synchronized)
    const token = this.getToken() || 'token_public';
    try {
      await fetch('/api/settings', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify(cloudSettings)
      });
    } catch {
      // Static fallback
    }

    return cloudSettings;
  },

  // Reviews
  async getReviews(params?: { productId?: string; status?: string }): Promise<Review[]> {
    let list: Review[] | null = null;
    try {
      const fbReviews = await FirebaseService.getReviews();
      if (Array.isArray(fbReviews)) {
        list = fbReviews;
        saveLocalReviews(list);
      }
    } catch (e) {
      console.warn('Firestore reviews fetch error:', e);
    }

    if (list === null) {
      try {
        const query = new URLSearchParams();
        if (params?.productId) query.append('productId', params.productId);
        if (params?.status) query.append('status', params.status);
        const res = await fetch(`/api/reviews?${query.toString()}`);
        if (res.ok) {
          const apiRevs = await res.json();
          if (Array.isArray(apiRevs)) {
            list = apiRevs;
            saveLocalReviews(list);
          }
        }
      } catch {
        // Backend offline
      }
    }

    if (list === null) {
      list = getLocalReviews();
    }

    let filtered = [...list];
    if (params?.productId) filtered = filtered.filter(r => r.productId === params.productId);
    if (params?.status) filtered = filtered.filter(r => r.status === params.status);

    return filtered;
  },

  async createReview(review: Partial<Review>): Promise<Review> {
    const rawReview: Review = {
      id: review.id || `rev_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      productId: review.productId || '',
      productName: review.productName || 'Producto',
      userName: review.userName || 'Cliente',
      userEmail: review.userEmail,
      rating: review.rating || 5,
      title: review.title,
      comment: review.comment || '',
      isVerifiedBuyer: Boolean(review.isVerifiedBuyer || review.orderNumber),
      orderNumber: review.orderNumber,
      status: review.status || 'approved',
      createdAt: new Date().toISOString(),
      helpfulCount: 0
    };

    let newReview = rawReview;
    try {
      newReview = await ensureImagesInCloudStorage(rawReview, 'reviews');
    } catch (e) {
      console.warn('Could not upload review images to Cloud Storage:', e);
    }

    // 1. Primary Source of Truth: Firebase Firestore
    try {
      await FirebaseService.saveReview(newReview);
    } catch (e: any) {
      console.error('Error crítico al guardar reseña en Firestore:', e);
      throw new Error(`No se pudo guardar la reseña en Firebase: ${e.message || e}`);
    }

    // 2. Secondary update to local cache ONLY after Firestore confirms
    const localList = getLocalReviews();
    saveLocalReviews([newReview, ...localList]);

    // 3. Optional Backend API notification (non-blocking)
    try {
      await fetch('/api/reviews', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newReview)
      });
    } catch {
      // Static fallback
    }

    return newReview;
  },

  async updateReview(id: string, updates: Partial<Review>): Promise<Review> {
    const existingReviews = await this.getReviews();
    const current = existingReviews.find(r => r.id === id);
    const rawUpdated: Review = { ...(current || ({} as Review)), ...updates, id };

    let updated = rawUpdated;
    try {
      updated = await ensureImagesInCloudStorage(rawUpdated, 'reviews');
    } catch (e) {
      console.warn('Could not upload review update images to Cloud Storage:', e);
    }

    // 1. Primary Source of Truth: Firebase Firestore
    try {
      await FirebaseService.saveReview(updated);
    } catch (e: any) {
      console.error('Error crítico al actualizar reseña en Firestore:', e);
      throw new Error(`No se pudo actualizar la reseña en Firebase: ${e.message || e}`);
    }

    // 2. Secondary update to local cache ONLY after Firestore confirms
    const localList = getLocalReviews();
    const idx = localList.findIndex(r => r.id === id);
    if (idx !== -1) {
      localList[idx] = updated;
      saveLocalReviews(localList);
    }

    // 3. Optional Backend API notification (non-blocking)
    const token = this.getToken();
    try {
      await fetch(`/api/reviews/${id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { 'Authorization': `Bearer ${token}` } : {})
        },
        body: JSON.stringify(updates)
      });
    } catch {
      // Static fallback
    }

    return updated;
  },

  async markReviewHelpful(id: string): Promise<{ success: boolean; helpfulCount: number }> {
    const list = await this.getReviews();
    const review = list.find(r => r.id === id);
    if (review) {
      const newCount = (review.helpfulCount || 0) + 1;
      await this.updateReview(id, { helpfulCount: newCount });
      return { success: true, helpfulCount: newCount };
    }
    return { success: true, helpfulCount: 1 };
  },

  async deleteReview(id: string): Promise<boolean> {
    if (!id) throw new Error('ID de reseña no válido para eliminación.');

    // 1. Primary Source of Truth: Firebase Firestore
    try {
      await FirebaseService.deleteReview(id);
    } catch (e: any) {
      console.error('Error crítico al eliminar reseña en Firestore:', e);
      throw new Error(`No se pudo eliminar la reseña en Firebase: ${e.message || e}`);
    }

    // 2. Sync Local Cache only after successful Firestore deletion
    const localList = getLocalReviews();
    saveLocalReviews(localList.filter(r => r.id !== id));

    // 3. Optional Backend notification (non-blocking)
    const token = this.getToken();
    try {
      await fetch(`/api/reviews/${id}`, {
        method: 'DELETE',
        headers: { ...(token ? { 'Authorization': `Bearer ${token}` } : {}) }
      });
    } catch {
      // Static fallback
    }

    return true;
  },

  async resetToSeed(): Promise<boolean> {
    try {
      await FirebaseService.backupAllToFirestore({
        products: INITIAL_PRODUCTS,
        categories: INITIAL_CATEGORIES,
        banners: INITIAL_BANNERS,
        settings: INITIAL_SETTINGS,
        reviews: INITIAL_REVIEWS
      });
      return true;
    } catch (e) {
      console.warn('Failed to reset seed to Firestore:', e);
      return false;
    }
  },

  // ----------------------------------------------------
  // ANALYTICS & STATISTICS
  // ----------------------------------------------------
  async recordAnalyticsEvent(event: Omit<AnalyticsEvent, 'id' | 'timestamp'>): Promise<void> {
    try {
      await FirebaseService.recordAnalyticsEvent(event);
    } catch (e) {
      console.warn('Could not record analytics event:', e);
    }
  },

  async getDailyAnalytics(days = 14, products: Product[] = []): Promise<DailyAnalyticsPoint[]> {
    try {
      return await FirebaseService.getDailyAnalytics(days, products);
    } catch (e) {
      console.warn('Error fetching daily analytics:', e);
      return [];
    }
  },

  async getRecentAnalyticsEvents(limit = 50): Promise<AnalyticsEvent[]> {
    try {
      return await FirebaseService.getRecentAnalyticsEvents(limit);
    } catch (e) {
      console.warn('Error fetching recent analytics events:', e);
      return [];
    }
  }
};
