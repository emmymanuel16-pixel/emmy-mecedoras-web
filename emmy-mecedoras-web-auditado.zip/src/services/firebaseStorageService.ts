import { ref, uploadBytes, getDownloadURL, deleteObject } from 'firebase/storage';
import { storage } from '../firebase';

export interface StorageUploadResult {
  url: string;
  storagePath: string;
  isCloudStorage: boolean;
  error?: string;
}

/**
 * Validates whether a file is a supported image and within size limits (<= 15MB).
 */
export function validateImageFile(file: File): { valid: boolean; error?: string } {
  if (!file) {
    return { valid: false, error: 'No se ha seleccionado ningún archivo.' };
  }
  const validTypes = ['image/jpeg', 'image/png', 'image/webp', 'image/gif', 'image/svg+xml'];
  if (!validTypes.includes(file.type.toLowerCase())) {
    return {
      valid: false,
      error: `Formato de imagen no soportado (${file.type}). Por favor usa JPG, PNG, WEBP o GIF.`
    };
  }
  const maxBytes = 15 * 1024 * 1024; // 15MB
  if (file.size > maxBytes) {
    return {
      valid: false,
      error: `El archivo excede el tamaño máximo permitido de 15 MB (tamaño: ${(file.size / (1024 * 1024)).toFixed(1)} MB).`
    };
  }
  return { valid: true };
}

/**
 * Checks if a string is already a valid Firebase Cloud Storage URL.
 */
export function isFirebaseStorageUrl(url: string): boolean {
  if (!url || typeof url !== 'string') return false;
  return url.includes('firebasestorage.googleapis.com') || url.includes('storage.googleapis.com');
}

/**
 * Extracts the storage bucket path from a Firebase Storage public download URL.
 * Example URL:
 * https://firebasestorage.googleapis.com/v0/b/{bucket}/o/productos%2F12345_abc.webp?alt=media&token=...
 * Output: "productos/12345_abc.webp"
 */
export function extractStoragePathFromUrl(url: string): string | null {
  if (!url || typeof url !== 'string') return null;

  // If already a relative storage path (e.g., "productos/12345_abc.webp")
  if (!url.startsWith('http://') && !url.startsWith('https://') && !url.startsWith('data:') && !url.startsWith('/')) {
    return url;
  }

  if (!isFirebaseStorageUrl(url)) {
    return null;
  }

  try {
    const urlObj = new URL(url);
    const pathname = urlObj.pathname;
    const match = pathname.match(/\/o\/(.+)$/);
    if (match && match[1]) {
      return decodeURIComponent(match[1]);
    }
  } catch {
    // Malformed URL
  }
  return null;
}

/**
 * Converts a base64 data URL string to a standard Blob.
 */
export function base64ToBlob(base64: string): Blob {
  const parts = base64.split(';base64,');
  const contentType = parts[0].replace('data:', '') || 'image/webp';
  const raw = atob(parts[1] || parts[0]);
  const rawLength = raw.length;
  const uInt8Array = new Uint8Array(rawLength);
  for (let i = 0; i < rawLength; ++i) {
    uInt8Array[i] = raw.charCodeAt(i);
  }
  return new Blob([uInt8Array], { type: contentType });
}

/**
 * Compresses an image in the browser and returns a WebP blob before upload.
 */
async function compressImageToBlob(source: File | Blob): Promise<Blob> {
  if (typeof window === 'undefined' || typeof document === 'undefined') {
    return source;
  }
  if (source.type === 'image/svg+xml') {
    return source;
  }

  return new Promise((resolve) => {
    const img = new Image();
    const url = URL.createObjectURL(source);
    img.src = url;

    img.onload = () => {
      URL.revokeObjectURL(url);
      const maxDim = 1600;
      let { width, height } = img;
      if (width > maxDim || height > maxDim) {
        const ratio = Math.min(maxDim / width, maxDim / height);
        width = Math.round(width * ratio);
        height = Math.round(height * ratio);
      }

      const canvas = document.createElement('canvas');
      canvas.width = width;
      canvas.height = height;
      const ctx = canvas.getContext('2d');
      if (!ctx) {
        resolve(source);
        return;
      }
      ctx.drawImage(img, 0, 0, width, height);

      canvas.toBlob(
        (blob) => {
          resolve(blob || source);
        },
        'image/webp',
        0.85
      );
    };

    img.onerror = () => {
      URL.revokeObjectURL(url);
      resolve(source);
    };
  });
}

/**
 * Uploads an image directly to Firebase Cloud Storage following the mandatory pipeline:
 * USUARIO SELECCIONA IMAGEN -> VALIDACIÓN -> COMPRESIÓN -> FIREBASE STORAGE -> getDownloadURL() -> URL PERMANENTE
 * 
 * Strict error handling: If storage upload fails, stops the operation and NEVER falls back to base64.
 */
export async function uploadToFirebaseStorage(
  source: File | Blob | string,
  folder: string = 'productos',
  customId?: string
): Promise<string> {
  // If already a valid Firebase Storage download URL, return it as is
  if (typeof source === 'string' && isFirebaseStorageUrl(source)) {
    return source;
  }

  // If external static image URL (e.g. Unsplash), return as is
  if (
    typeof source === 'string' &&
    (source.startsWith('http://') || source.startsWith('https://')) &&
    !source.includes('localhost') &&
    !source.includes('127.0.0.1')
  ) {
    return source;
  }

  if (!storage) {
    throw new Error('No se pudo guardar la imagen en Firebase Storage. Inténtalo nuevamente.');
  }

  let blob: Blob;
  let ext = 'webp';

  if (typeof source === 'string') {
    if (!source.startsWith('data:image/')) {
      throw new Error('No se pudo guardar la imagen en Firebase Storage. Inténtalo nuevamente.');
    }
    blob = base64ToBlob(source);
  } else if (source instanceof File) {
    const validation = validateImageFile(source);
    if (!validation.valid) {
      throw new Error(validation.error || 'Formato de imagen no válido');
    }
    blob = await compressImageToBlob(source);
  } else {
    blob = await compressImageToBlob(source);
  }

  if (blob.type) {
    if (blob.type.includes('webp')) ext = 'webp';
    else if (blob.type.includes('png')) ext = 'png';
    else if (blob.type.includes('jpeg') || blob.type.includes('jpg')) ext = 'jpg';
    else if (blob.type.includes('svg')) ext = 'svg';
  }

  // Official folder mapping per Firebase architecture specification:
  // productos, categorias, banners, telas, estampados, textalinas, ribetes, configuracion, reviews
  const cleanFolder = (folder || 'productos').trim().replace(/^\/+|\/+$/g, '') || 'productos';
  const timestamp = Date.now();
  const randomSuffix = Math.random().toString(36).substring(2, 9);
  const identifier = customId ? `${customId.replace(/[^a-zA-Z0-9_-]/g, '')}/` : '';
  const fileName = `${cleanFolder}/${identifier}img_${timestamp}_${randomSuffix}.${ext}`;

  try {
    const storageRef = ref(storage, fileName);
    const snapshot = await uploadBytes(storageRef, blob, {
      contentType: blob.type || `image/${ext}`,
      cacheControl: 'public, max-age=31536000',
    });

    const downloadUrl = await getDownloadURL(snapshot.ref);
    if (!downloadUrl || !isFirebaseStorageUrl(downloadUrl)) {
      throw new Error('No se pudo guardar la imagen en Firebase Storage. Inténtalo nuevamente.');
    }
    return downloadUrl;
  } catch (err: any) {
    console.error(`[Firebase Storage Error] Fallo al subir a ${fileName}:`, err);
    // Preserve the Firebase reason so the UI can tell the administrator what actually failed.
    const detail = err?.code ? `${err.code}: ${err?.message || 'Error de Firebase Storage'}` : (err?.message || String(err));
    throw new Error(`No se pudo guardar la imagen en Firebase Storage. ${detail}`);
  }
}

/**
 * Uploads an image and returns both the URL and the storagePath.
 */
export async function uploadImageWithStoragePath(
  source: File | Blob | string,
  folder: string = 'productos',
  customId?: string
): Promise<{ url: string; storagePath: string }> {
  const url = await uploadToFirebaseStorage(source, folder, customId);
  const storagePath = extractStoragePathFromUrl(url) || '';
  return { url, storagePath };
}

/**
 * Safely deletes a file from Firebase Cloud Storage given its public URL or storage path.
 * Non-blocking: treats 404 (not found) as a successful cleanup of orphaned records.
 */
export async function deleteFromFirebaseStorage(urlOrPath: string): Promise<boolean> {
  if (!storage || !urlOrPath || typeof urlOrPath !== 'string') {
    return false;
  }

  const path = extractStoragePathFromUrl(urlOrPath);
  if (!path) {
    // Not a Firebase Storage file (e.g. Unsplash URL or placeholder)
    return false;
  }

  try {
    const fileRef = ref(storage, path);
    await deleteObject(fileRef);
    return true;
  } catch (error: any) {
    if (error?.code === 'storage/object-not-found') {
      return true;
    }
    console.error(`No se pudo eliminar archivo de Firebase Storage (${path}):`, error?.message || error);
    throw error;
  }
}

/**
 * Uploads multiple images sequentially to Firebase Cloud Storage.
 */
export async function uploadMultipleToFirebaseStorage(
  sources: (File | Blob | string)[],
  folder: string = 'productos',
  onProgress?: (processed: number, total: number) => void
): Promise<string[]> {
  const results: string[] = [];
  const total = sources.length;

  for (let i = 0; i < total; i++) {
    const src = sources[i];
    const url = await uploadToFirebaseStorage(src, folder);
    results.push(url);
    if (onProgress) {
      onProgress(i + 1, total);
    }
  }

  return results;
}
