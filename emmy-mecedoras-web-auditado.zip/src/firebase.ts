import { initializeApp, getApps, getApp } from 'firebase/app';
import { getAuth, GoogleAuthProvider, browserLocalPersistence, setPersistence } from 'firebase/auth';
import { getFirestore, initializeFirestore, persistentLocalCache, persistentMultipleTabManager } from 'firebase/firestore';
import { getStorage, FirebaseStorage } from 'firebase/storage';
import firebaseConfig from '../firebase-applet-config.json';

// Configuration: Prefer Vite environment variables if defined, otherwise fall back to firebase-applet-config.json
const env = typeof import.meta !== 'undefined' && (import.meta as any).env ? (import.meta as any).env : {};
const resolvedConfig = {
  apiKey: env.VITE_FIREBASE_API_KEY || firebaseConfig.apiKey,
  authDomain: env.VITE_FIREBASE_AUTH_DOMAIN || firebaseConfig.authDomain,
  projectId: env.VITE_FIREBASE_PROJECT_ID || firebaseConfig.projectId,
  storageBucket: env.VITE_FIREBASE_STORAGE_BUCKET || firebaseConfig.storageBucket,
  messagingSenderId: env.VITE_FIREBASE_MESSAGING_SENDER_ID || firebaseConfig.messagingSenderId,
  appId: env.VITE_FIREBASE_APP_ID || firebaseConfig.appId,
  firestoreDatabaseId: env.VITE_FIREBASE_DATABASE_ID || firebaseConfig.firestoreDatabaseId,
};

// Initialize Firebase App instance (singleton)
export const app = !getApps().length ? initializeApp(resolvedConfig) : getApp();

// Authentication setup
export const auth = getAuth(app);
export const googleProvider = new GoogleAuthProvider();
googleProvider.setCustomParameters({ prompt: 'select_account' });

// Ensure persistence in browser
try {
  setPersistence(auth, browserLocalPersistence).catch(() => {
    // Graceful fallback for restricted iframe environments
  });
} catch {
  // Ignore in restricted environments
}

// Firestore Database setup with custom databaseId support
let firestoreDb;
const targetDbId = resolvedConfig.firestoreDatabaseId;
try {
  if (targetDbId && targetDbId !== '(default)') {
    try {
      firestoreDb = initializeFirestore(app, {
        localCache: persistentLocalCache({ tabManager: persistentMultipleTabManager() })
      }, targetDbId);
    } catch {
      firestoreDb = getFirestore(app, targetDbId);
    }
  } else {
    firestoreDb = getFirestore(app);
  }
} catch {
  firestoreDb = getFirestore(app);
}

export const db = firestoreDb;

// Firebase Storage setup
let storageInstance: FirebaseStorage | null = null;
try {
  const bucketName = resolvedConfig.storageBucket;
  if (bucketName) {
    const formattedBucket = bucketName.startsWith('gs://') ? bucketName : `gs://${bucketName}`;
    storageInstance = getStorage(app, formattedBucket);
  } else {
    storageInstance = getStorage(app);
  }
} catch (e) {
  console.warn('Firebase Storage initialization notice:', e);
  try {
    storageInstance = getStorage(app);
  } catch {
    // Storage will report unavailable if not enabled in console
  }
}

export const storage = storageInstance;
