import React, { useRef } from 'react';
import { ChevronLeft, ChevronRight, ArrowRight } from 'lucide-react';
import { Category, Product, StoreSettings } from '../types';
import { ProductCard } from './ProductCard';

interface CategoryCarouselSectionProps {
  category: Category;
  products: Product[];
  settings: StoreSettings;
  onSelectProduct: (product: Product) => void;
  onViewAllCategory: (categoryId: string) => void;
}

export const CategoryCarouselSection = React.memo<CategoryCarouselSectionProps>(({
  category,
  products,
  settings,
  onSelectProduct,
  onViewAllCategory,
}) => {
  const carouselRef = useRef<HTMLDivElement>(null);

  if (products.length === 0) return null;

  const scrollLeft = () => {
    if (carouselRef.current) {
      carouselRef.current.scrollBy({ left: -320, behavior: 'smooth' });
    }
  };

  const scrollRight = () => {
    if (carouselRef.current) {
      carouselRef.current.scrollBy({ left: 320, behavior: 'smooth' });
    }
  };

  return (
    <section id={`section-${category.id}`} className="py-6 sm:py-9">
      {/* Category Header */}
      <div className="flex items-end justify-between mb-4 sm:mb-6 px-1">
        <div>
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-[#5C4033]" />
            <h2 className="font-serif text-xl sm:text-2xl md:text-3xl font-bold text-[#2C1810] tracking-tight">
              {category.name}
            </h2>
          </div>
          {category.description && (
            <p className="text-xs sm:text-sm text-[#7A6A60] mt-1 max-w-2xl line-clamp-1 sm:line-clamp-none font-normal">
              {category.description}
            </p>
          )}
        </div>

        {/* Action button & navigation arrows */}
        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={() => onViewAllCategory(category.id)}
            className="text-xs sm:text-sm font-semibold text-[#5C4033] hover:text-[#2C1810] flex items-center gap-1 transition-colors px-2 py-1"
          >
            <span>Ver todas</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>

          {/* Desktop scroll arrows */}
          <div className="hidden sm:flex items-center gap-1.5 ml-2">
            <button
              onClick={scrollLeft}
              className="p-2 rounded-full border border-[#E8E2DC] bg-white hover:bg-[#F0EBE6] text-[#2C1810] transition-colors shadow-2xs"
              aria-label="Desplazar a la izquierda"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              onClick={scrollRight}
              className="p-2 rounded-full border border-[#E8E2DC] bg-white hover:bg-[#F0EBE6] text-[#2C1810] transition-colors shadow-2xs"
              aria-label="Desplazar a la derecha"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Horizontal Carousel Track (showing 1.2 to 1.5 cards on mobile, 3 to 4 on desktop) */}
      <div
        ref={carouselRef}
        className="flex items-stretch gap-4 sm:gap-6 overflow-x-auto no-scrollbar scroll-smooth snap-x-mandatory pb-4 -mx-4 px-4 sm:mx-0 sm:px-0"
      >
        {products.map((product) => (
          <div
            key={product.id}
            className="snap-start-align shrink-0 w-[74vw] xs:w-[68vw] sm:w-[300px] md:w-[320px] lg:w-[340px]"
          >
            <ProductCard
              product={product}
              settings={settings}
              onSelectProduct={onSelectProduct}
            />
          </div>
        ))}
      </div>
    </section>
  );
});
