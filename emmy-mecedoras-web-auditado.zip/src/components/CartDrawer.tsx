import React, { useState } from 'react';
import { X, Trash2, Plus, Minus, MessageCircle, ShoppingBag, ArrowRight, ShieldCheck } from 'lucide-react';
import { CartItem, StoreSettings } from '../types';
import { formatPrice, generateCartWhatsAppUrl } from '../utils/whatsapp';
import { FirebaseService } from '../services/firebaseService';
import confetti from 'canvas-confetti';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  settings: StoreSettings;
  onUpdateQuantity: (cartItemId: string, newQty: number) => void;
  onRemoveItem: (cartItemId: string) => void;
  onClearCart: () => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  items,
  settings,
  onUpdateQuantity,
  onRemoveItem,
  onClearCart,
}) => {
  const [customerNotes, setCustomerNotes] = useState('');

  if (!isOpen) return null;

  const total = items.reduce((sum, item) => sum + item.unitPrice * item.quantity, 0);
  const totalCount = items.reduce((sum, item) => sum + item.quantity, 0);

  const handleOrderViaWhatsApp = () => {
    if (items.length === 0) return;

    // Save order snapshot to Firebase Firestore and record analytics
    try {
      FirebaseService.saveOrder({
        id: `ord_${Date.now()}`,
        items: items.map(it => ({
          productId: it.productId,
          productName: it.product.name,
          quantity: it.quantity,
          selectedColor: it.selectedColor,
          selectedCushionColor: it.selectedCushionColor,
          unitPrice: it.unitPrice,
          subtotal: it.unitPrice * it.quantity
        })),
        totalAmount: total,
        customerNotes,
        createdAt: new Date().toISOString()
      });

      // Record analytics for each product ordered
      items.forEach(it => {
        FirebaseService.recordAnalyticsEvent({
          type: 'whatsapp_order',
          productId: it.productId,
          productName: it.product.name,
          categoryId: it.product.categoryId,
          price: it.unitPrice * it.quantity,
          metadata: {
            quantity: it.quantity,
            color: it.selectedColor,
            cushionColor: it.selectedCushionColor,
            source: 'cart_drawer'
          }
        });
      });
    } catch {
      // Background non-blocking
    }

    confetti({
      particleCount: 70,
      spread: 80,
      origin: { y: 0.7 },
      colors: ['#25D366', '#8a532b', '#ffffff']
    });

    const url = generateCartWhatsAppUrl(items, settings, customerNotes);
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden animate-fadeIn">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-[#2C1810]/60 backdrop-blur-xs transition-opacity"
        onClick={onClose}
      />

      <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-[#FDFCFB] shadow-2xl flex flex-col border-l border-[#F0EBE6]">
          
          {/* Header */}
          <div className="p-5 bg-white border-b border-[#F0EBE6] flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-xl bg-[#F0EBE6] text-[#5C4033]">
                <ShoppingBag className="w-5 h-5" />
              </div>
              <div>
                <h2 className="font-serif text-lg font-bold text-[#2C1810]">Carrito de Compras</h2>
                <p className="text-xs text-[#7A6A60]">{totalCount} {totalCount === 1 ? 'artículo' : 'artículos'}</p>
              </div>
            </div>

            <button
              onClick={onClose}
              className="p-2 rounded-xl text-[#7A6A60] hover:text-[#2C1810] hover:bg-[#F0EBE6] transition-colors"
              aria-label="Cerrar carrito"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Items List */}
          <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-3">
            {items.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center p-6 space-y-4">
                <div className="w-16 h-16 rounded-full bg-[#F0EBE6] flex items-center justify-center text-[#8C7A70]">
                  <ShoppingBag className="w-8 h-8" />
                </div>
                <div>
                  <h3 className="font-serif text-base font-bold text-[#2C1810]">Tu carrito está vacío</h3>
                  <p className="text-xs text-[#7A6A60] mt-1 max-w-xs">
                    Explora nuestras mecedoras artesanales, medio juegos y cojines para armar tu pedido.
                  </p>
                </div>
                <button
                  onClick={onClose}
                  className="px-5 py-2.5 rounded-xl bg-[#5C4033] text-white text-xs font-bold uppercase tracking-widest hover:bg-[#3E2723] transition-all"
                >
                  Explorar Catálogo
                </button>
              </div>
            ) : (
              <>
                {items.map((item) => (
                  <div
                    key={item.id}
                    className="p-3 bg-white rounded-2xl border border-[#F0EBE6] card-shadow flex gap-3 items-center"
                  >
                    {/* Thumbnail */}
                    <img
                      src={item.product.mainImage || 'https://images.unsplash.com/photo-1586023492125-27b2c045efd7?auto=format&fit=crop&w=400&q=80'}
                      alt={item.product.name}
                      referrerPolicy="no-referrer"
                      className="w-18 h-18 rounded-xl object-cover bg-[#F0EBE6] shrink-0"
                      onError={(e) => {
                        (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1586023492125-27b2c045efd7?auto=format&fit=crop&w=400&q=80';
                      }}
                    />

                    {/* Details */}
                    <div className="flex-1 min-w-0">
                      <h4 className="text-xs sm:text-sm font-bold text-[#2C1810] truncate font-serif">
                        {item.product.name}
                      </h4>
                      
                      {/* Selected Options / Variants or 3D Customization */}
                      {item.customization ? (
                        <div className="mt-1 p-2 rounded-xl bg-[#F6F4F0] border border-[#E8E2DC] text-[11px] text-[#5C4033] space-y-1">
                          <div className="flex items-center gap-1 text-[10px] font-bold text-[#8a532b] uppercase tracking-wider">
                            <span>🎨 Configuración 3D</span>
                          </div>
                          <div>
                            • Mecedora: <strong className="text-[#2C1810]">{item.customization.rockerColor.name}</strong>
                          </div>
                          <div>
                            • Cojín: <strong className="text-[#8a532b]">{item.customization.hasCushion && item.customization.fabric ? item.customization.fabric.name : 'Sin cojines'}</strong>
                          </div>
                          {item.customization.selectedAccessories && item.customization.selectedAccessories.length > 0 && (
                            <div className="text-[10px] text-[#7A6A60]">
                              • Extras: {item.customization.selectedAccessories.map(a => a.name).join(', ')}
                            </div>
                          )}
                        </div>
                      ) : (
                        <div className="text-[11px] text-[#7A6A60] space-y-0.5 mt-0.5">
                          {item.selectedFabricType && (
                            <span className="inline-block mr-2">
                              • Tela: <strong className="text-[#8a532b]">{item.selectedFabricType}</strong>
                            </span>
                          )}
                          {item.selectedColor && (
                            <span className="inline-block mr-2">
                              • Color mecedora: <strong className="text-[#2C1810]">{item.selectedColor}</strong>
                            </span>
                          )}
                          {item.selectedPatternName && (
                            <span className="inline-flex items-center gap-1 mr-2">
                              • Estampado: <strong className="text-[#2C1810]">{item.selectedPatternName}</strong>
                              {item.selectedPatternImage && (
                                <img
                                  src={item.selectedPatternImage}
                                  alt={item.selectedPatternName}
                                  className="w-4 h-4 rounded-full object-cover border border-stone-300 inline-block"
                                />
                              )}
                            </span>
                          )}
                          {!item.selectedPatternName && item.selectedCushionColor && (
                            <span className="inline-flex items-center gap-1 mr-2">
                              • Color cojín: <strong className="text-[#2C1810]">{item.selectedCushionColor}</strong>
                              {item.selectedTextalinaImage && (
                                <img
                                  src={item.selectedTextalinaImage}
                                  alt={item.selectedCushionColor}
                                  className="w-4 h-4 rounded-full object-cover border border-stone-300 inline-block shadow-2xs"
                                />
                              )}
                            </span>
                          )}
                          {item.selectedBorderColor && (
                            <span className="inline-block mr-2">
                              • Bordes/Ribete: <strong className="text-[#8a532b]">{item.selectedBorderColor}</strong>
                            </span>
                          )}
                          {item.selectedBackrestStyle && (
                            <span className="inline-block mr-2">
                              • Espaldar: <strong className="text-[#2C1810]">{item.selectedBackrestStyle === 'botones' ? 'Capitoneado (Con Botones)' : 'Con Costura'}</strong>
                            </span>
                          )}
                          {item.selectedFinish && (
                            <span className="inline-block mr-2">
                              • Acabado: <strong className="text-[#2C1810]">{item.selectedFinish}</strong>
                            </span>
                          )}
                          {item.selectedSize && (
                            <span className="inline-block mr-2">
                              • Tamaño: <strong className="text-[#2C1810]">{item.selectedSize}</strong>
                            </span>
                          )}
                        </div>
                      )}

                      {/* Price & Quantity Controls */}
                      <div className="flex items-center justify-between mt-2">
                        <span className="text-xs sm:text-sm font-extrabold text-[#2C1810]">
                          {formatPrice(item.unitPrice * item.quantity, settings.currency)}
                        </span>

                        <div className="flex items-center border border-[#E8E2DC] rounded-lg bg-[#FDFCFB]">
                          <button
                            onClick={() => onUpdateQuantity(item.id, item.quantity - 1)}
                            className="p-1 text-[#5C4033] hover:bg-[#F0EBE6] rounded-l-lg transition-colors"
                            aria-label="Disminuir cantidad"
                          >
                            <Minus className="w-3.5 h-3.5" />
                          </button>
                          <span className="px-2 text-xs font-bold text-[#2C1810]">
                            {item.quantity}
                          </span>
                          <button
                            onClick={() => onUpdateQuantity(item.id, item.quantity + 1)}
                            className="p-1 text-[#5C4033] hover:bg-[#F0EBE6] rounded-r-lg transition-colors"
                            aria-label="Aumentar cantidad"
                          >
                            <Plus className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    </div>

                    {/* Delete button */}
                    <button
                      onClick={() => onRemoveItem(item.id)}
                      className="p-1.5 text-[#9A8A80] hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                      title="Eliminar del carrito"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}

                {/* Customer Notes */}
                <div className="pt-2">
                  <label className="text-[11px] font-semibold text-[#5C4033] block mb-1">
                    Instrucciones o detalles especiales del pedido (opcional):
                  </label>
                  <textarea
                    value={customerNotes}
                    onChange={(e) => setCustomerNotes(e.target.value)}
                    placeholder="Ej. Tono nogal oscuro, entrega preferible en fin de semana..."
                    rows={2}
                    className="w-full text-xs p-2.5 bg-white border border-[#E8E2DC] rounded-xl focus:ring-1 focus:ring-[#5C4033] focus:outline-none placeholder:text-[#9A8A80]"
                  />
                </div>
              </>
            )}
          </div>

          {/* Footer with Subtotal and WhatsApp CTA */}
          {items.length > 0 && (
            <div className="p-5 bg-white border-t border-[#F0EBE6] space-y-4">
              <div className="space-y-1.5">
                <div className="flex justify-between text-xs text-[#7A6A60]">
                  <span>Subtotal ({totalCount} productos):</span>
                  <span>{formatPrice(total, settings.currency)}</span>
                </div>
                <div className="flex justify-between text-xs text-[#7A6A60]">
                  <span>Embalaje protector artesanal:</span>
                  <span className="text-emerald-800 font-semibold">Gratis</span>
                </div>
                <div className="flex justify-between text-base font-extrabold text-[#2C1810] pt-1 border-t border-[#F0EBE6]">
                  <span>Total estimado:</span>
                  <span className="text-lg text-[#5C4033]">
                    {formatPrice(total, settings.currency)}
                  </span>
                </div>
              </div>

              {/* The Iconic Green "PEDIR POR WHATSAPP" Button */}
              <button
                id="cart-whatsapp-order-btn"
                onClick={handleOrderViaWhatsApp}
                className="w-full py-4 px-4 rounded-2xl bg-[#25D366] hover:bg-[#20BD5A] text-white font-extrabold text-sm sm:text-base flex items-center justify-center gap-3 transition-all shadow-lg shadow-emerald-900/20 active:scale-98 cursor-pointer tracking-wider uppercase"
              >
                <MessageCircle className="w-6 h-6 fill-current shrink-0" />
                <span>PEDIR POR WHATSAPP</span>
              </button>

              <div className="flex items-center justify-center gap-2 text-[11px] text-[#8C7A70]">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-700" />
                <span>Atención directa y personalizada con el taller</span>
              </div>
            </div>
          )}

        </div>
      </div>
    </div>
  );
};
