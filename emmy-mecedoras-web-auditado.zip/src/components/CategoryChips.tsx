import React, { useRef } from 'react';
import { Category } from '../types';
import { Sparkles, Layers, Tag } from 'lucide-react';

interface CategoryChipsProps {
  categories: Category[];
  selectedCategory: string;
  onSelectCategory: (categoryId: string) => void;
  showOffersOnly?: boolean;
  onToggleOffers?: () => void;
}

export const CategoryChips = React.memo<CategoryChipsProps>(({
  categories,
  selectedCategory,
  onSelectCategory,
  showOffersOnly,
  onToggleOffers,
}) => {
  const scrollRef = useRef<HTMLDivElement>(null);

  const activeCategories = [...categories]
    .filter((c) => c.isActive)
    .sort((a, b) => (a.order ?? 0) - (b.order ?? 0));

  return (
    <div className="w-full bg-[#FDFCFB] border-b border-[#F0EBE6] sticky top-16 sm:top-20 z-30 shadow-2xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3">
        {/* Horizontal scroll container with hide-scrollbar and swipe support */}
        <div
          ref={scrollRef}
          className="flex items-center gap-2 overflow-x-auto no-scrollbar scroll-smooth py-1 -mx-4 px-4 sm:mx-0 sm:px-0"
        >
          {/* "Todos" Chip */}
          <button
            id="cat-chip-all"
            onClick={() => onSelectCategory('all')}
            className={`px-5 py-2 rounded-full text-xs sm:text-sm font-semibold tracking-wide whitespace-nowrap transition-all transform active:scale-95 flex items-center gap-1.5 shrink-0 ${
              selectedCategory === 'all' && !showOffersOnly
                ? 'bg-[#2C1810] text-[#FDFCFB] shadow-sm'
                : 'bg-white text-[#5C4033] hover:bg-[#F0EBE6] border border-[#E8E2DC] shadow-2xs'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Todos</span>
          </button>

          {/* Dynamic Categories Chips */}
          {activeCategories.map((category) => {
            const isSelected = selectedCategory === category.id && !showOffersOnly;
            return (
              <button
                key={category.id}
                id={`cat-chip-${category.id}`}
                onClick={() => onSelectCategory(category.id)}
                className={`px-4 sm:px-5 py-2 rounded-full text-xs sm:text-sm font-medium tracking-wide whitespace-nowrap transition-all transform active:scale-95 flex items-center gap-1.5 shrink-0 ${
                  isSelected
                    ? 'bg-[#2C1810] text-[#FDFCFB] shadow-sm'
                    : 'bg-white text-[#5C4033] hover:bg-[#F0EBE6] border border-[#E8E2DC] shadow-2xs'
                }`}
              >
                <span>{category.name}</span>
              </button>
            );
          })}

          {/* "Ofertas" Chip */}
          {onToggleOffers && (
            <button
              id="cat-chip-offers"
              onClick={onToggleOffers}
              className={`px-4 sm:px-5 py-2 rounded-full text-xs sm:text-sm font-semibold tracking-wide whitespace-nowrap transition-all transform active:scale-95 flex items-center gap-1.5 shrink-0 ${
                showOffersOnly
                  ? 'bg-[#9C2727] text-white shadow-sm'
                  : 'bg-rose-50 text-rose-900 hover:bg-rose-100 border border-rose-200 shadow-2xs'
              }`}
            >
              <Tag className="w-3.5 h-3.5" />
              <span>Ofertas</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
});
