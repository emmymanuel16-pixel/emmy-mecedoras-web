import React from 'react';
import { Category, StoreSettings } from '../types';
import { ShieldCheck, Truck, Clock, MapPin, Phone, Mail, Instagram, Facebook, Lock, ExternalLink } from 'lucide-react';
import { generateSupportWhatsAppUrl } from '../utils/whatsapp';

interface FooterProps {
  settings: StoreSettings;
  categories: Category[];
  onSelectCategory: (id: string) => void;
  onOpenAdmin: () => void;
}

export const Footer: React.FC<FooterProps> = ({
  settings,
  categories,
  onSelectCategory,
  onOpenAdmin,
}) => {
  return (
    <footer className="bg-[#2C1810] text-[#C5B5A5] pt-12 pb-12 border-t border-[#3E2723]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        
        {/* Value Proposition Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 pb-10 border-b border-[#3E2723] text-[#FDFCFB]">
          <div className="flex items-center gap-3 p-4 rounded-2xl bg-white/5 border border-white/5">
            <div className="p-3 rounded-xl bg-[#5C4033]/60 text-[#D4AF37]">
              <Truck className="w-6 h-6" />
            </div>
            <div>
              <h4 className="font-bold text-sm text-[#FDFCFB]">Envíos Especializados</h4>
              <p className="text-xs text-[#A8988C]">Embalaje acolchado de alta protección</p>
            </div>
          </div>

          <div className="flex items-center gap-3 p-4 rounded-2xl bg-white/5 border border-white/5">
            <div className="p-3 rounded-xl bg-[#5C4033]/60 text-[#D4AF37]">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <h4 className="font-bold text-sm text-[#FDFCFB]">Fibra de Vidrio Premium</h4>
              <p className="text-xs text-[#A8988C]">Alta resistencia, ligereza y durabilidad</p>
            </div>
          </div>

          <div className="flex items-center gap-3 p-4 rounded-2xl bg-white/5 border border-white/5">
            <div className="p-3 rounded-xl bg-[#5C4033]/60 text-[#D4AF37]">
              <Clock className="w-6 h-6" />
            </div>
            <div>
              <h4 className="font-bold text-sm text-[#FDFCFB]">Atención Inmediata</h4>
              <p className="text-xs text-[#A8988C]">Cotizaciones y pedidos por WhatsApp</p>
            </div>
          </div>
        </div>

        {/* Main Footer Columns */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 py-10">
          
          {/* Brand Info & Social Networks */}
          <div className="space-y-3 md:col-span-1">
            <h3 className="font-serif italic text-2xl font-bold text-[#F7EEDF]">
              {settings.storeName}
            </h3>
            <p className="text-xs text-[#A8988C] leading-relaxed">
              Especialistas en la fabricación de mecedoras en fibra de vidrio de alta resistencia, medio juegos, combinaciones con sofá y cojinería ergonómica.
            </p>
            
            {/* Direct Social & WhatsApp Buttons */}
            <div className="pt-2 flex flex-col gap-2">
              <a
                href={generateSupportWhatsAppUrl(settings)}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-[#25D366] text-white text-xs font-bold hover:bg-[#20BD5A] transition-colors shadow-xs"
              >
                <span>Chatear por WhatsApp: {settings.contactInformation.phone}</span>
              </a>

              <div className="flex items-center gap-2 pt-1">
                {settings.socialNetworks?.instagram && (
                  <a
                    href={settings.socialNetworks.instagram}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex-1 inline-flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl bg-gradient-to-r from-[#833ab4] via-[#fd1d1d] to-[#fcb045] text-white text-xs font-bold hover:opacity-90 transition-opacity shadow-xs"
                  >
                    <Instagram className="w-4 h-4" />
                    <span>Instagram</span>
                  </a>
                )}
                {settings.socialNetworks?.facebook && (
                  <a
                    href={settings.socialNetworks.facebook}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex-1 inline-flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl bg-[#1877F2] text-white text-xs font-bold hover:bg-[#166fe5] transition-colors shadow-xs"
                  >
                    <Facebook className="w-4 h-4" />
                    <span>Facebook</span>
                  </a>
                )}
              </div>
            </div>
          </div>

          {/* Categories links */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-[#D4AF37]">
              Categorías Principales
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <button
                  onClick={() => onSelectCategory('all')}
                  className="hover:text-white transition-colors"
                >
                  Catálogo General
                </button>
              </li>
              {[...categories]
                .filter((c) => c.isActive)
                .sort((a, b) => (a.order ?? 0) - (b.order ?? 0))
                .map((c) => (
                  <li key={c.id}>
                    <button
                      onClick={() => onSelectCategory(c.id)}
                      className="hover:text-white transition-colors"
                    >
                      {c.name}
                    </button>
                  </li>
                ))}
            </ul>
          </div>

          {/* Contact info */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-[#D4AF37]">
              Información de Contacto
            </h4>
            <ul className="space-y-2.5 text-xs text-[#A8988C]">
              <li className="flex items-start gap-2">
                <MapPin className="w-4 h-4 text-[#D4AF37] shrink-0 mt-0.5" />
                {settings.contactInformation.mapsUrl ? (
                  <a
                    href={settings.contactInformation.mapsUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="hover:text-white transition-colors group flex items-start gap-1"
                    title="Abrir ubicación en Google Maps"
                  >
                    <span>{settings.contactInformation.address}</span>
                    <ExternalLink className="w-3 h-3 text-[#D4AF37] shrink-0 mt-0.5 opacity-75 group-hover:opacity-100" />
                  </a>
                ) : (
                  <span>{settings.contactInformation.address}</span>
                )}
              </li>
              <li className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-[#D4AF37] shrink-0" />
                <a
                  href={`tel:${settings.contactInformation.phone?.replace(/[^0-9+]/g, '')}`}
                  className="hover:text-white transition-colors"
                >
                  {settings.contactInformation.phone}
                </a>
              </li>
              <li className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-[#D4AF37] shrink-0" />
                <a
                  href={`mailto:${settings.contactInformation.email}`}
                  className="hover:text-white transition-colors"
                >
                  {settings.contactInformation.email}
                </a>
              </li>
              <li className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-[#D4AF37] shrink-0" />
                <span>{settings.contactInformation.schedule}</span>
              </li>
            </ul>
          </div>

          {/* Guarantee & Deliveries */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-[#D4AF37]">
              Garantía & Envíos
            </h4>
            <p className="text-xs text-[#A8988C] leading-relaxed">
              {settings.deliveryInformation}
            </p>
            <p className="text-xs text-[#A8988C] leading-relaxed pt-1">
              {settings.returnPolicy}
            </p>
          </div>

        </div>

        {/* Bottom Bar: Discreet dot admin access & Copyright */}
        <div className="pt-6 border-t border-[#3E2723] flex flex-col sm:flex-row items-start sm:items-center justify-between text-xs text-[#A8988C] gap-3">
          <div className="flex flex-wrap items-center gap-2">
            <p>© 2026 {settings.storeName}. Todos los derechos reservados.</p>
            {/* Discreet admin dot access */}
            <button
              id="footer-admin-login-btn"
              onClick={onOpenAdmin}
              className="inline-block text-[#7A6A60] hover:text-[#D4AF37] transition-colors px-1 py-0.5 text-xs select-none cursor-pointer focus:outline-none"
              aria-label="Acceso"
            >
              .
            </button>
          </div>
          <div className="text-[11px] text-[#8C7A70] flex items-center gap-1.5">
            <span>Diseño y fabricación en fibra de vidrio de alta resistencia</span>
          </div>
        </div>

      </div>
    </footer>
  );
};
