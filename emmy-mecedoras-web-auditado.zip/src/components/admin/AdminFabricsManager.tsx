import React, { useState } from 'react';
import { 
  CushionFabricCategory, 
  StoreSettings, 
  CushionPatternOption, 
  CushionTextalinaOption,
  CushionBorderStyleSettings,
  CushionBackrestStyleSettings,
  ColorOption
} from '../../types';
import { 
  DEFAULT_CUSHION_FABRICS, 
  DEFAULT_CUSHION_PATTERNS, 
  DEFAULT_CUSHION_TEXTALINA_OPTIONS,
  DEFAULT_CUSHION_BORDER_STYLE_EXAMPLES,
  DEFAULT_CUSHION_STYLE_EXAMPLES,
  DEFAULT_CUSHION_BORDER_COLORS
} from '../../data/initialData';
import { formatPrice } from '../../utils/whatsapp';
import { compressImageFile } from '../../utils/imageCompressor';
import { uploadToFirebaseStorage, deleteFromFirebaseStorage, validateImageFile } from '../../services/firebaseStorageService';
import { notifyError, reportNonBlockingError } from '../../utils/errorReporting';
import { api } from '../../services/api';
import { 
  Layers, 
  Plus, 
  Trash2, 
  Edit3, 
  Eye, 
  EyeOff, 
  Upload, 
  Check, 
  Sparkles, 
  Tag, 
  Info, 
  ArrowUp, 
  ArrowDown, 
  RotateCcw, 
  Save, 
  X, 
  CheckCircle2, 
  Palette, 
  ShieldCheck, 
  ZoomIn,
  ImageIcon,
  Scissors,
  Sliders,
  HelpCircle,
  CheckCircle,
  AlertCircle
} from 'lucide-react';

interface AdminFabricsManagerProps {
  settings: StoreSettings;
  onUpdateSettings: (updated: StoreSettings) => void;
  onSaveAll: () => Promise<void>;
  isSaving: boolean;
  showFeedback: (msg: string) => void;
  onDataRefresh?: () => Promise<void> | void;
}

const COMMON_BADGES = [
  '100% Impermeable',
  'Exterior & Interior',
  'Protección UV',
  'Tacto Suave',
  'Antimanchas',
  'Lavable con Cierre',
  'Transpirable',
  'Secado Rápido',
  'Anti-líquidos',
  'Alto Tránsito',
  'Elegante',
  'Diseño Exclusivo',
];

export const AdminFabricsManager: React.FC<AdminFabricsManagerProps> = ({
  settings,
  onUpdateSettings,
  onSaveAll,
  isSaving,
  showFeedback,
  onDataRefresh,
}) => {
  const fabrics: CushionFabricCategory[] = 
    Array.isArray(settings.cushionFabrics)
      ? settings.cushionFabrics
      : [];

  const patterns: CushionPatternOption[] =
    Array.isArray(settings.cushionPatterns)
      ? settings.cushionPatterns
      : [];

  const textalinas: CushionTextalinaOption[] =
    Array.isArray(settings.cushionTextalinaOptions)
      ? settings.cushionTextalinaOptions
      : [];

  const borderStyleExamples: CushionBorderStyleSettings =
    settings.cushionBorderStyleExamples !== undefined
      ? settings.cushionBorderStyleExamples
      : DEFAULT_CUSHION_BORDER_STYLE_EXAMPLES;

  const styleExamples: CushionBackrestStyleSettings =
    settings.cushionStyleExamples !== undefined
      ? settings.cushionStyleExamples
      : DEFAULT_CUSHION_STYLE_EXAMPLES;

  const borderColors: ColorOption[] =
    Array.isArray(settings.cushionBorderColors)
      ? settings.cushionBorderColors
      : [];

  const [isUploadingImage, setIsUploadingImage] = useState<boolean>(false);

  const uploadFileToStorage = async (file: File, folder = 'telas'): Promise<string> => {
    const validation = validateImageFile(file);
    if (!validation.valid) {
      alert(validation.error);
      throw new Error(validation.error);
    }
    setIsUploadingImage(true);
    try {
      const compressed = await compressImageFile(file, { maxWidth: 1200, maxHeight: 1200, quality: 0.85 });
      const url = await uploadToFirebaseStorage(compressed, folder);
      showFeedback('Imagen guardada exitosamente en Firebase Storage');
      return url;
    } catch (err: any) {
      console.error(`Upload failed for ${folder}:`, err);
      showFeedback('No se pudo guardar la imagen en Firebase Storage. Inténtalo nuevamente.');
      throw err;
    } finally {
      setIsUploadingImage(false);
    }
  };

  // Active subtab inside fabrics manager
  const [subTab, setSubTab] = useState<'fabrics' | 'textalina' | 'patterns' | 'borders'>('fabrics');

  // Editing or creating a fabric
  const [editingFabric, setEditingFabric] = useState<CushionFabricCategory | null>(null);
  const [isNewFabric, setIsNewFabric] = useState<boolean>(false);
  const [customBadgeInput, setCustomBadgeInput] = useState<string>('');

  // Image preview modal
  const [previewImageModal, setPreviewImageModal] = useState<{
    isOpen: boolean;
    title: string;
    image: string;
    description?: string;
  } | null>(null);

  // New Pattern & Textalina quick modals
  const [newPatternForm, setNewPatternForm] = useState<{
    isOpen: boolean;
    name: string;
    image: string;
    description: string;
  }>({
    isOpen: false,
    name: '',
    image: '',
    description: '',
  });

  const [newTextalinaForm, setNewTextalinaForm] = useState<{
    isOpen: boolean;
    name: string;
    hex: string;
    image: string;
    description: string;
  }>({
    isOpen: false,
    name: '',
    hex: '#CBD5E1',
    image: '',
    description: '',
  });

  const [newBorderColorForm, setNewBorderColorForm] = useState<{
    isOpen: boolean;
    name: string;
    hex: string;
  }>({
    isOpen: false,
    name: '',
    hex: '#FFFFFF',
  });

  const [isAutoSaving, setIsAutoSaving] = useState<boolean>(false);

  const persistSettings = async (updated: StoreSettings, message?: string) => {
    setIsAutoSaving(true);
    try {
      await api.updateSettings(updated);
      onUpdateSettings(updated);
      if (onDataRefresh) {
        onDataRefresh();
      }
      if (message) {
        showFeedback(message);
      }
    } catch (err: any) {
      notifyError('No se pudo guardar el catálogo/configuración en Firebase.', err);
      throw err;
    } finally {
      setIsAutoSaving(false);
    }
  };

  const handleUpdateBorderStyles = async (updates: Partial<CushionBorderStyleSettings>) => {
    const updated: CushionBorderStyleSettings = {
      ...borderStyleExamples,
      ...updates,
    };
    await persistSettings({
      ...settings,
      cushionBorderStyleExamples: updated,
    }, 'Configuración de ribete guardada');
  };

  const handleUpdateBackrestStyles = async (updates: Partial<CushionBackrestStyleSettings>) => {
    const updated: CushionBackrestStyleSettings = {
      ...styleExamples,
      ...updates,
    };
    await persistSettings({
      ...settings,
      cushionStyleExamples: updated,
    }, 'Configuración de respaldo guardada');
  };

  // Fabric handlers
  const handleOpenCreateFabric = () => {
    const newFab: CushionFabricCategory = {
      id: `fabric_${Date.now()}`,
      name: '',
      description: '',
      priceDiff: 0,
      typeMode: 'solid',
      image: '',
      badges: ['Tacto Suave', 'Interior & Sombra'],
      material: 'Poliéster de alta durabilidad',
      usage: 'Interior y terrazas techadas',
      cleaningInfo: 'Funda desmontable lavable con agua fría o limpieza con paño húmedo.',
      isActive: true,
      order: fabrics.length + 1,
    };
    setEditingFabric(newFab);
    setIsNewFabric(true);
    setCustomBadgeInput('');
  };

  const handleOpenEditFabric = (fabric: CushionFabricCategory) => {
    setEditingFabric({ ...fabric });
    setIsNewFabric(false);
    setCustomBadgeInput('');
  };

  const handleSaveEditingFabric = async () => {
    if (!editingFabric || !editingFabric.name.trim()) {
      alert('Por favor introduce un nombre para la tela.');
      return;
    }

    const now = new Date().toISOString();
    let fabricToSave: CushionFabricCategory;
    let oldImageToDelete: string | null = null;

    if (isNewFabric) {
      fabricToSave = {
        ...editingFabric,
        id: editingFabric.id || `fabric_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
        name: editingFabric.name.trim(),
        priceDiff: Number(editingFabric.priceDiff) || 0,
        order: editingFabric.order !== undefined ? Number(editingFabric.order) : fabrics.length + 1,
        isActive: editingFabric.isActive !== false,
        createdAt: now,
        updatedAt: now,
      };
    } else {
      const existing = fabrics.find(f => f.id === editingFabric.id);
      if (existing && existing.image && existing.image !== editingFabric.image) {
        oldImageToDelete = existing.image;
      }
      fabricToSave = {
        ...editingFabric,
        name: editingFabric.name.trim(),
        priceDiff: Number(editingFabric.priceDiff) || 0,
        updatedAt: now,
        createdAt: existing?.createdAt || now,
      };
    }

    let updatedList: CushionFabricCategory[];
    if (isNewFabric) {
      updatedList = [...fabrics, fabricToSave];
    } else {
      updatedList = fabrics.map((f) => (f.id === fabricToSave.id ? fabricToSave : f));
    }

    await persistSettings({
      ...settings,
      cushionFabrics: updatedList,
    }, isNewFabric ? '¡Nueva tela guardada exitosamente!' : '¡Tela actualizada y guardada!');

    if (oldImageToDelete) {
      deleteFromFirebaseStorage(oldImageToDelete).catch((err) => reportNonBlockingError('Los datos se guardaron, pero no se pudo borrar la imagen anterior de Storage.', err));
    }

    setEditingFabric(null);
    setIsNewFabric(false);
  };

  const handleDeleteFabric = async (id: string, name: string) => {
    if (window.confirm(`¿Estás seguro de eliminar la tela "${name}" del catálogo general?`)) {
      const fabricToDelete = fabrics.find((f) => f.id === id);
      const updatedList = fabrics.filter((f) => f.id !== id);
      await persistSettings({
        ...settings,
        cushionFabrics: updatedList,
      }, updatedList.length === 0 ? 'Inventario de telas vaciado (Catálogo de telas vacío)' : 'Tela eliminada');
      if (fabricToDelete?.image) {
        deleteFromFirebaseStorage(fabricToDelete.image).catch((err) => reportNonBlockingError('La tela se eliminó, pero no se pudo borrar su imagen de Storage.', err));
      }
    }
  };

  const handleEmptyAllFabrics = async () => {
    if (
      window.confirm(
        '¿Vaciar por completo todo el inventario de telas? La tienda quedará en estado válido de Catálogo de telas vacío.'
      )
    ) {
      const imagesToDelete = fabrics.map(f => f.image).filter(Boolean);
      await persistSettings({
        ...settings,
        cushionFabrics: [],
      }, 'Catálogo de telas vaciado');
      for (const img of imagesToDelete) {
        if (img) deleteFromFirebaseStorage(img).catch((err) => reportNonBlockingError('El registro se eliminó, pero una imagen no pudo borrarse de Storage.', err));
      }
    }
  };

  const handleToggleFabricActive = async (id: string) => {
    const updatedList = fabrics.map((f) =>
      f.id === id ? { ...f, isActive: f.isActive === false ? true : false } : f
    );
    await persistSettings({
      ...settings,
      cushionFabrics: updatedList,
    });
  };

  const handleMoveFabric = async (index: number, direction: 'up' | 'down') => {
    const targetIdx = direction === 'up' ? index - 1 : index + 1;
    if (targetIdx < 0 || targetIdx >= fabrics.length) return;

    const list = [...fabrics];
    const temp = list[index];
    list[index] = list[targetIdx];
    list[targetIdx] = temp;

    await persistSettings({
      ...settings,
      cushionFabrics: list,
    });
  };

  const handleResetDefaultFabrics = async () => {
    if (
      window.confirm(
        '¿Restablecer las telas al catálogo de fábrica por defecto (Kiwi, Textalina, Vinil, Estampados)?'
      )
    ) {
      await persistSettings({
        ...settings,
        cushionFabrics: DEFAULT_CUSHION_FABRICS,
      }, 'Telas restablecidas a valores de fábrica');
    }
  };

  const handleImageFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && editingFabric) {
      try {
        const url = await uploadFileToStorage(file, 'telas');
        setEditingFabric({
          ...editingFabric,
          image: url,
        });
      } catch (err) {
        console.error('Error subiendo imagen de tela:', err);
      }
    }
  };

  const handleToggleBadge = (badge: string) => {
    if (!editingFabric) return;
    const current = editingFabric.badges || [];
    if (current.includes(badge)) {
      setEditingFabric({
        ...editingFabric,
        badges: current.filter((b) => b !== badge),
      });
    } else {
      setEditingFabric({
        ...editingFabric,
        badges: [...current, badge],
      });
    }
  };

  const handleAddCustomBadge = () => {
    if (!editingFabric || !customBadgeInput.trim()) return;
    const current = editingFabric.badges || [];
    const trimmed = customBadgeInput.trim();
    if (!current.includes(trimmed)) {
      setEditingFabric({
        ...editingFabric,
        badges: [...current, trimmed],
      });
    }
    setCustomBadgeInput('');
  };

  return (
    <div className="space-y-6 max-w-6xl mx-auto">
      {/* Header Banner */}
      <div className="bg-white p-6 sm:p-8 rounded-3xl border border-stone-200 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="p-2 rounded-xl bg-[#8a532b]/10 text-[#8a532b]">
              <Layers className="w-5 h-5" />
            </span>
            <h2 className="font-serif text-xl sm:text-2xl font-bold text-stone-900">
              Gestor Global de Telas y Tapicería
            </h2>
          </div>
          <p className="text-xs sm:text-sm text-stone-600 max-w-2xl">
            Edita las telas disponibles para todos los productos y mecedoras. Personaliza nombres, fotos de muestra, precios adicionales, características técnicas, insignias y recomendaciones de uso.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={handleEmptyAllFabrics}
            className="px-3 py-2 rounded-xl bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-300 text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
            title="Vaciar inventario de telas para activar el estado sin stock"
          >
            <Trash2 className="w-3.5 h-3.5 text-amber-700" />
            <span>Vaciar Telas (Sin Stock)</span>
          </button>

          <button
            type="button"
            onClick={handleResetDefaultFabrics}
            className="px-3 py-2 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-700 text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Restablecer Fábrica</span>
          </button>

          <button
            type="button"
            onClick={handleOpenCreateFabric}
            className="px-4 py-2.5 rounded-xl bg-[#8a532b] hover:bg-[#6e4121] text-white text-xs font-bold flex items-center gap-2 transition-colors shadow-xs cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Agregar Nueva Tela</span>
          </button>

          <button
            type="button"
            onClick={onSaveAll}
            disabled={isSaving || isAutoSaving}
            className="px-4 py-2.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold flex items-center gap-2 transition-colors shadow-xs cursor-pointer"
          >
            <Save className="w-4 h-4" />
            <span>{isSaving || isAutoSaving ? 'Sincronizando...' : 'Guardar Todo'}</span>
          </button>
        </div>
      </div>

      {/* Sub-Navigation Tabs */}
      <div className="flex items-center gap-2 border-b border-stone-200 pb-2 overflow-x-auto no-scrollbar">
        <button
          type="button"
          onClick={() => setSubTab('fabrics')}
          className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-2 transition-colors ${
            subTab === 'fabrics'
              ? 'bg-[#8a532b] text-white'
              : 'bg-white text-stone-600 hover:bg-stone-100 border border-stone-200'
          }`}
        >
          <Layers className="w-4 h-4" />
          <span>Telas Principales ({fabrics.length})</span>
        </button>

        <button
          type="button"
          onClick={() => setSubTab('textalina')}
          className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-2 transition-colors ${
            subTab === 'textalina'
              ? 'bg-[#8a532b] text-white'
              : 'bg-white text-stone-600 hover:bg-stone-100 border border-stone-200'
          }`}
        >
          <Palette className="w-4 h-4" />
          <span>Muestrario Textalina ({textalinas.length})</span>
        </button>

        <button
          type="button"
          onClick={() => setSubTab('patterns')}
          className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-2 transition-colors ${
            subTab === 'patterns'
              ? 'bg-[#8a532b] text-white'
              : 'bg-white text-stone-600 hover:bg-stone-100 border border-stone-200'
          }`}
        >
          <ImageIcon className="w-4 h-4" />
          <span>Diseños Estampados ({patterns.length})</span>
        </button>

        <button
          type="button"
          onClick={() => setSubTab('borders')}
          className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-2 transition-colors ${
            subTab === 'borders'
              ? 'bg-[#8a532b] text-white'
              : 'bg-white text-stone-600 hover:bg-stone-100 border border-stone-200'
          }`}
        >
          <Scissors className="w-4 h-4" />
          <span>Ribetes & Estilos (Con / Sin Ribete)</span>
        </button>
      </div>

      {/* ================= TAB 1: MAIN FABRICS LIST ================= */}
      {subTab === 'fabrics' && (
        <div className="space-y-4">
          {fabrics.length === 0 ? (
            <div className="bg-stone-50 border border-dashed border-stone-300 rounded-2xl p-8 text-center space-y-2">
              <Layers className="w-8 h-8 text-stone-400 mx-auto" />
              <p className="text-stone-600 font-bold text-sm">No hay telas principales registradas.</p>
              <p className="text-xs text-stone-400">Esta sección se encuentra vacía. Puedes agregar una nueva tela o restaurar las de fábrica cuando lo desees.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {fabrics.map((fabric, idx) => {
              const isActive = fabric.isActive !== false;
              return (
                <div
                  key={fabric.id || idx}
                  className={`bg-white rounded-2xl border transition-all p-4 sm:p-5 flex flex-col justify-between gap-4 shadow-sm ${
                    isActive ? 'border-stone-200 hover:border-[#8a532b]/40' : 'border-stone-200 bg-stone-50/70 opacity-70'
                  }`}
                >
                  <div className="space-y-3">
                    {/* Header Row: Image, Name, Status & Price Diff */}
                    <div className="flex items-start gap-3">
                      {/* Image Preview */}
                      <div className="relative w-16 h-16 rounded-xl overflow-hidden bg-stone-100 border border-stone-300 shrink-0 shadow-2xs group">
                        {fabric.image ? (
                          <img
                            src={fabric.image}
                            alt={fabric.name}
                            referrerPolicy="no-referrer"
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center text-stone-400 bg-stone-100">
                            <Layers className="w-6 h-6" />
                          </div>
                        )}
                        {fabric.image && (
                          <button
                            type="button"
                            onClick={() =>
                              setPreviewImageModal({
                                isOpen: true,
                                title: fabric.name,
                                image: fabric.image!,
                                description: fabric.description,
                              })
                            }
                            className="absolute inset-0 bg-black/40 text-white flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer"
                          >
                            <ZoomIn className="w-4 h-4" />
                          </button>
                        )}
                      </div>

                      {/* Title & Type Mode */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <h3 className="font-serif font-bold text-base text-stone-900 truncate">
                            {fabric.name}
                          </h3>
                          <span
                            className={`px-2 py-0.5 rounded-md text-[10.5px] font-bold ${
                              fabric.priceDiff === 0
                                ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                                : 'bg-[#8a532b]/10 text-[#8a532b] border border-[#8a532b]/20'
                            }`}
                          >
                            {fabric.priceDiff === 0
                              ? 'Precio Base (Sin costo extra)'
                              : `+${formatPrice(fabric.priceDiff, settings.currency)}`}
                          </span>
                        </div>

                        <div className="flex items-center gap-1.5 mt-1 flex-wrap">
                          <span className="px-2 py-0.5 rounded-full bg-stone-100 text-stone-600 text-[10px] font-bold">
                            Modo:{' '}
                            {fabric.typeMode === 'textalina'
                              ? 'Muestrario Textalina'
                              : fabric.typeMode === 'pattern'
                              ? 'Estampados'
                              : fabric.typeMode === 'custom'
                              ? 'Personalizado'
                              : 'Colores Lisos'}
                          </span>

                          <span
                            className={`px-2 py-0.5 rounded-full text-[10px] font-bold flex items-center gap-1 ${
                              isActive
                                ? 'bg-emerald-50 text-emerald-700'
                                : 'bg-stone-200 text-stone-600'
                            }`}
                          >
                            <span
                              className={`w-1.5 h-1.5 rounded-full ${
                                isActive ? 'bg-emerald-500' : 'bg-stone-400'
                              }`}
                            />
                            {isActive ? 'Activo en Catálogo' : 'Oculto'}
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Description */}
                    <p className="text-xs text-stone-600 leading-relaxed">
                      {fabric.description || 'Sin descripción'}
                    </p>

                    {/* Badges / Tags */}
                    {fabric.badges && fabric.badges.length > 0 && (
                      <div className="flex flex-wrap gap-1.5 pt-1">
                        {fabric.badges.map((b, bIdx) => (
                          <span
                            key={bIdx}
                            className="px-2 py-0.5 rounded-md bg-[#FAF8F5] border border-[#E8E2DC] text-[#7A6A60] text-[10.5px] font-medium flex items-center gap-1"
                          >
                            <Tag className="w-2.5 h-2.5 text-[#8a532b]" />
                            {b}
                          </span>
                        ))}
                      </div>
                    )}

                    {/* Technical metadata table/details */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px] bg-stone-50 p-2.5 rounded-xl border border-stone-200/80">
                      {fabric.material && (
                        <div>
                          <span className="font-bold text-stone-700 block">Composición / Material:</span>
                          <span className="text-stone-600">{fabric.material}</span>
                        </div>
                      )}
                      {fabric.usage && (
                        <div>
                          <span className="font-bold text-stone-700 block">Uso Recomendado:</span>
                          <span className="text-stone-600">{fabric.usage}</span>
                        </div>
                      )}
                      {fabric.cleaningInfo && (
                        <div className="sm:col-span-2">
                          <span className="font-bold text-stone-700 block">Cuidado y Limpieza:</span>
                          <span className="text-stone-600">{fabric.cleaningInfo}</span>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Actions Footer */}
                  <div className="flex items-center justify-between pt-3 border-t border-stone-100">
                    <div className="flex items-center gap-1">
                      <button
                        type="button"
                        disabled={idx === 0}
                        onClick={() => handleMoveFabric(idx, 'up')}
                        title="Subir posición"
                        className="p-1.5 rounded-lg border border-stone-200 text-stone-600 hover:bg-stone-100 disabled:opacity-30 cursor-pointer"
                      >
                        <ArrowUp className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        disabled={idx === fabrics.length - 1}
                        onClick={() => handleMoveFabric(idx, 'down')}
                        title="Bajar posición"
                        className="p-1.5 rounded-lg border border-stone-200 text-stone-600 hover:bg-stone-100 disabled:opacity-30 cursor-pointer"
                      >
                        <ArrowDown className="w-3.5 h-3.5" />
                      </button>

                      <button
                        type="button"
                        onClick={() => handleToggleFabricActive(fabric.id)}
                        title={isActive ? 'Ocultar tela en el catálogo' : 'Mostrar tela en el catálogo'}
                        className={`px-2.5 py-1.5 rounded-lg border text-xs font-semibold flex items-center gap-1 cursor-pointer transition-colors ${
                          isActive
                            ? 'border-emerald-200 bg-emerald-50 text-emerald-700 hover:bg-emerald-100'
                            : 'border-stone-300 bg-stone-100 text-stone-600 hover:bg-stone-200'
                        }`}
                      >
                        {isActive ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
                        <span>{isActive ? 'Visible' : 'Oculto'}</span>
                      </button>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => handleOpenEditFabric(fabric)}
                        className="px-3 py-1.5 rounded-lg bg-stone-800 hover:bg-stone-900 text-white text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
                      >
                        <Edit3 className="w-3.5 h-3.5" />
                        <span>Editar</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => handleDeleteFabric(fabric.id, fabric.name)}
                        className="p-1.5 rounded-lg border border-red-200 text-red-600 hover:bg-red-50 transition-colors cursor-pointer"
                        title="Eliminar tela"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
          )}
        </div>
      )}

      {/* ================= TAB 2: TEXTALINA SWATCHES ================= */}
      {subTab === 'textalina' && (
        <div className="bg-white p-6 rounded-3xl border border-stone-200 shadow-sm space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-stone-100 pb-3">
            <div>
              <h3 className="font-serif font-bold text-lg text-stone-900 flex items-center gap-2">
                <Palette className="w-5 h-5 text-[#8a532b]" />
                <span>Catálogo de Muestras de Textalina con Foto</span>
              </h3>
              <p className="text-xs text-stone-500">
                Estas opciones se presentan en cuadros con fotos y lupa cuando el cliente elige la tela Textalina.
              </p>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={async () => {
                  if (window.confirm('¿Vaciar por completo todas las muestras de Textalina? Quedará en estado de catálogo vacío.')) {
                    const imagesToDelete = textalinas.map(t => t.image).filter(Boolean);
                    await persistSettings({
                      ...settings,
                      cushionTextalinaOptions: [],
                    }, 'Muestrario de Textalina vaciado (Catálogo de telas vacío)');
                    for (const img of imagesToDelete) {
                      if (img) deleteFromFirebaseStorage(img).catch((err) => reportNonBlockingError('El registro se eliminó, pero una imagen no pudo borrarse de Storage.', err));
                    }
                  }
                }}
                className="px-3 py-2 rounded-xl bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-300 text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
                title="Vaciar muestras para activar el estado sin stock"
              >
                <Trash2 className="w-3.5 h-3.5 text-amber-700" />
                <span>Vaciar Muestras (Sin Stock)</span>
              </button>

              <button
                type="button"
                onClick={async () => {
                  if (window.confirm('¿Restablecer las muestras de Textalina de fábrica?')) {
                    await persistSettings({
                      ...settings,
                      cushionTextalinaOptions: DEFAULT_CUSHION_TEXTALINA_OPTIONS,
                    }, 'Muestras de Textalina de fábrica restablecidas');
                  }
                }}
                className="px-3 py-2 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-700 text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Restablecer Fábrica</span>
              </button>

              <button
                type="button"
                onClick={() =>
                  setNewTextalinaForm({
                    isOpen: true,
                    name: '',
                    hex: '#CBD5E1',
                    image: '',
                    description: '',
                  })
                }
                className="px-3.5 py-2 rounded-xl bg-[#8a532b] hover:bg-[#6e4121] text-white text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Agregar Tono Textalina</span>
              </button>
            </div>
          </div>

          {textalinas.length === 0 ? (
            <div className="bg-amber-50/50 border border-dashed border-amber-200 rounded-2xl p-8 text-center space-y-2">
              <div className="w-12 h-12 rounded-full bg-amber-100 text-amber-800 mx-auto flex items-center justify-center">
                <AlertCircle className="w-6 h-6 text-amber-700" />
              </div>
              <p className="text-stone-800 font-bold text-sm">Estado Sin Stock: No hay muestras de Textalina en inventario.</p>
              <p className="text-xs text-stone-500 max-w-md mx-auto">
                El inventario de Textalina está vacío. Los clientes verán la notificación de sin stock o puedes agregar nuevos tonos y fotos.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {textalinas.map((tex, idx) => (
              <div
                key={tex.id || idx}
                className="flex items-center gap-3 p-3 bg-stone-50 rounded-2xl border border-stone-200 shadow-2xs"
              >
                <div className="w-14 h-14 rounded-xl overflow-hidden bg-white border border-stone-300 shrink-0 relative group">
                  <img
                    src={tex.image}
                    alt={tex.name}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover"
                  />
                  {tex.hex && (
                    <span
                      className="absolute bottom-1 left-1 w-3.5 h-3.5 rounded-full border border-white shadow-xs"
                      style={{ backgroundColor: tex.hex }}
                    />
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <h4 className="font-bold text-xs text-stone-900 truncate">{tex.name}</h4>
                  <p className="text-[10.5px] text-stone-500 truncate">{tex.description}</p>
                </div>
                <button
                  type="button"
                  onClick={async () => {
                    if (window.confirm(`¿Eliminar la muestra de Textalina "${tex.name}"?`)) {
                      const updated = textalinas.filter((_, i) => i !== idx);
                      await persistSettings({
                        ...settings,
                        cushionTextalinaOptions: updated,
                      }, updated.length === 0 ? 'Muestrario de Textalina vaciado (Catálogo de telas vacío)' : 'Muestra de Textalina eliminada');
                      if (tex.image) {
                        deleteFromFirebaseStorage(tex.image).catch((err) => reportNonBlockingError('La textalina se eliminó, pero su imagen no pudo borrarse de Storage.', err));
                      }
                    }
                  }}
                  className="p-1.5 text-stone-400 hover:text-red-600 rounded-lg hover:bg-red-50 cursor-pointer"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
          )}
        </div>
      )}

      {/* ================= TAB 3: PATTERN FABRICS ================= */}
      {subTab === 'patterns' && (
        <div className="bg-white p-6 rounded-3xl border border-stone-200 shadow-sm space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-stone-100 pb-3">
            <div>
              <h3 className="font-serif font-bold text-lg text-stone-900 flex items-center gap-2">
                <ImageIcon className="w-5 h-5 text-[#8a532b]" />
                <span>Diseños de Telas Estampadas</span>
              </h3>
              <p className="text-xs text-stone-500">
                Patrones florales, geométricos y decorativos que los clientes pueden elegir para sus cojines.
              </p>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={async () => {
                  if (window.confirm('¿Vaciar por completo el inventario de estampados? Quedará en estado de catálogo vacío.')) {
                    const imagesToDelete = patterns.map(p => p.image).filter(Boolean);
                    await persistSettings({
                      ...settings,
                      cushionPatterns: [],
                    }, 'Inventario de estampados vaciado (Catálogo de telas vacío)');
                    for (const img of imagesToDelete) {
                      if (img) deleteFromFirebaseStorage(img).catch((err) => reportNonBlockingError('El registro se eliminó, pero una imagen no pudo borrarse de Storage.', err));
                    }
                  }
                }}
                className="px-3 py-2 rounded-xl bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-300 text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
                title="Vaciar estampados para activar el estado sin stock"
              >
                <Trash2 className="w-3.5 h-3.5 text-amber-700" />
                <span>Vaciar Estampados (Sin Stock)</span>
              </button>

              <button
                type="button"
                onClick={async () => {
                  if (window.confirm('¿Restablecer los diseños de estampados de fábrica?')) {
                    await persistSettings({
                      ...settings,
                      cushionPatterns: DEFAULT_CUSHION_PATTERNS,
                    }, 'Estampados de fábrica restablecidos');
                  }
                }}
                className="px-3 py-2 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-700 text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Restablecer Fábrica</span>
              </button>

              <button
                type="button"
                onClick={() =>
                  setNewPatternForm({
                    isOpen: true,
                    name: '',
                    image: '',
                    description: '',
                  })
                }
                className="px-3.5 py-2 rounded-xl bg-[#8a532b] hover:bg-[#6e4121] text-white text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Agregar Estampado</span>
              </button>
            </div>
          </div>

          {patterns.length === 0 ? (
            <div className="bg-amber-50/50 border border-dashed border-amber-200 rounded-2xl p-8 text-center space-y-2">
              <div className="w-12 h-12 rounded-full bg-amber-100 text-amber-800 mx-auto flex items-center justify-center">
                <AlertCircle className="w-6 h-6 text-amber-700" />
              </div>
              <p className="text-stone-800 font-bold text-sm">Estado Sin Stock: No hay estampados disponibles.</p>
              <p className="text-xs text-stone-500 max-w-md mx-auto">
                El catálogo de estampados se encuentra vacío. Se muestra la notificación de sin stock en la selección de telas.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {patterns.map((pat, idx) => (
              <div
                key={pat.id || idx}
                className="flex items-center gap-3 p-3 bg-stone-50 rounded-2xl border border-stone-200 shadow-2xs"
              >
                <div className="w-14 h-14 rounded-xl overflow-hidden bg-white border border-stone-300 shrink-0">
                  <img
                    src={pat.image}
                    alt={pat.name}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="flex-1 min-w-0">
                  <h4 className="font-bold text-xs text-stone-900 truncate">{pat.name}</h4>
                  <p className="text-[10.5px] text-stone-500 truncate">{pat.description}</p>
                </div>
                <button
                  type="button"
                  onClick={async () => {
                    if (window.confirm(`¿Eliminar el estampado "${pat.name}"?`)) {
                      const updated = patterns.filter((_, i) => i !== idx);
                      await persistSettings({
                        ...settings,
                        cushionPatterns: updated,
                      }, updated.length === 0 ? 'Inventario de estampados vaciado (Catálogo de telas vacío)' : 'Estampado eliminado');
                      if (pat.image) {
                        deleteFromFirebaseStorage(pat.image).catch((err) => reportNonBlockingError('El estampado se eliminó, pero su imagen no pudo borrarse de Storage.', err));
                      }
                    }
                  }}
                  className="p-1.5 text-stone-400 hover:text-red-600 rounded-lg hover:bg-red-50 cursor-pointer"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
          )}
        </div>
      )}

      {/* ================= TAB 4: BORDERS & CUSHION STYLES (CON / SIN RIBETE) ================= */}
      {subTab === 'borders' && (
        <div className="space-y-6">
          {/* Main Card: Ribetes (Sin Ribete vs Con Ribete) */}
          <div className="bg-white p-6 sm:p-8 rounded-3xl border border-stone-200 shadow-sm space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-stone-100 pb-4">
              <div>
                <div className="flex items-center gap-2">
                  <span className="p-2 rounded-xl bg-[#8a532b]/10 text-[#8a532b]">
                    <Scissors className="w-5 h-5" />
                  </span>
                  <h3 className="font-serif font-bold text-lg sm:text-xl text-stone-900">
                    Fotos y Muestras de Confección: Con Ribete vs Sin Ribete
                  </h3>
                </div>
                <p className="text-xs sm:text-sm text-stone-500 mt-1 max-w-3xl">
                  Personaliza las imágenes de ejemplo, títulos y descripciones que ven los clientes al seleccionar el acabado de los bordes (mismo color o vivo en contraste).
                </p>
              </div>

              <button
                type="button"
                onClick={() => {
                  if (window.confirm('¿Restablecer las fotos y textos de ribetes a los valores por defecto?')) {
                    handleUpdateBorderStyles(DEFAULT_CUSHION_BORDER_STYLE_EXAMPLES);
                  }
                }}
                className="px-3 py-1.5 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-700 text-xs font-bold flex items-center gap-1.5 transition-colors shrink-0 cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Restablecer Ribetes</span>
              </button>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* OPCIÓN 1: SIN RIBETES DE CONTRASTE */}
              <div className="p-5 bg-[#FAF8F5] rounded-3xl border border-stone-200/90 shadow-2xs space-y-4 flex flex-col justify-between">
                <div className="space-y-4">
                  <div className="flex items-center justify-between pb-2 border-b border-stone-200">
                    <span className="text-xs font-bold text-stone-800 uppercase tracking-wider flex items-center gap-1.5">
                      <span className="w-2.5 h-2.5 rounded-full bg-stone-400 inline-block" />
                      1. Sin Ribete de Contraste (Mismo Tono)
                    </span>
                    <span className="px-2.5 py-0.5 rounded-full bg-stone-200 text-stone-700 text-[10.5px] font-bold">
                      Look Uniforme
                    </span>
                  </div>

                  {/* Image Preview & Upload */}
                  <div className="space-y-3">
                    <div className="relative aspect-16/10 rounded-2xl overflow-hidden bg-stone-200 border border-stone-300 shadow-inner group">
                      <img
                        src={borderStyleExamples.sinBordesImage}
                        alt="Sin Ribetes"
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover"
                      />
                      <button
                        type="button"
                        onClick={() =>
                          setPreviewImageModal({
                            isOpen: true,
                            title: borderStyleExamples.sinBordesTitle || 'Sin Bordes de Contraste',
                            image: borderStyleExamples.sinBordesImage,
                            description: borderStyleExamples.sinBordesDescription,
                          })
                        }
                        className="absolute bottom-2 right-2 px-2.5 py-1 rounded-xl bg-black/60 hover:bg-black/80 text-white backdrop-blur-xs text-xs font-bold flex items-center gap-1 transition-colors cursor-pointer shadow-sm"
                      >
                        <ZoomIn className="w-3.5 h-3.5" />
                        <span>Ver Foto</span>
                      </button>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      <label className="cursor-pointer px-3 py-2 bg-white hover:bg-stone-50 text-stone-800 text-xs font-bold rounded-xl border border-stone-300 flex items-center justify-center gap-2 shadow-2xs transition-colors">
                        <Upload className="w-3.5 h-3.5 text-[#8a532b]" />
                        <span>Subir Foto Local</span>
                        <input
                          type="file"
                          accept="image/*"
                          className="hidden"
                          onChange={async (e) => {
                            const file = e.target.files?.[0];
                            if (file) {
                              try {
                                const url = await uploadFileToStorage(file, 'ribetes');
                                handleUpdateBorderStyles({
                                  sinBordesImage: url,
                                });
                              } catch (err) {
                                console.error('Error subiendo imagen:', err);
                              }
                            }
                          }}
                        />
                      </label>

                      <div className="text-[10.5px] text-stone-500 flex items-center justify-center bg-white/70 px-2 py-1 rounded-xl border border-stone-200">
                        O pega la URL directa abajo
                      </div>
                    </div>
                  </div>

                  {/* URL Input */}
                  <div>
                    <label className="text-[10.5px] font-bold text-stone-600 uppercase block mb-1">
                      URL de la Imagen
                    </label>
                    <input
                      type="text"
                      value={borderStyleExamples.sinBordesImage}
                      onChange={(e) =>
                        handleUpdateBorderStyles({
                          sinBordesImage: e.target.value,
                        })
                      }
                      className="w-full text-xs p-2.5 bg-white border border-stone-300 rounded-xl font-mono focus:ring-2 focus:ring-[#8a532b]"
                      placeholder="https://..."
                    />
                  </div>

                  {/* Title Input */}
                  <div>
                    <label className="text-[10.5px] font-bold text-stone-600 uppercase block mb-1">
                      Título en el Modal de Producto
                    </label>
                    <input
                      type="text"
                      value={borderStyleExamples.sinBordesTitle ?? ''}
                      onChange={(e) =>
                        handleUpdateBorderStyles({
                          sinBordesTitle: e.target.value,
                        })
                      }
                      className="w-full text-xs p-2.5 bg-white border border-stone-300 rounded-xl font-bold focus:ring-2 focus:ring-[#8a532b]"
                      placeholder="Sin Bordes de Contraste (Mismo Tono)"
                    />
                  </div>

                  {/* Description Input */}
                  <div>
                    <label className="text-[10.5px] font-bold text-stone-600 uppercase block mb-1">
                      Descripción Explicativa
                    </label>
                    <textarea
                      rows={2}
                      value={borderStyleExamples.sinBordesDescription ?? ''}
                      onChange={(e) =>
                        handleUpdateBorderStyles({
                          sinBordesDescription: e.target.value,
                        })
                      }
                      className="w-full text-xs p-2.5 bg-white border border-stone-300 rounded-xl text-stone-700 focus:ring-2 focus:ring-[#8a532b]"
                      placeholder="Costuras y bordes en el mismo tono..."
                    />
                  </div>
                </div>
              </div>

              {/* OPCIÓN 2: CON RIBETE EN CONTRASTE (VIVO) */}
              <div className="p-5 bg-white rounded-3xl border-2 border-[#8a532b]/30 shadow-xs space-y-4 flex flex-col justify-between">
                <div className="space-y-4">
                  <div className="flex items-center justify-between pb-2 border-b border-stone-200">
                    <span className="text-xs font-bold text-[#8a532b] uppercase tracking-wider flex items-center gap-1.5">
                      <span className="w-2.5 h-2.5 rounded-full bg-[#8a532b] inline-block" />
                      2. Con Bordes / Ribete en Contraste (Vivo)
                    </span>
                    <span className="px-2.5 py-0.5 rounded-full bg-[#8a532b] text-white text-[10.5px] font-bold">
                      Vivo Decorativo
                    </span>
                  </div>

                  {/* Image Preview & Upload */}
                  <div className="space-y-3">
                    <div className="relative aspect-16/10 rounded-2xl overflow-hidden bg-stone-100 border border-stone-300 shadow-inner group">
                      <img
                        src={borderStyleExamples.conBordesImage}
                        alt="Con Ribetes"
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover"
                      />
                      <button
                        type="button"
                        onClick={() =>
                          setPreviewImageModal({
                            isOpen: true,
                            title: borderStyleExamples.conBordesTitle || 'Con Ribete en Contraste',
                            image: borderStyleExamples.conBordesImage,
                            description: borderStyleExamples.conBordesDescription,
                          })
                        }
                        className="absolute bottom-2 right-2 px-2.5 py-1 rounded-xl bg-black/60 hover:bg-black/80 text-white backdrop-blur-xs text-xs font-bold flex items-center gap-1 transition-colors cursor-pointer shadow-sm"
                      >
                        <ZoomIn className="w-3.5 h-3.5" />
                        <span>Ver Foto</span>
                      </button>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      <label className="cursor-pointer px-3 py-2 bg-stone-50 hover:bg-stone-100 text-stone-800 text-xs font-bold rounded-xl border border-stone-300 flex items-center justify-center gap-2 shadow-2xs transition-colors">
                        <Upload className="w-3.5 h-3.5 text-[#8a532b]" />
                        <span>Subir Foto Local</span>
                        <input
                          type="file"
                          accept="image/*"
                          className="hidden"
                          onChange={async (e) => {
                            const file = e.target.files?.[0];
                            if (file) {
                              try {
                                const url = await uploadFileToStorage(file, 'ribetes');
                                handleUpdateBorderStyles({
                                  conBordesImage: url,
                                });
                              } catch (err) {
                                console.error('Error subiendo imagen:', err);
                              }
                            }
                          }}
                        />
                      </label>

                      <div className="text-[10.5px] text-stone-500 flex items-center justify-center bg-stone-50 px-2 py-1 rounded-xl border border-stone-200">
                        O pega la URL directa abajo
                      </div>
                    </div>
                  </div>

                  {/* URL Input */}
                  <div>
                    <label className="text-[10.5px] font-bold text-stone-600 uppercase block mb-1">
                      URL de la Imagen
                    </label>
                    <input
                      type="text"
                      value={borderStyleExamples.conBordesImage}
                      onChange={(e) =>
                        handleUpdateBorderStyles({
                          conBordesImage: e.target.value,
                        })
                      }
                      className="w-full text-xs p-2.5 bg-stone-50 border border-stone-300 rounded-xl font-mono focus:ring-2 focus:ring-[#8a532b]"
                      placeholder="https://..."
                    />
                  </div>

                  {/* Title Input */}
                  <div>
                    <label className="text-[10.5px] font-bold text-stone-600 uppercase block mb-1">
                      Título en el Modal de Producto
                    </label>
                    <input
                      type="text"
                      value={borderStyleExamples.conBordesTitle ?? ''}
                      onChange={(e) =>
                        handleUpdateBorderStyles({
                          conBordesTitle: e.target.value,
                        })
                      }
                      className="w-full text-xs p-2.5 bg-stone-50 border border-stone-300 rounded-xl font-bold focus:ring-2 focus:ring-[#8a532b]"
                      placeholder="Con Bordes / Ribete en Contraste (Vivo)"
                    />
                  </div>

                  {/* Description Input */}
                  <div>
                    <label className="text-[10.5px] font-bold text-stone-600 uppercase block mb-1">
                      Descripción Explicativa
                    </label>
                    <textarea
                      rows={2}
                      value={borderStyleExamples.conBordesDescription ?? ''}
                      onChange={(e) =>
                        handleUpdateBorderStyles({
                          conBordesDescription: e.target.value,
                        })
                      }
                      className="w-full text-xs p-2.5 bg-stone-50 border border-stone-300 rounded-xl text-stone-700 focus:ring-2 focus:ring-[#8a532b]"
                      placeholder="Incorpora un cordón perimetral decorativo..."
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Secondary Card: Estilos de Respaldo (Costura vs Botones) */}
          <div className="bg-white p-6 sm:p-8 rounded-3xl border border-stone-200 shadow-sm space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-stone-100 pb-4">
              <div>
                <div className="flex items-center gap-2">
                  <span className="p-2 rounded-xl bg-amber-500/10 text-amber-800">
                    <Sparkles className="w-5 h-5" />
                  </span>
                  <h3 className="font-serif font-bold text-lg sm:text-xl text-stone-900">
                    Estilos de Respaldo de Cojín (Costura vs Capitoneado con Botones)
                  </h3>
                </div>
                <p className="text-xs sm:text-sm text-stone-500 mt-1 max-w-3xl">
                  Configura las fotos y descripciones comparativas del acolchado del respaldo en el configurador.
                </p>
              </div>

              <button
                type="button"
                onClick={() => {
                  if (window.confirm('¿Restablecer las fotos de estilo de respaldo a los valores de fábrica?')) {
                    handleUpdateBackrestStyles(DEFAULT_CUSHION_STYLE_EXAMPLES);
                  }
                }}
                className="px-3 py-1.5 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-700 text-xs font-bold flex items-center gap-1.5 transition-colors shrink-0 cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Restablecer Respaldo</span>
              </button>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Estilo 1: Con Costura */}
              <div className="p-5 bg-stone-50/80 rounded-3xl border border-stone-200 space-y-4">
                <div className="flex items-center justify-between pb-2 border-b border-stone-200">
                  <span className="text-xs font-bold text-stone-800 uppercase tracking-wider">
                    Con Costura (Líneas Acolchadas)
                  </span>
                  <span className="px-2 py-0.5 rounded-full bg-stone-200 text-stone-700 text-[10.5px] font-bold">
                    Sin Botones
                  </span>
                </div>

                <div className="relative aspect-16/10 rounded-2xl overflow-hidden bg-stone-200 border border-stone-300 shadow-inner group">
                  <img
                    src={styleExamples.costuraImage}
                    alt="Con Costura"
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover"
                  />
                  <button
                    type="button"
                    onClick={() =>
                      setPreviewImageModal({
                        isOpen: true,
                        title: styleExamples.costuraTitle || 'Con Costura',
                        image: styleExamples.costuraImage,
                        description: styleExamples.costuraDescription,
                      })
                    }
                    className="absolute bottom-2 right-2 px-2.5 py-1 rounded-xl bg-black/60 hover:bg-black/80 text-white backdrop-blur-xs text-xs font-bold flex items-center gap-1 transition-colors cursor-pointer"
                  >
                    <ZoomIn className="w-3.5 h-3.5" />
                    <span>Ver</span>
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  <label className="cursor-pointer px-3 py-2 bg-white hover:bg-stone-100 text-stone-800 text-xs font-bold rounded-xl border border-stone-300 flex items-center justify-center gap-2 shadow-2xs transition-colors">
                    <Upload className="w-3.5 h-3.5 text-[#8a532b]" />
                    <span>Subir Foto</span>
                    <input
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={async (e) => {
                        const file = e.target.files?.[0];
                        if (file) {
                          try {
                            const url = await uploadFileToStorage(file, 'configuracion');
                            handleUpdateBackrestStyles({
                              costuraImage: url,
                            });
                          } catch (err) {
                            console.error('Error subiendo imagen:', err);
                          }
                        }
                      }}
                    />
                  </label>
                  <input
                    type="text"
                    value={styleExamples.costuraImage}
                    onChange={(e) =>
                      handleUpdateBackrestStyles({
                        costuraImage: e.target.value,
                      })
                    }
                    className="text-xs p-2 bg-white border border-stone-300 rounded-xl font-mono"
                    placeholder="URL de foto..."
                  />
                </div>

                <div>
                  <label className="text-[10px] font-bold text-stone-600 uppercase block mb-1">
                    Título
                  </label>
                  <input
                    type="text"
                    value={styleExamples.costuraTitle ?? ''}
                    onChange={(e) =>
                      handleUpdateBackrestStyles({
                        costuraTitle: e.target.value,
                      })
                    }
                    className="w-full text-xs p-2.5 bg-white border border-stone-300 rounded-xl font-bold"
                  />
                </div>

                <div>
                  <label className="text-[10px] font-bold text-stone-600 uppercase block mb-1">
                    Descripción
                  </label>
                  <textarea
                    rows={2}
                    value={styleExamples.costuraDescription ?? ''}
                    onChange={(e) =>
                      handleUpdateBackrestStyles({
                        costuraDescription: e.target.value,
                      })
                    }
                    className="w-full text-xs p-2.5 bg-white border border-stone-300 rounded-xl text-stone-700"
                  />
                </div>
              </div>

              {/* Estilo 2: Capitoneado con Botones */}
              <div className="p-5 bg-stone-50/80 rounded-3xl border border-stone-200 space-y-4">
                <div className="flex items-center justify-between pb-2 border-b border-stone-200">
                  <span className="text-xs font-bold text-stone-800 uppercase tracking-wider">
                    Capitoneado (Con Botones Decorativos)
                  </span>
                  <span className="px-2 py-0.5 rounded-full bg-stone-200 text-stone-700 text-[10.5px] font-bold">
                    Clásico
                  </span>
                </div>

                <div className="relative aspect-16/10 rounded-2xl overflow-hidden bg-stone-200 border border-stone-300 shadow-inner group">
                  <img
                    src={styleExamples.botonesImage}
                    alt="Con Botones"
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover"
                  />
                  <button
                    type="button"
                    onClick={() =>
                      setPreviewImageModal({
                        isOpen: true,
                        title: styleExamples.botonesTitle || 'Con Botones Capitoné',
                        image: styleExamples.botonesImage,
                        description: styleExamples.botonesDescription,
                      })
                    }
                    className="absolute bottom-2 right-2 px-2.5 py-1 rounded-xl bg-black/60 hover:bg-black/80 text-white backdrop-blur-xs text-xs font-bold flex items-center gap-1 transition-colors cursor-pointer"
                  >
                    <ZoomIn className="w-3.5 h-3.5" />
                    <span>Ver</span>
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  <label className="cursor-pointer px-3 py-2 bg-white hover:bg-stone-100 text-stone-800 text-xs font-bold rounded-xl border border-stone-300 flex items-center justify-center gap-2 shadow-2xs transition-colors">
                    <Upload className="w-3.5 h-3.5 text-[#8a532b]" />
                    <span>Subir Foto</span>
                    <input
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={async (e) => {
                        const file = e.target.files?.[0];
                        if (file) {
                          try {
                            const url = await uploadFileToStorage(file, 'configuracion');
                            handleUpdateBackrestStyles({
                              botonesImage: url,
                            });
                          } catch (err) {
                            console.error('Error subiendo imagen:', err);
                          }
                        }
                      }}
                    />
                  </label>
                  <input
                    type="text"
                    value={styleExamples.botonesImage}
                    onChange={(e) =>
                      handleUpdateBackrestStyles({
                        botonesImage: e.target.value,
                      })
                    }
                    className="text-xs p-2 bg-white border border-stone-300 rounded-xl font-mono"
                    placeholder="URL de foto..."
                  />
                </div>

                <div>
                  <label className="text-[10px] font-bold text-stone-600 uppercase block mb-1">
                    Título
                  </label>
                  <input
                    type="text"
                    value={styleExamples.botonesTitle ?? ''}
                    onChange={(e) =>
                      handleUpdateBackrestStyles({
                        botonesTitle: e.target.value,
                      })
                    }
                    className="w-full text-xs p-2.5 bg-white border border-stone-300 rounded-xl font-bold"
                  />
                </div>

                <div>
                  <label className="text-[10px] font-bold text-stone-600 uppercase block mb-1">
                    Descripción
                  </label>
                  <textarea
                    rows={2}
                    value={styleExamples.botonesDescription ?? ''}
                    onChange={(e) =>
                      handleUpdateBackrestStyles({
                        botonesDescription: e.target.value,
                      })
                    }
                    className="w-full text-xs p-2.5 bg-white border border-stone-300 rounded-xl text-stone-700"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Tertiary Card: Paleta de Colores de Ribetes / Vivos Disponibles */}
          <div className="bg-white p-6 sm:p-8 rounded-3xl border border-stone-200 shadow-sm space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-stone-100 pb-3">
              <div>
                <h4 className="font-serif font-bold text-base sm:text-lg text-stone-900 flex items-center gap-2">
                  <Palette className="w-5 h-5 text-[#8a532b]" />
                  <span>Paleta de Colores para Ribetes y Vivos de Contraste</span>
                </h4>
                <p className="text-xs text-stone-500">
                  Colores que los clientes pueden elegir para el vivo perimetral cuando activan "Con Ribete".
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={async () => {
                    if (window.confirm('¿Vaciar por completo todos los colores de ribete?')) {
                      await persistSettings({
                        ...settings,
                        cushionBorderColors: [],
                      }, 'Catálogo de ribetes vaciado');
                    }
                  }}
                  className="px-3 py-2 rounded-xl bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-300 text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
                  title="Vaciar colores de ribete"
                >
                  <Trash2 className="w-3.5 h-3.5 text-amber-700" />
                  <span>Vaciar Ribetes</span>
                </button>

                <button
                  type="button"
                  onClick={async () => {
                    if (window.confirm('¿Restablecer los colores de ribete de fábrica?')) {
                      await persistSettings({
                        ...settings,
                        cushionBorderColors: DEFAULT_CUSHION_BORDER_COLORS,
                      }, 'Colores de ribete restablecidos');
                    }
                  }}
                  className="px-3 py-2 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-700 text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Restablecer Fábrica</span>
                </button>

                <button
                  type="button"
                  onClick={() =>
                    setNewBorderColorForm({
                      isOpen: true,
                      name: '',
                      hex: '#FFFFFF',
                    })
                  }
                  className="px-3.5 py-2 rounded-xl bg-[#8a532b] hover:bg-[#6e4121] text-white text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Agregar Color de Ribete</span>
                </button>
              </div>
            </div>

            {/* Lista de colores de ribete */}
            {borderColors.length === 0 ? (
              <div className="bg-stone-50 border border-dashed border-stone-300 rounded-2xl p-6 text-center space-y-1">
                <p className="text-xs font-bold text-stone-600">No hay colores de ribete registrados.</p>
                <p className="text-[11px] text-stone-400">Puedes agregar un nuevo color de ribete con el botón superior o restablecer los de fábrica.</p>
              </div>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3">
              {borderColors.map((color, idx) => (
                <div
                  key={idx}
                  className="p-3 bg-stone-50 rounded-2xl border border-stone-200 flex items-center justify-between gap-2 shadow-2xs hover:bg-white hover:border-[#8a532b]/40 transition-all"
                >
                  <div className="flex items-center gap-2 min-w-0">
                    <span
                      className="w-5 h-5 rounded-full border border-stone-300 shadow-2xs shrink-0"
                      style={{ backgroundColor: color.hex }}
                    />
                    <div className="min-w-0">
                      <p className="text-xs font-bold text-stone-800 truncate">{color.name}</p>
                      <p className="text-[10px] text-stone-400 font-mono">{color.hex}</p>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={async () => {
                      if (window.confirm(`¿Eliminar el color de ribete "${color.name}"?`)) {
                        const updated = borderColors.filter((_, i) => i !== idx);
                        await persistSettings({
                          ...settings,
                          cushionBorderColors: updated,
                        }, 'Color de ribete eliminado');
                      }
                    }}
                    className="p-1 text-stone-400 hover:text-red-600 rounded-lg hover:bg-red-50 cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
            </div>
            )}

            {/* Quick Add Border Color Form Modal / Drawer */}
            {newBorderColorForm.isOpen && (
              <div className="p-4 bg-amber-50/70 rounded-2xl border border-amber-200/80 space-y-3 animate-fadeIn">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-stone-900">Nuevo Color de Ribete</span>
                  <button
                    type="button"
                    onClick={() => setNewBorderColorForm({ isOpen: false, name: '', hex: '#FFFFFF' })}
                    className="p-1 text-stone-400 hover:text-stone-700"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="text-[10px] font-bold text-stone-600 block mb-1">Nombre del Color</label>
                    <input
                      type="text"
                      value={newBorderColorForm.name}
                      onChange={(e) => setNewBorderColorForm({ ...newBorderColorForm, name: e.target.value })}
                      placeholder="Ej. Terracota Vivo"
                      className="w-full text-xs p-2 bg-white border border-stone-300 rounded-xl font-bold"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-bold text-stone-600 block mb-1">Código Hexadecimal</label>
                    <div className="flex items-center gap-2">
                      <input
                        type="color"
                        value={newBorderColorForm.hex}
                        onChange={(e) => setNewBorderColorForm({ ...newBorderColorForm, hex: e.target.value })}
                        className="w-8 h-8 rounded-lg cursor-pointer border border-stone-300 p-0.5"
                      />
                      <input
                        type="text"
                        value={newBorderColorForm.hex}
                        onChange={(e) => setNewBorderColorForm({ ...newBorderColorForm, hex: e.target.value })}
                        className="w-full text-xs p-2 bg-white border border-stone-300 rounded-xl font-mono uppercase"
                      />
                    </div>
                  </div>
                  <div className="flex items-end">
                    <button
                      type="button"
                      onClick={async () => {
                        if (!newBorderColorForm.name.trim()) {
                          alert('Por favor introduce un nombre para el color.');
                          return;
                        }
                        const updated = [
                          ...borderColors,
                          { name: newBorderColorForm.name.trim(), hex: newBorderColorForm.hex },
                        ];
                        await persistSettings({
                          ...settings,
                          cushionBorderColors: updated,
                        }, 'Color de ribete agregado y guardado');
                        setNewBorderColorForm({ isOpen: false, name: '', hex: '#FFFFFF' });
                      }}
                      className="w-full py-2 bg-[#8a532b] hover:bg-[#6e4121] text-white text-xs font-bold rounded-xl shadow-xs cursor-pointer"
                    >
                      Guardar Color
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ================= EDIT / CREATE FABRIC MODAL ================= */}
      {editingFabric && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-2xl w-full p-6 sm:p-8 shadow-2xl border border-stone-200 space-y-5 my-8">
            <div className="flex items-center justify-between border-b border-stone-100 pb-3">
              <div className="flex items-center gap-2">
                <span className="p-2 rounded-xl bg-[#8a532b]/10 text-[#8a532b]">
                  <Layers className="w-5 h-5" />
                </span>
                <h3 className="font-serif text-lg sm:text-xl font-bold text-stone-900">
                  {isNewFabric ? 'Agregar Nueva Tela al Catálogo' : `Editar Tela: ${editingFabric.name}`}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setEditingFabric(null)}
                className="p-2 rounded-xl text-stone-400 hover:text-stone-700 hover:bg-stone-100 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4 max-h-[75vh] overflow-y-auto pr-1">
              {/* Name & Mode */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-bold text-stone-800 block mb-1">
                    Nombre de la Tela *
                  </label>
                  <input
                    type="text"
                    value={editingFabric.name}
                    onChange={(e) => setEditingFabric({ ...editingFabric, name: e.target.value })}
                    placeholder="Ej. Microfibra Velvet Antimanchas"
                    className="w-full text-xs p-2.5 bg-stone-50 border border-stone-300 rounded-xl font-bold focus:ring-2 focus:ring-[#8a532b] focus:outline-none"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-stone-800 block mb-1">
                    Modo de Selección para el Cliente
                  </label>
                  <select
                    value={editingFabric.typeMode || 'solid'}
                    onChange={(e) =>
                      setEditingFabric({
                        ...editingFabric,
                        typeMode: e.target.value as any,
                      })
                    }
                    className="w-full text-xs p-2.5 bg-stone-50 border border-stone-300 rounded-xl font-semibold focus:ring-2 focus:ring-[#8a532b] focus:outline-none"
                  >
                    <option value="solid">Paleta de Colores Lisos (32 tonos)</option>
                    <option value="textalina">Muestrario de Textalina con Fotos</option>
                    <option value="pattern">Catálogo de Diseños Estampados</option>
                    <option value="custom">Muestra Única Personalizada</option>
                  </select>
                </div>
              </div>

              {/* Price Differential & Active State */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-bold text-stone-800 block mb-1">
                    Costo Adicional / Diferencia ({settings.currency})
                  </label>
                  <input
                    type="number"
                    step="1"
                    value={editingFabric.priceDiff}
                    onChange={(e) =>
                      setEditingFabric({
                        ...editingFabric,
                        priceDiff: parseFloat(e.target.value) || 0,
                      })
                    }
                    className="w-full text-xs p-2.5 bg-stone-50 border border-stone-300 rounded-xl font-bold focus:ring-2 focus:ring-[#8a532b] focus:outline-none"
                  />
                  <span className="text-[10px] text-stone-500 mt-0.5 block">
                    0 = Precio base incluido. Si es mayor a 0 se sumará al precio del producto o cojín.
                  </span>
                </div>

                <div className="flex flex-col justify-end">
                  <label className="flex items-center gap-2 p-2.5 rounded-xl border border-stone-200 bg-stone-50 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={editingFabric.isActive !== false}
                      onChange={(e) =>
                        setEditingFabric({
                          ...editingFabric,
                          isActive: e.target.checked,
                        })
                      }
                      className="w-4 h-4 text-[#8a532b] rounded focus:ring-[#8a532b]"
                    />
                    <div>
                      <span className="text-xs font-bold text-stone-800 block">
                        Tela Activa y Visible
                      </span>
                      <span className="text-[10px] text-stone-500">
                        Los clientes podrán verla y seleccionarla en el catálogo.
                      </span>
                    </div>
                  </label>
                </div>
              </div>

              {/* Sample Photo / Texture */}
              <div className="p-3.5 bg-stone-50 rounded-2xl border border-stone-200 space-y-2.5">
                <label className="text-xs font-bold text-stone-800 block">
                  Foto o Textura de Muestra de la Tela
                </label>
                <div className="flex flex-col sm:flex-row items-center gap-3">
                  <div className="w-20 h-20 rounded-xl overflow-hidden bg-white border border-stone-300 shrink-0 shadow-2xs relative">
                    {editingFabric.image ? (
                      <img
                        src={editingFabric.image}
                        alt="Muestra de tela"
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center text-stone-400 bg-stone-100">
                        <Upload className="w-6 h-6" />
                      </div>
                    )}
                  </div>

                  <div className="flex-1 space-y-2 w-full">
                    <div className="flex items-center gap-2">
                      <label className="px-3 py-1.5 rounded-xl bg-[#8a532b] hover:bg-[#6e4121] text-white text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer shrink-0">
                        <Upload className="w-3.5 h-3.5" />
                        <span>Subir Foto Local</span>
                        <input
                          type="file"
                          accept="image/*"
                          onChange={handleImageFileUpload}
                          className="hidden"
                        />
                      </label>
                      <span className="text-[10.5px] text-stone-500">o pega una URL directa:</span>
                    </div>

                    <input
                      type="text"
                      value={editingFabric.image || ''}
                      onChange={(e) =>
                        setEditingFabric({
                          ...editingFabric,
                          image: e.target.value,
                        })
                      }
                      placeholder="https://images.unsplash.com/..."
                      className="w-full text-xs p-2 bg-white border border-stone-300 rounded-xl font-mono"
                    />
                  </div>
                </div>
              </div>

              {/* Description */}
              <div>
                <label className="text-xs font-bold text-stone-800 block mb-1">
                  Descripción Comercial Explicativa
                </label>
                <textarea
                  rows={2}
                  value={editingFabric.description}
                  onChange={(e) =>
                    setEditingFabric({
                      ...editingFabric,
                      description: e.target.value,
                    })
                  }
                  placeholder="Ej. Tejido suave de máxima comodidad con tratamiento antimanchas..."
                  className="w-full text-xs p-2.5 bg-stone-50 border border-stone-300 rounded-xl"
                />
              </div>

              {/* Badges / Tags Manager */}
              <div className="space-y-2">
                <label className="text-xs font-bold text-stone-800 block">
                  Etiquetas y Características Destacadas (Insignias)
                </label>
                <div className="flex flex-wrap gap-1.5">
                  {COMMON_BADGES.map((badge) => {
                    const isSelected = (editingFabric.badges || []).includes(badge);
                    return (
                      <button
                        key={badge}
                        type="button"
                        onClick={() => handleToggleBadge(badge)}
                        className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition-all cursor-pointer flex items-center gap-1 ${
                          isSelected
                            ? 'bg-[#8a532b] text-white shadow-2xs'
                            : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
                        }`}
                      >
                        {isSelected && <Check className="w-3 h-3" />}
                        <span>{badge}</span>
                      </button>
                    );
                  })}
                </div>

                <div className="flex items-center gap-2 pt-1">
                  <input
                    type="text"
                    value={customBadgeInput}
                    onChange={(e) => setCustomBadgeInput(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        handleAddCustomBadge();
                      }
                    }}
                    placeholder="Agregar otra etiqueta personalizada..."
                    className="flex-1 text-xs p-2 bg-stone-50 border border-stone-300 rounded-xl"
                  />
                  <button
                    type="button"
                    onClick={handleAddCustomBadge}
                    className="px-3 py-2 rounded-xl bg-stone-800 text-white text-xs font-bold hover:bg-stone-900 cursor-pointer"
                  >
                    Agregar
                  </button>
                </div>
              </div>

              {/* Material Composition & Usage */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-bold text-stone-800 block mb-1">
                    Composición del Material
                  </label>
                  <input
                    type="text"
                    value={editingFabric.material || ''}
                    onChange={(e) =>
                      setEditingFabric({
                        ...editingFabric,
                        material: e.target.value,
                      })
                    }
                    placeholder="Ej. 100% Poliéster con teflón repelente"
                    className="w-full text-xs p-2.5 bg-stone-50 border border-stone-300 rounded-xl"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-stone-800 block mb-1">
                    Uso Recomendado
                  </label>
                  <input
                    type="text"
                    value={editingFabric.usage || ''}
                    onChange={(e) =>
                      setEditingFabric({
                        ...editingFabric,
                        usage: e.target.value,
                      })
                    }
                    placeholder="Ej. Exterior total, piscinas y jardines"
                    className="w-full text-xs p-2.5 bg-stone-50 border border-stone-300 rounded-xl"
                  />
                </div>
              </div>

              {/* Cleaning & Care Instructions */}
              <div>
                <label className="text-xs font-bold text-stone-800 block mb-1">
                  Instrucciones de Cuidado y Lavado
                </label>
                <input
                  type="text"
                  value={editingFabric.cleaningInfo || ''}
                  onChange={(e) =>
                    setEditingFabric({
                      ...editingFabric,
                      cleaningInfo: e.target.value,
                    })
                  }
                  placeholder="Ej. Lavado fácil con paño húmedo / Funda removible lavable a máquina con agua fría"
                  className="w-full text-xs p-2.5 bg-stone-50 border border-stone-300 rounded-xl"
                />
              </div>
            </div>

            {/* Modal Actions */}
            <div className="flex items-center justify-end gap-3 pt-3 border-t border-stone-100">
              <button
                type="button"
                onClick={() => setEditingFabric(null)}
                className="px-4 py-2.5 rounded-xl text-stone-600 hover:bg-stone-100 text-xs font-bold cursor-pointer"
              >
                Cancelar
              </button>

              <button
                type="button"
                onClick={handleSaveEditingFabric}
                className="px-5 py-2.5 rounded-xl bg-[#8a532b] hover:bg-[#6e4121] text-white text-xs font-bold flex items-center gap-1.5 shadow-xs cursor-pointer"
              >
                <Check className="w-4 h-4" />
                <span>{isNewFabric ? 'Crear Tela' : 'Guardar Cambios'}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ================= NEW PATTERN MODAL ================= */}
      {newPatternForm.isOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-stone-200 space-y-4">
            <h3 className="font-serif text-lg font-bold text-stone-900">
              Agregar Nuevo Diseño Estampado
            </h3>
            <div className="space-y-3">
              <div>
                <label className="text-xs font-bold text-stone-700 block mb-1">
                  Nombre del Estampado *
                </label>
                <input
                  type="text"
                  value={newPatternForm.name}
                  onChange={(e) => setNewPatternForm({ ...newPatternForm, name: e.target.value })}
                  placeholder="Ej. Flores Vintage Azul"
                  className="w-full text-xs p-2.5 bg-stone-50 border border-stone-300 rounded-xl font-bold"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-stone-700 block mb-1">
                  Foto del Estampado *
                </label>
                <input
                  type="file"
                  accept="image/*"
                  onChange={async (e) => {
                    const f = e.target.files?.[0];
                    if (f) {
                      try {
                        const url = await uploadFileToStorage(f, 'estampados');
                        setNewPatternForm({ ...newPatternForm, image: url });
                      } catch (err) {
                        console.error('Error subiendo estampado:', err);
                      }
                    }
                  }}
                  className="text-xs w-full mb-1"
                />
                <input
                  type="text"
                  value={newPatternForm.image}
                  onChange={(e) => setNewPatternForm({ ...newPatternForm, image: e.target.value })}
                  placeholder="o pega URL de imagen..."
                  className="w-full text-xs p-2 bg-stone-50 border border-stone-300 rounded-xl font-mono"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-stone-700 block mb-1">
                  Descripción breve
                </label>
                <input
                  type="text"
                  value={newPatternForm.description}
                  onChange={(e) =>
                    setNewPatternForm({ ...newPatternForm, description: e.target.value })
                  }
                  placeholder="Ej. Fondo marfil con hojas botánicas"
                  className="w-full text-xs p-2.5 bg-stone-50 border border-stone-300 rounded-xl"
                />
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2 border-t border-stone-100">
              <button
                type="button"
                onClick={() => setNewPatternForm({ ...newPatternForm, isOpen: false })}
                className="px-3.5 py-2 text-xs font-bold text-stone-600 rounded-xl hover:bg-stone-100"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={async () => {
                  if (!newPatternForm.name || !newPatternForm.image) {
                    alert('Introduce nombre e imagen');
                    return;
                  }
                  const newPat: CushionPatternOption = {
                    id: `pat_${Date.now()}`,
                    name: newPatternForm.name.trim(),
                    image: newPatternForm.image.trim(),
                    description: newPatternForm.description.trim(),
                    isActive: true,
                  };
                  await persistSettings({
                    ...settings,
                    cushionPatterns: [...patterns, newPat],
                  }, 'Diseño estampado guardado exitosamente');
                  setNewPatternForm({ isOpen: false, name: '', image: '', description: '' });
                }}
                className="px-4 py-2 bg-[#8a532b] text-white text-xs font-bold rounded-xl hover:bg-[#6e4121] cursor-pointer"
              >
                Guardar Estampado
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ================= NEW TEXTALINA MODAL ================= */}
      {newTextalinaForm.isOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-stone-200 space-y-4">
            <h3 className="font-serif text-lg font-bold text-stone-900">
              Agregar Nuevo Tono Textalina
            </h3>
            <div className="space-y-3">
              <div>
                <label className="text-xs font-bold text-stone-700 block mb-1">
                  Nombre del Tono *
                </label>
                <input
                  type="text"
                  value={newTextalinaForm.name}
                  onChange={(e) =>
                    setNewTextalinaForm({ ...newTextalinaForm, name: e.target.value })
                  }
                  placeholder="Ej. Textalina Azul Océano"
                  className="w-full text-xs p-2.5 bg-stone-50 border border-stone-300 rounded-xl font-bold"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-stone-700 block mb-1">
                  Color HEX de referencia
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="color"
                    value={newTextalinaForm.hex}
                    onChange={(e) =>
                      setNewTextalinaForm({ ...newTextalinaForm, hex: e.target.value })
                    }
                    className="w-10 h-10 rounded-lg cursor-pointer border-0"
                  />
                  <input
                    type="text"
                    value={newTextalinaForm.hex}
                    onChange={(e) =>
                      setNewTextalinaForm({ ...newTextalinaForm, hex: e.target.value })
                    }
                    className="w-28 text-xs p-2 bg-stone-50 border border-stone-300 rounded-xl font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-stone-700 block mb-1">
                  Foto de la Textura *
                </label>
                <input
                  type="file"
                  accept="image/*"
                  onChange={async (e) => {
                    const f = e.target.files?.[0];
                    if (f) {
                      try {
                        const url = await uploadFileToStorage(f, 'textalinas');
                        setNewTextalinaForm({ ...newTextalinaForm, image: url });
                      } catch (err) {
                        console.error('Error subiendo textalina:', err);
                      }
                    }
                  }}
                  className="text-xs w-full mb-1"
                />
                <input
                  type="text"
                  value={newTextalinaForm.image}
                  onChange={(e) =>
                    setNewTextalinaForm({ ...newTextalinaForm, image: e.target.value })
                  }
                  placeholder="o pega URL..."
                  className="w-full text-xs p-2 bg-stone-50 border border-stone-300 rounded-xl font-mono"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-stone-700 block mb-1">
                  Descripción
                </label>
                <input
                  type="text"
                  value={newTextalinaForm.description}
                  onChange={(e) =>
                    setNewTextalinaForm({ ...newTextalinaForm, description: e.target.value })
                  }
                  placeholder="Ej. Trama microperforada resistente al sol"
                  className="w-full text-xs p-2.5 bg-stone-50 border border-stone-300 rounded-xl"
                />
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2 border-t border-stone-100">
              <button
                type="button"
                onClick={() => setNewTextalinaForm({ ...newTextalinaForm, isOpen: false })}
                className="px-3.5 py-2 text-xs font-bold text-stone-600 rounded-xl hover:bg-stone-100"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={async () => {
                  if (!newTextalinaForm.name || !newTextalinaForm.image) {
                    alert('Introduce nombre e imagen');
                    return;
                  }
                  const newTex: CushionTextalinaOption = {
                    id: `tex_${Date.now()}`,
                    name: newTextalinaForm.name.trim(),
                    hex: newTextalinaForm.hex,
                    image: newTextalinaForm.image.trim(),
                    description: newTextalinaForm.description.trim(),
                  };
                  await persistSettings({
                    ...settings,
                    cushionTextalinaOptions: [...textalinas, newTex],
                  }, 'Tono de Textalina guardado exitosamente');
                  setNewTextalinaForm({
                    isOpen: false,
                    name: '',
                    hex: '#CBD5E1',
                    image: '',
                    description: '',
                  });
                }}
                className="px-4 py-2 bg-[#8a532b] text-white text-xs font-bold rounded-xl hover:bg-[#6e4121] cursor-pointer"
              >
                Guardar Tono
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ================= IMAGE ZOOM PREVIEW MODAL ================= */}
      {previewImageModal && previewImageModal.isOpen && (
        <div
          className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4"
          onClick={() => setPreviewImageModal(null)}
        >
          <div
            className="bg-white rounded-3xl max-w-lg w-full overflow-hidden shadow-2xl border border-stone-200"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="p-4 bg-stone-900 text-white flex items-center justify-between">
              <h4 className="font-serif font-bold text-sm">{previewImageModal.title}</h4>
              <button
                type="button"
                onClick={() => setPreviewImageModal(null)}
                className="p-1 rounded-lg text-stone-400 hover:text-white hover:bg-stone-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="max-h-[60vh] bg-stone-100 flex items-center justify-center">
              <img
                src={previewImageModal.image}
                alt={previewImageModal.title}
                referrerPolicy="no-referrer"
                className="max-w-full max-h-[60vh] object-contain"
              />
            </div>
            {previewImageModal.description && (
              <div className="p-4 bg-[#FAF8F5] border-t border-[#E8E2DC]">
                <p className="text-xs text-[#5C3D2E]">{previewImageModal.description}</p>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
