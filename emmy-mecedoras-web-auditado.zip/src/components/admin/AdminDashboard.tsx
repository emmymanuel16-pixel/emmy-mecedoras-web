import React, { useState, useEffect } from 'react';
import { 
  X, LogOut, Package, FolderTree, Image as ImageIcon, Settings, 
  Plus, Trash2, Edit3, Save, Check, AlertCircle, ArrowUp, 
  ArrowDown, Star, Tag, Eye, EyeOff, Lock, Upload, Sparkles, Layers, 
  CheckCircle2, RefreshCw, Download, HelpCircle, MessageSquare, 
  ShieldCheck, CornerDownRight, CheckCircle, XCircle, Loader2,
  Cloud, Database, Flame, Zap, Rotate3d, BarChart3, TrendingUp, Palette, Scissors, Key, FileText, RotateCcw,
  HardDrive, ExternalLink, AlertTriangle, Copy
} from 'lucide-react';
import { Banner, Category, ColorOption, CushionBackrestStyleSettings, CushionBorderStyleSettings, CushionColorOption, CushionFabricCategory, CushionPatternOption, CushionTextalinaOption, Product, ProductVariant, Review, StoreSettings } from '../../types';
import { api } from '../../services/api';
import { FirebaseService } from '../../services/firebaseService';
import { uploadToFirebaseStorage } from '../../services/firebaseStorageService';
import { formatPrice } from '../../utils/whatsapp';
import { generateCatalogPDF } from '../../utils/pdfGenerator';
import { compressImageFile, compressMultipleImageFiles, uploadImagesToServer, validateImageFile, deleteUploadedImageFromServer } from '../../utils/imageCompressor';
import { notifyError, reportNonBlockingError } from '../../utils/errorReporting';
import { 
  STANDARD_ROCKER_COLORS, 
  WIDE_CUSHION_COLOR_PALETTE 
} from '../../data/initialData';
import { AdminAnalyticsSection } from './AdminAnalyticsSection';
import { AdminFabricsManager } from './AdminFabricsManager';

interface AdminDashboardProps {
  isOpen: boolean;
  onClose: () => void;
  products: Product[];
  categories: Category[];
  banners: Banner[];
  settings: StoreSettings;
  onDataRefresh: () => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  isOpen,
  onClose,
  products,
  categories,
  banners,
  settings,
  onDataRefresh,
}) => {
  // Authentication State
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoggingIn, setIsLoggingIn] = useState(false);
  const [loginError, setLoginError] = useState('');
  const [activeTab, setActiveTab] = useState<'products' | 'categories' | 'banners' | 'reviews' | 'fabrics' | 'settings' | 'tools' | 'firebase' | 'analytics'>('products');
  const [isFirebaseSyncing, setIsFirebaseSyncing] = useState(false);
  const [firebaseUserEmail, setFirebaseUserEmail] = useState<string | null>(null);

  // Reviews State
  const [reviewsList, setReviewsList] = useState<Review[]>([]);
  const [reviewStatusFilter, setReviewStatusFilter] = useState<'all' | 'pending' | 'approved' | 'rejected'>('all');
  const [replyingReviewId, setReplyingReviewId] = useState<string | null>(null);
  const [replyText, setReplyText] = useState<string>('');

  // Product Editing State
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [isCreatingProduct, setIsCreatingProduct] = useState(false);
  const [productSearch, setProductSearch] = useState('');
  const [productCategoryFilter, setProductCategoryFilter] = useState('all');
  const [adminCushionColorFilter, setAdminCushionColorFilter] = useState<string>('all');

  // Category Editing State
  const [editingCategory, setEditingCategory] = useState<Category | null>(null);
  const [isCreatingCategory, setIsCreatingCategory] = useState(false);

  // Banner Editing State
  const [editingBanner, setEditingBanner] = useState<Banner | null>(null);
  const [isCreatingBanner, setIsCreatingBanner] = useState(false);

  // Settings State
  const [localSettings, setLocalSettings] = useState<StoreSettings>(settings);
  const [saveSuccessMsg, setSaveSuccessMsg] = useState('');
  const [isSaving, setIsSaving] = useState(false);
  const [isOptimizingImages, setIsOptimizingImages] = useState(false);
  const [optimizingStatus, setOptimizingStatus] = useState<string>('');

  // Check auth on mount
  useEffect(() => {
    const checkAuth = async () => {
      const valid = await api.verifyToken();
      if (valid) {
        setIsAuthenticated(true);
        const fbUser = FirebaseService.getCurrentUser();
        if (fbUser) {
          setFirebaseUserEmail(fbUser.email || fbUser.displayName || 'Usuario Firebase');
        }
        loadAdminReviews();
      }
    };
    if (isOpen) {
      checkAuth();
      setLocalSettings(settings);
    }
  }, [isOpen]);

  const loadAdminReviews = async () => {
    try {
      const data = await api.getReviews();
      setReviewsList(data);
    } catch (e) {
      console.warn('Failed to load reviews in admin:', e);
    }
  };

  const handleApproveReview = async (id: string) => {
    try {
      await api.updateReview(id, { status: 'approved' });
      showFeedback('Reseña aprobada con éxito');
      loadAdminReviews();
      onDataRefresh();
    } catch (err: any) {
      alert('Error al aprobar: ' + err.message);
    }
  };

  const handleRejectReview = async (id: string) => {
    try {
      await api.updateReview(id, { status: 'rejected' });
      showFeedback('Reseña rechazada');
      loadAdminReviews();
      onDataRefresh();
    } catch (err: any) {
      alert('Error al rechazar: ' + err.message);
    }
  };

  const handleSaveReply = async (id: string) => {
    if (!replyText.trim()) return;
    try {
      await api.updateReview(id, { adminReply: replyText.trim() });
      showFeedback('Respuesta oficial publicada');
      setReplyingReviewId(null);
      setReplyText('');
      loadAdminReviews();
      onDataRefresh();
    } catch (err: any) {
      alert('Error al responder: ' + err.message);
    }
  };

  const handleDeleteReview = async (id: string) => {
    if (!window.confirm('¿Estás seguro de eliminar esta reseña permanentemente?')) return;
    try {
      await api.deleteReview(id);
      showFeedback('Reseña eliminada');
      loadAdminReviews();
      onDataRefresh();
    } catch (err: any) {
      alert('Error al eliminar: ' + err.message);
    }
  };

  if (!isOpen) return null;

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!username.trim() || !password.trim()) {
      setLoginError('Por favor ingresa usuario y contraseña');
      return;
    }
    setLoginError('');
    setIsLoggingIn(true);
    try {
      const res = await api.login(username.trim(), password.trim());
      if (res.success) {
        setIsAuthenticated(true);
        setPassword('');
        const fbUser = FirebaseService.getCurrentUser();
        if (fbUser) setFirebaseUserEmail(fbUser.email || fbUser.displayName || 'Usuario Firebase');
        loadAdminReviews();
      } else {
        setLoginError(res.error || 'Credenciales incorrectas');
        setPassword('');
      }
    } catch {
      setLoginError('Error en la autenticación. Intente de nuevo.');
      setPassword('');
    } finally {
      setIsLoggingIn(false);
    }
  };

  const handleGoogleLogin = async () => {
    setLoginError('');
    setIsLoggingIn(true);
    try {
      const res = await api.loginWithGoogle();
      if (res.success) {
        setIsAuthenticated(true);
        setFirebaseUserEmail(res.username || 'Usuario Google');
        loadAdminReviews();
      } else {
        setLoginError(res.error || 'No se pudo iniciar sesión con Google');
      }
    } catch (e: any) {
      setLoginError(e.message || 'Error al conectar con Firebase Auth');
    } finally {
      setIsLoggingIn(false);
    }
  };

  const handleBackupToFirebase = async () => {
    setIsFirebaseSyncing(true);
    try {
      const res = await FirebaseService.backupAllToFirestore({
        products,
        categories,
        banners,
        settings: localSettings,
        reviews: reviewsList
      });
      if (res.success) {
        showFeedback(res.message);
      } else {
        alert(res.message);
      }
    } catch (err: any) {
      alert('Error al respaldar en Firebase: ' + (err.message || err));
    } finally {
      setIsFirebaseSyncing(false);
    }
  };

  const handleRestoreFromFirebase = async () => {
    setIsFirebaseSyncing(true);
    try {
      await onDataRefresh();
      showFeedback('¡Catálogo sincronizado desde Firestore!');
    } catch (err: any) {
      alert('Error al restaurar desde Firebase: ' + (err.message || err));
    } finally {
      setIsFirebaseSyncing(false);
    }
  };

  const handleSeedFirebase = async () => {
    setIsFirebaseSyncing(true);
    try {
      const res = await FirebaseService.seedInitialDataIfEmpty();
      if (res.seeded) {
        showFeedback('¡Datos iniciales sembrados exitosamente en Firestore!');
        onDataRefresh();
      } else {
        showFeedback('Firestore ya contiene datos. Usa "Sincronizar y Respaldar" para actualizar.');
      }
    } catch (err: any) {
      alert('Error al inicializar Firestore: ' + (err.message || err));
    } finally {
      setIsFirebaseSyncing(false);
    }
  };

  // Firebase Cloud Storage diagnostics
  const [storageCheckState, setStorageCheckState] = useState<{
    status: 'idle' | 'checking' | 'active' | 'rules_needed' | 'not_enabled';
    message: string;
  }>({
    status: 'idle',
    message: ''
  });
  const [copiedStorageRules, setCopiedStorageRules] = useState(false);

  const handleTestStorageConnection = async () => {
    setStorageCheckState({ status: 'checking', message: 'Verificando conexión con Firebase Storage...' });
    try {
      const testBlob = new Blob(['ping'], { type: 'text/plain' });
      await uploadToFirebaseStorage(testBlob, '_ping');
      setStorageCheckState({
        status: 'active',
        message: '¡Excelente! Firebase Cloud Storage está activo y listo para almacenar fotos de tus productos.'
      });
    } catch (err: any) {
      console.warn('Test Cloud Storage:', err);
      const isUnauthorized = err?.code === 'storage/unauthorized' || String(err).includes('unauthorized');
      if (isUnauthorized) {
        setStorageCheckState({
          status: 'rules_needed',
          message: '¡El almacenamiento ya está creado en tu proyecto! Solo falta habilitar el permiso de lectura/escritura en la pestaña Reglas de Storage para que la web pueda subir fotos.'
        });
      } else {
        setStorageCheckState({
          status: 'not_enabled',
          message: 'Cloud Storage aún no responde. Asegúrate de haber completado la configuración inicial en la consola de Firebase.'
        });
      }
    }
  };

  const handleLogout = () => {
    api.clearAuth();
    setIsAuthenticated(false);
    setUsername('');
    setPassword('');
    setShowPassword(false);
  };

  const showFeedback = (msg: string) => {
    setSaveSuccessMsg(msg);
    setTimeout(() => setSaveSuccessMsg(''), 3000);
  };

  const uploadSingleImage = async (file: File, folder = 'telas'): Promise<string> => {
    const compressed = await compressImageFile(file, { maxWidth: 1000, maxHeight: 1000, quality: 0.8 });
    try {
      const url = await uploadToFirebaseStorage(compressed, folder);
      if (url && !url.startsWith('data:image/')) return url;
    } catch (e) {
      console.warn('Firebase storage fallback to server:', e);
    }
    const serverUrls = await uploadImagesToServer([compressed]);
    return serverUrls[0] || compressed;
  };

  // ================= PRODUCTS CRUD =================
  const handleOpenCreateProduct = () => {
    const defaultCat = categories[0]?.id || 'mecedoras-grandes';
    setEditingProduct({
      id: `prod_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      name: '',
      description: '',
      price: 0,
      previousPrice: undefined,
      categoryId: defaultCat,
      productType: 'mecedora-grande',
      stock: 5,
      material: 'Fibra de vidrio',
      woodType: undefined,
      dimensions: undefined,
      weightCapacity: undefined,
      colors: [
        { name: 'Blanco', hex: '#FFFFFF' },
        { name: 'Caoba (marrón)', hex: '#4A1515' },
        { name: 'Negro', hex: '#1C1C1C' },
      ],
      finishes: ['Barniz semimate', 'Brillante'],
      upholstery: 'Lino antimanchas',
      includedItems: ['1 Mecedora'],
      images: [],
      mainImage: '',
      isActive: true,
      isFeatured: false,
      isNew: true,
      isOffer: false,
    });
    setIsCreatingProduct(true);
  };

  const handleSaveProduct = async () => {
    if (!editingProduct || !editingProduct.name || !editingProduct.name.trim()) {
      alert('Por favor introduce un nombre para el producto');
      return;
    }
    if (isOptimizingImages) {
      alert('Por favor espera a que terminen de procesarse y optimizarse las imágenes seleccionadas.');
      return;
    }
    setIsSaving(true);
    try {
      const defaultPlaceholder = 'https://images.unsplash.com/photo-1586023492125-27b2c045efd7?auto=format&fit=crop&w=800&q=80';
      const rawImages = (editingProduct.images || []).filter(img => img && typeof img === 'string' && img.trim().length > 0);
      
      const uniqueImages: string[] = [];
      const seen = new Set<string>();

      const targetMain = (editingProduct.mainImage && editingProduct.mainImage.trim().length > 0)
        ? editingProduct.mainImage.trim()
        : rawImages[0];

      if (targetMain) {
        seen.add(targetMain);
        uniqueImages.push(targetMain);
      }

      rawImages.forEach(img => {
        const trimmed = img.trim();
        if (trimmed && !seen.has(trimmed)) {
          seen.add(trimmed);
          uniqueImages.push(trimmed);
        }
      });

      const productImages = uniqueImages.length > 0 ? uniqueImages : [defaultPlaceholder];

      // Auto-upload any base64 images directly to Firebase Cloud Storage before saving
      let finalImages = productImages;
      if (productImages.some(img => img && typeof img === 'string' && img.startsWith('data:image/'))) {
        try {
          finalImages = await uploadImagesToServer(productImages);
        } catch (uploadErr) {
          console.warn('Pre-upload to Cloud Storage warning:', uploadErr);
        }
      }
      const mainImg = finalImages[0] || defaultPlaceholder;

      const productPayload: Product = {
        ...editingProduct,
        id: editingProduct.id || `prod_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
        name: editingProduct.name.trim(),
        description: editingProduct.description?.trim() || '',
        price: Number(editingProduct.price) || 0,
        previousPrice: editingProduct.previousPrice ? Number(editingProduct.previousPrice) : undefined,
        stock: editingProduct.stock !== undefined ? Number(editingProduct.stock) : 0,
        categoryId: editingProduct.categoryId || (categories[0]?.id || 'mecedoras-grandes'),
        productType: (editingProduct.productType || editingProduct.categoryId || 'mecedora-grande') as any,
        material: editingProduct.material || 'Fibra de vidrio',
        images: finalImages,
        mainImage: mainImg,
        colors: Array.isArray(editingProduct.colors) ? editingProduct.colors : [],
        isActive: editingProduct.isActive !== undefined ? editingProduct.isActive : true,
        isFeatured: Boolean(editingProduct.isFeatured),
        isNew: Boolean(editingProduct.isNew),
        isOffer: Boolean(editingProduct.isOffer),
        rating: editingProduct.rating || 5.0,
        reviewCount: editingProduct.reviewCount || 0,
      };

      if (isCreatingProduct) {
        await api.createProduct(productPayload);
        showFeedback('¡Producto creado exitosamente!');
      } else {
        await api.updateProduct(productPayload.id, productPayload);
        showFeedback('¡Producto actualizado exitosamente!');
      }
      setEditingProduct(null);
      setIsCreatingProduct(false);
      await onDataRefresh();
    } catch (err: any) {
      console.error('Error saving product:', err);
      alert(err.message || 'Error al guardar el producto');
    } finally {
      setIsSaving(false);
    }
  };

  const handleDeleteProduct = async (id: string) => {
    if (!window.confirm('¿Seguro que deseas eliminar este producto del catálogo?')) return;
    try {
      setIsSaving(true);
      await api.deleteProduct(id);
      showFeedback('Producto eliminado');
      await onDataRefresh();
    } catch (err: any) {
      console.error('Error deleting product:', err);
      alert(err.message || 'Error al eliminar el producto');
    } finally {
      setIsSaving(false);
    }
  };

  const handleDeleteAllProducts = async () => {
    if (products.length === 0) {
      alert('El catálogo ya se encuentra vacío.');
      return;
    }
    const confirmed = window.confirm(
      '¿Estás seguro de que deseas eliminar TODOS los productos del catálogo? Esta acción dejará el catálogo en 0 artículos y NO se rellenará automáticamente.'
    );
    if (!confirmed) return;

    try {
      setIsSaving(true);
      await api.deleteAllProducts();
      showFeedback('Catálogo vaciado exitosamente (0 productos).');
      await onDataRefresh();
    } catch (err: any) {
      alert(err.message || 'Error al vaciar el catálogo.');
    } finally {
      setIsSaving(false);
    }
  };

  const handleRestoreFactoryProducts = async () => {
    const confirmed = window.confirm(
      '¿Deseas restaurar el catálogo con los 12 productos de fábrica estándar?'
    );
    if (!confirmed) return;

    try {
      setIsSaving(true);
      await api.restoreFactoryProducts();
      showFeedback('Stock de fábrica restaurado exitosamente.');
      await onDataRefresh();
    } catch (err: any) {
      alert(err.message || 'Error al restaurar los productos.');
    } finally {
      setIsSaving(false);
    }
  };

  // Image helpers for product editor
  const handleMultipleFilesUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0 || !editingProduct) return;

    const fileList: File[] = Array.from(files);

    // 1. Validate file formats and sizes
    for (const file of fileList) {
      const val = validateImageFile(file);
      if (!val.valid) {
        alert(val.error);
        e.target.value = '';
        return;
      }
    }

    setIsOptimizingImages(true);
    setOptimizingStatus(`Optimizando 0 de ${fileList.length} imágenes...`);

    try {
      // 2. Compress images in client with high fidelity while preserving exact order
      const compressedList = await compressMultipleImageFiles(
        fileList,
        { maxWidth: 900, maxHeight: 900, quality: 0.75, mimeType: 'image/jpeg' },
        (processed, total, currentName) => {
          setOptimizingStatus(`Optimizando imagen ${processed} de ${total}: ${currentName}`);
        }
      );

      if (compressedList.length > 0) {
        setOptimizingStatus(`Guardando ${compressedList.length} imágenes en el servidor...`);
        // 3. Upload to server to convert base64 into permanent lightweight /uploads/productos/... URLs
        const serverUrls = await uploadImagesToServer(compressedList, (uploaded, total) => {
          setOptimizingStatus(`Subiendo imagen ${uploaded} de ${total} al servidor...`);
        });

        const finalUrls = serverUrls.length > 0 ? serverUrls : compressedList;

        setEditingProduct((prev) => {
          if (!prev) return null;
          // Clean up placeholder if it was the only image
          const existingImages = (prev.images || []).filter(
            (img) => !img.includes('images.unsplash.com/photo-1586023492125')
          );
          const combined = [...existingImages, ...finalUrls];
          return {
            ...prev,
            images: combined,
            mainImage: prev.mainImage && !prev.mainImage.includes('images.unsplash.com/photo-1586023492125')
              ? prev.mainImage
              : combined[0] || '',
          };
        });
        showFeedback(`¡${finalUrls.length} fotos procesadas y guardadas correctamente!`);
      }
    } catch (err: any) {
      console.error('Error procesando múltiples fotos:', err);
      alert('Error procesando las imágenes: ' + (err.message || err));
    } finally {
      setIsOptimizingImages(false);
      setOptimizingStatus('');
      // Reset input element so user can upload more or same files
      e.target.value = '';
    }
  };

  const handleAddImageUrl = (url: string) => {
    if (!url.trim() || !editingProduct) return;
    const updatedImages = [...editingProduct.images, url.trim()];
    setEditingProduct({
      ...editingProduct,
      images: updatedImages,
      mainImage: editingProduct.mainImage || updatedImages[0],
    });
  };

  const handleRemoveImage = (index: number) => {
    if (!editingProduct) return;
    const imageToRemove = editingProduct.images[index];
    const updatedImages = editingProduct.images.filter((_, i) => i !== index);
    const newMain = editingProduct.mainImage === imageToRemove
      ? updatedImages[0] || ''
      : editingProduct.mainImage;
    
    // Clean up physical file on server in background if it was stored locally
    if (imageToRemove && imageToRemove.startsWith('/uploads/productos/')) {
      deleteUploadedImageFromServer(imageToRemove).catch((err) => reportNonBlockingError('La imagen se quitó del producto, pero no pudo eliminarse físicamente del almacenamiento.', err));
    }

    setEditingProduct({
      ...editingProduct,
      images: updatedImages,
      mainImage: newMain,
    });
  };

  const handleMoveImage = (fromIdx: number, toIdx: number) => {
    if (!editingProduct) return;
    if (toIdx < 0 || toIdx >= editingProduct.images.length) return;
    const imgs = [...editingProduct.images];
    const [moved] = imgs.splice(fromIdx, 1);
    imgs.splice(toIdx, 0, moved);
    setEditingProduct({
      ...editingProduct,
      images: imgs,
      mainImage: imgs[0],
    });
  };

  // ================= CATEGORIES CRUD =================
  const handleSaveCategory = async () => {
    if (!editingCategory || !editingCategory.name || !editingCategory.name.trim()) {
      alert('Por favor introduce el nombre de la categoría');
      return;
    }
    setIsSaving(true);
    try {
      if (isCreatingCategory) {
        const slugId = editingCategory.name
          .toLowerCase()
          .trim()
          .normalize('NFD')
          .replace(/[\u0300-\u036f]/g, '')
          .replace(/[^a-z0-9]+/g, '-')
          .replace(/^-+|-+$/g, '') || `cat_${Date.now()}`;
        
        const existingCat = categories.find(c => c.id === slugId || c.id === editingCategory.id);
        const finalId = existingCat ? `cat_${Date.now()}` : (editingCategory.id || slugId);

        const categoryToSave: Category = {
          ...editingCategory,
          id: finalId,
          name: editingCategory.name.trim(),
          description: editingCategory.description?.trim() || '',
          image: editingCategory.image || 'https://images.unsplash.com/photo-1586023492125-27b2c045efd7?auto=format&fit=crop&w=800&q=80',
          order: editingCategory.order !== undefined ? Number(editingCategory.order) : (categories.length + 1),
          isActive: editingCategory.isActive !== undefined ? editingCategory.isActive : true
        };

        await api.createCategory(categoryToSave);
        showFeedback('¡Categoría creada exitosamente!');
      } else {
        const categoryToUpdate: Category = {
          ...editingCategory,
          name: editingCategory.name.trim(),
          description: editingCategory.description?.trim() || '',
          order: editingCategory.order !== undefined ? Number(editingCategory.order) : 1,
          isActive: editingCategory.isActive !== undefined ? editingCategory.isActive : true
        };
        await api.updateCategory(editingCategory.id, categoryToUpdate);
        showFeedback('¡Categoría actualizada exitosamente!');
      }
      setEditingCategory(null);
      setIsCreatingCategory(false);
      await onDataRefresh();
    } catch (err: any) {
      alert('Error al guardar categoría: ' + (err.message || err));
    } finally {
      setIsSaving(false);
    }
  };

  const handleDeleteCategory = async (id: string) => {
    if (!window.confirm('¿Seguro que deseas eliminar esta categoría?')) return;
    setIsSaving(true);
    try {
      await api.deleteCategory(id);
      showFeedback('Categoría eliminada');
      await onDataRefresh();
    } catch (err) {
      notifyError('No se pudo eliminar la categoría.', err);
    } finally {
      setIsSaving(false);
    }
  };

  // ================= BANNERS CRUD =================
  const handleSaveBanner = async () => {
    if (!editingBanner || !editingBanner.title) return;
    setIsSaving(true);
    try {
      if (isCreatingBanner) {
        await api.createBanner(editingBanner);
        showFeedback('Banner agregado');
      } else {
        await api.updateBanner(editingBanner.id, editingBanner);
        showFeedback('Banner actualizado');
      }
      setEditingBanner(null);
      setIsCreatingBanner(false);
      onDataRefresh();
    } catch (err: any) {
      notifyError('No se pudo guardar el banner.', err);
    } finally {
      setIsSaving(false);
    }
  };

  const handleDeleteBanner = async (id: string) => {
    if (!window.confirm('¿Seguro que deseas eliminar este banner?')) return;
    setIsSaving(true);
    try {
      await api.deleteBanner(id);
      showFeedback('Banner eliminado');
      await onDataRefresh();
    } catch (err) {
      notifyError('No se pudo eliminar el banner.', err);
    } finally {
      setIsSaving(false);
    }
  };

  // ================= SETTINGS SAVE =================
  const handleSaveSettings = async () => {
    setIsSaving(true);
    try {
      await api.updateSettings(localSettings);
      showFeedback('¡Configuración de la tienda guardada!');
      onDataRefresh();
    } catch (err: any) {
      notifyError('No se pudo guardar la configuración.', err);
    } finally {
      setIsSaving(false);
    }
  };

  // ================= SEED RESET =================
  const handleResetCatalog = async () => {
    if (window.confirm('¿Estás seguro de restablecer el catálogo a los datos predeterminados de mecedoras y muebles?')) {
      const ok = await api.resetToSeed();
      if (ok) {
        showFeedback('Catálogo restaurado a datos iniciales');
        onDataRefresh();
      }
    }
  };

  // PDF Generation State
  const [isGeneratingPDF, setIsGeneratingPDF] = useState(false);
  const [pdfProgress, setPdfProgress] = useState<{ step: string; percentage: number } | null>(null);

  const handleGeneratePDF = async () => {
    if (isGeneratingPDF) return;
    try {
      setIsGeneratingPDF(true);
      setPdfProgress({ step: 'Iniciando generación de catálogo...', percentage: 0 });
      await generateCatalogPDF(products, categories, localSettings, (prog) => {
        setPdfProgress(prog);
      });
      showFeedback('¡Catálogo PDF generado y descargado con éxito!');
    } catch (err) {
      console.error('Error generating PDF catalog:', err);
      showFeedback('Hubo un inconveniente al generar el PDF. Por favor reintente.');
    } finally {
      setIsGeneratingPDF(false);
      setTimeout(() => setPdfProgress(null), 3500);
    }
  };

  // Filtered Products for Admin List
  const filteredProducts = products.filter((p) => {
    const matchesCat = productCategoryFilter === 'all' || p.categoryId === productCategoryFilter;
    const searchLower = (productSearch || '').toLowerCase().trim();
    const prodName = (p.name || '').toLowerCase();
    const prodMat = (p.material || '').toLowerCase();
    const matchesSearch = !searchLower || prodName.includes(searchLower) || prodMat.includes(searchLower);
    return matchesCat && matchesSearch;
  });

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-stone-950/80 backdrop-blur-sm flex items-center justify-center p-2 sm:p-4 animate-fadeIn">
      <div className="relative w-full max-w-6xl bg-[#fbf9f5] rounded-3xl shadow-2xl overflow-hidden min-h-[85vh] max-h-[95vh] flex flex-col border border-stone-300">
        
        {/* TOP BAR */}
        <div className="p-4 sm:p-5 bg-[#3b2210] text-[#f7eedf] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-[#8a532b] text-white">
              <Settings className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-serif text-lg sm:text-xl font-bold">Panel Administrativo</h2>
              <p className="text-xs text-stone-300">Gestión de Catálogo, Precios, Fotos y WhatsApp</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <div className="hidden md:flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-950/40 border border-emerald-500/30 text-emerald-300 text-xs font-semibold">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span>Firebase Conectado</span>
            </div>
            {isAuthenticated && (
              <>
                <button
                  onClick={handleGeneratePDF}
                  disabled={isGeneratingPDF}
                  className="px-3 py-1.5 rounded-xl bg-amber-600 hover:bg-amber-500 disabled:opacity-50 text-white text-xs font-semibold flex items-center gap-1.5 transition-colors shadow-xs cursor-pointer"
                  title="Descargar Catálogo Completo en formato PDF"
                >
                  {isGeneratingPDF ? (
                    <>
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      <span className="hidden sm:inline">Generando PDF...</span>
                    </>
                  ) : (
                    <>
                      <FileText className="w-3.5 h-3.5" />
                      <span className="hidden sm:inline">Catálogo PDF</span>
                    </>
                  )}
                </button>
                <button
                  onClick={handleLogout}
                  className="px-3 py-1.5 rounded-xl bg-stone-800/80 hover:bg-stone-800 text-stone-200 text-xs font-semibold flex items-center gap-1.5 transition-colors"
                  title="Cerrar sesión"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">Cerrar Sesión</span>
                </button>
              </>
            )}
            <button
              onClick={onClose}
              className="p-2 rounded-xl text-stone-300 hover:text-white hover:bg-stone-800 transition-colors"
              aria-label="Cerrar panel"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* PDF GENERATION PROGRESS BANNER */}
        {pdfProgress && (
          <div className="bg-stone-900 text-stone-100 text-xs py-2.5 px-4 flex flex-col sm:flex-row items-center justify-between gap-2 border-b border-stone-800 animate-fadeIn">
            <div className="flex items-center gap-2">
              <Loader2 className="w-3.5 h-3.5 animate-spin text-amber-400 shrink-0" />
              <span>{pdfProgress.step}</span>
            </div>
            <div className="w-full sm:w-48 bg-stone-800 rounded-full h-2 overflow-hidden">
              <div
                className="bg-amber-500 h-full rounded-full transition-all duration-300"
                style={{ width: `${pdfProgress.percentage}%` }}
              />
            </div>
          </div>
        )}

        {/* FEEDBACK TOAST */}
        {saveSuccessMsg && (
          <div className="bg-emerald-600 text-white text-xs font-bold py-2.5 px-4 text-center animate-fadeIn flex items-center justify-center gap-2 shadow-inner">
            <CheckCircle2 className="w-4 h-4" />
            <span>{saveSuccessMsg}</span>
          </div>
        )}

        {/* CONTENT AREA */}
        {!isAuthenticated ? (
          /* SECURE LOGIN FORM */
          <div className="flex-1 flex items-center justify-center p-4 sm:p-6 bg-stone-100/90">
            <div className="max-w-md w-full bg-white p-6 sm:p-8 rounded-3xl shadow-xl border border-stone-200/90 space-y-6">
              <div className="text-center space-y-2">
                <div className="w-14 h-14 rounded-2xl bg-[#8a532b]/10 text-[#8a532b] mx-auto flex items-center justify-center border border-[#8a532b]/20 shadow-inner">
                  <Lock className="w-7 h-7" />
                </div>
                <h3 className="font-serif text-2xl font-bold text-stone-900">Acceso Administrativo</h3>
                <p className="text-xs text-stone-500">
                  Ingresa tus credenciales autorizadas para gestionar el catálogo.
                </p>
              </div>

              {loginError && (
                <div className="p-3.5 rounded-xl bg-red-50 border border-red-200 text-red-700 text-xs font-medium flex items-center gap-2.5 animate-fadeIn">
                  <AlertCircle className="w-4 h-4 shrink-0 text-red-600" />
                  <span className="leading-snug">{loginError}</span>
                </div>
              )}

              <form onSubmit={handleLogin} className="space-y-4">
                <div>
                  <label className="text-xs font-bold text-stone-700 block mb-1.5">
                    Correo Electrónico o Usuario
                  </label>
                  <div className="relative">
                    <input
                      id="admin-username-input"
                      type="text"
                      value={username}
                      onChange={(e) => setUsername(e.target.value)}
                      placeholder="ej. emmy.manuel16@gmail.com"
                      autoComplete="username"
                      disabled={isLoggingIn}
                      required
                      className="w-full text-sm p-3.5 bg-stone-50 border border-stone-300 rounded-xl focus:ring-2 focus:ring-[#8a532b] focus:border-[#8a532b] focus:bg-white focus:outline-none transition-all disabled:opacity-60"
                    />
                  </div>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <label className="text-xs font-bold text-stone-700">
                      Contraseña
                    </label>
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="text-[11px] text-stone-500 hover:text-[#8a532b] flex items-center gap-1 font-medium cursor-pointer transition-colors"
                      tabIndex={-1}
                    >
                      {showPassword ? (
                        <>
                          <EyeOff className="w-3.5 h-3.5" />
                          <span>Ocultar</span>
                        </>
                      ) : (
                        <>
                          <Eye className="w-3.5 h-3.5" />
                          <span>Mostrar</span>
                        </>
                      )}
                    </button>
                  </div>
                  <div className="relative">
                    <input
                      id="admin-password-input"
                      type={showPassword ? 'text' : 'password'}
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="••••••••••••"
                      autoComplete="current-password"
                      disabled={isLoggingIn}
                      required
                      className="w-full text-sm p-3.5 pr-11 bg-stone-50 border border-stone-300 rounded-xl focus:ring-2 focus:ring-[#8a532b] focus:border-[#8a532b] focus:bg-white focus:outline-none transition-all disabled:opacity-60 font-mono tracking-wider"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-stone-400 hover:text-stone-700 p-1 rounded-lg transition-colors cursor-pointer"
                      title={showPassword ? 'Ocultar contraseña' : 'Ver contraseña'}
                    >
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                <button
                  id="admin-submit-btn"
                  type="submit"
                  disabled={isLoggingIn}
                  className="w-full py-3.5 px-4 rounded-xl bg-[#8a532b] hover:bg-[#6e4121] active:bg-[#573319] text-white font-bold text-sm shadow-md hover:shadow-lg transition-all active:scale-[0.99] disabled:opacity-60 flex items-center justify-center gap-2 cursor-pointer"
                >
                  {isLoggingIn ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span>Verificando credenciales...</span>
                    </>
                  ) : (
                    <>
                      <Lock className="w-4 h-4" />
                      <span>Entrar al Administrador</span>
                    </>
                  )}
                </button>
              </form>

              {/* GOOGLE FIREBASE AUTH BUTTON */}
              <div className="pt-1">
                <div className="relative flex py-2 items-center">
                  <div className="flex-grow border-t border-stone-200"></div>
                  <span className="flex-shrink mx-3 text-stone-400 text-xs uppercase tracking-wider font-semibold">o continuar con</span>
                  <div className="flex-grow border-t border-stone-200"></div>
                </div>

                <button
                  type="button"
                  onClick={handleGoogleLogin}
                  disabled={isLoggingIn}
                  className="w-full py-3 px-4 rounded-xl bg-white hover:bg-stone-50 border border-stone-300 text-stone-700 font-bold text-xs shadow-xs transition-all flex items-center justify-center gap-2.5 cursor-pointer disabled:opacity-60"
                >
                  <svg className="w-4 h-4" viewBox="0 0 24 24">
                    <path
                      fill="#4285F4"
                      d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                    />
                    <path
                      fill="#34A853"
                      d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                    />
                    <path
                      fill="#FBBC05"
                      d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                    />
                    <path
                      fill="#EA4335"
                      d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                    />
                  </svg>
                  <span>Iniciar Sesión con Google (Firebase)</span>
                </button>
              </div>

              <div className="pt-2">
                <div className="flex items-center justify-center gap-1.5 text-[11px] text-stone-500 bg-stone-50 py-2.5 px-3 rounded-xl border border-stone-200/70">
                  <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>Acceso cifrado y seguro con protección contra ataques</span>
                </div>
              </div>
            </div>
          </div>
        ) : (
          /* AUTHENTICATED ADMIN INTERFACE */
          <div className="flex-1 flex flex-col overflow-hidden">
            
            {/* TABS NAVIGATION */}
            <div className="bg-white border-b border-stone-200 px-4 sm:px-6 flex items-center gap-2 sm:gap-4 overflow-x-auto no-scrollbar py-2">
              <button
                onClick={() => setActiveTab('analytics')}
                className={`px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-2 transition-colors shrink-0 ${
                  activeTab === 'analytics'
                    ? 'bg-[#8a532b] text-white shadow-xs'
                    : 'text-stone-600 hover:bg-stone-100'
                }`}
              >
                <BarChart3 className="w-4 h-4 text-amber-400" />
                <span>Estadísticas & Visitas</span>
              </button>

              <button
                onClick={() => { setActiveTab('products'); setEditingProduct(null); }}
                className={`px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-2 transition-colors shrink-0 ${
                  activeTab === 'products'
                    ? 'bg-[#8a532b] text-white'
                    : 'text-stone-600 hover:bg-stone-100'
                }`}
              >
                <Package className="w-4 h-4" />
                <span>Productos ({products.length})</span>
              </button>

              <button
                onClick={() => { setActiveTab('categories'); setEditingCategory(null); }}
                className={`px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-2 transition-colors shrink-0 ${
                  activeTab === 'categories'
                    ? 'bg-[#8a532b] text-white'
                    : 'text-stone-600 hover:bg-stone-100'
                }`}
              >
                <FolderTree className="w-4 h-4" />
                <span>Categorías ({categories.length})</span>
              </button>

              <button
                onClick={() => { setActiveTab('banners'); setEditingBanner(null); }}
                className={`px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-2 transition-colors shrink-0 ${
                  activeTab === 'banners'
                    ? 'bg-[#8a532b] text-white'
                    : 'text-stone-600 hover:bg-stone-100'
                }`}
              >
                <ImageIcon className="w-4 h-4" />
                <span>Carrusel Principal ({banners.length})</span>
              </button>

              <button
                onClick={() => { setActiveTab('reviews'); loadAdminReviews(); }}
                className={`px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-2 transition-colors shrink-0 ${
                  activeTab === 'reviews'
                    ? 'bg-[#8a532b] text-white'
                    : 'text-stone-600 hover:bg-stone-100'
                }`}
              >
                <MessageSquare className="w-4 h-4" />
                <span>Reseñas y Moderación ({reviewsList.length})</span>
                {reviewsList.filter(r => r.status === 'pending').length > 0 && (
                  <span className="px-1.5 py-0.5 rounded-full bg-amber-500 text-white text-[10px] font-bold">
                    {reviewsList.filter(r => r.status === 'pending').length}
                  </span>
                )}
              </button>

              <button
                onClick={() => setActiveTab('fabrics')}
                className={`px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-2 transition-colors shrink-0 ${
                  activeTab === 'fabrics'
                    ? 'bg-[#8a532b] text-white shadow-xs'
                    : 'text-stone-600 hover:bg-stone-100'
                }`}
              >
                <Layers className="w-4 h-4 text-amber-300" />
                <span>Telas & Tapicería Global ({(localSettings.cushionFabrics || []).length})</span>
              </button>

              <button
                onClick={() => setActiveTab('settings')}
                className={`px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-2 transition-colors shrink-0 ${
                  activeTab === 'settings'
                    ? 'bg-[#8a532b] text-white'
                    : 'text-stone-600 hover:bg-stone-100'
                }`}
              >
                <Settings className="w-4 h-4" />
                <span>Tienda & WhatsApp</span>
              </button>

              <button
                onClick={() => setActiveTab('firebase')}
                className={`px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-2 transition-colors shrink-0 ${
                  activeTab === 'firebase'
                    ? 'bg-[#8a532b] text-white'
                    : 'text-stone-600 hover:bg-stone-100'
                }`}
              >
                <Flame className="w-4 h-4 text-amber-500" />
                <span>Firebase & Respaldo</span>
              </button>

              <button
                onClick={() => setActiveTab('tools')}
                className={`px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-2 transition-colors shrink-0 ${
                  activeTab === 'tools'
                    ? 'bg-[#8a532b] text-white'
                    : 'text-stone-600 hover:bg-stone-100'
                }`}
              >
                <RefreshCw className="w-4 h-4" />
                <span>Mantenimiento</span>
              </button>
            </div>

            {/* TAB PANELS */}
            <div className="flex-1 overflow-y-auto p-4 sm:p-6">
              
              {/* ================= ANALYTICS TAB ================= */}
              {activeTab === 'analytics' && (
                <AdminAnalyticsSection
                  products={products}
                  categories={categories}
                  settings={localSettings}
                  onSelectProductToEdit={(product) => {
                    setActiveTab('products');
                    setEditingProduct(product);
                  }}
                />
              )}

              {/* ================= PRODUCTS TAB ================= */}
              {activeTab === 'products' && (
                <div>
                  {editingProduct ? (
                    /* PRODUCT EDIT / CREATE FORM */
                    <div className="bg-white p-5 sm:p-8 rounded-3xl border border-stone-200 shadow-lg space-y-6 max-w-4xl mx-auto">
                      <div className="flex items-center justify-between border-b border-stone-200 pb-4">
                        <h3 className="font-serif text-xl font-bold text-stone-900">
                          {isCreatingProduct ? 'Crear Nuevo Artículo' : `Editar: ${editingProduct.name}`}
                        </h3>
                        <button
                          onClick={() => setEditingProduct(null)}
                          className="text-stone-400 hover:text-stone-700 text-xs font-semibold px-3 py-1.5 rounded-lg hover:bg-stone-100"
                        >
                          Cancelar
                        </button>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 sm:gap-6">
                        {/* Name */}
                        <div className="sm:col-span-2">
                          <label className="text-xs font-bold text-stone-700 block mb-1">
                            Nombre del Producto / Conjunto *
                          </label>
                          <input
                            type="text"
                            value={editingProduct.name}
                            onChange={(e) => setEditingProduct({ ...editingProduct, name: e.target.value })}
                            placeholder="Ej. Mecedora Colonial Real Gran Majestad"
                            className="w-full text-sm p-3 bg-stone-50 border border-stone-300 rounded-xl focus:ring-2 focus:ring-[#8a532b] focus:outline-none font-semibold"
                          />
                        </div>

                        {/* Category */}
                        <div>
                          <label className="text-xs font-bold text-stone-700 block mb-1">Categoría *</label>
                          <select
                            value={editingProduct.categoryId}
                            onChange={(e) => setEditingProduct({ 
                              ...editingProduct, 
                              categoryId: e.target.value,
                              productType: e.target.value as any
                            })}
                            className="w-full text-sm p-3 bg-stone-50 border border-stone-300 rounded-xl focus:ring-2 focus:ring-[#8a532b] focus:outline-none"
                          >
                            {categories.map((c) => (
                              <option key={c.id} value={c.id}>
                                {c.name}
                              </option>
                            ))}
                          </select>
                        </div>

                        {/* Stock */}
                        <div>
                          <label className="text-xs font-bold text-stone-700 block mb-1">Stock Disponible</label>
                          <input
                            type="number"
                            value={editingProduct.stock}
                            onChange={(e) => setEditingProduct({ ...editingProduct, stock: parseInt(e.target.value) || 0 })}
                            className="w-full text-sm p-3 bg-stone-50 border border-stone-300 rounded-xl focus:ring-2 focus:ring-[#8a532b] focus:outline-none"
                          />
                        </div>

                        {/* Price */}
                        <div>
                          <label className="text-xs font-bold text-stone-700 block mb-1">Precio Actual ({settings.currency}) *</label>
                          <input
                            type="number"
                            step="0.01"
                            value={editingProduct.price}
                            onChange={(e) => setEditingProduct({ ...editingProduct, price: parseFloat(e.target.value) || 0 })}
                            className="w-full text-sm p-3 bg-stone-50 border border-stone-300 rounded-xl focus:ring-2 focus:ring-[#8a532b] focus:outline-none font-bold"
                          />
                        </div>

                        {/* Previous Price */}
                        <div>
                          <label className="text-xs font-bold text-stone-700 block mb-1">Precio Anterior (Opcional, para tachar)</label>
                          <input
                            type="number"
                            step="0.01"
                            value={editingProduct.previousPrice || ''}
                            onChange={(e) => setEditingProduct({ ...editingProduct, previousPrice: e.target.value ? parseFloat(e.target.value) : undefined })}
                            placeholder="Ej. 420.00"
                            className="w-full text-sm p-3 bg-stone-50 border border-stone-300 rounded-xl focus:ring-2 focus:ring-[#8a532b] focus:outline-none"
                          />
                        </div>

                        {/* Material */}
                        <div className="sm:col-span-2">
                          <label className="text-xs font-bold text-stone-700 block mb-1">Material</label>
                          <input
                            type="text"
                            value={editingProduct.material}
                            onChange={(e) => setEditingProduct({ ...editingProduct, material: e.target.value })}
                            placeholder="Ej. Fibra de vidrio"
                            className="w-full text-sm p-3 bg-stone-50 border border-stone-300 rounded-xl"
                          />
                        </div>

                        {/* Description */}
                        <div className="sm:col-span-2">
                          <label className="text-xs font-bold text-stone-700 block mb-1">Descripción Detallada</label>
                          <textarea
                            rows={3}
                            value={editingProduct.description}
                            onChange={(e) => setEditingProduct({ ...editingProduct, description: e.target.value })}
                            className="w-full text-sm p-3 bg-stone-50 border border-stone-300 rounded-xl"
                          />
                        </div>

                        {/* ================= INCLUDED ITEMS BUILDER ================= */}
                        <div className="sm:col-span-2 p-4 rounded-2xl bg-[#f7eedf]/60 border border-[#ecdac2] space-y-3">
                          <div className="flex items-center justify-between">
                            <label className="text-xs font-bold text-[#3b2210] flex items-center gap-1.5">
                              <Layers className="w-4 h-4 text-[#8a532b]" />
                              <span>Contenido del Juego / Piezas Incluidas (Especial para Medio Juegos y Sofás)</span>
                            </label>
                            <button
                              type="button"
                              onClick={() => {
                                const items = editingProduct.includedItems || [];
                                setEditingProduct({
                                  ...editingProduct,
                                  includedItems: [...items, '1 Nueva Pieza']
                                });
                              }}
                              className="px-2.5 py-1 rounded-lg bg-[#8a532b] text-white text-xs font-semibold flex items-center gap-1"
                            >
                              <Plus className="w-3.5 h-3.5" />
                              <span>Agregar Pieza</span>
                            </button>
                          </div>

                          <div className="space-y-2">
                            {editingProduct.includedItems && editingProduct.includedItems.length > 0 ? (
                              editingProduct.includedItems.map((item, idx) => (
                                <div key={idx} className="flex items-center gap-2">
                                  <input
                                    type="text"
                                    value={item}
                                    onChange={(e) => {
                                      const updated = [...(editingProduct.includedItems || [])];
                                      updated[idx] = e.target.value;
                                      setEditingProduct({ ...editingProduct, includedItems: updated });
                                    }}
                                    placeholder="Ej. 2 Mecedoras Coloniales, 1 Sofá de 3 Plazas..."
                                    className="flex-1 text-xs p-2.5 bg-white border border-stone-300 rounded-xl"
                                  />
                                  <button
                                    type="button"
                                    onClick={() => {
                                      const updated = (editingProduct.includedItems || []).filter((_, i) => i !== idx);
                                      setEditingProduct({ ...editingProduct, includedItems: updated });
                                    }}
                                    className="p-2 text-stone-400 hover:text-red-600 rounded-lg"
                                  >
                                    <Trash2 className="w-4 h-4" />
                                  </button>
                                </div>
                              ))
                            ) : (
                              <p className="text-xs text-stone-500 italic">No hay piezas especificadas.</p>
                            )}
                          </div>
                        </div>

                        {/* ================= CONDITIONAL COLOR SWATCHES / CUSHION PALETTE ================= */}
                        {editingProduct.categoryId === 'cojines' || editingProduct.productType === 'cojin' ? (
                          <div className="sm:col-span-2 p-5 rounded-2xl bg-[#FAF8F5] border border-[#E8E2DC] space-y-4">
                            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-[#E8E2DC] pb-3">
                              <div>
                                <h4 className="font-serif font-bold text-sm text-[#2C1810] flex items-center gap-2">
                                  <Tag className="w-4 h-4 text-[#8a532b]" />
                                  <span>Paleta Amplia de Colores para Cojines</span>
                                </h4>
                                <p className="text-[11px] text-[#7A6A60]">
                                  Selecciona los colores disponibles para este modelo de cojín desde el catálogo o agrega tonos específicos.
                                </p>
                              </div>
                              <div className="flex flex-wrap gap-1.5">
                                <button
                                  type="button"
                                  onClick={() => {
                                    const allCols: ColorOption[] = WIDE_CUSHION_COLOR_PALETTE.map(c => ({ name: c.name, hex: c.hex }));
                                    setEditingProduct({
                                      ...editingProduct,
                                      colors: allCols
                                    });
                                  }}
                                  className="px-2.5 py-1 rounded-lg bg-[#8a532b] text-white text-[11px] font-bold hover:bg-[#6e4121] transition-colors cursor-pointer"
                                >
                                  Seleccionar los 32 Colores
                                </button>
                                <button
                                  type="button"
                                  onClick={() => {
                                    setEditingProduct({
                                      ...editingProduct,
                                      colors: []
                                    });
                                  }}
                                  className="px-2.5 py-1 rounded-lg bg-stone-200 text-stone-700 text-[11px] font-bold hover:bg-stone-300 transition-colors cursor-pointer"
                                >
                                  Limpiar
                                </button>
                              </div>
                            </div>

                            {/* Color Category Tabs */}
                            <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
                              {[
                                { id: 'all', label: 'Todos' },
                                { id: 'Neutros & Tierra', label: 'Neutros & Tierra' },
                                { id: 'Cálidos & Rojos', label: 'Cálidos & Rojos' },
                                { id: 'Azules & Marinos', label: 'Azules & Marinos' },
                                { id: 'Verdes & Botánicos', label: 'Verdes & Botánicos' },
                                { id: 'Vivos & Tropicales', label: 'Vivos & Tropicales' },
                              ].map((tab) => (
                                <button
                                  key={tab.id}
                                  type="button"
                                  onClick={() => setAdminCushionColorFilter(tab.id)}
                                  className={`px-2.5 py-1 rounded-lg text-[10px] font-bold transition-all shrink-0 cursor-pointer ${
                                    adminCushionColorFilter === tab.id
                                      ? 'bg-[#2C1810] text-white'
                                      : 'bg-white border border-[#E8E2DC] text-[#7A6A60] hover:bg-[#F0EBE6]'
                                  }`}
                                >
                                  {tab.label}
                                </button>
                              ))}
                            </div>

                            {/* Quick Swatch Grid from Wide Palette */}
                            <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 gap-2 max-h-48 overflow-y-auto p-2 bg-white rounded-xl border border-[#E8E2DC]">
                              {WIDE_CUSHION_COLOR_PALETTE
                                .filter((c) => adminCushionColorFilter === 'all' || c.category === adminCushionColorFilter)
                                .map((paletteColor) => {
                                  const isSelected = editingProduct.colors.some(
                                    (c) => c.name.toLowerCase() === paletteColor.name.toLowerCase() || c.hex.toLowerCase() === paletteColor.hex.toLowerCase()
                                  );

                                  return (
                                    <button
                                      key={paletteColor.name}
                                      type="button"
                                      onClick={() => {
                                        if (isSelected) {
                                          const updated = editingProduct.colors.filter(
                                            (c) => c.name.toLowerCase() !== paletteColor.name.toLowerCase() && c.hex.toLowerCase() !== paletteColor.hex.toLowerCase()
                                          );
                                          setEditingProduct({ ...editingProduct, colors: updated });
                                        } else {
                                          setEditingProduct({
                                            ...editingProduct,
                                            colors: [...editingProduct.colors, { name: paletteColor.name, hex: paletteColor.hex }]
                                          });
                                        }
                                      }}
                                      className={`p-1.5 rounded-lg border text-left flex items-center gap-1.5 transition-all text-[11px] cursor-pointer ${
                                        isSelected
                                          ? 'border-[#8a532b] bg-[#FAF3EE] font-bold text-[#8a532b]'
                                          : 'border-stone-200 bg-stone-50 text-stone-600 hover:bg-stone-100'
                                      }`}
                                    >
                                      <span
                                        className="w-4 h-4 rounded-full shrink-0 border border-black/10 shadow-xs flex items-center justify-center text-[9px] text-white"
                                        style={{ backgroundColor: paletteColor.hex }}
                                      >
                                        {isSelected && <Check className="w-2.5 h-2.5 drop-shadow" />}
                                      </span>
                                      <span className="truncate">{paletteColor.name}</span>
                                    </button>
                                  );
                                })}
                            </div>

                            {/* Active Selected Colors list & Custom Color Add */}
                            <div className="space-y-2 pt-2 border-t border-[#E8E2DC]">
                              <div className="flex items-center justify-between">
                                <label className="text-[11px] font-bold text-stone-700">
                                  Colores Habilitados ({editingProduct.colors.length}):
                                </label>
                                <button
                                  type="button"
                                  onClick={() => {
                                    setEditingProduct({
                                      ...editingProduct,
                                      colors: [...editingProduct.colors, { name: 'Color Personalizado', hex: '#8a532b' }]
                                    });
                                  }}
                                  className="px-2 py-1 rounded-lg bg-stone-800 text-white text-[10px] font-bold flex items-center gap-1 cursor-pointer"
                                >
                                  <Plus className="w-3 h-3" />
                                  <span>Nuevo Color Manual</span>
                                </button>
                              </div>

                              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-36 overflow-y-auto">
                                {editingProduct.colors.map((color, idx) => (
                                  <div key={idx} className="flex items-center gap-2 bg-white p-2 rounded-xl border border-stone-200 shadow-xs">
                                    <input
                                      type="color"
                                      value={color.hex}
                                      onChange={(e) => {
                                        const updated = [...editingProduct.colors];
                                        updated[idx] = { ...updated[idx], hex: e.target.value };
                                        setEditingProduct({ ...editingProduct, colors: updated });
                                      }}
                                      className="w-7 h-7 rounded-lg border-0 cursor-pointer p-0 shrink-0"
                                    />
                                    <input
                                      type="text"
                                      value={color.name}
                                      onChange={(e) => {
                                        const updated = [...editingProduct.colors];
                                        updated[idx] = { ...updated[idx], name: e.target.value };
                                        setEditingProduct({ ...editingProduct, colors: updated });
                                      }}
                                      placeholder="Nombre de color"
                                      className="flex-1 text-xs p-1 border border-stone-300 rounded-lg"
                                    />
                                    <button
                                      type="button"
                                      onClick={() => {
                                        const updated = editingProduct.colors.filter((_, i) => i !== idx);
                                        setEditingProduct({ ...editingProduct, colors: updated });
                                      }}
                                      className="p-1 text-stone-400 hover:text-red-600 cursor-pointer"
                                    >
                                      <Trash2 className="w-3.5 h-3.5" />
                                    </button>
                                  </div>
                                ))}
                              </div>
                            </div>

                            {/* Cushion Fabrics Notice */}
                            <div className="p-3 bg-amber-50/80 rounded-xl border border-amber-200 text-xs text-[#5C4033] space-y-1">
                              <p className="font-bold flex items-center gap-1.5 text-[#8a532b]">
                                <span>🧵 Telas Disponibles para este Cojín:</span>
                              </p>
                              <p className="text-[11px] text-stone-600">
                                Los clientes pueden elegir entre <strong>Textalina</strong> (semi impermeable y disponible en 6 tonos exclusivos: Gris claro, Gris oscuro, Marrón, Crema, Blanco y Crema oscuro), <strong>Tela o Kiwi</strong> (amplia paleta de colores), <strong>Vinil</strong> (impermeable) y <strong>Estampados</strong> (patrones decorativos). Puedes ajustar sus descripciones y precios en la pestaña <em>Configuración</em>.
                              </p>
                            </div>
                          </div>
                        ) : (
                          /* ROCKER COLOR OPTIONS - STRICTLY WHITE, MAHOGANY, BLACK */
                          <div className="sm:col-span-2 p-4 rounded-2xl bg-stone-50 border border-stone-200 space-y-3">
                            <div className="flex items-center justify-between">
                              <div>
                                <label className="text-xs font-bold text-stone-800 block">
                                  Colores de Mecedora de Fábrica
                                </label>
                                <p className="text-[11px] text-stone-500">
                                  Las mecedoras se fabrican en los 3 tonos estándar: Blanco, Caoba (marrón) y Negro. (Las opciones de telas y cojines no aplican a mecedoras).
                                </p>
                              </div>
                              <button
                                type="button"
                                onClick={() => {
                                  setEditingProduct({
                                    ...editingProduct,
                                    colors: [...STANDARD_ROCKER_COLORS]
                                  });
                                }}
                                className="px-2.5 py-1 rounded-lg bg-stone-800 text-white text-xs font-semibold flex items-center gap-1 cursor-pointer"
                              >
                                <span>Restablecer Blanco, Caoba y Negro</span>
                              </button>
                            </div>

                            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                              {editingProduct.colors.map((color, idx) => (
                                <div key={idx} className="flex items-center gap-2 bg-white p-2 rounded-xl border border-stone-200">
                                  <span
                                    className="w-6 h-6 rounded-full border border-black/20 shrink-0"
                                    style={{ backgroundColor: color.hex }}
                                  />
                                  <input
                                    type="text"
                                    value={color.name}
                                    onChange={(e) => {
                                      const updated = [...editingProduct.colors];
                                      updated[idx] = { ...updated[idx], name: e.target.value };
                                      setEditingProduct({ ...editingProduct, colors: updated });
                                    }}
                                    className="flex-1 text-xs p-1.5 border border-stone-300 rounded-lg font-semibold"
                                  />
                                </div>
                              ))}
                            </div>
                          </div>
                        )}

                        {/* ================= MULTIPLE PHOTOGRAPHY MANAGER ================= */}
                        <div className="sm:col-span-2 p-4 sm:p-5 rounded-2xl bg-stone-100 border border-stone-200 space-y-4">
                          <div>
                            <label className="text-xs font-bold text-stone-900 block">
                              Fotografías del Producto (Múltiples vistas: Frontal, Lateral, Detalle, En sala)
                            </label>
                            <p className="text-xs text-stone-500">
                              Arrastra o sube varias imágenes. Puedes reordenarlas para definir el orden exacto del carrusel.
                            </p>
                          </div>

                          {/* Upload Actions */}
                          <div className="flex flex-wrap items-center gap-3">
                            <label className={`px-4 py-2.5 rounded-xl text-white text-xs font-bold flex items-center gap-2 transition-all shadow-xs ${
                              isOptimizingImages 
                                ? 'bg-stone-400 cursor-not-allowed' 
                                : 'bg-[#8a532b] hover:bg-[#6e4121] cursor-pointer'
                            }`}>
                              {isOptimizingImages ? (
                                <Loader2 className="w-4 h-4 animate-spin" />
                              ) : (
                                <Upload className="w-4 h-4" />
                              )}
                              <span>{isOptimizingImages ? 'Optimizando Fotos...' : 'Subir Múltiples Fotos'}</span>
                              <input
                                type="file"
                                multiple
                                accept="image/*"
                                disabled={isOptimizingImages}
                                onChange={handleMultipleFilesUpload}
                                className="hidden"
                              />
                            </label>

                            {/* Add by URL input */}
                            <div className="flex items-center gap-1.5 flex-1 min-w-[240px]">
                              <input
                                id="add-photo-url-input"
                                type="text"
                                placeholder="Pegar URL de imagen..."
                                className="flex-1 text-xs p-2.5 bg-white border border-stone-300 rounded-xl"
                                onKeyDown={(e) => {
                                  if (e.key === 'Enter') {
                                    e.preventDefault();
                                    handleAddImageUrl((e.target as HTMLInputElement).value);
                                    (e.target as HTMLInputElement).value = '';
                                  }
                                }}
                              />
                              <button
                                type="button"
                                onClick={() => {
                                  const input = document.getElementById('add-photo-url-input') as HTMLInputElement;
                                  if (input && input.value) {
                                    handleAddImageUrl(input.value);
                                    input.value = '';
                                  }
                                }}
                                className="px-3 py-2.5 rounded-xl bg-stone-800 text-white text-xs font-bold hover:bg-stone-900"
                              >
                                Agregar
                              </button>
                            </div>
                          </div>

                          {/* Quick Sample Photos from Catalog */}
                          <div className="flex flex-wrap items-center gap-2 pt-1">
                            <span className="text-[11px] font-bold text-stone-500">Muestras rápidas:</span>
                            {[
                              { label: 'Mecedora Caoba', url: 'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?auto=format&fit=crop&w=800&q=80' },
                              { label: 'Mecedora Colonial', url: 'https://images.unsplash.com/photo-1586023492125-27b2c045efd7?auto=format&fit=crop&w=800&q=80' },
                              { label: 'Juego Terraza', url: 'https://images.unsplash.com/photo-1519947486511-46149fa0a254?auto=format&fit=crop&w=800&q=80' },
                              { label: 'Sillón Confort', url: 'https://images.unsplash.com/photo-1567538096630-e0c55bd6374c?auto=format&fit=crop&w=800&q=80' }
                            ].map((preset, pIdx) => (
                              <button
                                key={pIdx}
                                type="button"
                                onClick={() => handleAddImageUrl(preset.url)}
                                className="px-2.5 py-1 bg-stone-100 hover:bg-[#8a532b]/10 hover:text-[#8a532b] text-stone-600 rounded-lg text-[10px] font-semibold border border-stone-200 transition-colors"
                              >
                                + {preset.label}
                              </button>
                            ))}
                          </div>

                          {/* Image Optimization Status Notification */}
                          {isOptimizingImages && (
                            <div className="flex items-center gap-2 px-3.5 py-2.5 bg-amber-50 border border-amber-200 rounded-xl text-amber-900 text-xs font-medium animate-pulse">
                              <Loader2 className="w-4 h-4 animate-spin text-[#8a532b] shrink-0" />
                              <span>{optimizingStatus || 'Comprimiendo y preparando imágenes para alta velocidad...'}</span>
                            </div>
                          )}

                          {/* Empty state when no images added yet */}
                          {editingProduct.images.length === 0 && !isOptimizingImages && (
                            <div className="text-center py-6 px-4 border border-dashed border-stone-300 rounded-2xl bg-white/60">
                              <ImageIcon className="w-8 h-8 text-stone-400 mx-auto mb-1.5" />
                              <p className="text-xs font-semibold text-stone-700">Aún no has agregado fotos personalizadas</p>
                              <p className="text-[11px] text-stone-500 mt-0.5">
                                Haz clic en &ldquo;Subir Múltiples Fotos&rdquo; para seleccionar varias fotos desde tu dispositivo (frontal, lateral, ambiente).
                              </p>
                            </div>
                          )}

                          {/* Image Cards Reordering Grid */}
                          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2">
                            {editingProduct.images.map((imgUrl, idx) => {
                              const isMain = editingProduct.mainImage === imgUrl || (idx === 0 && !editingProduct.mainImage);
                              return (
                                <div
                                  key={`${editingProduct.id || 'new'}-img-${idx}-${imgUrl.slice(-25)}`}
                                  className={`relative bg-white p-2 rounded-2xl border-2 space-y-2 card-shadow ${
                                    isMain ? 'border-[#8a532b] ring-2 ring-[#8a532b]/20' : 'border-stone-200'
                                  }`}
                                >
                                  <div className="aspect-square w-full rounded-xl overflow-hidden bg-stone-100 relative">
                                    <img src={imgUrl} alt={`Foto ${idx + 1}`} className="w-full h-full object-cover" />
                                    {isMain && (
                                      <span className="absolute top-1.5 left-1.5 bg-[#8a532b] text-white text-[9px] font-extrabold px-2 py-0.5 rounded-full shadow-xs">
                                        PRINCIPAL
                                      </span>
                                    )}
                                    <span className="absolute bottom-1.5 right-1.5 bg-black/60 text-white text-[9px] font-bold px-1.5 py-0.5 rounded-md">
                                      #{idx + 1}
                                    </span>
                                  </div>

                                  {/* Controls */}
                                  <div className="flex items-center justify-between gap-1 pt-1">
                                    <div className="flex items-center gap-1">
                                      <button
                                        type="button"
                                        disabled={idx === 0}
                                        onClick={() => handleMoveImage(idx, idx - 1)}
                                        className="p-1 text-stone-500 hover:text-stone-900 disabled:opacity-30 rounded-md hover:bg-stone-100"
                                        title="Mover a la izquierda"
                                      >
                                        <ArrowUp className="w-3.5 h-3.5 -rotate-90" />
                                      </button>
                                      <button
                                        type="button"
                                        disabled={idx === editingProduct.images.length - 1}
                                        onClick={() => handleMoveImage(idx, idx + 1)}
                                        className="p-1 text-stone-500 hover:text-stone-900 disabled:opacity-30 rounded-md hover:bg-stone-100"
                                        title="Mover a la derecha"
                                      >
                                        <ArrowDown className="w-3.5 h-3.5 -rotate-90" />
                                      </button>
                                    </div>

                                    {!isMain && (
                                      <button
                                        type="button"
                                        onClick={() => setEditingProduct({ ...editingProduct, mainImage: imgUrl })}
                                        className="text-[10px] text-[#8a532b] hover:underline font-bold"
                                      >
                                        Hacer principal
                                      </button>
                                    )}

                                    <button
                                      type="button"
                                      onClick={() => handleRemoveImage(idx)}
                                      className="p-1 text-stone-400 hover:text-red-600 rounded-md hover:bg-red-50"
                                      title="Eliminar foto"
                                    >
                                      <Trash2 className="w-3.5 h-3.5" />
                                    </button>
                                  </div>
                                </div>
                              );
                            })}
                          </div>
                        </div>

                        {/* Status Checkboxes */}
                        <div className="sm:col-span-2 flex flex-wrap items-center gap-6 p-4 rounded-2xl bg-white border border-stone-200">
                          <label className="flex items-center gap-2 cursor-pointer">
                            <input
                              type="checkbox"
                              checked={editingProduct.isActive}
                              onChange={(e) => setEditingProduct({ ...editingProduct, isActive: e.target.checked })}
                              className="w-4 h-4 rounded text-[#8a532b] focus:ring-[#8a532b]"
                            />
                            <span className="text-xs font-bold text-stone-800">Producto Activo (Visible)</span>
                          </label>

                          <label className="flex items-center gap-2 cursor-pointer">
                            <input
                              type="checkbox"
                              checked={editingProduct.isFeatured}
                              onChange={(e) => setEditingProduct({ ...editingProduct, isFeatured: e.target.checked })}
                              className="w-4 h-4 rounded text-[#8a532b] focus:ring-[#8a532b]"
                            />
                            <span className="text-xs font-bold text-stone-800">Destacado</span>
                          </label>

                          <label className="flex items-center gap-2 cursor-pointer">
                            <input
                              type="checkbox"
                              checked={editingProduct.isNew}
                              onChange={(e) => setEditingProduct({ ...editingProduct, isNew: e.target.checked })}
                              className="w-4 h-4 rounded text-[#8a532b] focus:ring-[#8a532b]"
                            />
                            <span className="text-xs font-bold text-stone-800">Etiqueta "Nuevo"</span>
                          </label>

                          <label className="flex items-center gap-2 cursor-pointer">
                            <input
                              type="checkbox"
                              checked={editingProduct.isOffer}
                              onChange={(e) => setEditingProduct({ ...editingProduct, isOffer: e.target.checked })}
                              className="w-4 h-4 rounded text-[#8a532b] focus:ring-[#8a532b]"
                            />
                            <span className="text-xs font-bold text-stone-800">En Oferta</span>
                          </label>
                        </div>
                      </div>

                      {/* Bottom Action Bar */}
                      <div className="flex items-center justify-end gap-3 pt-4 border-t border-stone-200">
                        <button
                          type="button"
                          onClick={() => setEditingProduct(null)}
                          className="px-5 py-2.5 rounded-xl border border-stone-300 text-stone-700 text-xs font-bold hover:bg-stone-100"
                        >
                          Cancelar
                        </button>
                        <button
                          type="button"
                          onClick={handleSaveProduct}
                          disabled={isSaving}
                          className="px-6 py-2.5 rounded-xl bg-[#8a532b] hover:bg-[#6e4121] text-white text-xs font-bold flex items-center gap-2 shadow-md disabled:opacity-50"
                        >
                          <Save className="w-4 h-4" />
                          <span>{isSaving ? 'Guardando...' : 'Guardar Producto'}</span>
                        </button>
                      </div>
                    </div>
                  ) : (
                    /* PRODUCT LIST VIEW */
                    <div className="space-y-4">
                      {/* Search & Actions Bar */}
                      <div className="flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-3 bg-white p-4 rounded-2xl border border-stone-200">
                        <div className="flex items-center gap-2 flex-1 flex-wrap">
                          <input
                            type="text"
                            value={productSearch}
                            onChange={(e) => setProductSearch(e.target.value)}
                            placeholder="Buscar en catálogo..."
                            className="text-xs p-2.5 bg-stone-50 border border-stone-300 rounded-xl flex-1 min-w-[180px] max-w-sm"
                          />
                          <select
                            value={productCategoryFilter}
                            onChange={(e) => setProductCategoryFilter(e.target.value)}
                            className="text-xs p-2.5 bg-stone-50 border border-stone-300 rounded-xl"
                          >
                            <option value="all">Todas las Categorías</option>
                            {categories.map((c) => (
                              <option key={c.id} value={c.id}>
                                {c.name}
                              </option>
                            ))}
                          </select>
                        </div>

                        <div className="flex items-center gap-2 flex-wrap justify-end">
                          {products.length > 0 && (
                            <button
                              type="button"
                              onClick={handleDeleteAllProducts}
                              disabled={isSaving}
                              className="px-3.5 py-2.5 rounded-xl border border-red-200 text-red-600 hover:bg-red-50 text-xs font-bold flex items-center gap-1.5 transition-colors disabled:opacity-50 cursor-pointer"
                              title="Elimina todos los artículos para empezar un catálogo nuevo desde cero"
                            >
                              <Trash2 className="w-4 h-4" />
                              <span className="hidden sm:inline">Vaciar Catálogo</span>
                            </button>
                          )}

                          <button
                            type="button"
                            onClick={handleRestoreFactoryProducts}
                            disabled={isSaving}
                            className="px-3.5 py-2.5 rounded-xl border border-stone-300 text-stone-700 hover:bg-stone-100 text-xs font-bold flex items-center gap-1.5 transition-colors disabled:opacity-50 cursor-pointer"
                            title="Restaura los 12 productos iniciales de muestra"
                          >
                            <RotateCcw className="w-4 h-4" />
                            <span className="hidden sm:inline">Stock de Fábrica</span>
                          </button>

                          <button
                            type="button"
                            onClick={handleOpenCreateProduct}
                            className="px-4 py-2.5 rounded-xl bg-[#8a532b] hover:bg-[#6e4121] text-white text-xs font-bold flex items-center justify-center gap-2 shadow-md transition-colors cursor-pointer"
                          >
                            <Plus className="w-4 h-4" />
                            <span>Crear Nuevo Artículo</span>
                          </button>
                        </div>
                      </div>

                      {/* Products Table */}
                      <div className="bg-white rounded-2xl border border-stone-200 overflow-hidden shadow-xs">
                        <div className="overflow-x-auto">
                          <table className="w-full text-left text-xs text-stone-700">
                            <thead className="bg-stone-100 text-stone-600 font-bold border-b border-stone-200">
                              <tr>
                                <th className="p-3">Foto</th>
                                <th className="p-3">Nombre & Material</th>
                                <th className="p-3">Categoría</th>
                                <th className="p-3">Precio</th>
                                <th className="p-3">Fotos</th>
                                <th className="p-3">Estado</th>
                                <th className="p-3 text-right">Acciones</th>
                              </tr>
                            </thead>
                            <tbody className="divide-y divide-stone-200">
                              {filteredProducts.length === 0 ? (
                                <tr>
                                  <td colSpan={7} className="p-12 text-center">
                                    <div className="max-w-md mx-auto space-y-3">
                                      <div className="w-12 h-12 rounded-full bg-stone-100 flex items-center justify-center mx-auto text-stone-400">
                                        <Layers className="w-6 h-6" />
                                      </div>
                                      <p className="text-sm font-bold text-stone-800">
                                        {products.length === 0
                                          ? 'El catálogo está completamente vacío (0 artículos).'
                                          : 'No hay artículos que coincidan con la búsqueda o filtro.'}
                                      </p>
                                      <p className="text-xs text-stone-500">
                                        {products.length === 0
                                          ? 'Puedes crear tus propios artículos desde cero o cargar los modelos estándar de fábrica si lo deseas.'
                                          : 'Prueba cambiando los términos de búsqueda o seleccionando "Todas las Categorías".'}
                                      </p>
                                      <div className="pt-2 flex items-center justify-center gap-3">
                                        {products.length === 0 ? (
                                          <>
                                            <button
                                              type="button"
                                              onClick={handleOpenCreateProduct}
                                              className="px-4 py-2 rounded-xl bg-[#8a532b] text-white text-xs font-bold flex items-center gap-1.5 shadow-sm"
                                            >
                                              <Plus className="w-4 h-4" />
                                              <span>Crear Primer Artículo</span>
                                            </button>
                                            <button
                                              type="button"
                                              onClick={handleRestoreFactoryProducts}
                                              className="px-4 py-2 rounded-xl border border-stone-300 text-stone-700 hover:bg-stone-100 text-xs font-bold flex items-center gap-1.5"
                                            >
                                              <RotateCcw className="w-4 h-4" />
                                              <span>Restablecer Stock de Fábrica</span>
                                            </button>
                                          </>
                                        ) : (
                                          <button
                                            type="button"
                                            onClick={() => {
                                              setProductSearch('');
                                              setProductCategoryFilter('all');
                                            }}
                                            className="px-4 py-2 rounded-xl bg-stone-100 text-stone-700 hover:bg-stone-200 text-xs font-bold"
                                          >
                                            Limpiar Filtros
                                          </button>
                                        )}
                                      </div>
                                    </div>
                                  </td>
                                </tr>
                              ) : (
                                filteredProducts.map((prod) => (
                                  <tr key={prod.id} className="hover:bg-stone-50/80 transition-colors">
                                    <td className="p-3">
                                      <img
                                        src={prod.mainImage}
                                        alt={prod.name}
                                        className="w-12 h-12 rounded-xl object-cover border border-stone-200"
                                      />
                                    </td>
                                    <td className="p-3 font-semibold text-stone-900">
                                      <div>{prod.name}</div>
                                      <div className="text-[10px] text-stone-500 font-normal">{prod.material || 'Fibra de vidrio'}</div>
                                    </td>
                                    <td className="p-3 text-stone-600 capitalize">
                                      {prod.categoryId.replace('-', ' ')}
                                    </td>
                                    <td className="p-3 font-bold text-stone-900">
                                      {formatPrice(prod.price, settings.currency)}
                                    </td>
                                    <td className="p-3">
                                      <span className="px-2 py-0.5 rounded-full bg-stone-100 text-stone-600 text-[10px] font-bold">
                                        {prod.images.length} {prod.images.length === 1 ? 'foto' : 'fotos'}
                                      </span>
                                    </td>
                                    <td className="p-3">
                                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                                        prod.isActive ? 'bg-emerald-100 text-emerald-800' : 'bg-stone-200 text-stone-600'
                                      }`}>
                                        {prod.isActive ? 'Activo' : 'Oculto'}
                                      </span>
                                    </td>
                                    <td className="p-3 text-right space-x-1">
                                      <button
                                        onClick={() => {
                                          setEditingProduct(prod);
                                          setIsCreatingProduct(false);
                                        }}
                                        className="p-1.5 text-[#8a532b] hover:bg-[#8a532b]/10 rounded-lg transition-colors"
                                        title="Editar producto"
                                      >
                                        <Edit3 className="w-4 h-4" />
                                      </button>
                                      <button
                                        onClick={() => handleDeleteProduct(prod.id)}
                                        disabled={isSaving}
                                        className="p-1.5 text-red-500 hover:bg-red-50 rounded-lg transition-colors disabled:opacity-40 cursor-pointer"
                                        title="Eliminar producto"
                                      >
                                        <Trash2 className="w-4 h-4" />
                                      </button>
                                    </td>
                                  </tr>
                                ))
                              )}
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* ================= CATEGORIES TAB ================= */}
              {activeTab === 'categories' && (
                <div className="space-y-4 max-w-4xl mx-auto">
                  <div className="flex items-center justify-between bg-white p-4 rounded-2xl border border-stone-200">
                    <div>
                      <h3 className="font-serif text-lg font-bold text-stone-900">Categorías Principales</h3>
                      <p className="text-xs text-stone-500">Mecedoras Grandes, Medianas, Medio Juegos, Combinados con Sofá y Cojines</p>
                    </div>
                    <button
                      onClick={() => {
                        setEditingCategory({
                          id: `cat_${Date.now()}`,
                          name: '',
                          description: '',
                          order: categories.length + 1,
                          isActive: true,
                        });
                        setIsCreatingCategory(true);
                      }}
                      className="px-4 py-2 rounded-xl bg-[#8a532b] text-white text-xs font-bold flex items-center gap-1.5"
                    >
                      <Plus className="w-4 h-4" />
                      <span>Nueva Categoría</span>
                    </button>
                  </div>

                  {editingCategory && (
                    <div className="bg-white p-6 rounded-3xl border border-stone-300 shadow-md space-y-4">
                      <h4 className="font-bold text-sm text-stone-900">
                        {isCreatingCategory ? 'Crear Categoría' : 'Editar Categoría'}
                      </h4>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                          <label className="text-xs font-bold text-stone-700 block mb-1">Nombre de la Categoría *</label>
                          <input
                            type="text"
                            value={editingCategory.name}
                            onChange={(e) => setEditingCategory({ ...editingCategory, name: e.target.value })}
                            className="w-full text-xs p-2.5 bg-stone-50 border border-stone-300 rounded-xl"
                          />
                        </div>
                        <div>
                          <label className="text-xs font-bold text-stone-700 block mb-1">Orden numérico</label>
                          <input
                            type="number"
                            value={editingCategory.order}
                            onChange={(e) => setEditingCategory({ ...editingCategory, order: parseInt(e.target.value) || 1 })}
                            className="w-full text-xs p-2.5 bg-stone-50 border border-stone-300 rounded-xl"
                          />
                        </div>
                        <div className="sm:col-span-2">
                          <label className="text-xs font-bold text-stone-700 block mb-1">Descripción</label>
                          <input
                            type="text"
                            value={editingCategory.description}
                            onChange={(e) => setEditingCategory({ ...editingCategory, description: e.target.value })}
                            className="w-full text-xs p-2.5 bg-stone-50 border border-stone-300 rounded-xl"
                          />
                        </div>
                        <div className="sm:col-span-2">
                          <label className="text-xs font-bold text-stone-700 block mb-1">Imagen / Foto de Portada</label>
                          <div className="flex items-center gap-2">
                            {editingCategory.image ? (
                              <img
                                src={editingCategory.image}
                                alt="Vista previa"
                                className="w-12 h-12 object-cover rounded-xl border border-stone-200 shrink-0"
                              />
                            ) : null}
                            <input
                              type="text"
                              value={editingCategory.image || ''}
                              onChange={(e) => setEditingCategory({ ...editingCategory, image: e.target.value })}
                              placeholder="URL de la imagen o sube un archivo..."
                              className="flex-1 text-xs p-2.5 bg-stone-50 border border-stone-300 rounded-xl"
                            />
                            <label className="px-3 py-2.5 bg-stone-100 hover:bg-stone-200 text-stone-700 text-xs font-bold rounded-xl flex items-center gap-1.5 cursor-pointer shrink-0 transition-colors">
                              <Upload className="w-3.5 h-3.5" />
                              <span>Subir Foto</span>
                              <input
                                type="file"
                                accept="image/*"
                                className="hidden"
                                onChange={async (e) => {
                                  const file = e.target.files?.[0];
                                  if (file) {
                                    try {
                                      const compressed = await compressImageFile(file, { maxWidth: 1200, maxHeight: 800, quality: 0.8 });
                                      const urls = await uploadImagesToServer([compressed]);
                                      if (urls[0]) {
                                        setEditingCategory((prev) => prev ? ({ ...prev, image: urls[0] }) : null);
                                        showFeedback('Foto de categoría cargada');
                                      }
                                    } catch (err: any) {
                                      alert('Error subiendo imagen: ' + (err.message || err));
                                    }
                                  }
                                  e.target.value = '';
                                }}
                              />
                            </label>
                          </div>
                        </div>
                      </div>
                      <div className="flex justify-end gap-2 pt-2">
                        <button
                          onClick={() => setEditingCategory(null)}
                          className="px-4 py-2 rounded-xl text-xs font-bold border border-stone-300"
                        >
                          Cancelar
                        </button>
                        <button
                          onClick={handleSaveCategory}
                          className="px-4 py-2 rounded-xl bg-[#8a532b] text-white text-xs font-bold"
                        >
                          Guardar Categoría
                        </button>
                      </div>
                    </div>
                  )}

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {[...categories]
                      .sort((a, b) => (a.order ?? 0) - (b.order ?? 0))
                      .map((c) => (
                      <div key={c.id} className="p-4 bg-white rounded-2xl border border-stone-200 flex items-center justify-between card-shadow">
                        <div>
                          <span className="text-[10px] font-bold text-[#8a532b] uppercase">Orden #{c.order}</span>
                          <h4 className="font-serif text-base font-bold text-stone-900">{c.name}</h4>
                          <p className="text-xs text-stone-500 line-clamp-1">{c.description}</p>
                        </div>
                        <div className="flex items-center gap-1">
                          <button
                            onClick={() => {
                              setEditingCategory(c);
                              setIsCreatingCategory(false);
                            }}
                            className="p-2 text-[#8a532b] hover:bg-stone-100 rounded-lg"
                          >
                            <Edit3 className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => handleDeleteCategory(c.id)}
                            className="p-2 text-red-500 hover:bg-red-50 rounded-lg"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* ================= BANNERS TAB ================= */}
              {activeTab === 'banners' && (
                <div className="space-y-4 max-w-4xl mx-auto">
                  <div className="flex items-center justify-between bg-white p-4 rounded-2xl border border-stone-200">
                    <div>
                      <h3 className="font-serif text-lg font-bold text-stone-900">Banners del Carrusel Superior</h3>
                      <p className="text-xs text-stone-500">Imágenes y promociones de la portada</p>
                    </div>
                    <button
                      onClick={() => {
                        setEditingBanner({
                          id: `banner_${Date.now()}`,
                          image: 'https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?auto=format&fit=crop&w=1600&q=80',
                          title: 'Nuevo Banner',
                          subtitle: 'Mecedoras artesanales de alta calidad',
                          buttonText: 'VER COLECCIÓN',
                          order: banners.length + 1,
                          isActive: true,
                        });
                        setIsCreatingBanner(true);
                      }}
                      className="px-4 py-2 rounded-xl bg-[#8a532b] text-white text-xs font-bold flex items-center gap-1.5"
                    >
                      <Plus className="w-4 h-4" />
                      <span>Nuevo Banner</span>
                    </button>
                  </div>

                  {editingBanner && (
                    <div className="bg-white p-6 rounded-3xl border border-stone-300 shadow-md space-y-4">
                      <h4 className="font-bold text-sm text-stone-900">
                        {isCreatingBanner ? 'Crear Banner' : 'Editar Banner'}
                      </h4>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div className="sm:col-span-2 space-y-1.5">
                          <label className="text-xs font-bold text-stone-700 block">Imagen del Banner *</label>
                          <div className="flex gap-2">
                            <input
                              type="text"
                              value={editingBanner.image}
                              onChange={(e) => setEditingBanner({ ...editingBanner, image: e.target.value })}
                              placeholder="https://... o sube una imagen"
                              className="flex-1 text-xs p-2.5 bg-stone-50 border border-stone-300 rounded-xl"
                            />
                            <label className="px-3 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 text-xs font-bold rounded-xl flex items-center gap-1.5 cursor-pointer shrink-0 transition-colors">
                              <Upload className="w-3.5 h-3.5" />
                              <span>Subir Foto</span>
                              <input
                                type="file"
                                accept="image/*"
                                className="hidden"
                                onChange={async (e) => {
                                  const file = e.target.files?.[0];
                                  if (file) {
                                    try {
                                      const compressed = await compressImageFile(file, { maxWidth: 1600, maxHeight: 900, quality: 0.8 });
                                      const urls = await uploadImagesToServer([compressed]);
                                      if (urls[0]) {
                                        setEditingBanner((prev) => prev ? ({ ...prev, image: urls[0] }) : null);
                                        showFeedback('Foto de banner cargada');
                                      }
                                    } catch (err: any) {
                                      alert('Error subiendo imagen: ' + (err.message || err));
                                    }
                                  }
                                  e.target.value = '';
                                }}
                              />
                            </label>
                          </div>
                        </div>
                        <div>
                          <label className="text-xs font-bold text-stone-700 block mb-1">Título Principal *</label>
                          <input
                            type="text"
                            value={editingBanner.title}
                            onChange={(e) => setEditingBanner({ ...editingBanner, title: e.target.value })}
                            className="w-full text-xs p-2.5 bg-stone-50 border border-stone-300 rounded-xl font-bold"
                          />
                        </div>
                        <div>
                          <label className="text-xs font-bold text-stone-700 block mb-1">Texto del Botón</label>
                          <input
                            type="text"
                            value={editingBanner.buttonText}
                            onChange={(e) => setEditingBanner({ ...editingBanner, buttonText: e.target.value })}
                            className="w-full text-xs p-2.5 bg-stone-50 border border-stone-300 rounded-xl"
                          />
                        </div>
                        <div className="sm:col-span-2">
                          <label className="text-xs font-bold text-stone-700 block mb-1">Subtítulo / Mensaje</label>
                          <textarea
                            rows={2}
                            value={editingBanner.subtitle}
                            onChange={(e) => setEditingBanner({ ...editingBanner, subtitle: e.target.value })}
                            className="w-full text-xs p-2.5 bg-stone-50 border border-stone-300 rounded-xl"
                          />
                        </div>
                      </div>
                      <div className="flex justify-end gap-2 pt-2">
                        <button
                          onClick={() => setEditingBanner(null)}
                          className="px-4 py-2 rounded-xl text-xs font-bold border border-stone-300"
                        >
                          Cancelar
                        </button>
                        <button
                          onClick={handleSaveBanner}
                          className="px-4 py-2 rounded-xl bg-[#8a532b] text-white text-xs font-bold"
                        >
                          Guardar Banner
                        </button>
                      </div>
                    </div>
                  )}

                  <div className="space-y-3">
                    {banners.map((b) => (
                      <div key={b.id} className="p-3 bg-white rounded-2xl border border-stone-200 flex gap-4 items-center card-shadow">
                        <img src={b.image} alt={b.title} className="w-24 h-16 rounded-xl object-cover shrink-0" />
                        <div className="flex-1 min-w-0">
                          <h4 className="font-bold text-sm text-stone-900 truncate">{b.title}</h4>
                          <p className="text-xs text-stone-500 truncate">{b.subtitle}</p>
                          <span className="text-[10px] font-bold text-[#8a532b]">Botón: {b.buttonText}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <button
                            onClick={() => {
                              setEditingBanner(b);
                              setIsCreatingBanner(false);
                            }}
                            className="p-2 text-[#8a532b] hover:bg-stone-100 rounded-lg"
                          >
                            <Edit3 className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => handleDeleteBanner(b.id)}
                            className="p-2 text-red-500 hover:bg-red-50 rounded-lg"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* ================= REVIEWS MODERATION TAB ================= */}
              {activeTab === 'reviews' && (
                <div className="space-y-6 max-w-5xl mx-auto">
                  
                  {/* Header and Stats */}
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-5 sm:p-6 rounded-3xl border border-stone-200 shadow-xs">
                    <div>
                      <h3 className="font-serif text-xl font-bold text-stone-900 flex items-center gap-2">
                        <MessageSquare className="w-5 h-5 text-[#8a532b]" />
                        <span>Moderación de Reseñas y Calificaciones</span>
                      </h3>
                      <p className="text-xs text-stone-500">
                        Gestiona las opiniones de clientes, responde como taller oficial y aprueba o modera comentarios.
                      </p>
                    </div>

                    <button
                      onClick={loadAdminReviews}
                      className="py-2 px-3.5 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-800 text-xs font-semibold flex items-center gap-1.5 self-start sm:self-auto cursor-pointer"
                    >
                      <RefreshCw className="w-3.5 h-3.5" />
                      <span>Actualizar lista</span>
                    </button>
                  </div>

                  {/* Status Filters Bar */}
                  <div className="flex items-center gap-2 overflow-x-auto pb-1">
                    {[
                      { id: 'all', label: 'Todas las Reseñas', count: reviewsList.length },
                      { id: 'pending', label: 'Pendientes', count: reviewsList.filter(r => r.status === 'pending').length },
                      { id: 'approved', label: 'Aprobadas', count: reviewsList.filter(r => r.status === 'approved' || !r.status).length },
                      { id: 'rejected', label: 'Rechazadas', count: reviewsList.filter(r => r.status === 'rejected').length },
                    ].map((st) => (
                      <button
                        key={st.id}
                        onClick={() => setReviewStatusFilter(st.id as any)}
                        className={`px-4 py-2 rounded-xl text-xs font-bold transition-all shrink-0 cursor-pointer flex items-center gap-2 ${
                          reviewStatusFilter === st.id
                            ? 'bg-[#8a532b] text-white shadow-xs'
                            : 'bg-white border border-stone-200 text-stone-700 hover:bg-stone-50'
                        }`}
                      >
                        <span>{st.label}</span>
                        <span className={`px-1.5 py-0.2 rounded-full text-[10px] ${
                          reviewStatusFilter === st.id ? 'bg-white/20 text-white' : 'bg-stone-100 text-stone-600'
                        }`}>
                          {st.count}
                        </span>
                      </button>
                    ))}
                  </div>

                  {/* Reviews List */}
                  <div className="space-y-3.5">
                    {reviewsList
                      .filter((r) => {
                        if (reviewStatusFilter === 'all') return true;
                        if (reviewStatusFilter === 'approved') return r.status === 'approved' || !r.status;
                        return r.status === reviewStatusFilter;
                      })
                      .map((review) => {
                        const isReplying = replyingReviewId === review.id;
                        const formattedDate = new Date(review.createdAt).toLocaleDateString('es-ES', {
                          year: 'numeric',
                          month: 'short',
                          day: 'numeric',
                          hour: '2-digit',
                          minute: '2-digit',
                        });

                        return (
                          <div
                            key={review.id}
                            className="bg-white p-5 rounded-2xl border border-stone-200 shadow-xs space-y-3"
                          >
                            {/* Top Info Bar */}
                            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-stone-100 pb-3">
                              <div>
                                <div className="flex items-center gap-2">
                                  <span className="font-bold text-sm text-stone-900">{review.userName}</span>
                                  {review.isVerifiedBuyer && (
                                    <span className="inline-flex items-center gap-1 text-[10px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
                                      <ShieldCheck className="w-3 h-3 text-emerald-600" />
                                      Comprador Verificado
                                    </span>
                                  )}
                                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider ${
                                    review.status === 'approved' || !review.status
                                      ? 'bg-emerald-100 text-emerald-800'
                                      : review.status === 'rejected'
                                      ? 'bg-red-100 text-red-800'
                                      : 'bg-amber-100 text-amber-800'
                                  }`}>
                                    {review.status === 'approved' || !review.status ? 'Aprobada' : review.status === 'rejected' ? 'Rechazada' : 'Pendiente'}
                                  </span>
                                </div>

                                <div className="flex items-center gap-2 mt-1">
                                  <div className="flex items-center text-amber-400">
                                    {Array.from({ length: 5 }).map((_, i) => (
                                      <Star
                                        key={i}
                                        className={`w-3.5 h-3.5 ${
                                          i < review.rating ? 'fill-amber-400' : 'text-stone-200'
                                        }`}
                                      />
                                    ))}
                                  </div>
                                  <span className="text-xs font-semibold text-stone-500">
                                    Producto: <strong className="text-stone-800">{review.productName || review.productId}</strong>
                                  </span>
                                  <span className="text-[11px] text-stone-400">• {formattedDate}</span>
                                </div>
                              </div>

                              {review.orderNumber && (
                                <span className="text-xs text-stone-500 font-mono bg-stone-50 px-2.5 py-1 rounded-lg border border-stone-200 self-start sm:self-auto">
                                  Pedido: {review.orderNumber}
                                </span>
                              )}
                            </div>

                            {/* Content */}
                            {review.title && (
                              <h5 className="font-serif font-bold text-sm text-stone-900">
                                "{review.title}"
                              </h5>
                            )}
                            <p className="text-xs text-stone-700 leading-relaxed bg-stone-50 p-3 rounded-xl">
                              {review.comment}
                            </p>

                            {/* Workshop Reply Display or Form */}
                            {review.adminReply && !isReplying && (
                              <div className="p-3 rounded-xl bg-amber-50/50 border-l-4 border-[#8a532b] text-xs space-y-1">
                                <div className="flex items-center justify-between font-bold text-[#8a532b] text-[11px]">
                                  <span className="flex items-center gap-1">
                                    <CornerDownRight className="w-3 h-3" />
                                    Respuesta Oficial del Taller
                                  </span>
                                  <button
                                    onClick={() => {
                                      setReplyingReviewId(review.id);
                                      setReplyText(review.adminReply || '');
                                    }}
                                    className="text-stone-500 hover:text-stone-800 text-[10px] underline cursor-pointer"
                                  >
                                    Editar respuesta
                                  </button>
                                </div>
                                <p className="text-stone-700 italic pl-4">
                                  {review.adminReply}
                                </p>
                              </div>
                            )}

                            {isReplying && (
                              <div className="p-3 rounded-xl bg-stone-100 border border-stone-300 space-y-2">
                                <label className="text-xs font-bold text-stone-800 block">
                                  Respuesta Oficial de Emmy Mecedoras:
                                </label>
                                <textarea
                                  rows={2}
                                  value={replyText}
                                  onChange={(e) => setReplyText(e.target.value)}
                                  placeholder="Escribe la respuesta que verán los clientes en la tienda..."
                                  className="w-full text-xs p-2.5 bg-white border border-stone-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-[#8a532b]"
                                />
                                <div className="flex justify-end gap-2">
                                  <button
                                    onClick={() => {
                                      setReplyingReviewId(null);
                                      setReplyText('');
                                    }}
                                    className="px-3 py-1 text-xs text-stone-600 hover:bg-stone-200 rounded-lg"
                                  >
                                    Cancelar
                                  </button>
                                  <button
                                    onClick={() => handleSaveReply(review.id)}
                                    className="px-3 py-1 text-xs font-bold bg-[#8a532b] text-white rounded-lg hover:bg-[#724322]"
                                  >
                                    Guardar Respuesta
                                  </button>
                                </div>
                              </div>
                            )}

                            {/* Moderation Actions Bar */}
                            <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-stone-100 text-xs">
                              <div className="flex items-center gap-2">
                                {review.status !== 'approved' && (
                                  <button
                                    onClick={() => handleApproveReview(review.id)}
                                    className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold flex items-center gap-1 cursor-pointer transition-colors"
                                  >
                                    <CheckCircle className="w-3.5 h-3.5" />
                                    <span>Aprobar</span>
                                  </button>
                                )}

                                {review.status !== 'rejected' && (
                                  <button
                                    onClick={() => handleRejectReview(review.id)}
                                    className="px-3 py-1.5 rounded-lg bg-amber-600 hover:bg-amber-700 text-white font-bold flex items-center gap-1 cursor-pointer transition-colors"
                                  >
                                    <XCircle className="w-3.5 h-3.5" />
                                    <span>Rechazar</span>
                                  </button>
                                )}

                                {!review.adminReply && !isReplying && (
                                  <button
                                    onClick={() => {
                                      setReplyingReviewId(review.id);
                                      setReplyText('');
                                    }}
                                    className="px-3 py-1.5 rounded-lg border border-stone-300 hover:bg-stone-100 text-stone-700 font-semibold flex items-center gap-1 cursor-pointer transition-colors"
                                  >
                                    <CornerDownRight className="w-3.5 h-3.5" />
                                    <span>Responder al cliente</span>
                                  </button>
                                )}
                              </div>

                              <button
                                onClick={() => handleDeleteReview(review.id)}
                                className="p-1.5 text-red-500 hover:bg-red-50 rounded-lg transition-colors cursor-pointer"
                                title="Eliminar reseña permanentemente"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>

                          </div>
                        );
                      })}

                    {reviewsList.length === 0 && (
                      <div className="text-center py-12 bg-white rounded-3xl border border-stone-200">
                        <MessageSquare className="w-10 h-10 text-stone-400 mx-auto mb-2 opacity-50" />
                        <p className="text-sm font-semibold text-stone-700">No hay reseñas registradas aún.</p>
                      </div>
                    )}
                  </div>

                </div>
              )}

              {/* ================= SETTINGS TAB ================= */}
              {activeTab === 'settings' && (
                <div className="bg-white p-6 sm:p-8 rounded-3xl border border-stone-200 shadow-md space-y-6 max-w-4xl mx-auto">
                  <div>
                    <h3 className="font-serif text-xl font-bold text-stone-900">Configuración de la Tienda</h3>
                    <p className="text-xs text-stone-500">
                      Actualiza el número de WhatsApp para pedidos, nombre comercial e información de entrega.
                    </p>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {/* WhatsApp Number */}
                    <div className="sm:col-span-2 p-4 rounded-2xl bg-emerald-50 border border-emerald-200 space-y-1">
                      <label className="text-xs font-bold text-emerald-900 block">
                        Número de WhatsApp para Pedidos (con código de país) *
                      </label>
                      <input
                        type="text"
                        value={localSettings.whatsapp}
                        onChange={(e) => setLocalSettings({ ...localSettings, whatsapp: e.target.value })}
                        placeholder="Ej. 18095551234"
                        className="w-full text-sm p-3 bg-white border border-emerald-300 rounded-xl font-bold text-emerald-950 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                      />
                      <p className="text-[11px] text-emerald-700">
                        Todos los pedidos generados por los clientes se enviarán directamente a este WhatsApp con el formato detallado.
                      </p>
                    </div>

                    <div>
                      <label className="text-xs font-bold text-stone-700 block mb-1">Nombre de la Tienda</label>
                      <input
                        type="text"
                        value={localSettings.storeName}
                        onChange={(e) => setLocalSettings({ ...localSettings, storeName: e.target.value })}
                        className="w-full text-xs p-2.5 bg-stone-50 border border-stone-300 rounded-xl font-bold"
                      />
                    </div>

                    <div>
                      <label className="text-xs font-bold text-stone-700 block mb-1">Símbolo de Moneda</label>
                      <input
                        type="text"
                        value={localSettings.currency}
                        onChange={(e) => setLocalSettings({ ...localSettings, currency: e.target.value })}
                        placeholder="$, RD$, MXN, USD"
                        className="w-full text-xs p-2.5 bg-stone-50 border border-stone-300 rounded-xl"
                      />
                    </div>

                    <div>
                      <label className="text-xs font-bold text-stone-700 block mb-1">Teléfono Fijo / Asistencia</label>
                      <input
                        type="text"
                        value={localSettings.contactInformation.phone || ''}
                        onChange={(e) => setLocalSettings({
                          ...localSettings,
                          contactInformation: { ...localSettings.contactInformation, phone: e.target.value }
                        })}
                        className="w-full text-xs p-2.5 bg-stone-50 border border-stone-300 rounded-xl"
                      />
                    </div>

                    <div>
                      <label className="text-xs font-bold text-stone-700 block mb-1">Horario de Atención</label>
                      <input
                        type="text"
                        value={localSettings.contactInformation.schedule || ''}
                        onChange={(e) => setLocalSettings({
                          ...localSettings,
                          contactInformation: { ...localSettings.contactInformation, schedule: e.target.value }
                        })}
                        className="w-full text-xs p-2.5 bg-stone-50 border border-stone-300 rounded-xl"
                      />
                    </div>

                    <div className="sm:col-span-2 grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="text-xs font-bold text-stone-700 block mb-1">Dirección del Taller / Showroom</label>
                        <input
                          type="text"
                          value={localSettings.contactInformation.address || ''}
                          onChange={(e) => setLocalSettings({
                            ...localSettings,
                            contactInformation: { ...localSettings.contactInformation, address: e.target.value }
                          })}
                          placeholder="C. Salome Ureña 34, La Guáyiga, República Dominicana"
                          className="w-full text-xs p-2.5 bg-stone-50 border border-stone-300 rounded-xl"
                        />
                      </div>
                      <div>
                        <label className="text-xs font-bold text-stone-700 block mb-1">Enlace a Google Maps</label>
                        <input
                          type="text"
                          value={localSettings.contactInformation.mapsUrl || ''}
                          onChange={(e) => setLocalSettings({
                            ...localSettings,
                            contactInformation: { ...localSettings.contactInformation, mapsUrl: e.target.value }
                          })}
                          placeholder="https://maps.app.goo.gl/..."
                          className="w-full text-xs p-2.5 bg-stone-50 border border-stone-300 rounded-xl"
                        />
                      </div>
                    </div>

                    <div className="sm:col-span-2 grid grid-cols-1 sm:grid-cols-2 gap-4 p-4 rounded-2xl bg-stone-50 border border-stone-200">
                      <div>
                        <label className="text-xs font-bold text-stone-700 block mb-1">Enlace de Instagram</label>
                        <input
                          type="text"
                          value={localSettings.socialNetworks?.instagram || ''}
                          onChange={(e) => setLocalSettings({
                            ...localSettings,
                            socialNetworks: { ...localSettings.socialNetworks, instagram: e.target.value }
                          })}
                          placeholder="https://www.instagram.com/emmy_mecedoras"
                          className="w-full text-xs p-2.5 bg-white border border-stone-300 rounded-xl"
                        />
                      </div>
                      <div>
                        <label className="text-xs font-bold text-stone-700 block mb-1">Enlace de Facebook</label>
                        <input
                          type="text"
                          value={localSettings.socialNetworks?.facebook || ''}
                          onChange={(e) => setLocalSettings({
                            ...localSettings,
                            socialNetworks: { ...localSettings.socialNetworks, facebook: e.target.value }
                          })}
                          placeholder="https://www.facebook.com/..."
                          className="w-full text-xs p-2.5 bg-white border border-stone-300 rounded-xl"
                        />
                      </div>
                    </div>

                    <div className="sm:col-span-2">
                      <label className="text-xs font-bold text-stone-700 block mb-1">Información de Entrega y Envíos</label>
                      <textarea
                        rows={2}
                        value={localSettings.deliveryInformation}
                        onChange={(e) => setLocalSettings({ ...localSettings, deliveryInformation: e.target.value })}
                        className="w-full text-xs p-2.5 bg-stone-50 border border-stone-300 rounded-xl"
                      />
                    </div>

                    {/* ENLACE DIRECTO A LA PESTAÑA DEDICADA DE TELAS & TAPICERÍA */}
                    <div className="sm:col-span-2 p-5 rounded-2xl bg-[#FAF8F5] border border-[#E8E2DC] flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                      <div className="space-y-1">
                        <h4 className="font-serif font-bold text-sm text-[#2C1810] flex items-center gap-2">
                          <Layers className="w-4 h-4 text-[#8a532b]" />
                          <span>Gestión Centralizada de Telas, Tapicería y Confección</span>
                        </h4>
                        <p className="text-xs text-stone-600">
                          Los tipos de telas, estampados, muestras de textalina, bordes, ribetes y estilos de confección se administran ahora desde su propia sección dedicada en el panel.
                        </p>
                      </div>
                      <button
                        type="button"
                        onClick={() => setActiveTab('fabrics')}
                        className="px-4 py-2.5 rounded-xl bg-[#8a532b] hover:bg-[#6e4121] text-white text-xs font-bold flex items-center gap-2 shrink-0 transition-colors shadow-xs cursor-pointer"
                      >
                        <Layers className="w-4 h-4" />
                        <span>Ir a Telas & Tapicería Global ({(localSettings.cushionFabrics || []).length})</span>
                      </button>
                    </div>
                  </div>

                  {/* SEGURIDAD & ADMINISTRADORES FIREBASE */}
                  <div className="p-5 rounded-2xl bg-amber-50/60 border border-amber-200 space-y-4">
                    <div className="flex items-center gap-3">
                      <div className="p-2.5 rounded-xl bg-amber-600 text-white shadow-xs">
                        <ShieldCheck className="w-5 h-5" />
                      </div>
                      <div>
                        <h4 className="font-bold text-sm text-stone-900">Seguridad & Administradores Firebase</h4>
                        <p className="text-xs text-stone-600">
                          Autenticación administrativa gobernada por Firebase Authentication y autorizada en Firestore <code className="bg-amber-100 px-1 py-0.5 rounded font-mono text-[11px]">/admins/{'{uid}'}</code>.
                        </p>
                      </div>
                    </div>

                    <div className="p-4 rounded-xl bg-white border border-amber-200/80 space-y-2 text-xs">
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <span className="font-semibold text-stone-700">Administrador en Sesión:</span>
                        <span className="font-mono text-stone-900 bg-stone-100 px-2 py-1 rounded">
                          {firebaseUserEmail || 'Sesión Activa'}
                        </span>
                      </div>
                      {FirebaseService.getCurrentUser()?.uid && (
                        <div className="flex flex-wrap items-center justify-between gap-2 pt-1 border-t border-stone-100">
                          <span className="font-semibold text-stone-700">UID de Firebase:</span>
                          <div className="flex items-center gap-2">
                            <span className="font-mono text-[11px] text-stone-800 bg-stone-100 px-2 py-0.5 rounded select-all">
                              {FirebaseService.getCurrentUser()?.uid}
                            </span>
                            <button
                              type="button"
                              onClick={() => {
                                const uid = FirebaseService.getCurrentUser()?.uid;
                                if (uid) {
                                  navigator.clipboard.writeText(uid);
                                  showFeedback('UID copiado al portapapeles');
                                }
                              }}
                              className="p-1 hover:bg-stone-200 rounded text-stone-600 cursor-pointer"
                              title="Copiar UID"
                            >
                              <Copy className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                      )}
                      <div className="flex items-center justify-between pt-1 border-t border-stone-100">
                        <span className="font-semibold text-stone-700">Ruta de Autorización:</span>
                        <span className="text-emerald-700 font-bold flex items-center gap-1">
                          <CheckCircle className="w-3.5 h-3.5 text-emerald-600" />
                          /admins/{'{uid}'} (role: "admin", active: true)
                        </span>
                      </div>
                    </div>

                    <p className="text-[11px] text-stone-500 italic">
                      * Por estrictos estándares de seguridad externa de Firebase, ninguna contraseña se almacena dentro de <code className="font-mono text-[10px]">/settings/store</code>.
                    </p>
                  </div>

                  <div className="flex justify-end pt-4 border-t border-stone-200">
                    <button
                      onClick={handleSaveSettings}
                      disabled={isSaving}
                      className="px-6 py-3 rounded-xl bg-[#8a532b] hover:bg-[#6e4121] text-white text-xs font-bold flex items-center gap-2 shadow-md"
                    >
                      <Save className="w-4 h-4" />
                      <span>{isSaving ? 'Guardando...' : 'Guardar Toda la Configuración'}</span>
                    </button>
                  </div>
                </div>
              )}

              {/* ================= GLOBAL FABRICS & UPHOLSTERY MANAGER TAB ================= */}
              {activeTab === 'fabrics' && (
                <AdminFabricsManager
                  settings={localSettings}
                  onUpdateSettings={(updated) => {
                    setLocalSettings(updated);
                    onDataRefresh();
                  }}
                  onSaveAll={handleSaveSettings}
                  isSaving={isSaving}
                  showFeedback={showFeedback}
                  onDataRefresh={onDataRefresh}
                />
              )}

              {/* ================= FIREBASE & CLOUD BACKUP TAB ================= */}
              {activeTab === 'firebase' && (
                <div className="bg-white p-6 sm:p-8 rounded-3xl border border-stone-200 shadow-md space-y-6 max-w-4xl mx-auto">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-stone-200">
                    <div>
                      <h3 className="font-serif text-xl font-bold text-stone-900 flex items-center gap-2">
                        <Flame className="w-6 h-6 text-amber-500" />
                        <span>Sincronización y Respaldo en la Nube con Firebase</span>
                      </h3>
                      <p className="text-xs text-stone-500">
                        Almacenamiento persistente en Firebase Firestore para productos, fotos, precios, reseñas y pedidos.
                      </p>
                    </div>
                    <div className="flex items-center gap-2 px-3 py-1.5 bg-emerald-50 border border-emerald-200 rounded-2xl text-emerald-800 text-xs font-bold">
                      <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
                      <span>Firestore Activo</span>
                    </div>
                  </div>

                  {/* Status Banner */}
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div className="p-4 rounded-2xl bg-[#faf8f5] border border-stone-200 space-y-1">
                      <span className="text-[11px] font-bold text-stone-500 uppercase tracking-wider block">Proyecto Firebase</span>
                      <p className="text-sm font-mono font-bold text-stone-800 truncate">gen-lang-client-0866147233</p>
                      <span className="text-[10px] text-emerald-700 font-semibold flex items-center gap-1">
                        <CheckCircle className="w-3 h-3" /> Conexión establecida
                      </span>
                    </div>

                    <div className="p-4 rounded-2xl bg-[#faf8f5] border border-stone-200 space-y-1">
                      <span className="text-[11px] font-bold text-stone-500 uppercase tracking-wider block">Base de Datos</span>
                      <p className="text-sm font-mono font-bold text-stone-800 truncate">Firestore Cloud Database</p>
                      <span className="text-[10px] text-emerald-700 font-semibold flex items-center gap-1">
                        <Database className="w-3 h-3" /> Reglas de seguridad configuradas
                      </span>
                    </div>

                    <div className="p-4 rounded-2xl bg-[#faf8f5] border border-stone-200 space-y-1">
                      <span className="text-[11px] font-bold text-stone-500 uppercase tracking-wider block">Sesión de Administrador</span>
                      <p className="text-sm font-bold text-stone-800 truncate">{firebaseUserEmail || api.getUsername() || 'Admin Conectado'}</p>
                      <span className="text-[10px] text-emerald-700 font-semibold flex items-center gap-1">
                        <ShieldCheck className="w-3 h-3" /> Autenticación verificada
                      </span>
                    </div>
                  </div>

                  {/* Catalog Stats in Cloud */}
                  <div className="p-5 rounded-2xl bg-stone-50 border border-stone-200 space-y-3">
                    <h4 className="font-bold text-xs uppercase tracking-wider text-stone-700">Resumen de Datos Listos para Sincronizar</h4>
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                      <div className="p-3 bg-white rounded-xl border border-stone-200 text-center">
                        <p className="text-xl font-bold text-[#8a532b]">{products.length}</p>
                        <p className="text-[11px] text-stone-500 font-medium">Productos Activos</p>
                      </div>
                      <div className="p-3 bg-white rounded-xl border border-stone-200 text-center">
                        <p className="text-xl font-bold text-[#8a532b]">{categories.length}</p>
                        <p className="text-[11px] text-stone-500 font-medium">Categorías</p>
                      </div>
                      <div className="p-3 bg-white rounded-xl border border-stone-200 text-center">
                        <p className="text-xl font-bold text-[#8a532b]">{banners.length}</p>
                        <p className="text-[11px] text-stone-500 font-medium">Banners Carrusel</p>
                      </div>
                      <div className="p-3 bg-white rounded-xl border border-stone-200 text-center">
                        <p className="text-xl font-bold text-[#8a532b]">{reviewsList.length}</p>
                        <p className="text-[11px] text-stone-500 font-medium">Reseñas y Opiniones</p>
                      </div>
                    </div>
                  </div>

                  {/* Cloud Action Cards */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {/* Backup to Firebase */}
                    <div className="p-5 rounded-2xl bg-amber-50/70 border border-amber-200 space-y-3 flex flex-col justify-between">
                      <div>
                        <div className="w-10 h-10 rounded-xl bg-amber-600 text-white flex items-center justify-center mb-2 shadow-xs">
                          <Cloud className="w-5 h-5" />
                        </div>
                        <h4 className="font-bold text-sm text-stone-900">Respaldar Todo en Firebase</h4>
                        <p className="text-xs text-stone-600 mt-1">
                          Guarda un respaldo completo e instantáneo de todos los productos, fotos, categorías, WhatsApp y reseñas en la base de datos Firestore.
                        </p>
                      </div>
                      <button
                        onClick={handleBackupToFirebase}
                        disabled={isFirebaseSyncing}
                        className="w-full py-3 px-4 rounded-xl bg-amber-700 hover:bg-amber-800 text-white text-xs font-bold shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-60"
                      >
                        {isFirebaseSyncing ? (
                          <>
                            <Loader2 className="w-4 h-4 animate-spin" />
                            <span>Sincronizando con Firebase...</span>
                          </>
                        ) : (
                          <>
                            <Upload className="w-4 h-4" />
                            <span>Sincronizar y Respaldar en la Nube</span>
                          </>
                        )}
                      </button>
                    </div>

                    {/* Restore from Firebase */}
                    <div className="p-5 rounded-2xl bg-stone-50 border border-stone-200 space-y-3 flex flex-col justify-between">
                      <div>
                        <div className="w-10 h-10 rounded-xl bg-stone-800 text-white flex items-center justify-center mb-2 shadow-xs">
                          <Download className="w-5 h-5" />
                        </div>
                        <h4 className="font-bold text-sm text-stone-900">Restaurar Datos desde la Nube</h4>
                        <p className="text-xs text-stone-600 mt-1">
                          Recarga las últimas versiones de catálogo y configuración guardadas en tu base de datos Firestore.
                        </p>
                      </div>
                      <button
                        onClick={handleRestoreFromFirebase}
                        disabled={isFirebaseSyncing}
                        className="w-full py-3 px-4 rounded-xl bg-stone-800 hover:bg-stone-900 text-white text-xs font-bold shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-60"
                      >
                        {isFirebaseSyncing ? (
                          <>
                            <Loader2 className="w-4 h-4 animate-spin" />
                            <span>Restaurando...</span>
                          </>
                        ) : (
                          <>
                            <RefreshCw className="w-4 h-4" />
                            <span>Restaurar Catálogo desde Firestore</span>
                          </>
                        )}
                      </button>
                    </div>
                  </div>

                  {/* Seed / Initialize Button */}
                  <div className="p-4 rounded-2xl bg-emerald-50/60 border border-emerald-200 flex flex-col sm:flex-row items-center justify-between gap-3">
                    <div>
                      <h5 className="font-bold text-xs text-emerald-950 flex items-center gap-1.5">
                        <Zap className="w-4 h-4 text-emerald-700" />
                        <span>Inicialización Automática de Colecciones</span>
                      </h5>
                      <p className="text-[11px] text-emerald-800">
                        Si creas una base de datos nueva o vacía, pulsa aquí para poblar todas las colecciones con el catálogo predeterminado.
                      </p>
                    </div>
                    <button
                      onClick={handleSeedFirebase}
                      disabled={isFirebaseSyncing}
                      className="px-4 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold shrink-0 transition-colors cursor-pointer"
                    >
                      Poblar Colecciones en Firestore
                    </button>
                  </div>

                  {/* Firebase Cloud Storage 5GB Card */}
                  <div className="p-5 rounded-2xl bg-[#faf8f5] border border-stone-200 space-y-4">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-xl bg-[#8a532b] text-white flex items-center justify-center shrink-0 shadow-xs">
                          <HardDrive className="w-5 h-5" />
                        </div>
                        <div>
                          <h4 className="font-bold text-sm text-stone-900 flex items-center gap-2">
                            <span>Firebase Cloud Storage (5 GB Gratis)</span>
                            <span className="text-[10px] bg-amber-100 text-amber-900 px-2 py-0.5 rounded-full font-semibold">Plan Spark</span>
                          </h4>
                          <p className="text-xs text-stone-600">
                            Aloja fotografías de productos sin límite de 1MB en la base de datos Firestore.
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={handleTestStorageConnection}
                          disabled={storageCheckState.status === 'checking'}
                          className="px-3.5 py-2 bg-stone-100 hover:bg-stone-200 text-stone-800 text-xs font-bold rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer disabled:opacity-50"
                        >
                          {storageCheckState.status === 'checking' ? (
                            <>
                              <Loader2 className="w-3.5 h-3.5 animate-spin" />
                              <span>Verificando...</span>
                            </>
                          ) : (
                            <>
                              <RefreshCw className="w-3.5 h-3.5" />
                              <span>Comprobar Storage</span>
                            </>
                          )}
                        </button>
                        <a
                          href="https://console.firebase.google.com/project/gen-lang-client-0866147233/storage"
                          target="_blank"
                          rel="noreferrer noopener"
                          className="px-3.5 py-2 bg-[#8a532b] hover:bg-[#6e4121] text-white text-xs font-bold rounded-xl flex items-center gap-1.5 shadow-xs transition-colors"
                        >
                          <span>Abrir Consola Storage</span>
                          <ExternalLink className="w-3.5 h-3.5" />
                        </a>
                      </div>
                    </div>

                    {storageCheckState.status === 'active' && (
                      <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-800 flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                        <span>{storageCheckState.message}</span>
                      </div>
                    )}

                    {storageCheckState.status === 'rules_needed' && (
                      <div className="p-4 bg-sky-50 border border-sky-200 rounded-xl space-y-3 text-xs text-sky-950">
                        <div className="flex items-start gap-2">
                          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                          <div>
                            <p className="font-bold text-emerald-900">¡Depósito de Firebase Storage creado exitosamente!</p>
                            <p className="text-stone-700 mt-0.5">
                              Solo falta un paso de 15 segundos: permitir lectura y subida en las <strong>Reglas de Storage</strong>.
                            </p>
                          </div>
                        </div>

                        <div className="bg-stone-900 text-stone-100 p-3 rounded-xl font-mono text-[11px] relative">
                          <pre className="overflow-x-auto whitespace-pre">
{`rules_version = '2';
service firebase.storage {
  match /b/{bucket}/o {
    match /{allPaths=**} {
      allow read, write: if true;
    }
  }
}`}
                          </pre>
                          <button
                            type="button"
                            onClick={() => {
                              navigator.clipboard.writeText(
`rules_version = '2';
service firebase.storage {
  match /b/{bucket}/o {
    match /{allPaths=**} {
      allow read, write: if true;
    }
  }
}`
                              );
                              setCopiedStorageRules(true);
                              setTimeout(() => setCopiedStorageRules(false), 3000);
                            }}
                            className="absolute top-2.5 right-2.5 px-2.5 py-1 bg-stone-800 hover:bg-stone-700 text-stone-200 text-[10px] font-bold rounded-lg flex items-center gap-1 cursor-pointer transition-colors"
                          >
                            {copiedStorageRules ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                            <span>{copiedStorageRules ? '¡Copiado!' : 'Copiar Reglas'}</span>
                          </button>
                        </div>

                        <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
                          <span className="text-[11px] text-stone-600">
                            Pega esto en la pestaña <strong>Reglas</strong> de Firebase Storage y pulsa <strong>"Publicar"</strong>.
                          </span>
                          <a
                            href="https://console.firebase.google.com/project/gen-lang-client-0866147233/storage/rules"
                            target="_blank"
                            rel="noreferrer noopener"
                            className="px-3 py-1.5 bg-[#8a532b] hover:bg-[#6e4121] text-white font-bold rounded-lg flex items-center gap-1.5 transition-colors shadow-xs text-xs"
                          >
                            <span>Ir a Reglas de Storage</span>
                            <ExternalLink className="w-3.5 h-3.5" />
                          </a>
                        </div>
                      </div>
                    )}

                    {storageCheckState.status === 'not_enabled' && (
                      <div className="p-3.5 bg-amber-50 border border-amber-200 rounded-xl space-y-2 text-xs text-amber-900">
                        <div className="flex items-start gap-2">
                          <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                          <div>
                            <p className="font-bold">Cómo habilitar Storage en tu cuenta gratuita (1 minuto):</p>
                            <ol className="list-decimal ml-4 mt-1 space-y-1 text-stone-700">
                              <li>Haz clic en <strong>"Abrir Consola Storage"</strong> (o ve a Firebase Console &gt; Storage).</li>
                              <li>Presiona el botón <strong>"Comenzar" (Get started)</strong>.</li>
                              <li>Acepta las reglas por defecto y presiona <strong>"Listo"</strong>.</li>
                            </ol>
                            <p className="mt-2 text-[11px] text-stone-600">
                              <em>Nota: Tu plan gratuito Spark ya incluye 5 GB de Cloud Storage sin costo adicional. Mientras lo activas, el sistema comprime las fotos automáticamente para proteger la tienda.</em>
                            </p>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* ================= TOOLS & RESTORE TAB ================= */}
              {activeTab === 'tools' && (
                <div className="bg-white p-6 sm:p-8 rounded-3xl border border-stone-200 shadow-md space-y-6 max-w-3xl mx-auto">
                  <div>
                    <h3 className="font-serif text-xl font-bold text-stone-900">Mantenimiento de Catálogo</h3>
                    <p className="text-xs text-stone-500">Opciones de respaldo y restauración de datos del catálogo.</p>
                  </div>

                  <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200 space-y-3">
                    <h4 className="font-bold text-sm text-amber-900 flex items-center gap-2">
                      <RefreshCw className="w-4 h-4 text-amber-700" />
                      <span>Restablecer a Datos Iniciales</span>
                    </h4>
                    <p className="text-xs text-amber-800">
                      Restaura la lista completa de mecedoras grandes, medianas, medio juegos, combinados con sofá y cojines predeterminados.
                    </p>
                    <button
                      onClick={handleResetCatalog}
                      className="px-4 py-2.5 rounded-xl bg-amber-700 hover:bg-amber-800 text-white text-xs font-bold shadow-xs transition-colors"
                    >
                      Restablecer Catálogo Predeterminado
                    </button>
                  </div>

                  {/* PDF Catalog Generator Tool */}
                  <div className="p-5 rounded-2xl bg-linear-to-br from-amber-500/10 via-amber-600/5 to-transparent border border-amber-300/80 space-y-3 shadow-xs">
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <h4 className="font-bold text-sm text-stone-900 flex items-center gap-2">
                          <FileText className="w-4 h-4 text-amber-700" />
                          <span>Generador Profesional de Catálogo en PDF</span>
                        </h4>
                        <p className="text-xs text-stone-600 mt-1">
                          Genera un archivo PDF con portada, {categories.length} categorías temáticas, {products.length} productos con fotos de alta calidad, precios, especificaciones técnicas y enlaces de contacto directo.
                        </p>
                      </div>
                      <span className="px-2.5 py-1 rounded-full bg-amber-100 text-amber-800 text-[10px] font-bold shrink-0 border border-amber-200">
                        {products.length} Artículos
                      </span>
                    </div>

                    <div className="pt-1 flex flex-wrap items-center gap-3">
                      <button
                        onClick={handleGeneratePDF}
                        disabled={isGeneratingPDF}
                        className="px-5 py-2.5 rounded-xl bg-amber-700 hover:bg-amber-800 disabled:opacity-50 text-white text-xs font-bold shadow-md transition-all flex items-center gap-2 cursor-pointer"
                      >
                        {isGeneratingPDF ? (
                          <>
                            <Loader2 className="w-4 h-4 animate-spin" />
                            <span>Generando documento PDF...</span>
                          </>
                        ) : (
                          <>
                            <Download className="w-4 h-4" />
                            <span>Generar y Descargar Catálogo PDF</span>
                          </>
                        )}
                      </button>
                    </div>
                  </div>

                  <div className="p-4 rounded-2xl bg-stone-50 border border-stone-200 space-y-3">
                    <h4 className="font-bold text-sm text-stone-900 flex items-center gap-2">
                      <Download className="w-4 h-4 text-stone-700" />
                      <span>Exportar Catálogo JSON</span>
                    </h4>
                    <p className="text-xs text-stone-600">
                      Descarga una copia de seguridad con todos los productos, fotos, categorías y banners actuales.
                    </p>
                    <button
                      onClick={() => {
                        const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify({
                          products,
                          categories,
                          banners,
                          settings
                        }, null, 2));
                        const downloadAnchor = document.createElement('a');
                        downloadAnchor.setAttribute("href", dataStr);
                        downloadAnchor.setAttribute("download", `catalogo_mecedoras_${Date.now()}.json`);
                        document.body.appendChild(downloadAnchor);
                        downloadAnchor.click();
                        downloadAnchor.remove();
                      }}
                      className="px-4 py-2.5 rounded-xl bg-stone-800 hover:bg-stone-900 text-white text-xs font-bold shadow-xs transition-colors"
                    >
                      Descargar Respaldo JSON
                    </button>
                  </div>
                </div>
              )}

            </div>
          </div>
        )}

      </div>
    </div>
  );
};
