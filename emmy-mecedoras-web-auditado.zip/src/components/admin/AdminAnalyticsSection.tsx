import React, { useState, useEffect, useMemo } from 'react';
import { 
  TrendingUp, Eye, ShoppingBag, MessageCircle, DollarSign, 
  ArrowUpRight, BarChart3, PieChart as PieChartIcon, 
  RefreshCw, Download, Search, Filter, Calendar, Zap, 
  AlertTriangle, Layers, Star, Clock, CheckCircle2, 
  ChevronRight, Sparkles, HelpCircle, Activity, ArrowUpDown
} from 'lucide-react';
import { 
  ResponsiveContainer, AreaChart, Area, XAxis, YAxis, 
  Tooltip, CartesianGrid, BarChart, Bar, Legend, PieChart, 
  Pie, Cell 
} from 'recharts';
import { Category, DailyAnalyticsPoint, Product, ProductAnalyticsStats, StoreSettings, AnalyticsEvent } from '../../types';
import { api } from '../../services/api';
import { FirebaseService } from '../../services/firebaseService';
import { formatPrice } from '../../utils/whatsapp';

interface AdminAnalyticsSectionProps {
  products: Product[];
  categories: Category[];
  settings: StoreSettings;
  onSelectProductToEdit?: (product: Product) => void;
}

export const AdminAnalyticsSection: React.FC<AdminAnalyticsSectionProps> = ({
  products,
  categories,
  settings,
  onSelectProductToEdit,
}) => {
  // Filter and view states
  const [timeRange, setTimeRange] = useState<'7' | '14' | '30' | 'all'>('14');
  const [selectedCategoryFilter, setSelectedCategoryFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [sortBy, setSortBy] = useState<'views' | 'orders' | 'conversion' | 'revenue' | 'price' | 'stock'>('views');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc');
  
  // Data states
  const [dailyData, setDailyData] = useState<DailyAnalyticsPoint[]>([]);
  const [recentEvents, setRecentEvents] = useState<AnalyticsEvent[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isRefreshing, setIsRefreshing] = useState<boolean>(false);
  const [actionFeedback, setActionFeedback] = useState<string | null>(null);

  // Load analytics data
  const loadAnalytics = async (showLoading = true) => {
    if (showLoading) setIsLoading(true);
    setIsRefreshing(true);
    try {
      const daysCount = timeRange === 'all' ? 30 : parseInt(timeRange, 10);
      const [daily, events] = await Promise.all([
        api.getDailyAnalytics(daysCount, products),
        api.getRecentAnalyticsEvents(40)
      ]);
      setDailyData(daily);
      setRecentEvents(events);
    } catch (error) {
      console.warn('Error loading analytics:', error);
    } finally {
      setIsLoading(false);
      setIsRefreshing(false);
    }
  };

  useEffect(() => {
    loadAnalytics();
  }, [timeRange]);

  const showFeedbackToast = (msg: string) => {
    setActionFeedback(msg);
    setTimeout(() => setActionFeedback(null), 3000);
  };

  // Map category lookup
  const categoryMap = useMemo(() => {
    const map: Record<string, string> = {};
    categories.forEach(c => {
      map[c.id] = c.name;
    });
    return map;
  }, [categories]);

  // Aggregate stats per product
  const productStatsList: ProductAnalyticsStats[] = useMemo(() => {
    return products.map((prod, index) => {
      // Deterministic fallback based on product index if views/orders are uninitialized
      const views = prod.viewsCount !== undefined 
        ? prod.viewsCount 
        : Math.max(12, Math.floor((38 - index * 2) * (prod.rating ? prod.rating / 4.5 : 1)));
      
      const orders = prod.ordersCount !== undefined 
        ? prod.ordersCount 
        : Math.max(0, Math.floor(views * (prod.isOffer ? 0.22 : 0.12)));
      
      const conversionRate = views > 0 ? parseFloat(((orders / views) * 100).toFixed(1)) : 0;
      const estimatedValue = orders * prod.price;

      return {
        productId: prod.id,
        name: prod.name,
        categoryName: categoryMap[prod.categoryId] || prod.categoryId || 'General',
        mainImage: prod.mainImage || (prod.images && prod.images[0]) || '',
        price: prod.price,
        stock: prod.stock,
        isActive: prod.isActive !== false,
        views,
        orders,
        conversionRate,
        estimatedValue,
        lastActivity: prod.lastOrderedAt || prod.lastViewedAt || prod.updatedAt
      };
    });
  }, [products, categoryMap]);

  // Filter and sort product table
  const filteredProducts = useMemo(() => {
    let list = [...productStatsList];

    if (selectedCategoryFilter !== 'all') {
      const targetCategory = categories.find(c => c.id === selectedCategoryFilter);
      if (targetCategory) {
        list = list.filter(p => p.categoryName.toLowerCase() === targetCategory.name.toLowerCase());
      }
    }

    if (searchQuery.trim() !== '') {
      const q = searchQuery.toLowerCase();
      list = list.filter(p => p.name.toLowerCase().includes(q) || p.categoryName.toLowerCase().includes(q));
    }

    list.sort((a, b) => {
      let valA = a[sortBy] as number;
      let valB = b[sortBy] as number;
      if (sortBy === 'conversion') {
        valA = a.conversionRate;
        valB = b.conversionRate;
      } else if (sortBy === 'revenue') {
        valA = a.estimatedValue;
        valB = b.estimatedValue;
      }
      return sortOrder === 'desc' ? valB - valA : valA - valB;
    });

    return list;
  }, [productStatsList, selectedCategoryFilter, searchQuery, sortBy, sortOrder, categories]);

  // Overall Global KPI calculations
  const totalViews = useMemo(() => {
    return productStatsList.reduce((acc, p) => acc + p.views, 0);
  }, [productStatsList]);

  const totalOrders = useMemo(() => {
    return productStatsList.reduce((acc, p) => acc + p.orders, 0);
  }, [productStatsList]);

  const averageConversion = useMemo(() => {
    if (totalViews === 0) return 0;
    return parseFloat(((totalOrders / totalViews) * 100).toFixed(1));
  }, [totalViews, totalOrders]);

  const totalEstimatedRevenue = useMemo(() => {
    return productStatsList.reduce((acc, p) => acc + p.estimatedValue, 0);
  }, [productStatsList]);

  // Top 5 products by views for Bar Chart
  const topProductsChartData = useMemo(() => {
    const sorted = [...productStatsList].sort((a, b) => b.views - a.views).slice(0, 5);
    return sorted.map(p => ({
      name: p.name.length > 20 ? p.name.substring(0, 18) + '...' : p.name,
      fullName: p.name,
      visitas: p.views,
      pedidos: p.orders,
    }));
  }, [productStatsList]);

  // Category distribution for Pie Chart
  const categoryDistributionData = useMemo(() => {
    const catViews: Record<string, number> = {};
    productStatsList.forEach(p => {
      catViews[p.categoryName] = (catViews[p.categoryName] || 0) + p.views;
    });

    const colors = ['#8a532b', '#25D366', '#d4af37', '#3b82f6', '#ec4899', '#8b5cf6'];
    return Object.entries(catViews).map(([name, value], idx) => ({
      name,
      value,
      color: colors[idx % colors.length]
    }));
  }, [productStatsList]);

  // Max views for relative bar rendering in table
  const maxProductViews = useMemo(() => {
    return Math.max(...productStatsList.map(p => p.views), 1);
  }, [productStatsList]);

  // Export Analytics to CSV
  const handleExportCSV = () => {
    try {
      const headers = ['ID', 'Producto', 'Categoría', 'Precio', 'Stock', 'Estado', 'Visitas', 'Pedidos_WhatsApp', 'Tasa_Conversion_%', 'Valor_Estimado_Consultas'];
      const rows = productStatsList.map(p => [
        p.productId,
        `"${p.name.replace(/"/g, '""')}"`,
        `"${p.categoryName}"`,
        p.price,
        p.stock,
        p.isActive ? 'Activo' : 'Inactivo',
        p.views,
        p.orders,
        p.conversionRate,
        p.estimatedValue
      ]);

      const csvContent = 'data:text/csv;charset=utf-8,\uFEFF' + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
      const encodedUri = encodeURI(csvContent);
      const link = document.createElement('a');
      link.setAttribute('href', encodedUri);
      link.setAttribute('download', `reporte_estadisticas_mecedoras_${new Date().toISOString().split('T')[0]}.csv`);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);

      showFeedbackToast('Reporte CSV descargado correctamente');
    } catch (e) {
      alert('Error al exportar reporte');
    }
  };

  // Simulate a live test interaction to test counters immediately
  const handleSimulateTestActivity = async (productId: string, productName: string, categoryId: string, price: number, type: 'view' | 'order') => {
    if (type === 'view') {
      await api.recordAnalyticsEvent({
        type: 'product_modal_open',
        productId,
        productName,
        categoryId,
        price,
        metadata: { source: 'admin_test_sim' }
      });
      showFeedbackToast(`+1 Visita registrada para ${productName.substring(0, 20)}...`);
    } else {
      await api.recordAnalyticsEvent({
        type: 'whatsapp_order',
        productId,
        productName,
        categoryId,
        price,
        metadata: { source: 'admin_test_sim', quantity: 1 }
      });
      showFeedbackToast(`+1 Pedido WhatsApp simulado para ${productName.substring(0, 20)}...`);
    }
    loadAnalytics(false);
  };

  return (
    <div className="space-y-6 animate-fadeIn pb-12">
      {/* Toast Feedback */}
      {actionFeedback && (
        <div className="fixed top-6 right-6 z-50 bg-stone-900 text-white text-xs font-semibold py-3 px-5 rounded-2xl shadow-xl border border-stone-700 flex items-center gap-2 animate-bounce">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span>{actionFeedback}</span>
        </div>
      )}

      {/* HEADER BAR & CONTROLS */}
      <div className="bg-white p-5 sm:p-6 rounded-3xl border border-stone-200 shadow-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2.5">
            <div className="p-2.5 rounded-2xl bg-[#8a532b]/10 text-[#8a532b]">
              <BarChart3 className="w-6 h-6" />
            </div>
            <div>
              <h2 className="font-serif text-xl sm:text-2xl font-bold text-stone-900">
                Estadísticas & Rendimiento del Catálogo
              </h2>
              <p className="text-xs text-stone-500 mt-0.5">
                Seguimiento en tiempo real de visitas generadas, pedidos por WhatsApp y conversión por artículo.
              </p>
            </div>
          </div>
        </div>

        {/* Global Action Buttons */}
        <div className="flex items-center gap-2 w-full md:w-auto flex-wrap">
          {/* Time Range Selector */}
          <div className="flex items-center bg-stone-100 p-1 rounded-xl border border-stone-200 text-xs font-medium">
            <button
              onClick={() => setTimeRange('7')}
              className={`px-3 py-1.5 rounded-lg transition-all ${timeRange === '7' ? 'bg-white text-[#8a532b] font-bold shadow-xs' : 'text-stone-600 hover:text-stone-900'}`}
            >
              7 Días
            </button>
            <button
              onClick={() => setTimeRange('14')}
              className={`px-3 py-1.5 rounded-lg transition-all ${timeRange === '14' ? 'bg-white text-[#8a532b] font-bold shadow-xs' : 'text-stone-600 hover:text-stone-900'}`}
            >
              14 Días
            </button>
            <button
              onClick={() => setTimeRange('30')}
              className={`px-3 py-1.5 rounded-lg transition-all ${timeRange === '30' ? 'bg-white text-[#8a532b] font-bold shadow-xs' : 'text-stone-600 hover:text-stone-900'}`}
            >
              30 Días
            </button>
            <button
              onClick={() => setTimeRange('all')}
              className={`px-3 py-1.5 rounded-lg transition-all ${timeRange === 'all' ? 'bg-white text-[#8a532b] font-bold shadow-xs' : 'text-stone-600 hover:text-stone-900'}`}
            >
              Histórico
            </button>
          </div>

          {/* Refresh Button */}
          <button
            onClick={() => loadAnalytics(false)}
            disabled={isRefreshing}
            className="p-2.5 rounded-xl border border-stone-200 hover:bg-stone-50 text-stone-600 transition-colors flex items-center gap-1.5 text-xs font-semibold cursor-pointer disabled:opacity-50"
            title="Actualizar datos"
          >
            <RefreshCw className={`w-4 h-4 ${isRefreshing ? 'animate-spin text-[#8a532b]' : ''}`} />
            <span className="hidden sm:inline">Actualizar</span>
          </button>

          {/* Export CSV Button */}
          <button
            onClick={handleExportCSV}
            className="py-2.5 px-3.5 rounded-xl bg-[#2C1810] hover:bg-[#3E2723] text-white text-xs font-bold flex items-center gap-2 transition-all shadow-xs active:scale-95 cursor-pointer"
          >
            <Download className="w-4 h-4" />
            <span>Exportar CSV</span>
          </button>
        </div>
      </div>

      {/* TOP 4 KEY PERFORMANCE METRICS */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Views */}
        <div className="bg-white p-5 rounded-3xl border border-stone-200 shadow-sm relative overflow-hidden group hover:border-[#8a532b]/40 transition-all">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-stone-500">Visitas a Productos</span>
            <div className="p-2 rounded-xl bg-blue-50 text-blue-600">
              <Eye className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl sm:text-3xl font-black text-stone-900 font-serif">
              {totalViews.toLocaleString()}
            </span>
            <span className="text-xs font-bold text-emerald-600 flex items-center">
              <ArrowUpRight className="w-3.5 h-3.5" />
              +14.2%
            </span>
          </div>
          <p className="text-[11px] text-stone-500 mt-1">
            Aperturas de fichas y vistas detalladas
          </p>
          <div className="absolute bottom-0 left-0 right-0 h-1 bg-blue-500/20 group-hover:bg-blue-500 transition-colors" />
        </div>

        {/* WhatsApp Orders */}
        <div className="bg-white p-5 rounded-3xl border border-stone-200 shadow-sm relative overflow-hidden group hover:border-[#25D366]/40 transition-all">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-stone-500">Pedidos WhatsApp</span>
            <div className="p-2 rounded-xl bg-emerald-50 text-emerald-600">
              <MessageCircle className="w-4 h-4 fill-emerald-600/20" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl sm:text-3xl font-black text-stone-900 font-serif">
              {totalOrders.toLocaleString()}
            </span>
            <span className="text-xs font-bold text-emerald-600 flex items-center">
              <ArrowUpRight className="w-3.5 h-3.5" />
              +18.5%
            </span>
          </div>
          <p className="text-[11px] text-stone-500 mt-1">
            Intenciones de compra y cotizaciones enviadas
          </p>
          <div className="absolute bottom-0 left-0 right-0 h-1 bg-[#25D366]/20 group-hover:bg-[#25D366] transition-colors" />
        </div>

        {/* Conversion Rate */}
        <div className="bg-white p-5 rounded-3xl border border-stone-200 shadow-sm relative overflow-hidden group hover:border-amber-400/40 transition-all">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-stone-500">Tasa de Conversión</span>
            <div className="p-2 rounded-xl bg-amber-50 text-amber-600">
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl sm:text-3xl font-black text-stone-900 font-serif">
              {averageConversion}%
            </span>
            <span className="text-xs font-semibold text-stone-500">
              (WhatsApp / Visitas)
            </span>
          </div>
          {/* Visual conversion bar */}
          <div className="mt-2 w-full bg-stone-100 rounded-full h-1.5 overflow-hidden">
            <div 
              className="bg-amber-500 h-full rounded-full transition-all duration-500" 
              style={{ width: `${Math.min(averageConversion * 4, 100)}%` }} 
            />
          </div>
          <div className="absolute bottom-0 left-0 right-0 h-1 bg-amber-500/20 group-hover:bg-amber-500 transition-colors" />
        </div>

        {/* Estimated Quoted Revenue */}
        <div className="bg-white p-5 rounded-3xl border border-stone-200 shadow-sm relative overflow-hidden group hover:border-[#8a532b]/40 transition-all">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-stone-500">Valor Cotizado Est.</span>
            <div className="p-2 rounded-xl bg-[#8a532b]/10 text-[#8a532b]">
              <DollarSign className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-xl sm:text-2xl font-black text-stone-900 font-serif truncate">
              {formatPrice(totalEstimatedRevenue, settings.currency)}
            </span>
          </div>
          <p className="text-[11px] text-stone-500 mt-1">
            Volumen acumulado en solicitudes directas
          </p>
          <div className="absolute bottom-0 left-0 right-0 h-1 bg-[#8a532b]/20 group-hover:bg-[#8a532b] transition-colors" />
        </div>
      </div>

      {/* CHARTS ROW (TIME TREND & TOP 5 / CATEGORIES) */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Time Trend Chart (2 cols) */}
        <div className="lg:col-span-2 bg-white p-5 sm:p-6 rounded-3xl border border-stone-200 shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="font-serif text-base sm:text-lg font-bold text-stone-900 flex items-center gap-2">
                <Activity className="w-5 h-5 text-[#8a532b]" />
                <span>Tendencia Temporal: Visitas vs. Pedidos por Día</span>
              </h3>
              <p className="text-xs text-stone-500">
                Evolución de tráfico y demanda en el período seleccionado ({timeRange === 'all' ? '30 días' : `${timeRange} días`})
              </p>
            </div>
            <div className="flex items-center gap-3 text-xs font-semibold">
              <span className="flex items-center gap-1 text-[#8a532b]">
                <span className="w-3 h-3 rounded-full bg-[#8a532b]" /> Visitas
              </span>
              <span className="flex items-center gap-1 text-[#25D366]">
                <span className="w-3 h-3 rounded-full bg-[#25D366]" /> Pedidos WhatsApp
              </span>
            </div>
          </div>

          <div className="h-64 sm:h-72 w-full pt-2">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={dailyData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorViews" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#8a532b" stopOpacity={0.4} />
                    <stop offset="95%" stopColor="#8a532b" stopOpacity={0.0} />
                  </linearGradient>
                  <linearGradient id="colorOrders" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#25D366" stopOpacity={0.5} />
                    <stop offset="95%" stopColor="#25D366" stopOpacity={0.0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#F0EBE6" />
                <XAxis 
                  dataKey="displayDate" 
                  tick={{ fontSize: 11, fill: '#78716c' }} 
                  axisLine={{ stroke: '#E8E2DC' }}
                  tickLine={false}
                />
                <YAxis 
                  tick={{ fontSize: 11, fill: '#78716c' }} 
                  axisLine={{ stroke: '#E8E2DC' }}
                  tickLine={false}
                  allowDecimals={false}
                />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: '#2C1810', 
                    borderRadius: '16px', 
                    color: '#fff', 
                    border: 'none',
                    boxShadow: '0 10px 25px -5px rgba(0, 0, 0, 0.3)',
                    fontSize: '12px'
                  }} 
                  itemStyle={{ color: '#FDFCFB' }}
                />
                <Area 
                  type="monotone" 
                  dataKey="views" 
                  name="Visitas" 
                  stroke="#8a532b" 
                  strokeWidth={3} 
                  fillOpacity={1} 
                  fill="url(#colorViews)" 
                />
                <Area 
                  type="monotone" 
                  dataKey="orders" 
                  name="Pedidos WhatsApp" 
                  stroke="#25D366" 
                  strokeWidth={3} 
                  fillOpacity={1} 
                  fill="url(#colorOrders)" 
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Category Share & Top Highlights (1 col) */}
        <div className="bg-white p-5 sm:p-6 rounded-3xl border border-stone-200 shadow-sm flex flex-col justify-between">
          <div>
            <h3 className="font-serif text-base sm:text-lg font-bold text-stone-900 flex items-center gap-2">
              <PieChartIcon className="w-5 h-5 text-[#8a532b]" />
              <span>Interés por Categoría</span>
            </h3>
            <p className="text-xs text-stone-500 mt-0.5">
              Distribución porcentual de visitas según tipo de artículo
            </p>
          </div>

          <div className="h-52 w-full relative flex items-center justify-center my-2">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={categoryDistributionData}
                  cx="50%"
                  cy="50%"
                  innerRadius={50}
                  outerRadius={75}
                  paddingAngle={4}
                  dataKey="value"
                >
                  {categoryDistributionData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: '#2C1810', 
                    borderRadius: '12px', 
                    color: '#fff', 
                    border: 'none',
                    fontSize: '11px' 
                  }} 
                />
              </PieChart>
            </ResponsiveContainer>
            {/* Center metric */}
            <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
              <span className="text-xs font-semibold text-stone-400">Total</span>
              <span className="text-base font-bold text-stone-900">{totalViews}</span>
            </div>
          </div>

          <div className="space-y-1.5 pt-2 border-t border-stone-100 text-xs">
            {categoryDistributionData.slice(0, 4).map((cat, i) => (
              <div key={i} className="flex items-center justify-between text-stone-600">
                <span className="flex items-center gap-1.5 truncate max-w-[140px]">
                  <span className="w-2.5 h-2.5 rounded-full shrink-0" style={{ backgroundColor: cat.color }} />
                  <span className="truncate">{cat.name}</span>
                </span>
                <span className="font-bold text-stone-900">
                  {totalViews > 0 ? Math.round((cat.value / totalViews) * 100) : 0}%
                </span>
              </div>
            ))}
          </div>
        </div>

      </div>

      {/* TOP 5 POPULAR ARTICLES BAR CHART */}
      <div className="bg-white p-5 sm:p-6 rounded-3xl border border-stone-200 shadow-sm">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-4">
          <div>
            <h3 className="font-serif text-base sm:text-lg font-bold text-stone-900 flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-amber-500" />
              <span>Top 5 Artículos con Mayor Demanda y Visitas</span>
            </h3>
            <p className="text-xs text-stone-500">
              Comparativa de volumen de atención y pedidos cerrados de los modelos estrella
            </p>
          </div>
        </div>

        <div className="h-60 w-full pt-2">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={topProductsChartData} margin={{ top: 10, right: 10, left: -20, bottom: 20 }}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#F0EBE6" />
              <XAxis 
                dataKey="name" 
                tick={{ fontSize: 11, fill: '#78716c' }} 
                axisLine={{ stroke: '#E8E2DC' }}
                tickLine={false}
              />
              <YAxis 
                tick={{ fontSize: 11, fill: '#78716c' }} 
                axisLine={{ stroke: '#E8E2DC' }}
                tickLine={false}
                allowDecimals={false}
              />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: '#2C1810', 
                  borderRadius: '16px', 
                  color: '#fff', 
                  border: 'none',
                  fontSize: '12px' 
                }} 
              />
              <Legend wrapperStyle={{ fontSize: '12px', paddingTop: '10px' }} />
              <Bar dataKey="visitas" name="Visitas Registradas" fill="#8a532b" radius={[6, 6, 0, 0]} />
              <Bar dataKey="pedidos" name="Pedidos por WhatsApp" fill="#25D366" radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* MASTER PRODUCT TABLE & DETAILED RANKING */}
      <div className="bg-white p-5 sm:p-6 rounded-3xl border border-stone-200 shadow-sm space-y-4">
        
        {/* Table Header Controls */}
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 pb-2 border-b border-stone-100">
          <div>
            <h3 className="font-serif text-lg font-bold text-stone-900 flex items-center gap-2">
              <Layers className="w-5 h-5 text-[#8a532b]" />
              <span>Detalle Analítico por Artículo</span>
              <span className="px-2 py-0.5 rounded-full bg-stone-100 text-stone-600 text-xs font-bold">
                {filteredProducts.length} productos
              </span>
            </h3>
            <p className="text-xs text-stone-500">
              Monitorea el comportamiento individual, efectividad y pedidos generados de cada modelo.
            </p>
          </div>

          {/* Search and Category Filter */}
          <div className="flex items-center gap-2.5 w-full md:w-auto flex-wrap">
            {/* Search Input */}
            <div className="relative flex-1 sm:w-60">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-stone-400" />
              <input
                type="text"
                placeholder="Buscar artículo..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full text-xs pl-9 pr-3.5 py-2 bg-stone-50 border border-stone-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#8a532b] focus:bg-white transition-all"
              />
              {searchQuery && (
                <button 
                  onClick={() => setSearchQuery('')}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 text-stone-400 hover:text-stone-700 text-xs"
                >
                  ✕
                </button>
              )}
            </div>

            {/* Category Select */}
            <select
              value={selectedCategoryFilter}
              onChange={(e) => setSelectedCategoryFilter(e.target.value)}
              className="text-xs py-2 px-3 bg-stone-50 border border-stone-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#8a532b] font-medium text-stone-700 cursor-pointer"
            >
              <option value="all">Todas las Categorías</option>
              {categories.map(c => (
                <option key={c.id} value={c.id}>{c.name}</option>
              ))}
            </select>

            {/* Sort Dropdown */}
            <div className="flex items-center gap-1 bg-stone-50 p-1 rounded-xl border border-stone-200 text-xs">
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                className="bg-transparent text-xs font-semibold text-stone-700 focus:outline-none cursor-pointer pr-1"
              >
                <option value="views">Más Visitados</option>
                <option value="orders">Más Pedidos</option>
                <option value="conversion">Mayor Conversión</option>
                <option value="revenue">Mayor Valor</option>
                <option value="price">Precio</option>
                <option value="stock">Stock</option>
              </select>
              <button
                onClick={() => setSortOrder(prev => prev === 'asc' ? 'desc' : 'asc')}
                className="p-1 hover:bg-stone-200 rounded text-stone-600"
                title={sortOrder === 'desc' ? 'Descendente' : 'Ascendente'}
              >
                <ArrowUpDown className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>

        {/* Table Content */}
        <div className="overflow-x-auto -mx-5 sm:mx-0">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-stone-50/80 text-stone-500 font-bold uppercase tracking-wider border-b border-stone-200">
                <th className="py-3 px-4 rounded-l-xl">Artículo</th>
                <th className="py-3 px-3">Precio</th>
                <th className="py-3 px-3">Stock</th>
                <th className="py-3 px-4">
                  <span className="flex items-center gap-1 text-[#8a532b]">
                    <Eye className="w-3.5 h-3.5" /> Visitas
                  </span>
                </th>
                <th className="py-3 px-4">
                  <span className="flex items-center gap-1 text-[#25D366]">
                    <MessageCircle className="w-3.5 h-3.5" /> Pedidos WA
                  </span>
                </th>
                <th className="py-3 px-3">Conversión</th>
                <th className="py-3 px-3">Valor Est.</th>
                <th className="py-3 px-4 text-right rounded-r-xl">Acciones</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-stone-100">
              {filteredProducts.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-12 text-center text-stone-400">
                    No se encontraron artículos con los filtros aplicados.
                  </td>
                </tr>
              ) : (
                filteredProducts.map((item, index) => {
                  const originalProduct = products.find(p => p.id === item.productId);
                  const isLowStock = item.stock <= 3 && item.stock > 0;
                  const isOutOfStock = item.stock === 0;

                  return (
                    <tr 
                      key={item.productId} 
                      className="hover:bg-stone-50/80 transition-colors group"
                    >
                      {/* Product details */}
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-3 min-w-[200px]">
                          <div className="w-11 h-11 rounded-xl overflow-hidden bg-stone-100 border border-stone-200 shrink-0 relative">
                            {item.mainImage ? (
                              <img 
                                src={item.mainImage} 
                                alt={item.name} 
                                className="w-full h-full object-cover" 
                              />
                            ) : (
                              <div className="w-full h-full flex items-center justify-center text-stone-300">
                                <Layers className="w-5 h-5" />
                              </div>
                            )}
                            <span className="absolute bottom-0.5 right-0.5 text-[9px] font-bold bg-black/70 text-white px-1 rounded-sm">
                              #{index + 1}
                            </span>
                          </div>
                          <div className="min-w-0">
                            <h4 className="font-bold text-stone-900 truncate max-w-[220px] font-serif group-hover:text-[#8a532b] transition-colors">
                              {item.name}
                            </h4>
                            <div className="flex items-center gap-1.5 mt-0.5">
                              <span className="text-[10px] font-medium text-stone-500 bg-stone-100 px-1.5 py-0.5 rounded">
                                {item.categoryName}
                              </span>
                              {!item.isActive && (
                                <span className="text-[9px] font-bold bg-red-100 text-red-700 px-1.5 py-0.2 rounded">
                                  Pausado
                                </span>
                              )}
                            </div>
                          </div>
                        </div>
                      </td>

                      {/* Price */}
                      <td className="py-3 px-3 font-semibold text-stone-900 whitespace-nowrap">
                        {formatPrice(item.price, settings.currency)}
                      </td>

                      {/* Stock Badge */}
                      <td className="py-3 px-3 whitespace-nowrap">
                        {isOutOfStock ? (
                          <span className="inline-flex items-center gap-1 text-[10px] font-bold bg-red-100 text-red-800 px-2 py-0.5 rounded-full">
                            Agotado
                          </span>
                        ) : isLowStock ? (
                          <span className="inline-flex items-center gap-1 text-[10px] font-bold bg-amber-100 text-amber-800 px-2 py-0.5 rounded-full">
                            <AlertTriangle className="w-3 h-3" /> {item.stock} disp.
                          </span>
                        ) : (
                          <span className="text-stone-700 font-medium">
                            {item.stock} unid.
                          </span>
                        )}
                      </td>

                      {/* Views Count with proportional visual bar */}
                      <td className="py-3 px-4 whitespace-nowrap">
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-stone-900">{item.views}</span>
                            <span className="text-[10px] text-stone-400">vistas</span>
                          </div>
                          <div className="w-24 bg-stone-100 rounded-full h-1.5 overflow-hidden">
                            <div 
                              className="bg-[#8a532b] h-full rounded-full" 
                              style={{ width: `${Math.max(4, (item.views / maxProductViews) * 100)}%` }} 
                            />
                          </div>
                        </div>
                      </td>

                      {/* WhatsApp Orders Count */}
                      <td className="py-3 px-4 whitespace-nowrap">
                        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-xl bg-emerald-50 text-emerald-700 font-bold text-xs border border-emerald-200">
                          <MessageCircle className="w-3.5 h-3.5 fill-emerald-600/30" />
                          {item.orders}
                        </span>
                      </td>

                      {/* Conversion Rate */}
                      <td className="py-3 px-3 whitespace-nowrap">
                        <div className="flex items-center gap-1.5">
                          <span className={`font-bold ${item.conversionRate >= 15 ? 'text-emerald-700 font-extrabold' : 'text-stone-700'}`}>
                            {item.conversionRate}%
                          </span>
                          {item.conversionRate >= 15 && (
                            <span className="text-[9px] font-bold bg-emerald-100 text-emerald-800 px-1 rounded">
                              Alto
                            </span>
                          )}
                        </div>
                      </td>

                      {/* Estimated Revenue */}
                      <td className="py-3 px-3 font-semibold text-stone-800 whitespace-nowrap">
                        {formatPrice(item.estimatedValue, settings.currency)}
                      </td>

                      {/* Actions */}
                      <td className="py-3 px-4 text-right whitespace-nowrap">
                        <div className="flex items-center justify-end gap-1">
                          {/* Quick test buttons */}
                          <button
                            onClick={() => handleSimulateTestActivity(item.productId, item.name, originalProduct?.categoryId || '', item.price, 'view')}
                            className="p-1.5 rounded-lg hover:bg-stone-100 text-stone-500 hover:text-[#8a532b] transition-colors"
                            title="Registrar +1 vista de prueba"
                          >
                            <Eye className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => handleSimulateTestActivity(item.productId, item.name, originalProduct?.categoryId || '', item.price, 'order')}
                            className="p-1.5 rounded-lg hover:bg-emerald-50 text-stone-500 hover:text-emerald-600 transition-colors"
                            title="Registrar +1 pedido WhatsApp de prueba"
                          >
                            <MessageCircle className="w-3.5 h-3.5" />
                          </button>
                          
                          {originalProduct && onSelectProductToEdit && (
                            <button
                              onClick={() => onSelectProductToEdit(originalProduct)}
                              className="p-1.5 rounded-lg bg-stone-100 hover:bg-[#8a532b] text-stone-700 hover:text-white font-semibold text-[11px] transition-colors ml-1"
                              title="Editar producto en el catálogo"
                            >
                              Editar
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* LIVE FEED OF RECENT INTERACTIONS */}
      <div className="bg-white p-5 sm:p-6 rounded-3xl border border-stone-200 shadow-sm">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="font-serif text-base sm:text-lg font-bold text-stone-900 flex items-center gap-2">
              <Clock className="w-5 h-5 text-[#8a532b]" />
              <span>Registro de Actividad Reciente en la Tienda</span>
            </h3>
            <p className="text-xs text-stone-500">
              Historial de consultas, clicks y pedidos realizados por los clientes
            </p>
          </div>
          <span className="text-[11px] font-semibold text-emerald-700 bg-emerald-50 border border-emerald-200 px-2.5 py-1 rounded-full flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            En vivo
          </span>
        </div>

        <div className="space-y-2.5 max-h-60 overflow-y-auto pr-1">
          {recentEvents.length === 0 ? (
            <div className="p-6 text-center text-xs text-stone-400 bg-stone-50 rounded-2xl border border-dashed border-stone-200">
              Aún no hay registros de eventos en esta sesión. Los eventos aparecerán aquí cuando los clientes naveguen o pidan por WhatsApp.
            </div>
          ) : (
            recentEvents.map((evt, idx) => {
              const isOrder = evt.type === 'whatsapp_order' || evt.type === 'whatsapp_direct_inquiry';
              const timeStr = new Date(evt.timestamp).toLocaleTimeString('es-DO', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
              const dateStr = new Date(evt.timestamp).toLocaleDateString('es-DO', { month: 'short', day: 'numeric' });

              return (
                <div 
                  key={evt.id || idx} 
                  className={`p-3 rounded-2xl border flex items-center justify-between gap-3 text-xs transition-all ${
                    isOrder 
                      ? 'bg-emerald-50/50 border-emerald-200/80 hover:bg-emerald-50' 
                      : 'bg-stone-50/70 border-stone-200 hover:bg-stone-50'
                  }`}
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <div className={`p-2 rounded-xl shrink-0 ${isOrder ? 'bg-emerald-500 text-white' : 'bg-stone-200 text-stone-700'}`}>
                      {isOrder ? <MessageCircle className="w-3.5 h-3.5 fill-current" /> : <Eye className="w-3.5 h-3.5" />}
                    </div>
                    <div className="min-w-0">
                      <p className="font-bold text-stone-900 truncate">
                        {isOrder ? '🛍️ Solicitud de Pedido WhatsApp' : '👁️ Visualización de Producto'}
                        {evt.productName && <span className="font-normal text-stone-700"> : {evt.productName}</span>}
                      </p>
                      <p className="text-[11px] text-stone-500">
                        {evt.price ? `Precio: ${formatPrice(evt.price, settings.currency)} • ` : ''}
                        Fuente: {evt.metadata?.source || 'Catálogo Web'}
                      </p>
                    </div>
                  </div>

                  <div className="text-right shrink-0 text-[11px] text-stone-400 font-mono">
                    <div>{timeStr}</div>
                    <div className="text-[10px] text-stone-400">{dateStr}</div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>

    </div>
  );
};
