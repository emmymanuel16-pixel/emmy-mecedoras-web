import React, { useState } from 'react';
import { 
  Sparkles, Plus, Trash2, Edit3, Save, Check, RefreshCw, Upload, 
  Rotate3d, Image as ImageIcon, Palette, DollarSign, CheckCircle2, 
  Sliders, Shield, Layers, HelpCircle, Eye, EyeOff
} from 'lucide-react';
import { ConfiguratorSettings, CustomizerAccessoryOption, CustomizerColorOption, CustomizerFabricOption, StoreSettings } from '../../types';
import { Cushion2DViewer } from '../configurator/Cushion2DViewer';
import { formatPrice } from '../../utils/whatsapp';
import { compressImageFile, uploadImagesToServer } from '../../utils/imageCompressor';
import { uploadToFirebaseStorage } from '../../services/firebaseStorageService';
import { notifyError } from '../../utils/errorReporting';

interface AdminConfiguratorManagerProps {
  settings: StoreSettings;
  onSaveSettings: (updatedSettings: StoreSettings) => Promise<void>;
  onRefresh: () => void;
}

export const AdminConfiguratorManager: React.FC<AdminConfiguratorManagerProps> = ({
  settings,
  onSaveSettings,
  onRefresh,
}) => {
  const [config, setConfig] = useState<ConfiguratorSettings>(() => {
    if (settings.configurator) {
      return {
        ...settings.configurator,
        rockerColors: Array.isArray(settings.configurator.rockerColors)
          ? settings.configurator.rockerColors
          : [
              { id: 'col_blanco', name: 'Blanco', hex: '#FFFFFF', finish: 'glossy', priceAdjustment: 0, isActive: true },
              { id: 'col_caoba', name: 'Caoba', hex: '#4A1515', finish: 'satin', priceAdjustment: 0, isActive: true },
              { id: 'col_negro', name: 'Negro', hex: '#1C1C1C', finish: 'glossy', priceAdjustment: 0, isActive: true },
            ],
        fabrics: Array.isArray(settings.configurator.fabrics)
          ? settings.configurator.fabrics
          : [
              { id: 'fab_beige', name: 'Beige Arena (Lino)', colorHex: '#D8C7B5', fabricType: 'Lino', priceAdjustment: 0, isActive: true },
              { id: 'fab_gris', name: 'Gris Grafito (Lino)', colorHex: '#4A4E5A', fabricType: 'Lino', priceAdjustment: 0, isActive: true },
              { id: 'fab_terracota', name: 'Terracota Cálido (Lino)', colorHex: '#C3583C', fabricType: 'Lino', priceAdjustment: 0, isActive: true },
            ],
        accessories: Array.isArray(settings.configurator.accessories)
          ? settings.configurator.accessories
          : [
              { id: 'acc_lumbar', name: 'Cojín Lumbar Extra', description: 'Soporte ergonómico acolchado adicional', price: 950, isActive: true },
              { id: 'acc_waterproof', name: 'Protección Impermeabilizante', description: 'Tratamiento hidrófugo para exteriores', price: 600, isActive: true },
            ],
      };
    }
    return {
      enabled: true,
      defaultRockerColor: 'Blanco',
      defaultFabric: 'Beige Arena',
      allowNoCushion: true,
      noCushionDiscount: 1500,
      rockerColors: [
        { id: 'col_blanco', name: 'Blanco', hex: '#FFFFFF', finish: 'glossy', priceAdjustment: 0, isActive: true },
        { id: 'col_caoba', name: 'Caoba', hex: '#4A1515', finish: 'satin', priceAdjustment: 0, isActive: true },
        { id: 'col_negro', name: 'Negro', hex: '#1C1C1C', finish: 'glossy', priceAdjustment: 0, isActive: true },
      ],
      fabrics: [
        { id: 'fab_beige', name: 'Beige Arena (Lino)', colorHex: '#D8C7B5', fabricType: 'Lino', priceAdjustment: 0, isActive: true },
        { id: 'fab_gris', name: 'Gris Grafito (Lino)', colorHex: '#4A4E5A', fabricType: 'Lino', priceAdjustment: 0, isActive: true },
        { id: 'fab_terracota', name: 'Terracota Cálido (Lino)', colorHex: '#C3583C', fabricType: 'Lino', priceAdjustment: 0, isActive: true },
      ],
      accessories: [
        { id: 'acc_lumbar', name: 'Cojín Lumbar Extra', description: 'Soporte ergonómico acolchado adicional', price: 950, isActive: true },
        { id: 'acc_waterproof', name: 'Protección Impermeabilizante', description: 'Tratamiento hidrófugo para exteriores', price: 600, isActive: true },
      ]
    };
  });

  const [activeSubTab, setActiveSubTab] = useState<'colors' | 'fabrics' | 'accessories' | 'rules'>('colors');
  const [isSaving, setIsSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);

  // Live preview testing state
  const [previewColor, setPreviewColor] = useState<CustomizerColorOption>(config.rockerColors[0] || {
    id: 'col_blanco', name: 'Blanco', hex: '#FFFFFF', finish: 'glossy', priceAdjustment: 0, isActive: true
  });
  const [previewFabric, setPreviewFabric] = useState<CustomizerFabricOption | undefined>(config.fabrics[0]);
  const [previewHasCushion, setPreviewHasCushion] = useState(true);

  // New item modal or forms
  const [editingColor, setEditingColor] = useState<CustomizerColorOption | null>(null);
  const [editingFabric, setEditingFabric] = useState<CustomizerFabricOption | null>(null);
  const [editingAccessory, setEditingAccessory] = useState<CustomizerAccessoryOption | null>(null);

  const handleSaveAll = async () => {
    setIsSaving(true);
    try {
      const updatedSettings: StoreSettings = {
        ...settings,
        configurator: config,
      };
      await onSaveSettings(updatedSettings);
      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 4000);
    } catch (err: any) {
      alert('Error al guardar la configuración 3D: ' + err.message);
    } finally {
      setIsSaving(false);
    }
  };


  const persistConfigImmediately = async (nextConfig: ConfiguratorSettings, operation: string) => {
    try {
      await onSaveSettings({ ...settings, configurator: nextConfig });
      setConfig(nextConfig);
      onRefresh();
    } catch (err) {
      notifyError(operation, err);
      throw err;
    }
  };

  // Color handlers
  const handleSaveColor = (color: CustomizerColorOption) => {
    setConfig((prev) => {
      const exists = prev.rockerColors.some((c) => c.id === color.id);
      const updated = exists
        ? prev.rockerColors.map((c) => (c.id === color.id ? color : c))
        : [...prev.rockerColors, color];
      return { ...prev, rockerColors: updated };
    });
    setEditingColor(null);
  };

  const handleDeleteColor = async (id: string) => {
    if (config.rockerColors.length <= 1) {
      alert('Debe existir al menos un color para la mecedora.');
      return;
    }
    if (!window.confirm('¿Seguro que deseas eliminar este color?')) return;
    const next = { ...config, rockerColors: config.rockerColors.filter((c) => c.id !== id) };
    try { await persistConfigImmediately(next, 'No se pudo eliminar el color del configurador.'); } catch { /* error already reported */ }
  };

  // Fabric handlers
  const handleSaveFabric = (fabric: CustomizerFabricOption) => {
    setConfig((prev) => {
      const exists = prev.fabrics.some((f) => f.id === fabric.id);
      const updated = exists
        ? prev.fabrics.map((f) => (f.id === fabric.id ? fabric : f))
        : [...prev.fabrics, fabric];
      return { ...prev, fabrics: updated };
    });
    setEditingFabric(null);
  };

  const handleDeleteFabric = async (id: string) => {
    if (config.fabrics.length <= 1) {
      alert('Debe existir al menos una tela para los cojines.');
      return;
    }
    if (!window.confirm('¿Seguro que deseas eliminar esta tela/textura?')) return;
    const next = { ...config, fabrics: config.fabrics.filter((f) => f.id !== id) };
    try { await persistConfigImmediately(next, 'No se pudo eliminar la tela/textura del configurador.'); } catch { /* error already reported */ }
  };

  // Accessory handlers
  const handleSaveAccessory = (acc: CustomizerAccessoryOption) => {
    setConfig((prev) => {
      const exists = prev.accessories.some((a) => a.id === acc.id);
      const updated = exists
        ? prev.accessories.map((a) => (a.id === acc.id ? acc : a))
        : [...prev.accessories, acc];
      return { ...prev, accessories: updated };
    });
    setEditingAccessory(null);
  };

  const handleDeleteAccessory = async (id: string) => {
    if (!window.confirm('¿Seguro que deseas eliminar este accesorio?')) return;
    const next = { ...config, accessories: config.accessories.filter((a) => a.id !== id) };
    try { await persistConfigImmediately(next, 'No se pudo eliminar el accesorio del configurador.'); } catch { /* error already reported */ }
  };

  // Texture image upload via compressImageFile & Cloud Storage
  const handleTextureUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !editingFabric) return;

    if (!['image/jpeg', 'image/png', 'image/webp'].includes(file.type)) {
      alert('Formato no soportado. Por favor sube archivos JPG, PNG o WebP.');
      return;
    }

    try {
      const compressed = await compressImageFile(file, { maxWidth: 1000, maxHeight: 1000, quality: 0.85 });
      const finalUrl = await uploadToFirebaseStorage(compressed, 'configurador-texturas');
      if (!finalUrl) throw new Error('Firebase Storage no devolvió una URL permanente para la textura.');
      setEditingFabric((prev) => (prev ? { ...prev, textureUrl: finalUrl } : null));
    } catch (err: any) {
      console.error('Error comprimiendo textura:', err);
      alert('Error procesando imagen de textura: ' + (err.message || err));
    }
  };

  // 3D Model file upload via Cloud Storage
  const handle3DModelUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (event) => {
      const base64 = event.target?.result as string;
      if (base64) {
        let finalUrl = base64;
        try {
          const url = await uploadToFirebaseStorage(base64, 'modelos-3d');
          if (url) finalUrl = url;
        } catch (err) {
          console.warn('Firebase Storage upload failed for 3D model, falling back to server:', err);
          try {
            const urls = await uploadImagesToServer([base64]);
            if (urls[0]) finalUrl = urls[0];
          } catch {
            // fallback
          }
        }
        setConfig((prev) => ({ ...prev, customModel3DUrl: finalUrl }));
        alert('¡Modelo 3D cargado y guardado con éxito!');
      }
    };
    reader.readAsDataURL(file);
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="p-6 rounded-2xl bg-gradient-to-r from-[#2C1810] to-[#5C3826] text-white shadow-lg flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full bg-amber-400 text-stone-950 font-bold text-xs">
              ESTUDIO 3D VIRTUAL
            </span>
            <span className="text-xs text-stone-300">Personalización en tiempo real</span>
          </div>
          <h2 className="text-xl font-bold font-serif mt-1">Configurador de Mecedoras y Cojines</h2>
          <p className="text-xs text-stone-300 max-w-xl mt-1">
            Administra los colores de fibra de vidrio (Blanco, Caoba, Negro y nuevos tonos), sube texturas de telas (JPG, PNG, WebP), define reglas de precios y carga modelos 3D sin escribir código.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={handleSaveAll}
            disabled={isSaving}
            className="px-5 py-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-stone-950 font-bold text-xs sm:text-sm transition-all shadow-md flex items-center gap-2 active:scale-95 disabled:opacity-60 cursor-pointer"
          >
            {isSaving ? (
              <RefreshCw className="w-4 h-4 animate-spin" />
            ) : saveSuccess ? (
              <CheckCircle2 className="w-4 h-4 text-stone-950" />
            ) : (
              <Save className="w-4 h-4" />
            )}
            <span>{saveSuccess ? '¡Guardado en Firebase!' : 'Guardar Cambios 3D'}</span>
          </button>
        </div>
      </div>

      {saveSuccess && (
        <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-semibold flex items-center gap-2 animate-fadeIn">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>La configuración 3D ha sido sincronizada exitosamente con la base de datos Firestore.</span>
        </div>
      )}

      {/* Main Grid: 3D Preview on Right, Configuration on Left */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* LEFT COLUMN: Controls & Management */}
        <div className="lg:col-span-7 space-y-6">
          
          {/* Sub Navigation Tabs */}
          <div className="flex items-center gap-2 bg-stone-100 p-1.5 rounded-xl border border-stone-200 overflow-x-auto">
            <button
              onClick={() => setActiveSubTab('colors')}
              className={`px-3.5 py-2 rounded-lg text-xs font-bold transition-all shrink-0 flex items-center gap-1.5 ${
                activeSubTab === 'colors' ? 'bg-white text-[#2C1810] shadow-xs' : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              <Palette className="w-3.5 h-3.5 text-[#8a532b]" />
              <span>Colores Fibra ({config.rockerColors.length})</span>
            </button>

            <button
              onClick={() => setActiveSubTab('fabrics')}
              className={`px-3.5 py-2 rounded-lg text-xs font-bold transition-all shrink-0 flex items-center gap-1.5 ${
                activeSubTab === 'fabrics' ? 'bg-white text-[#2C1810] shadow-xs' : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              <Layers className="w-3.5 h-3.5 text-[#8a532b]" />
              <span>Telas & Texturas ({config.fabrics.length})</span>
            </button>

            <button
              onClick={() => setActiveSubTab('accessories')}
              className={`px-3.5 py-2 rounded-lg text-xs font-bold transition-all shrink-0 flex items-center gap-1.5 ${
                activeSubTab === 'accessories' ? 'bg-white text-[#2C1810] shadow-xs' : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              <Shield className="w-3.5 h-3.5 text-[#8a532b]" />
              <span>Accesorios ({config.accessories.length})</span>
            </button>

            <button
              onClick={() => setActiveSubTab('rules')}
              className={`px-3.5 py-2 rounded-lg text-xs font-bold transition-all shrink-0 flex items-center gap-1.5 ${
                activeSubTab === 'rules' ? 'bg-white text-[#2C1810] shadow-xs' : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              <Sliders className="w-3.5 h-3.5 text-[#8a532b]" />
              <span>Opciones & Modelos 3D</span>
            </button>
          </div>

          {/* TAB 1: FIBERGLASS ROCKER COLORS */}
          {activeSubTab === 'colors' && (
            <div className="bg-white p-5 rounded-2xl border border-stone-200 space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold text-[#2C1810] font-serif">Colores de Fibra de Vidrio</h3>
                  <p className="text-xs text-stone-500">Colores iniciales: Blanco, Caoba y Negro. Puedes crear más colores con acabados y recargos.</p>
                </div>
                <button
                  type="button"
                  onClick={() => setEditingColor({
                    id: `col_${Date.now()}`,
                    name: '',
                    hex: '#5C3826',
                    finish: 'glossy',
                    priceAdjustment: 0,
                    isActive: true,
                  })}
                  className="px-3 py-1.5 rounded-lg bg-[#8a532b] hover:bg-[#6e4121] text-white text-xs font-bold transition-all flex items-center gap-1 shadow-xs cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Nuevo Color</span>
                </button>
              </div>

              {/* Color List */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {config.rockerColors.map((col) => (
                  <div
                    key={col.id}
                    className={`p-3 rounded-xl border flex items-center justify-between transition-all ${
                      col.isActive ? 'border-stone-200 bg-white hover:border-[#8a532b]/50' : 'border-stone-200 bg-stone-50 opacity-60'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div
                        className="w-8 h-8 rounded-full border border-black/15 shadow-inner shrink-0"
                        style={{ backgroundColor: col.hex }}
                      />
                      <div>
                        <div className="text-xs font-bold text-stone-800 flex items-center gap-1.5">
                          <span>{col.name}</span>
                          <span className="text-[10px] uppercase px-1.5 py-0.2 rounded-md bg-stone-100 text-stone-600 font-semibold">
                            {col.finish}
                          </span>
                        </div>
                        <div className="text-[11px] text-stone-500 font-mono">
                          {col.hex} {col.priceAdjustment ? `(+${formatPrice(col.priceAdjustment, settings.currency)})` : ''}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-1">
                      <button
                        type="button"
                        onClick={() => {
                          setPreviewColor(col);
                        }}
                        title="Probar en el visor 3D"
                        className="p-1.5 rounded-lg hover:bg-stone-100 text-stone-600 text-[11px] font-bold"
                      >
                        <Eye className="w-3.5 h-3.5 text-[#8a532b]" />
                      </button>
                      <button
                        type="button"
                        onClick={() => setEditingColor(col)}
                        title="Editar color"
                        className="p-1.5 rounded-lg hover:bg-stone-100 text-stone-600"
                      >
                        <Edit3 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() => handleDeleteColor(col.id)}
                        title="Eliminar"
                        className="p-1.5 rounded-lg hover:bg-red-50 text-red-600"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 2: CUSHION FABRICS & TEXTURES */}
          {activeSubTab === 'fabrics' && (
            <div className="bg-white p-5 rounded-2xl border border-stone-200 space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold text-[#2C1810] font-serif">Telas y Texturas para Cojines</h3>
                  <p className="text-xs text-stone-500">Sube imágenes de textura (JPG, PNG, WebP) o define colores base para aplicarse al modelo 3D en tiempo real.</p>
                </div>
                <button
                  type="button"
                  onClick={() => setEditingFabric({
                    id: `fab_${Date.now()}`,
                    name: '',
                    colorHex: '#C5A880',
                    fabricType: 'Lino',
                    priceAdjustment: 0,
                    isActive: true,
                  })}
                  className="px-3 py-1.5 rounded-lg bg-[#8a532b] hover:bg-[#6e4121] text-white text-xs font-bold transition-all flex items-center gap-1 shadow-xs cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Nueva Tela / Textura</span>
                </button>
              </div>

              {/* Fabrics List */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {config.fabrics.map((fab) => (
                  <div
                    key={fab.id}
                    className={`p-3 rounded-xl border flex items-center justify-between transition-all ${
                      fab.isActive ? 'border-stone-200 bg-white hover:border-[#8a532b]/50' : 'border-stone-200 bg-stone-50 opacity-60'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      {fab.textureUrl ? (
                        <img
                          src={fab.textureUrl}
                          alt={fab.name}
                          className="w-9 h-9 rounded-xl object-cover border border-black/15 shadow-inner shrink-0"
                        />
                      ) : (
                        <div
                          className="w-9 h-9 rounded-xl border border-black/15 shadow-inner shrink-0"
                          style={{ backgroundColor: fab.colorHex }}
                        />
                      )}
                      <div>
                        <div className="text-xs font-bold text-stone-800 flex items-center gap-1">
                          <span>{fab.name}</span>
                        </div>
                        <div className="text-[11px] text-stone-500">
                          {fab.fabricType} {fab.priceAdjustment ? `(+${formatPrice(fab.priceAdjustment, settings.currency)})` : '(Incluido)'}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-1">
                      <button
                        type="button"
                        onClick={() => {
                          setPreviewFabric(fab);
                          setPreviewHasCushion(true);
                        }}
                        title="Probar en el visor 3D"
                        className="p-1.5 rounded-lg hover:bg-stone-100 text-stone-600 text-[11px] font-bold"
                      >
                        <Eye className="w-3.5 h-3.5 text-[#8a532b]" />
                      </button>
                      <button
                        type="button"
                        onClick={() => setEditingFabric(fab)}
                        title="Editar tela"
                        className="p-1.5 rounded-lg hover:bg-stone-100 text-stone-600"
                      >
                        <Edit3 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() => handleDeleteFabric(fab.id)}
                        title="Eliminar"
                        className="p-1.5 rounded-lg hover:bg-red-50 text-red-600"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 3: ACCESSORIES & UPGRADES */}
          {activeSubTab === 'accessories' && (
            <div className="bg-white p-5 rounded-2xl border border-stone-200 space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold text-[#2C1810] font-serif">Accesorios y Extras Opcionales</h3>
                  <p className="text-xs text-stone-500">Permite al cliente agregar complementos con precios automáticos calculados al instante.</p>
                </div>
                <button
                  type="button"
                  onClick={() => setEditingAccessory({
                    id: `acc_${Date.now()}`,
                    name: '',
                    description: '',
                    price: 500,
                    isActive: true,
                  })}
                  className="px-3 py-1.5 rounded-lg bg-[#8a532b] hover:bg-[#6e4121] text-white text-xs font-bold transition-all flex items-center gap-1 shadow-xs cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Nuevo Accesorio</span>
                </button>
              </div>

              {/* Accessory List */}
              <div className="space-y-2">
                {config.accessories.map((acc) => (
                  <div
                    key={acc.id}
                    className="p-3.5 rounded-xl border border-stone-200 bg-white flex items-center justify-between"
                  >
                    <div>
                      <div className="text-xs font-bold text-stone-800">{acc.name}</div>
                      <div className="text-[11px] text-stone-500">{acc.description}</div>
                      <div className="text-xs font-extrabold text-[#8a532b] mt-0.5">
                        +{formatPrice(acc.price, settings.currency)}
                      </div>
                    </div>

                    <div className="flex items-center gap-1">
                      <button
                        type="button"
                        onClick={() => setEditingAccessory(acc)}
                        className="p-1.5 rounded-lg hover:bg-stone-100 text-stone-600"
                      >
                        <Edit3 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() => handleDeleteAccessory(acc.id)}
                        className="p-1.5 rounded-lg hover:bg-red-50 text-red-600"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 4: GENERAL 3D SETTINGS & MODEL UPLOAD */}
          {activeSubTab === 'rules' && (
            <div className="bg-white p-5 rounded-2xl border border-stone-200 space-y-5">
              <h3 className="text-sm font-bold text-[#2C1810] font-serif">Reglas del Configurador & Carga de Modelo 3D</h3>

              <div className="space-y-4 text-xs">
                {/* Enable / Disable */}
                <div className="flex items-center justify-between p-3 rounded-xl bg-stone-50 border border-stone-200">
                  <div>
                    <strong className="block text-stone-800">Activar Configurador 3D en la tienda</strong>
                    <span className="text-stone-500">Muestra la opción "Personalizar este modelo" debajo de las fotos</span>
                  </div>
                  <input
                    type="checkbox"
                    checked={config.enabled}
                    onChange={(e) => setConfig((prev) => ({ ...prev, enabled: e.target.checked }))}
                    className="w-5 h-5 accent-[#8a532b] rounded cursor-pointer"
                  />
                </div>

                {/* Allow No Cushion & Discount */}
                <div className="p-3.5 rounded-xl bg-stone-50 border border-stone-200 space-y-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <strong className="block text-stone-800">Permitir opción "Sin Cojines"</strong>
                      <span className="text-stone-500">Aplica un descuento si el cliente desea solo la estructura de fibra</span>
                    </div>
                    <input
                      type="checkbox"
                      checked={config.allowNoCushion}
                      onChange={(e) => setConfig((prev) => ({ ...prev, allowNoCushion: e.target.checked }))}
                      className="w-5 h-5 accent-[#8a532b] rounded cursor-pointer"
                    />
                  </div>

                  {config.allowNoCushion && (
                    <div className="pt-2 border-t border-stone-200 flex items-center justify-between">
                      <label className="text-stone-700 font-semibold">Descuento sin cojines (RD$):</label>
                      <input
                        type="number"
                        value={config.noCushionDiscount}
                        onChange={(e) => setConfig((prev) => ({ ...prev, noCushionDiscount: Number(e.target.value) || 0 }))}
                        className="w-32 p-2 bg-white border border-stone-300 rounded-lg text-right font-bold text-stone-800"
                      />
                    </div>
                  )}
                </div>

                {/* Upload Custom 3D Model (.glb / .gltf) */}
                <div className="p-3.5 rounded-xl bg-stone-50 border border-stone-200 space-y-3">
                  <div>
                    <strong className="block text-stone-800">Cargar Archivo de Modelo 3D Personalizado (.glb / .gltf)</strong>
                    <span className="text-stone-500">Puedes cargar un modelo 3D GLB/GLTF para reemplazar la geometría procedural</span>
                  </div>

                  <div className="flex flex-col sm:flex-row gap-2">
                    <label className="flex-1 px-4 py-2.5 rounded-xl bg-white border border-stone-300 hover:border-[#8a532b] text-stone-700 font-semibold cursor-pointer text-center flex items-center justify-center gap-2">
                      <Upload className="w-4 h-4 text-[#8a532b]" />
                      <span>Subir archivo .GLB / .GLTF</span>
                      <input
                        type="file"
                        accept=".glb,.gltf"
                        onChange={handle3DModelUpload}
                        className="hidden"
                      />
                    </label>

                    <input
                      type="text"
                      placeholder="O pega una URL de modelo 3D (.glb)"
                      value={config.customModel3DUrl || ''}
                      onChange={(e) => setConfig((prev) => ({ ...prev, customModel3DUrl: e.target.value }))}
                      className="flex-1 p-2 bg-white border border-stone-300 rounded-lg text-xs"
                    />
                  </div>
                </div>

              </div>
            </div>
          )}

        </div>

        {/* RIGHT COLUMN: Live 3D Preview Inspector */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-sm space-y-3">
            <div className="flex items-center justify-between border-b border-stone-100 pb-2">
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-[#8a532b]" />
                <h3 className="text-xs font-bold uppercase tracking-wider text-stone-800">Previsualizador 2D en Vivo</h3>
              </div>
              <span className="text-[10px] bg-emerald-100 text-emerald-800 font-bold px-2 py-0.5 rounded-full">
                Vista Foto Activa
              </span>
            </div>

            {/* 2D Container */}
            <div className="h-64 sm:h-72 w-full rounded-xl overflow-hidden bg-[#EAE5DF] relative border border-stone-200">
              <Cushion2DViewer
                mainFabric={{
                  id: previewFabric?.id || 'fab-1',
                  name: previewFabric?.name || 'Blanco Crema',
                  hex: previewFabric?.hex || '#F3EFE6',
                  type: 'terciopelo'
                }}
                trimColor={{
                  id: previewColor.id,
                  name: previewColor.name,
                  hex: previewColor.hex,
                }}
                fabricType="terciopelo"
              />
            </div>

            {/* Quick Testing Bar */}
            <div className="space-y-2 pt-1 text-xs">
              <div className="flex items-center justify-between text-stone-600">
                <span>Color Fibra Seleccionado:</span>
                <strong className="text-stone-900">{previewColor.name}</strong>
              </div>
              <div className="flex items-center justify-between text-stone-600">
                <span>Tela Cojín Seleccionada:</span>
                <strong className="text-stone-900">{previewHasCushion && previewFabric ? previewFabric.name : 'Sin cojines'}</strong>
              </div>

              <div className="flex items-center gap-2 pt-2 border-t border-stone-100">
                <button
                  type="button"
                  onClick={() => setPreviewHasCushion(!previewHasCushion)}
                  className="flex-1 py-1.5 px-2 rounded-lg bg-stone-100 hover:bg-stone-200 text-stone-800 font-semibold text-[11px] text-center"
                >
                  {previewHasCushion ? 'Ver sin cojines' : 'Ver con cojines'}
                </button>
              </div>
            </div>
          </div>
        </div>

      </div>

      {/* COLOR EDIT MODAL */}
      {editingColor && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-5 space-y-4 shadow-2xl border border-stone-200">
            <h3 className="text-sm font-bold font-serif text-[#2C1810]">
              {editingColor.name ? `Editar Color: ${editingColor.name}` : 'Crear Nuevo Color de Fibra'}
            </h3>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold text-stone-700 mb-1">Nombre del Color:</label>
                <input
                  type="text"
                  placeholder="Ej: Caoba Real, Blanco Nieve, Negro Mate..."
                  value={editingColor.name}
                  onChange={(e) => setEditingColor({ ...editingColor, name: e.target.value })}
                  className="w-full p-2.5 bg-stone-50 border border-stone-300 rounded-xl"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-stone-700 mb-1">Color Hexadecimal:</label>
                  <div className="flex items-center gap-2">
                    <input
                      type="color"
                      value={editingColor.hex}
                      onChange={(e) => setEditingColor({ ...editingColor, hex: e.target.value })}
                      className="w-10 h-10 rounded-lg cursor-pointer border border-stone-300 p-0.5"
                    />
                    <input
                      type="text"
                      value={editingColor.hex}
                      onChange={(e) => setEditingColor({ ...editingColor, hex: e.target.value })}
                      className="w-full p-2 bg-stone-50 border border-stone-300 rounded-lg font-mono"
                    />
                  </div>
                </div>

                <div>
                  <label className="block font-semibold text-stone-700 mb-1">Acabado:</label>
                  <select
                    value={editingColor.finish}
                    onChange={(e) => setEditingColor({ ...editingColor, finish: e.target.value as any })}
                    className="w-full p-2.5 bg-stone-50 border border-stone-300 rounded-xl"
                  >
                    <option value="glossy">Brillante (Glossy)</option>
                    <option value="satin">Satinado (Satin)</option>
                    <option value="matte">Mate (Matte)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-stone-700 mb-1">Recargo de Precio (RD$):</label>
                <input
                  type="number"
                  placeholder="0"
                  value={editingColor.priceAdjustment || 0}
                  onChange={(e) => setEditingColor({ ...editingColor, priceAdjustment: Number(e.target.value) || 0 })}
                  className="w-full p-2.5 bg-stone-50 border border-stone-300 rounded-xl"
                />
              </div>

              <div className="flex items-center gap-2 pt-1">
                <input
                  type="checkbox"
                  id="color-active"
                  checked={editingColor.isActive}
                  onChange={(e) => setEditingColor({ ...editingColor, isActive: e.target.checked })}
                  className="w-4 h-4 accent-[#8a532b] rounded cursor-pointer"
                />
                <label htmlFor="color-active" className="text-stone-700 font-semibold cursor-pointer">
                  Color activo y visible en el configurador
                </label>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-stone-100">
              <button
                type="button"
                onClick={() => setEditingColor(null)}
                className="px-4 py-2 rounded-xl text-stone-600 hover:bg-stone-100 text-xs font-bold"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={() => {
                  if (!editingColor.name.trim()) {
                    alert('Introduce un nombre para el color');
                    return;
                  }
                  handleSaveColor(editingColor);
                }}
                className="px-4 py-2 rounded-xl bg-[#8a532b] hover:bg-[#6e4121] text-white text-xs font-bold shadow-xs"
              >
                Guardar Color
              </button>
            </div>
          </div>
        </div>
      )}

      {/* FABRIC EDIT MODAL */}
      {editingFabric && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-5 space-y-4 shadow-2xl border border-stone-200">
            <h3 className="text-sm font-bold font-serif text-[#2C1810]">
              {editingFabric.name ? `Editar Tela: ${editingFabric.name}` : 'Crear Nueva Tela / Textura'}
            </h3>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold text-stone-700 mb-1">Nombre de la Tela:</label>
                <input
                  type="text"
                  placeholder="Ej: Lino Arena, Chenille Mostaza, Impermeable Hojas..."
                  value={editingFabric.name}
                  onChange={(e) => setEditingFabric({ ...editingFabric, name: e.target.value })}
                  className="w-full p-2.5 bg-stone-50 border border-stone-300 rounded-xl"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-stone-700 mb-1">Color Base (Hex):</label>
                  <div className="flex items-center gap-2">
                    <input
                      type="color"
                      value={editingFabric.colorHex}
                      onChange={(e) => setEditingFabric({ ...editingFabric, colorHex: e.target.value })}
                      className="w-10 h-10 rounded-lg cursor-pointer border border-stone-300 p-0.5"
                    />
                    <input
                      type="text"
                      value={editingFabric.colorHex}
                      onChange={(e) => setEditingFabric({ ...editingFabric, colorHex: e.target.value })}
                      className="w-full p-2 bg-stone-50 border border-stone-300 rounded-lg font-mono"
                    />
                  </div>
                </div>

                <div>
                  <label className="block font-semibold text-stone-700 mb-1">Tipo de Tejido:</label>
                  <input
                    type="text"
                    placeholder="Lino, Chenille, Exterior..."
                    value={editingFabric.fabricType || 'Lino'}
                    onChange={(e) => setEditingFabric({ ...editingFabric, fabricType: e.target.value })}
                    className="w-full p-2.5 bg-stone-50 border border-stone-300 rounded-xl"
                  />
                </div>
              </div>

              {/* Texture Image Upload (JPG, PNG, WebP) */}
              <div className="p-3 bg-stone-50 rounded-xl border border-stone-200 space-y-2">
                <label className="block font-semibold text-stone-700">Subir Textura Real (JPG, PNG, WebP):</label>
                <input
                  type="file"
                  accept="image/jpeg,image/png,image/webp"
                  onChange={handleTextureUpload}
                  className="text-xs text-stone-500 file:mr-3 file:py-1.5 file:px-3 file:rounded-lg file:border-0 file:text-xs file:font-semibold file:bg-[#8a532b] file:text-white hover:file:bg-[#6e4121] cursor-pointer"
                />
                {editingFabric.textureUrl && (
                  <div className="flex items-center gap-2 pt-1">
                    <img src={editingFabric.textureUrl} alt="Preview" className="w-10 h-10 rounded-lg object-cover border border-stone-300" />
                    <span className="text-[11px] text-emerald-700 font-semibold">Textura cargada correctamente</span>
                  </div>
                )}
              </div>

              <div>
                <label className="block font-semibold text-stone-700 mb-1">Recargo de Precio (RD$):</label>
                <input
                  type="number"
                  placeholder="0"
                  value={editingFabric.priceAdjustment || 0}
                  onChange={(e) => setEditingFabric({ ...editingFabric, priceAdjustment: Number(e.target.value) || 0 })}
                  className="w-full p-2.5 bg-stone-50 border border-stone-300 rounded-xl"
                />
              </div>

              <div className="flex items-center gap-2 pt-1">
                <input
                  type="checkbox"
                  id="fabric-active"
                  checked={editingFabric.isActive}
                  onChange={(e) => setEditingFabric({ ...editingFabric, isActive: e.target.checked })}
                  className="w-4 h-4 accent-[#8a532b] rounded cursor-pointer"
                />
                <label htmlFor="fabric-active" className="text-stone-700 font-semibold cursor-pointer">
                  Tela activa y visible para selección
                </label>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-stone-100">
              <button
                type="button"
                onClick={() => setEditingFabric(null)}
                className="px-4 py-2 rounded-xl text-stone-600 hover:bg-stone-100 text-xs font-bold"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={() => {
                  if (!editingFabric.name.trim()) {
                    alert('Introduce un nombre para la tela');
                    return;
                  }
                  handleSaveFabric(editingFabric);
                }}
                className="px-4 py-2 rounded-xl bg-[#8a532b] hover:bg-[#6e4121] text-white text-xs font-bold shadow-xs"
              >
                Guardar Tela
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ACCESSORY EDIT MODAL */}
      {editingAccessory && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-5 space-y-4 shadow-2xl border border-stone-200">
            <h3 className="text-sm font-bold font-serif text-[#2C1810]">
              {editingAccessory.name ? `Editar Accesorio: ${editingAccessory.name}` : 'Crear Nuevo Accesorio'}
            </h3>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold text-stone-700 mb-1">Nombre del Accesorio:</label>
                <input
                  type="text"
                  placeholder="Ej: Cojín Lumbar, Patines de Silicona..."
                  value={editingAccessory.name}
                  onChange={(e) => setEditingAccessory({ ...editingAccessory, name: e.target.value })}
                  className="w-full p-2.5 bg-stone-50 border border-stone-300 rounded-xl"
                />
              </div>

              <div>
                <label className="block font-semibold text-stone-700 mb-1">Descripción Breve:</label>
                <input
                  type="text"
                  placeholder="Ej: Proporciona confort adicional y soporte..."
                  value={editingAccessory.description || ''}
                  onChange={(e) => setEditingAccessory({ ...editingAccessory, description: e.target.value })}
                  className="w-full p-2.5 bg-stone-50 border border-stone-300 rounded-xl"
                />
              </div>

              <div>
                <label className="block font-semibold text-stone-700 mb-1">Precio Adicional (RD$):</label>
                <input
                  type="number"
                  placeholder="0"
                  value={editingAccessory.price || 0}
                  onChange={(e) => setEditingAccessory({ ...editingAccessory, price: Number(e.target.value) || 0 })}
                  className="w-full p-2.5 bg-stone-50 border border-stone-300 rounded-xl"
                />
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-stone-100">
              <button
                type="button"
                onClick={() => setEditingAccessory(null)}
                className="px-4 py-2 rounded-xl text-stone-600 hover:bg-stone-100 text-xs font-bold"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={() => {
                  if (!editingAccessory.name.trim()) {
                    alert('Introduce un nombre para el accesorio');
                    return;
                  }
                  handleSaveAccessory(editingAccessory);
                }}
                className="px-4 py-2 rounded-xl bg-[#8a532b] hover:bg-[#6e4121] text-white text-xs font-bold shadow-xs"
              >
                Guardar Accesorio
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
