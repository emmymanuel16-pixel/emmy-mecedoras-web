import React, { useState } from 'react';
import { 
  Star, CheckCircle2, ThumbsUp, MessageSquare, 
  Send, ShieldCheck, UserCheck, AlertCircle, CornerDownRight 
} from 'lucide-react';
import { Product, Review } from '../types';
import { api } from '../services/api';
import confetti from 'canvas-confetti';

interface ReviewsSectionProps {
  product: Product;
  reviews: Review[];
  onReviewAdded: (newReview: Review) => void;
}

export const ReviewsSection: React.FC<ReviewsSectionProps> = ({
  product,
  reviews,
  onReviewAdded,
}) => {
  const [showForm, setShowForm] = useState(false);
  const [selectedStarFilter, setSelectedStarFilter] = useState<number | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [submitSuccess, setSubmitSuccess] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  // Form State
  const [rating, setRating] = useState<number>(5);
  const [hoverRating, setHoverRating] = useState<number>(0);
  const [userName, setUserName] = useState('');
  const [userEmail, setUserEmail] = useState('');
  const [isVerifiedBuyer, setIsVerifiedBuyer] = useState(true);
  const [orderNumber, setOrderNumber] = useState('');
  const [title, setTitle] = useState('');
  const [comment, setComment] = useState('');
  const [votedHelpfulIds, setVotedHelpfulIds] = useState<{ [id: string]: boolean }>({});

  // Product reviews
  const productReviews = reviews.filter(
    (r) => r.productId === product.id && (r.status === 'approved' || !r.status)
  );

  // Filtered by star
  const displayedReviews = selectedStarFilter
    ? productReviews.filter((r) => r.rating === selectedStarFilter)
    : productReviews;

  // Calculate statistics
  const totalReviews = productReviews.length;
  const avgRating = totalReviews > 0
    ? (productReviews.reduce((sum, r) => sum + r.rating, 0) / totalReviews).toFixed(1)
    : product.rating?.toFixed(1) || '5.0';

  const starCounts = [5, 4, 3, 2, 1].map((star) => ({
    star,
    count: productReviews.filter((r) => r.rating === star).length,
    percentage: totalReviews > 0
      ? Math.round((productReviews.filter((r) => r.rating === star).length / totalReviews) * 100)
      : 0,
  }));

  const verifiedBuyersCount = productReviews.filter((r) => r.isVerifiedBuyer).length;
  const recommendedPercent = totalReviews > 0
    ? Math.round((productReviews.filter((r) => r.rating >= 4).length / totalReviews) * 100)
    : 100;

  const handleHelpfulClick = async (reviewId: string) => {
    if (votedHelpfulIds[reviewId]) return;
    setVotedHelpfulIds((prev) => ({ ...prev, [reviewId]: true }));
    try {
      await api.markReviewHelpful(reviewId);
    } catch (e) {
      console.warn('Failed to submit helpful vote:', e);
    }
  };

  const handleSubmitReview = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!userName.trim() || !comment.trim()) {
      setErrorMessage('Por favor completa tu nombre y tu comentario sobre el producto.');
      return;
    }

    setSubmitting(true);
    setErrorMessage('');

    try {
      const created = await api.createReview({
        productId: product.id,
        productName: product.name,
        userName: userName.trim(),
        userEmail: userEmail.trim() || undefined,
        rating,
        title: title.trim() || undefined,
        comment: comment.trim(),
        isVerifiedBuyer,
        orderNumber: orderNumber.trim() || (isVerifiedBuyer ? '#DM-' + Math.floor(1000 + Math.random() * 9000) : undefined),
      });

      onReviewAdded(created);

      // Celebration
      confetti({
        particleCount: 50,
        spread: 70,
        origin: { y: 0.7 },
        colors: ['#8a532b', '#25D366', '#d4af37'],
      });

      setSubmitSuccess(true);
      setShowForm(false);
      // Reset fields
      setTitle('');
      setComment('');
      setOrderNumber('');
      setTimeout(() => setSubmitSuccess(false), 4000);
    } catch (err: any) {
      setErrorMessage(err.message || 'Ocurrió un error al registrar la reseña.');
    } finally {
      setSubmitting(false);
    }
  };

  const getRatingLabel = (stars: number) => {
    switch (stars) {
      case 5: return 'Excelente - ¡Superó mis expectativas!';
      case 4: return 'Muy bueno - Cumplió con lo esperado';
      case 3: return 'Bueno - Buen producto';
      case 2: return 'Regular - Puede mejorar';
      case 1: return 'Malo - No lo recomiendo';
      default: return '';
    }
  };

  return (
    <div className="space-y-6 pt-4 border-t border-[#E8E2DC] text-[#2C1810]">
      
      {/* SECTION HEADER & SUMMARY */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h3 className="font-serif font-bold text-base sm:text-lg text-[#2C1810] flex items-center gap-2">
            <MessageSquare className="w-5 h-5 text-[#8a532b]" />
            <span>Calificaciones y Reseñas de Clientes</span>
          </h3>
          <p className="text-xs text-[#7A6A60]">
            Opiniones de compradores verificados sobre la calidad, madera y acabado de este modelo.
          </p>
        </div>

        <button
          onClick={() => setShowForm(!showForm)}
          className="py-2 px-4 rounded-xl bg-[#8a532b] hover:bg-[#724322] text-[#FDFCFB] text-xs font-bold transition-all shadow-xs flex items-center justify-center gap-1.5 self-start sm:self-auto cursor-pointer"
        >
          <Star className="w-3.5 h-3.5 fill-current" />
          <span>{showForm ? 'Cerrar formulario' : 'Escribir una Reseña'}</span>
        </button>
      </div>

      {/* SUCCESS BANNER */}
      {submitSuccess && (
        <div className="p-3.5 rounded-xl bg-emerald-50 border border-emerald-300 text-emerald-900 text-xs font-semibold flex items-center gap-2 animate-fadeIn">
          <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
          <span>¡Muchas gracias por tu reseña! Ha sido publicada exitosamente en el catálogo.</span>
        </div>
      )}

      {/* WRITE REVIEW FORM COLLAPSIBLE */}
      {showForm && (
        <form
          onSubmit={handleSubmitReview}
          className="p-5 rounded-2xl bg-[#FDFCFB] border border-[#D6CCC2] shadow-xs space-y-4 animate-fadeIn"
        >
          <div className="flex items-center justify-between pb-2 border-b border-[#E8E2DC]">
            <h4 className="font-serif font-bold text-sm text-[#2C1810]">
              Deja tu opinión sobre: <span className="text-[#8a532b]">{product.name}</span>
            </h4>
            <span className="text-[11px] text-[#8C7A70]">* Campos obligatorios</span>
          </div>

          {errorMessage && (
            <div className="p-2.5 rounded-xl bg-red-50 border border-red-200 text-red-800 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-red-600 shrink-0" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* Star Selection */}
          <div className="space-y-1.5">
            <label className="block text-xs font-bold text-[#2C1810]">
              Calificación general *
            </label>
            <div className="flex items-center gap-2">
              <div className="flex items-center gap-1">
                {[1, 2, 3, 4, 5].map((starVal) => {
                  const isFilled = (hoverRating || rating) >= starVal;
                  return (
                    <button
                      key={starVal}
                      type="button"
                      onMouseEnter={() => setHoverRating(starVal)}
                      onMouseLeave={() => setHoverRating(0)}
                      onClick={() => setRating(starVal)}
                      className="p-1 text-amber-400 hover:scale-110 transition-transform cursor-pointer"
                    >
                      <Star
                        className={`w-6 h-6 ${
                          isFilled ? 'fill-amber-400 text-amber-400' : 'text-[#D6CCC2]'
                        }`}
                      />
                    </button>
                  );
                })}
              </div>
              <span className="text-xs font-medium text-[#5C4033] italic">
                {getRatingLabel(hoverRating || rating)}
              </span>
            </div>
          </div>

          {/* User Details Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-[#2C1810] mb-1">
                Tu Nombre completo *
              </label>
              <input
                type="text"
                required
                value={userName}
                onChange={(e) => setUserName(e.target.value)}
                placeholder="Ej. Carmen Valenzuela"
                className="w-full px-3 py-2 rounded-xl border border-[#D6CCC2] bg-white text-xs text-[#2C1810] focus:border-[#8a532b] focus:outline-hidden"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#2C1810] mb-1">
                Correo Electrónico (opcional)
              </label>
              <input
                type="email"
                value={userEmail}
                onChange={(e) => setUserEmail(e.target.value)}
                placeholder="carmen@ejemplo.com"
                className="w-full px-3 py-2 rounded-xl border border-[#D6CCC2] bg-white text-xs text-[#2C1810] focus:border-[#8a532b] focus:outline-hidden"
              />
            </div>
          </div>

          {/* Verified Buyer Checkbox & Order ID */}
          <div className="p-3 rounded-xl bg-[#F0EBE6] border border-[#E8E2DC] space-y-2">
            <label className="flex items-center gap-2 cursor-pointer text-xs font-semibold text-[#2C1810]">
              <input
                type="checkbox"
                checked={isVerifiedBuyer}
                onChange={(e) => setIsVerifiedBuyer(e.target.checked)}
                className="w-4 h-4 rounded accent-[#8a532b]"
              />
              <span className="flex items-center gap-1.5 text-emerald-800">
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                Soy comprador verificado de Emmy Mecedoras
              </span>
            </label>

            {isVerifiedBuyer && (
              <div className="pt-1">
                <input
                  type="text"
                  value={orderNumber}
                  onChange={(e) => setOrderNumber(e.target.value)}
                  placeholder="Número de pedido o WhatsApp (Ej. #DM-2026-1042)"
                  className="w-full sm:w-80 px-3 py-1.5 rounded-lg border border-[#D6CCC2] bg-white text-xs text-[#2C1810] placeholder:text-[#9A8A80]"
                />
              </div>
            )}
          </div>

          {/* Title */}
          <div>
            <label className="block text-xs font-semibold text-[#2C1810] mb-1">
              Título de la reseña (opcional)
            </label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Ej. 'Excelente acabado y confort para nuestra sala'"
              className="w-full px-3 py-2 rounded-xl border border-[#D6CCC2] bg-white text-xs text-[#2C1810] focus:border-[#8a532b] focus:outline-hidden"
            />
          </div>

          {/* Comment */}
          <div>
            <label className="block text-xs font-semibold text-[#2C1810] mb-1">
              Tu experiencia detallada *
            </label>
            <textarea
              required
              rows={3}
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              placeholder="Cuéntanos sobre el balanceo, la calidad de la madera, la comodidad de los cojines o la entrega..."
              className="w-full px-3 py-2 rounded-xl border border-[#D6CCC2] bg-white text-xs text-[#2C1810] focus:border-[#8a532b] focus:outline-hidden"
            />
          </div>

          {/* Submit Actions */}
          <div className="flex items-center justify-end gap-2 pt-2 border-t border-[#E8E2DC]">
            <button
              type="button"
              onClick={() => setShowForm(false)}
              className="py-2 px-4 rounded-xl border border-[#D6CCC2] text-xs font-semibold text-[#2C1810] hover:bg-[#F0EBE6]"
            >
              Cancelar
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="py-2 px-5 rounded-xl bg-[#2C1810] hover:bg-[#3E2723] text-white text-xs font-bold flex items-center gap-1.5 shadow-md disabled:opacity-50 cursor-pointer"
            >
              <Send className="w-3.5 h-3.5" />
              <span>{submitting ? 'Publicando...' : 'Publicar Reseña'}</span>
            </button>
          </div>
        </form>
      )}

      {/* RATINGS SCORE CARD & DISTRIBUTION */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 p-4 sm:p-5 rounded-2xl bg-[#FDFCFB] border border-[#E8E2DC]">
        
        {/* Score Column */}
        <div className="flex flex-col items-center justify-center text-center p-2 border-b md:border-b-0 md:border-r border-[#E8E2DC]">
          <span className="text-4xl sm:text-5xl font-serif font-black text-[#2C1810]">
            {avgRating}
          </span>
          <div className="flex items-center gap-1 my-1.5 text-amber-400">
            {Array.from({ length: 5 }).map((_, i) => (
              <Star
                key={i}
                className={`w-4 h-4 ${
                  i < Math.round(Number(avgRating)) ? 'fill-amber-400' : 'text-[#D6CCC2]'
                }`}
              />
            ))}
          </div>
          <span className="text-xs font-semibold text-[#7A6A60]">
            Basado en {totalReviews} {totalReviews === 1 ? 'opinión' : 'opiniones'}
          </span>
          <div className="mt-2 text-[11px] font-bold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-200">
            ✓ {recommendedPercent}% lo recomiendan
          </div>
        </div>

        {/* Breakdown Bars */}
        <div className="md:col-span-2 space-y-1.5 flex flex-col justify-center">
          {starCounts.map(({ star, count, percentage }) => {
            const isFilterActive = selectedStarFilter === star;
            return (
              <button
                key={star}
                onClick={() => setSelectedStarFilter(isFilterActive ? null : star)}
                className={`w-full flex items-center gap-3 text-xs p-1 rounded-lg transition-colors text-left ${
                  isFilterActive ? 'bg-[#8a532b]/10 font-bold' : 'hover:bg-[#F0EBE6]'
                }`}
              >
                <span className="w-12 text-[#2C1810] font-semibold flex items-center gap-1">
                  {star} <Star className="w-3 h-3 fill-amber-400 text-amber-400 inline" />
                </span>
                <div className="flex-1 h-2 rounded-full bg-[#E8E2DC] overflow-hidden">
                  <div
                    className="h-full bg-[#8a532b] rounded-full transition-all duration-500"
                    style={{ width: `${percentage}%` }}
                  />
                </div>
                <span className="w-14 text-right text-[11px] text-[#7A6A60]">
                  {percentage}% ({count})
                </span>
              </button>
            );
          })}
        </div>

      </div>

      {/* FILTER CHIPS */}
      {selectedStarFilter && (
        <div className="flex items-center gap-2 text-xs">
          <span className="text-[#7A6A60]">Filtrando por:</span>
          <span className="px-2.5 py-1 rounded-full bg-[#8a532b] text-white font-bold flex items-center gap-1.5">
            {selectedStarFilter} Estrellas
            <button
              onClick={() => setSelectedStarFilter(null)}
              className="hover:text-red-200 font-bold ml-1"
            >
              ×
            </button>
          </span>
          <button
            onClick={() => setSelectedStarFilter(null)}
            className="text-[11px] text-[#8a532b] hover:underline"
          >
            Ver todas
          </button>
        </div>
      )}

      {/* REVIEWS LIST */}
      <div className="space-y-3.5">
        {displayedReviews.length === 0 ? (
          <div className="text-center py-8 px-4 rounded-2xl bg-[#FDFCFB] border border-dashed border-[#D6CCC2]">
            <MessageSquare className="w-8 h-8 text-[#8C7A70] mx-auto mb-2 opacity-50" />
            <p className="text-xs font-semibold text-[#2C1810]">
              No hay reseñas que coincidan con este filtro.
            </p>
            <button
              onClick={() => setSelectedStarFilter(null)}
              className="text-xs text-[#8a532b] font-bold mt-2 hover:underline"
            >
              Mostrar todas las reseñas
            </button>
          </div>
        ) : (
          displayedReviews.map((review) => {
            const hasVoted = votedHelpfulIds[review.id];
            const helpfulCount = (review.helpfulCount || 0) + (hasVoted ? 1 : 0);
            const formattedDate = new Date(review.createdAt).toLocaleDateString('es-ES', {
              year: 'numeric',
              month: 'short',
              day: 'numeric',
            });

            return (
              <div
                key={review.id}
                className="p-4 sm:p-5 rounded-2xl bg-white border border-[#E8E2DC] shadow-xs space-y-2.5 transition-all hover:border-[#D6CCC2]"
              >
                {/* Reviewer Header */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1.5">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-full bg-[#F0EBE6] text-[#2C1810] font-bold font-serif flex items-center justify-center text-xs shrink-0">
                      {review.userName.charAt(0).toUpperCase()}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-[#2C1810]">{review.userName}</span>
                        {review.isVerifiedBuyer && (
                          <span className="inline-flex items-center gap-1 text-[10px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
                            <UserCheck className="w-3 h-3 text-emerald-600" />
                            Comprador Verificado
                          </span>
                        )}
                      </div>
                      <div className="flex items-center gap-2 mt-0.5">
                        <div className="flex items-center text-amber-400">
                          {Array.from({ length: 5 }).map((_, i) => (
                            <Star
                              key={i}
                              className={`w-3 h-3 ${
                                i < review.rating ? 'fill-amber-400' : 'text-[#D6CCC2]'
                              }`}
                            />
                          ))}
                        </div>
                        <span className="text-[11px] text-[#8C7A70]">{formattedDate}</span>
                      </div>
                    </div>
                  </div>

                  {review.orderNumber && (
                    <span className="text-[10px] text-[#8C7A70] font-mono self-start sm:self-auto bg-[#FDFCFB] px-2 py-0.5 rounded border border-[#E8E2DC]">
                      Pedido {review.orderNumber}
                    </span>
                  )}
                </div>

                {/* Title and Comment */}
                {review.title && (
                  <h5 className="font-serif font-bold text-xs sm:text-sm text-[#2C1810] pt-1">
                    "{review.title}"
                  </h5>
                )}

                <p className="text-xs text-[#4A3B32] leading-relaxed">
                  {review.comment}
                </p>

                {/* Official Workshop Reply */}
                {review.adminReply && (
                  <div className="p-3 rounded-xl bg-[#FDFCFB] border-l-3 border-[#8a532b] text-xs text-[#2C1810] space-y-1">
                    <div className="flex items-center gap-1.5 font-bold text-[#8a532b] text-[11px]">
                      <CornerDownRight className="w-3.5 h-3.5" />
                      <span>Respuesta de Emmy Mecedoras</span>
                    </div>
                    <p className="text-[#5C4033] text-xs pl-5 italic">
                      {review.adminReply}
                    </p>
                  </div>
                )}

                {/* Helpful Button Bar */}
                <div className="flex items-center justify-between pt-2 border-t border-[#F0EBE6] text-[11px] text-[#8C7A70]">
                  <span>¿Te resultó útil esta reseña?</span>
                  <button
                    onClick={() => handleHelpfulClick(review.id)}
                    className={`flex items-center gap-1 px-2.5 py-1 rounded-lg border transition-all ${
                      hasVoted
                        ? 'bg-emerald-50 border-emerald-300 text-emerald-800 font-bold'
                        : 'border-[#E8E2DC] hover:border-[#D6CCC2] text-[#2C1810] hover:bg-[#F0EBE6]'
                    }`}
                  >
                    <ThumbsUp className="w-3 h-3" />
                    <span>{hasVoted ? '¡Gracias!' : 'Sí'} ({helpfulCount})</span>
                  </button>
                </div>

              </div>
            );
          })
        )}
      </div>

    </div>
  );
};
