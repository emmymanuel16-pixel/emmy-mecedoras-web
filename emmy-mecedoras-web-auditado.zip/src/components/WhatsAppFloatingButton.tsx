import React, { useState } from 'react';
import { MessageCircle, X } from 'lucide-react';
import { StoreSettings } from '../types';
import { generateSupportWhatsAppUrl } from '../utils/whatsapp';

interface WhatsAppFloatingButtonProps {
  settings: StoreSettings;
}

export const WhatsAppFloatingButton: React.FC<WhatsAppFloatingButtonProps> = ({ settings }) => {
  const [showTooltip, setShowTooltip] = useState(true);

  const handleClick = () => {
    window.open(generateSupportWhatsAppUrl(settings), '_blank', 'noopener,noreferrer');
  };

  return (
    <div className="fixed bottom-6 right-4 sm:right-6 z-40 flex flex-col items-end gap-2">
      {/* Tooltip speech bubble */}
      {showTooltip && (
        <div className="bg-white text-stone-800 text-xs py-2 px-3 rounded-2xl shadow-xl border border-stone-200 flex items-center gap-2 max-w-[220px] animate-bounce-gentle">
          <span>¿Deseas ayuda o cotizar una mecedora a medida?</span>
          <button
            onClick={(e) => {
              e.stopPropagation();
              setShowTooltip(false);
            }}
            className="text-stone-400 hover:text-stone-600 p-0.5"
            aria-label="Cerrar mensaje"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Floating Button */}
      <button
        id="floating-whatsapp-btn"
        onClick={handleClick}
        className="p-3.5 sm:p-4 rounded-full bg-[#25D366] hover:bg-[#20bd5a] text-white shadow-xl shadow-emerald-950/20 hover:scale-105 active:scale-95 transition-all duration-200 flex items-center justify-center cursor-pointer group"
        aria-label="Contactar por WhatsApp"
      >
        <MessageCircle className="w-7 h-7 fill-current group-hover:rotate-12 transition-transform duration-300" />
      </button>
    </div>
  );
};
