import React, { useState, useEffect, useRef } from 'react';
import { ChevronLeft, ChevronRight, Sparkles } from 'lucide-react';
import { Banner } from '../types';

interface HeroCarouselProps {
  banners: Banner[];
  onCtaClick?: (link?: string) => void;
}

export const HeroCarousel = React.memo<HeroCarouselProps>(({ banners, onCtaClick }) => {
  const activeBanners = banners.filter(b => b.isActive);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isPaused, setIsPaused] = useState(false);
  const touchStartX = useRef<number | null>(null);
  const touchEndX = useRef<number | null>(null);

  // Auto-play interval
  useEffect(() => {
    if (activeBanners.length <= 1 || isPaused) return;
    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % activeBanners.length);
    }, 5500);
    return () => clearInterval(interval);
  }, [activeBanners.length, isPaused]);

  if (activeBanners.length === 0) return null;

  const handlePrev = () => {
    setCurrentIndex((prev) => (prev - 1 + activeBanners.length) % activeBanners.length);
  };

  const handleNext = () => {
    setCurrentIndex((prev) => (prev + 1) % activeBanners.length);
  };

  // Touch Swipe handlers
  const handleTouchStart = (e: React.TouchEvent) => {
    touchStartX.current = e.targetTouches[0].clientX;
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    touchEndX.current = e.targetTouches[0].clientX;
  };

  const handleTouchEnd = () => {
    if (!touchStartX.current || !touchEndX.current) return;
    const diff = touchStartX.current - touchEndX.current;
    if (diff > 50) {
      handleNext();
    } else if (diff < -50) {
      handlePrev();
    }
    touchStartX.current = null;
    touchEndX.current = null;
  };

  const currentBanner = activeBanners[currentIndex];

  return (
    <div
      className="relative w-full overflow-hidden bg-stone-900 group select-none"
      onMouseEnter={() => setIsPaused(true)}
      onMouseLeave={() => setIsPaused(false)}
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
    >
      {/* Banner Slides */}
      <div className="relative h-[360px] sm:h-[440px] md:h-[500px] w-full">
        {activeBanners.map((banner, idx) => {
          const isActive = idx === currentIndex;
          return (
            <div
              key={banner.id}
              className={`absolute inset-0 transition-opacity duration-1000 ease-in-out ${
                isActive ? 'opacity-100 z-10' : 'opacity-0 z-0 pointer-events-none'
              }`}
            >
              {/* Image with subtle zoom & warm lighting overlay */}
              <div className="relative w-full h-full">
                <img
                  src={banner.image}
                  alt={banner.title}
                  loading={idx === 0 ? "eager" : "lazy"}
                  decoding="async"
                  className="w-full h-full object-cover object-center scale-105 transition-transform duration-10000 ease-out"
                />
                {/* Gradient overlays for readability */}
                <div className="absolute inset-0 bg-gradient-to-t from-stone-950/90 via-stone-950/40 to-stone-950/20 sm:bg-gradient-to-r sm:from-stone-950/90 sm:via-stone-950/50 sm:to-transparent" />
              </div>

              {/* Text & Content */}
              <div className="absolute inset-0 z-20 flex items-end sm:items-center">
                <div className="max-w-7xl mx-auto px-5 sm:px-10 pb-12 sm:pb-0 w-full">
                  <div className="max-w-xl text-white space-y-3 sm:space-y-4 animate-fadeIn">
                    <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#D4AF37]/20 border border-[#D4AF37]/40 text-[#FDFCFB] text-[11px] sm:text-xs font-semibold backdrop-blur-xs">
                      <Sparkles className="w-3.5 h-3.5 text-[#D4AF37]" />
                      <span>Colección Exclusiva 2026</span>
                    </div>
                    <h2 className="font-serif text-2xl sm:text-4xl md:text-5xl font-bold leading-tight drop-shadow-md text-[#FDFCFB]">
                      {banner.title}
                    </h2>
                    <p className="text-sm sm:text-base text-[#E8E2DC] line-clamp-2 sm:line-clamp-3 font-normal drop-shadow-sm">
                      {banner.subtitle}
                    </p>
                    <div className="pt-2">
                      <button
                        onClick={() => onCtaClick && onCtaClick(banner.link)}
                        className="px-6 sm:px-8 py-3 sm:py-3.5 rounded-xl sm:rounded-2xl bg-[#5C4033] hover:bg-[#3E2723] text-white font-bold text-xs sm:text-sm tracking-widest uppercase transition-all transform active:scale-95 shadow-lg shadow-black/40 flex items-center gap-2 border border-[#8C5332]/50 cursor-pointer"
                      >
                        <span>{banner.buttonText || 'Ver Colección'}</span>
                        <ChevronRight className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Navigation Arrows (Desktop visible, mobile touch) */}
      {activeBanners.length > 1 && (
        <>
          <button
            onClick={handlePrev}
            className="absolute left-4 top-1/2 -translate-y-1/2 z-30 p-2.5 sm:p-3 rounded-full bg-black/40 text-white/90 hover:bg-black/70 hover:text-white backdrop-blur-xs transition-all opacity-0 group-hover:opacity-100 hidden sm:flex items-center justify-center border border-white/10"
            aria-label="Anterior"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>
          <button
            onClick={handleNext}
            className="absolute right-4 top-1/2 -translate-y-1/2 z-30 p-2.5 sm:p-3 rounded-full bg-black/40 text-white/90 hover:bg-black/70 hover:text-white backdrop-blur-xs transition-all opacity-0 group-hover:opacity-100 hidden sm:flex items-center justify-center border border-white/10"
            aria-label="Siguiente"
          >
            <ChevronRight className="w-5 h-5" />
          </button>
        </>
      )}

      {/* Slide Indicators / Dots */}
      {activeBanners.length > 1 && (
        <div className="absolute bottom-4 left-1/2 -translate-x-1/2 z-30 flex items-center gap-2">
          {activeBanners.map((_, idx) => (
            <button
              key={idx}
              onClick={() => setCurrentIndex(idx)}
              className={`h-2 rounded-full transition-all duration-300 ${
                idx === currentIndex
                  ? 'w-8 bg-[#d4af37]'
                  : 'w-2 bg-white/50 hover:bg-white/80'
              }`}
              aria-label={`Ir al banner ${idx + 1}`}
            />
          ))}
        </div>
      )}
    </div>
  );
});
