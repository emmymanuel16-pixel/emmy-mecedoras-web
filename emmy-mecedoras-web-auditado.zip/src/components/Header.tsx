import React, { useState } from 'react';
import { Search, ShoppingBag, X, ShieldCheck, Truck } from 'lucide-react';
import { CartItem, Category, StoreSettings } from '../types';

interface HeaderProps {
  settings: StoreSettings;
  categories: Category[];
  cartItems: CartItem[];
  onOpenCart: () => void;
  onOpenAdmin?: () => void;
  onSelectCategory: (categoryId: string) => void;
  activeCategory: string;
  searchQuery: string;
  onSearchChange: (query: string) => void;
}

export const Header = React.memo<HeaderProps>(({
  settings,
  categories,
  cartItems,
  onOpenCart,
  onSelectCategory,
  activeCategory,
  searchQuery,
  onSearchChange,
}) => {
  const [isSearchOpen, setIsSearchOpen] = useState(false);

  const totalCartCount = cartItems.reduce((acc, item) => acc + item.quantity, 0);

  return (
    <header className="sticky top-0 z-40 bg-[#FDFCFB]/95 backdrop-blur-md border-b border-[#F0EBE6] transition-all">
      {/* Top micro banner */}
      <div className="bg-[#2C1810] text-[#F7EEDF] text-xs py-1.5 px-4 text-center font-medium flex items-center justify-center gap-4">
        <span className="flex items-center gap-1.5">
          <Truck className="w-3.5 h-3.5 text-[#D4AF37]" />
          <span>Envío disponible a todo el país</span>
        </span>
        <span className="hidden sm:inline text-[#7A6A60]">•</span>
        <span className="hidden sm:flex items-center gap-1.5">
          <ShieldCheck className="w-3.5 h-3.5 text-[#D4AF37]" />
          <span>Garantía artesanal de 12 meses</span>
        </span>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="flex items-center justify-between h-16 sm:h-20 gap-3">
          
          {/* Brand Logo & Subtitle */}
          <div 
            id="header-brand-logo"
            className="cursor-pointer select-none py-1 flex flex-col justify-center" 
            onClick={() => onSelectCategory('all')}
          >
            <h1 className="font-serif italic text-xl sm:text-2xl md:text-3xl font-bold tracking-tight text-[#2C1810] hover:opacity-90 transition-opacity leading-none">
              {settings.storeName}
            </h1>
            <p className="text-[11px] sm:text-xs font-semibold text-[#8C7A70] tracking-normal mt-1">
              Catálogo & Tienda Oficial
            </p>
          </div>

          {/* Desktop Navigation Links */}
          <nav className="hidden md:flex items-center gap-5 text-sm font-medium text-[#5C4033]">
            <button
              onClick={() => onSelectCategory('all')}
              className={`transition-colors hover:text-[#2C1810] ${
                activeCategory === 'all' 
                  ? 'text-[#2C1810] font-bold border-b-2 border-[#5C4033] pb-0.5' 
                  : 'text-[#7A6A60]'
              }`}
            >
              Catálogo Completo
            </button>
            {[...categories]
              .filter((c) => c.isActive)
              .sort((a, b) => (a.order ?? 0) - (b.order ?? 0))
              .slice(0, 4)
              .map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => onSelectCategory(cat.id)}
                  className={`transition-colors hover:text-[#2C1810] ${
                    activeCategory === cat.id 
                      ? 'text-[#2C1810] font-bold border-b-2 border-[#5C4033] pb-0.5' 
                      : 'text-[#7A6A60]'
                  }`}
                >
                  {cat.name}
                </button>
              ))}
          </nav>

          {/* Right Action Icons (Search & Cart) */}
          <div className="flex items-center gap-1.5 sm:gap-2">
            {/* Search Button */}
            <button
              id="header-search-btn"
              onClick={() => setIsSearchOpen(!isSearchOpen)}
              className={`p-2.5 rounded-xl transition-colors ${
                isSearchOpen 
                  ? 'bg-[#F0EBE6] text-[#2C1810]' 
                  : 'text-[#2C1810] hover:text-[#5C4033] hover:bg-[#F0EBE6]/60'
              }`}
              aria-label="Buscar en el catálogo"
              title="Buscar en el catálogo"
            >
              <Search className="w-5 h-5" />
            </button>

            {/* Cart Button with Count Badge */}
            <button
              id="header-cart-btn"
              onClick={onOpenCart}
              className="p-2.5 rounded-xl text-[#2C1810] hover:text-[#5C4033] hover:bg-[#F0EBE6]/60 transition-colors relative flex items-center"
              aria-label="Ver carrito"
              title="Ver carrito de compras"
            >
              <ShoppingBag className="w-6 h-6" />
              {totalCartCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-[#25D366] text-white text-[11px] font-bold rounded-full h-5 min-w-[20px] px-1 flex items-center justify-center shadow-md animate-scale-in">
                  {totalCartCount}
                </span>
              )}
            </button>
          </div>
        </div>

        {/* Expandable Search Input Bar */}
        {isSearchOpen && (
          <div className="py-3 px-1 border-t border-[#F0EBE6] animate-fadeIn">
            <div className="relative">
              <input
                id="search-input-field"
                type="text"
                value={searchQuery}
                onChange={(e) => onSearchChange(e.target.value)}
                placeholder="Buscar mecedoras grandes, medianas, cojines, colores..."
                className="w-full bg-white border border-[#E8E2DC] rounded-2xl py-3 pl-11 pr-10 text-sm text-[#2C1810] placeholder:text-[#9A8A80] focus:outline-none focus:ring-2 focus:ring-[#5C4033] focus:border-transparent card-shadow"
                autoFocus
              />
              <Search className="w-5 h-5 text-[#9A8A80] absolute left-3.5 top-3.5" />
              {searchQuery && (
                <button
                  onClick={() => onSearchChange('')}
                  className="absolute right-3.5 top-3.5 text-[#9A8A80] hover:text-[#2C1810]"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>
            {searchQuery && (
              <p className="text-xs text-[#7A6A60] mt-2 px-2">
                Filtrando catálogo por: <span className="font-semibold text-[#2C1810]">"{searchQuery}"</span>
              </p>
            )}
          </div>
        )}
      </div>
    </header>
  );
});

