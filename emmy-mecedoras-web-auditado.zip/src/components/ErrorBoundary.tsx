import React from 'react';
import { describeFirebaseError } from '../utils/errorReporting';

type State = { error: Error | null };
export class ErrorBoundary extends React.Component<React.PropsWithChildren, State> {
  state: State = { error: null };
  static getDerivedStateFromError(error: Error): State { return { error }; }
  componentDidCatch(error: Error, info: React.ErrorInfo) { console.error('Error no controlado de interfaz:', error, info); }
  render() {
    if (!this.state.error) return this.props.children;
    return <div style={{padding:24,fontFamily:'sans-serif'}}><h2>Ocurrió un error en la página</h2><p>{describeFirebaseError(this.state.error)}</p><button onClick={() => { this.setState({error:null}); window.location.reload(); }}>Recargar página</button></div>;
  }
}
