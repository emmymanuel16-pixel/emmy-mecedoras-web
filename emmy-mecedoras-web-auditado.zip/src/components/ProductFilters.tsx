import React, { useState } from 'react';
import { 
  SlidersHorizontal, X, RotateCcw, Check, Sparkles, 
  ChevronDown, ChevronUp, Star, Palette, Layers, DollarSign, Shield 
} from 'lucide-react';
import { Category, CatalogFilterState, Product, StoreSettings } from '../types';

interface ProductFiltersProps {
  categories: Category[];
  allProducts: Product[];
  filterState: CatalogFilterState;
  onFilterChange: (newState: CatalogFilterState) => void;
  onResetFilters: () => void;
  isMobileDrawerOpen: boolean;
  onCloseMobileDrawer: () => void;
  filteredCount: number;
  settings?: StoreSettings;
}

export const ProductFilters: React.FC<ProductFiltersProps> = ({
  categories,
  allProducts,
  filterState,
  onFilterChange,
  onResetFilters,
  isMobileDrawerOpen,
  onCloseMobileDrawer,
  filteredCount,
  settings,
}) => {
  // Collapsible section states for accordion on filter panel
  const [openSections, setOpenSections] = useState<{ [key: string]: boolean }>({
    categories: true,
    rockerColor: true,
    cushionStyle: true,
    price: true,
    rating: true,
  });

  const toggleSection = (section: string) => {
    setOpenSections(prev => ({ ...prev, [section]: !prev[section] }));
  };

  const rockerColorOptions = [
    { name: 'Blanco', hex: '#FFFFFF' },
    { name: 'Caoba (marrón)', hex: '#4A1515' },
    { name: 'Negro', hex: '#1C1C1C' },
  ];

  const availableCushionStyles = Array.from(
    new Set(allProducts.map(p => p.cushionStyle).filter(Boolean) as string[])
  );

  // Helper toggle functions
  const handleToggleArrayItem = (key: keyof CatalogFilterState, item: string) => {
    const currentList = (filterState[key] as string[]) || [];
    const exists = currentList.includes(item);
    const updated = exists ? currentList.filter(i => i !== item) : [...currentList, item];
    onFilterChange({
      ...filterState,
      [key]: updated,
    });
  };

  const handleCategorySelect = (catId: string) => {
    onFilterChange({
      ...filterState,
      categoryId: catId,
    });
  };

  const hasActiveFilters = 
    filterState.categoryId !== 'all' ||
    (filterState.rockerColors && filterState.rockerColors.length > 0) ||
    (filterState.cushionStyles && filterState.cushionStyles.length > 0) ||
    filterState.minRating > 0 ||
    filterState.onlyOffers ||
    filterState.onlyInStock ||
    filterState.priceRange[0] > 0 ||
    filterState.priceRange[1] < 100000;

  const activeFiltersCount = 
    (filterState.categoryId !== 'all' ? 1 : 0) +
    (filterState.rockerColors?.length || 0) +
    (filterState.cushionStyles?.length || 0) +
    (filterState.minRating > 0 ? 1 : 0) +
    (filterState.onlyOffers ? 1 : 0) +
    (filterState.onlyInStock ? 1 : 0) +
    (filterState.priceRange[0] > 0 || filterState.priceRange[1] < 100000 ? 1 : 0);

  const filterContent = (
    <div className="space-y-6 text-sm text-[#2C1810]">
      
      {/* Header with active counter and reset */}
      <div className="flex items-center justify-between pb-3 border-b border-[#E8E2DC]">
        <div className="flex items-center gap-2">
          <SlidersHorizontal className="w-4 h-4 text-[#8a532b]" />
          <span className="font-serif font-bold text-base text-[#2C1810]">Filtros del Catálogo</span>
          {activeFiltersCount > 0 && (
            <span className="px-2 py-0.5 rounded-full bg-[#8a532b] text-[#FDFCFB] text-xs font-bold">
              {activeFiltersCount}
            </span>
          )}
        </div>
        {hasActiveFilters && (
          <button
            onClick={onResetFilters}
            className="text-xs text-[#8a532b] hover:text-[#5C4033] font-semibold flex items-center gap-1 transition-colors cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Limpiar todo</span>
          </button>
        )}
      </div>

      {/* 1. Categorías Principales */}
      <div className="space-y-2.5">
        <button
          onClick={() => toggleSection('categories')}
          className="w-full flex items-center justify-between font-serif font-bold text-xs uppercase tracking-wider text-[#5C4033] cursor-pointer"
        >
          <span>Categoría Principal</span>
          {openSections.categories ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
        </button>

        {openSections.categories && (
          <div className="space-y-1 pt-1">
            <button
              onClick={() => handleCategorySelect('all')}
              className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-medium transition-all text-left cursor-pointer ${
                filterState.categoryId === 'all'
                  ? 'bg-[#2C1810] text-[#FDFCFB] font-bold shadow-xs'
                  : 'hover:bg-[#F0EBE6] text-[#2C1810]'
              }`}
            >
              <span>Todas las categorías</span>
              <span className="text-[11px] opacity-75">{allProducts.length}</span>
            </button>
            {[...categories]
              .sort((a, b) => (a.order ?? 0) - (b.order ?? 0))
              .map((cat) => {
              const count = allProducts.filter(p => p.categoryId === cat.id).length;
              const isSelected = filterState.categoryId === cat.id;
              return (
                <button
                  key={cat.id}
                  onClick={() => handleCategorySelect(cat.id)}
                  className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-medium transition-all text-left cursor-pointer ${
                    isSelected
                      ? 'bg-[#2C1810] text-[#FDFCFB] font-bold shadow-xs'
                      : 'hover:bg-[#F0EBE6] text-[#2C1810]'
                  }`}
                >
                  <span className="truncate">{cat.name}</span>
                  <span className={`text-[11px] ${isSelected ? 'text-[#FDFCFB]' : 'text-[#8C7A70]'}`}>
                    {count}
                  </span>
                </button>
              );
            })}
          </div>
        )}
      </div>

      {/* 2. Color de Mecedora (Blanco, Caoba (marrón), Negro) */}
      <div className="pt-4 border-t border-[#E8E2DC] space-y-2.5">
        <button
          onClick={() => toggleSection('rockerColor')}
          className="w-full flex items-center justify-between font-serif font-bold text-xs uppercase tracking-wider text-[#5C4033] cursor-pointer"
        >
          <span className="flex items-center gap-1.5">
            <Palette className="w-3.5 h-3.5 text-[#8a532b]" />
            <span>Color de la Mecedora</span>
          </span>
          {openSections.rockerColor ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
        </button>

        {openSections.rockerColor && (
          <div className="space-y-1.5 pt-1">
            {rockerColorOptions.map((c) => {
              const isSelected = (filterState.rockerColors || []).includes(c.name);
              return (
                <button
                  key={c.name}
                  onClick={() => handleToggleArrayItem('rockerColors', c.name)}
                  className={`w-full flex items-center justify-between p-2 rounded-xl border text-xs text-left transition-all cursor-pointer ${
                    isSelected
                      ? 'border-[#2C1810] bg-[#2C1810] text-white font-bold'
                      : 'border-[#E8E2DC] bg-[#FDFCFB] hover:border-[#D6CCC2] text-[#4A3B32]'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <span
                      className="w-4 h-4 rounded-full border border-black/20 shrink-0 shadow-2xs"
                      style={{ backgroundColor: c.hex }}
                    />
                    <span>{c.name}</span>
                  </div>
                  {isSelected && <Check className="w-3.5 h-3.5 text-white" />}
                </button>
              );
            })}
          </div>
        )}
      </div>

      {/* 4. Estilo y Diseño del Cojín */}
      {availableCushionStyles.length > 0 && (
        <div className="pt-4 border-t border-[#E8E2DC] space-y-2.5">
          <button
            onClick={() => toggleSection('cushionStyle')}
            className="w-full flex items-center justify-between font-serif font-bold text-xs uppercase tracking-wider text-[#5C4033] cursor-pointer"
          >
            <span className="flex items-center gap-1.5">
              <Layers className="w-3.5 h-3.5 text-[#8a532b]" />
              <span>Estilo / Diseño de Cojín</span>
            </span>
            {openSections.cushionStyle ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </button>

          {openSections.cushionStyle && (
            <div className="space-y-1.5 pt-1">
              {availableCushionStyles.map((style) => {
                const isSelected = (filterState.cushionStyles || []).includes(style);
                const count = allProducts.filter(p => p.cushionStyle === style).length;
                return (
                  <label
                    key={style}
                    onClick={() => handleToggleArrayItem('cushionStyles', style)}
                    className={`flex items-center justify-between p-2 rounded-xl border text-xs cursor-pointer transition-all ${
                      isSelected
                        ? 'bg-[#8a532b]/10 border-[#8a532b] text-[#2C1810] font-semibold'
                        : 'border-[#E8E2DC] hover:border-[#D6CCC2] bg-[#FDFCFB] text-[#4A3B32]'
                    }`}
                  >
                    <div className="flex items-center gap-2 min-w-0">
                      <div className={`w-4 h-4 rounded flex items-center justify-center border transition-colors ${
                        isSelected ? 'bg-[#8a532b] border-[#8a532b] text-white' : 'border-[#C8BEB5] bg-white'
                      }`}>
                        {isSelected && <Check className="w-3 h-3" />}
                      </div>
                      <span className="truncate">{style}</span>
                    </div>
                    <span className="text-[11px] text-[#8C7A70]">{count}</span>
                  </label>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* 5. Rango de Precio */}
      <div className="pt-4 border-t border-[#E8E2DC] space-y-2.5">
        <button
          onClick={() => toggleSection('price')}
          className="w-full flex items-center justify-between font-serif font-bold text-xs uppercase tracking-wider text-[#5C4033] cursor-pointer"
        >
          <span className="flex items-center gap-1.5">
            <DollarSign className="w-3.5 h-3.5 text-[#8a532b]" />
            <span>Rango de Precio</span>
          </span>
          {openSections.price ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
        </button>

        {openSections.price && (
          <div className="space-y-3 pt-1">
            <div className="flex items-center justify-between text-xs font-semibold text-[#2C1810]">
              <span>Hasta ${filterState.priceRange[1].toLocaleString()}</span>
              <span className="text-[11px] text-[#8C7A70]">Min $0 - Max $100,000</span>
            </div>
            <input
              type="range"
              min="0"
              max="100000"
              step="500"
              value={filterState.priceRange[1]}
              onChange={(e) => onFilterChange({
                ...filterState,
                priceRange: [filterState.priceRange[0], Number(e.target.value)]
              })}
              className="w-full accent-[#8a532b] cursor-pointer"
            />
            <div className="flex gap-2">
              <button
                onClick={() => onFilterChange({ ...filterState, priceRange: [0, 8000] })}
                className="flex-1 py-1 px-2 rounded-lg bg-[#F0EBE6] hover:bg-[#E8E2DC] text-[11px] font-semibold text-[#2C1810] text-center cursor-pointer"
              >
                Hasta $8,000
              </button>
              <button
                onClick={() => onFilterChange({ ...filterState, priceRange: [8000, 15000] })}
                className="flex-1 py-1 px-2 rounded-lg bg-[#F0EBE6] hover:bg-[#E8E2DC] text-[11px] font-semibold text-[#2C1810] text-center cursor-pointer"
              >
                $8,000 - $15,000
              </button>
              <button
                onClick={() => onFilterChange({ ...filterState, priceRange: [15000, 100000] })}
                className="flex-1 py-1 px-2 rounded-lg bg-[#F0EBE6] hover:bg-[#E8E2DC] text-[11px] font-semibold text-[#2C1810] text-center cursor-pointer"
              >
                +$15,000
              </button>
            </div>
          </div>
        )}
      </div>

      {/* 6. Calificación Mínima */}
      <div className="pt-4 border-t border-[#E8E2DC] space-y-2.5">
        <button
          onClick={() => toggleSection('rating')}
          className="w-full flex items-center justify-between font-serif font-bold text-xs uppercase tracking-wider text-[#5C4033] cursor-pointer"
        >
          <span className="flex items-center gap-1.5">
            <Star className="w-3.5 h-3.5 text-[#d4af37]" />
            <span>Calificación de Clientes</span>
          </span>
          {openSections.rating ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
        </button>

        {openSections.rating && (
          <div className="space-y-1.5 pt-1">
            {[4.5, 4.0, 0].map((starVal) => {
              const isSelected = filterState.minRating === starVal;
              return (
                <button
                  key={starVal}
                  onClick={() => onFilterChange({ ...filterState, minRating: isSelected && starVal !== 0 ? 0 : starVal })}
                  className={`w-full flex items-center justify-between p-2 rounded-xl border text-xs transition-all cursor-pointer ${
                    isSelected && starVal > 0
                      ? 'bg-[#8a532b]/10 border-[#8a532b] text-[#2C1810] font-bold'
                      : 'border-[#E8E2DC] hover:border-[#D6CCC2] bg-[#FDFCFB] text-[#4A3B32]'
                  }`}
                >
                  <div className="flex items-center gap-1.5">
                    {starVal === 0 ? (
                      <span>Todas las calificaciones</span>
                    ) : (
                      <>
                        <div className="flex items-center text-amber-500">
                          {Array.from({ length: 5 }).map((_, i) => (
                            <Star
                              key={i}
                              className={`w-3.5 h-3.5 ${
                                i < Math.floor(starVal) ? 'fill-amber-400 text-amber-400' : 'text-[#D6CCC2]'
                              }`}
                            />
                          ))}
                        </div>
                        <span>{starVal} estrellas o más</span>
                      </>
                    )}
                  </div>
                </button>
              );
            })}
          </div>
        )}
      </div>

      {/* 7. Ofertas y Disponibilidad */}
      <div className="pt-4 border-t border-[#E8E2DC] space-y-2">
        <label className="flex items-center gap-2.5 cursor-pointer text-xs font-semibold text-[#2C1810]">
          <input
            type="checkbox"
            checked={filterState.onlyOffers}
            onChange={(e) => onFilterChange({ ...filterState, onlyOffers: e.target.checked })}
            className="w-4 h-4 rounded text-[#8a532b] accent-[#8a532b]"
          />
          <span>Solo piezas en Oferta / Descuento</span>
        </label>
        <label className="flex items-center gap-2.5 cursor-pointer text-xs font-semibold text-[#2C1810]">
          <input
            type="checkbox"
            checked={filterState.onlyInStock}
            onChange={(e) => onFilterChange({ ...filterState, onlyInStock: e.target.checked })}
            className="w-4 h-4 rounded text-[#8a532b] accent-[#8a532b]"
          />
          <span>Solo con Entrega Inmediata (en stock)</span>
        </label>
      </div>

    </div>
  );

  return (
    <>
      {/* DESKTOP SIDEBAR FILTER */}
      <aside className="hidden lg:block w-72 shrink-0 bg-[#FDFCFB] border border-[#E8E2DC] rounded-2xl p-5 shadow-xs sticky top-24 self-start max-h-[calc(100vh-120px)] overflow-y-auto">
        {filterContent}
      </aside>

      {/* MOBILE / TABLET SLIDE-OVER DRAWER */}
      {isMobileDrawerOpen && (
        <div className="fixed inset-0 z-50 lg:hidden flex justify-end">
          {/* Backdrop overlay */}
          <div
            onClick={onCloseMobileDrawer}
            className="fixed inset-0 bg-black/60 backdrop-blur-xs transition-opacity animate-fadeIn"
          />

          {/* Drawer Panel */}
          <div className="relative w-full max-w-sm sm:max-w-md bg-[#FDFCFB] h-full flex flex-col shadow-2xl z-10 animate-slideLeft">
            
            {/* Header */}
            <div className="p-4 border-b border-[#E8E2DC] flex items-center justify-between bg-white">
              <div className="flex items-center gap-2">
                <SlidersHorizontal className="w-4 h-4 text-[#8a532b]" />
                <h3 className="font-serif font-bold text-base text-[#2C1810]">Filtros del Catálogo</h3>
              </div>
              <button
                onClick={onCloseMobileDrawer}
                className="p-2 rounded-full hover:bg-[#F0EBE6] text-[#2C1810] transition-colors cursor-pointer"
                aria-label="Cerrar filtros"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Scrollable Filters */}
            <div className="flex-1 overflow-y-auto p-5">
              {filterContent}
            </div>

            {/* Sticky Bottom Actions */}
            <div className="p-4 border-t border-[#E8E2DC] bg-white flex items-center gap-3">
              {hasActiveFilters && (
                <button
                  onClick={onResetFilters}
                  className="py-3 px-4 rounded-xl border border-[#D6CCC2] text-[#2C1810] hover:bg-[#F0EBE6] text-xs font-bold transition-all cursor-pointer"
                >
                  Limpiar
                </button>
              )}
              <button
                onClick={onCloseMobileDrawer}
                className="flex-1 py-3 px-4 rounded-xl bg-[#2C1810] hover:bg-[#3E2723] text-white text-xs sm:text-sm font-bold shadow-md transition-all text-center flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>Ver {filteredCount} {filteredCount === 1 ? 'producto' : 'productos'}</span>
              </button>
            </div>

          </div>
        </div>
      )}
    </>
  );
};

