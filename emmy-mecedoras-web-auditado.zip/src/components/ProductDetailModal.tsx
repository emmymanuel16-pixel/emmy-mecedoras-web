import React, { useState, useRef, useEffect, useMemo } from 'react';
import { 
  X, MessageCircle, ShoppingBag, Check, Layers, Sparkles, 
  ShieldCheck, Truck, ChevronLeft, ChevronRight, Maximize2, 
  Ruler, Weight, Palette, Box, CheckCircle2, Star, Sparkle, Tag, Image as ImageIcon, Eye, Scissors, ZoomIn, Info
} from 'lucide-react';
import { ColorOption, CushionBackrestStyleSettings, CushionBorderStyleSettings, CushionFabricCategory, CushionTextalinaOption, Product, ProductCustomization, Review, StoreSettings } from '../types';
import { formatPrice, generateSingleProductWhatsAppUrl } from '../utils/whatsapp';
import { 
  DEFAULT_CUSHION_FABRICS, 
  DEFAULT_CUSHION_PATTERNS, 
  DEFAULT_CUSHION_TEXTALINA_OPTIONS,
  DEFAULT_CUSHION_BORDER_COLORS,
  DEFAULT_CUSHION_STYLE_EXAMPLES,
  DEFAULT_CUSHION_BORDER_STYLE_EXAMPLES,
  TEXTALINA_CUSHION_COLORS, 
  WIDE_CUSHION_COLOR_PALETTE 
} from '../data/initialData';
import { ReviewsSection } from './ReviewsSection';
import { api } from '../services/api';
import confetti from 'canvas-confetti';

interface ProductDetailModalProps {
  product: Product | null;
  allProducts: Product[];
  reviews: Review[];
  settings: StoreSettings;
  onClose: () => void;
  onAddToCart: (
    product: Product, 
    quantity: number, 
    options: { 
      color?: string; 
      cushionColor?: string; 
      borderColor?: string;
      backrestStyle?: 'costura' | 'botones' | string;
      fabricType?: string;
      fabricPriceDiff?: number;
      patternName?: string;
      patternImage?: string;
      selectedTextalinaImage?: string;
      finish?: string; 
      upholstery?: string; 
      size?: string; 
      notes?: string;
      customization?: ProductCustomization;
    }
  ) => void;
  onSelectProduct: (product: Product) => void;
  onReviewAdded: (newReview: Review) => void;
}

export const ProductDetailModal: React.FC<ProductDetailModalProps> = ({
  product,
  allProducts,
  reviews,
  settings,
  onClose,
  onAddToCart,
  onSelectProduct,
  onReviewAdded,
}) => {
  if (!product) return null;

  const FALLBACK_PRODUCT_IMAGE = 'https://images.unsplash.com/photo-1586023492125-27b2c045efd7?auto=format&fit=crop&w=900&q=85';

  const images = useMemo(() => {
    const list: string[] = [];
    const seen = new Set<string>();

    const addImg = (imgStr: any) => {
      if (typeof imgStr === 'string') {
        const trimmed = imgStr.trim();
        if (trimmed.length > 0 && !seen.has(trimmed)) {
          seen.add(trimmed);
          list.push(trimmed);
        }
      }
    };

    // Add main image first
    if (product.mainImage) {
      addImg(product.mainImage);
    }

    // Add gallery images without duplicating
    if (Array.isArray(product.images)) {
      product.images.forEach(addImg);
    }

    if (list.length === 0) {
      list.push(FALLBACK_PRODUCT_IMAGE);
    }

    return list;
  }, [product.mainImage, product.images]);
  const isCushionOnly = product.categoryId === 'cojines' || product.productType === 'cojin';
  
  // Rocker colors: Blanco, Caoba (marrón), Negro
  const defaultRockerColors = [
    { name: 'Blanco', hex: '#FFFFFF' },
    { name: 'Caoba (marrón)', hex: '#4A1515' },
    { name: 'Negro', hex: '#1C1C1C' },
  ];
  const rockerColors = product.colors && product.colors.length > 0 
    ? product.colors 
    : (settings.rockerColors || defaultRockerColors);

  // Cushion Fabrics
  const cushionFabrics = Array.isArray(settings.cushionFabrics)
    ? settings.cushionFabrics
    : [];

  // Available Cushion Colors (Wide Palette)
  const availableCushionColors = useMemo(() => {
    const list: { name: string; hex: string; category?: string }[] = [];
    const seen = new Set<string>();

    if (product.colors && product.colors.length > 0 && isCushionOnly) {
      product.colors.forEach((c) => {
        if (!seen.has(c.name.toLowerCase())) {
          seen.add(c.name.toLowerCase());
          list.push({ name: c.name, hex: c.hex, category: 'Destacados' });
        }
      });
    }

    if (settings.cushionColors && settings.cushionColors.length > 0) {
      settings.cushionColors.forEach((c) => {
        if (!seen.has(c.name.toLowerCase())) {
          seen.add(c.name.toLowerCase());
          list.push({ name: c.name, hex: c.hex, category: c.category || 'Catálogo' });
        }
      });
    }

    WIDE_CUSHION_COLOR_PALETTE.forEach((c) => {
      if (!seen.has(c.name.toLowerCase())) {
        seen.add(c.name.toLowerCase());
        list.push(c);
      }
    });

    return list;
  }, [product.colors, isCushionOnly, settings.cushionColors]);

  const [selectedImageIdx, setSelectedImageIdx] = useState(0);
  const [failedImageIndices, setFailedImageIndices] = useState<Record<number, boolean>>({});

  // Reset image failure cache when product changes
  useEffect(() => {
    setFailedImageIndices({});
    setSelectedImageIdx(0);
  }, [product.id]);

  const [selectedColor, setSelectedColor] = useState<string>(rockerColors[0]?.name || 'Blanco');
  const [selectedFabricId, setSelectedFabricId] = useState<string>(cushionFabrics[0]?.id || '');
  const [selectedCushionColor, setSelectedCushionColor] = useState<string>(
    availableCushionColors[0]?.name || 'Beige Arena'
  );

  // Synchronize selectedFabricId whenever cushionFabrics changes
  useEffect(() => {
    if (cushionFabrics && cushionFabrics.length > 0) {
      if (!selectedFabricId || !cushionFabrics.some(f => f.id === selectedFabricId)) {
        setSelectedFabricId(cushionFabrics[0].id);
      }
    } else {
      if (selectedFabricId !== '') {
        setSelectedFabricId('');
      }
    }
  }, [cushionFabrics, selectedFabricId]);
  const [cushionCategoryFilter, setCushionCategoryFilter] = useState<string>('Todos');
  const [selectedFinish, setSelectedFinish] = useState<string>(product.finishes?.[0] || '');
  const [selectedUpholstery, setSelectedUpholstery] = useState<string>(product.upholstery || '');
  const [selectedSize, setSelectedSize] = useState<string>('');
  const [quantity, setQuantity] = useState<number>(1);
  const [isZoomed, setIsZoomed] = useState<boolean>(false);
  const [addedToast, setAddedToast] = useState<boolean>(false);

  const availablePatterns = useMemo(() => {
    const patterns = Array.isArray(product.cushionPatterns)
      ? product.cushionPatterns
      : (Array.isArray(settings.cushionPatterns) ? settings.cushionPatterns : []);
    return patterns.filter(p => p.isActive !== false);
  }, [product.cushionPatterns, settings.cushionPatterns]);

  const [selectedPatternId, setSelectedPatternId] = useState<string>(
    availablePatterns[0]?.id || ''
  );

  const availableTextalinaOptions: CushionTextalinaOption[] = useMemo(() => {
    const options = Array.isArray(settings.cushionTextalinaOptions)
      ? settings.cushionTextalinaOptions
      : [];
    return options.filter((t) => t.isActive !== false);
  }, [settings.cushionTextalinaOptions]);

  const borderColors: ColorOption[] = useMemo(() => {
    return Array.isArray(settings.cushionBorderColors)
      ? settings.cushionBorderColors
      : [];
  }, [settings.cushionBorderColors]);

  const styleExamples: CushionBackrestStyleSettings = useMemo(() => {
    return settings.cushionStyleExamples || DEFAULT_CUSHION_STYLE_EXAMPLES;
  }, [settings.cushionStyleExamples]);

  const borderStyleExamples: CushionBorderStyleSettings = useMemo(() => {
    return settings.cushionBorderStyleExamples || DEFAULT_CUSHION_BORDER_STYLE_EXAMPLES;
  }, [settings.cushionBorderStyleExamples]);

  const [customBorderEnabled, setCustomBorderEnabled] = useState<boolean>(false);
  const [selectedBorderColor, setSelectedBorderColor] = useState<string>(
    borderColors[0]?.name || 'Blanco'
  );
  const [selectedBackrestStyle, setSelectedBackrestStyle] = useState<'costura' | 'botones'>('botones');
  const [showStyleExamplesModal, setShowStyleExamplesModal] = useState<boolean>(false);
  const [showBorderExamplesModal, setShowBorderExamplesModal] = useState<boolean>(false);
  const [activeFabricInfoModal, setActiveFabricInfoModal] = useState<CushionFabricCategory | null>(null);
  const [previewSampleModal, setPreviewSampleModal] = useState<{
    isOpen: boolean;
    title: string;
    image: string;
    description?: string;
    hex?: string;
  } | null>(null);

  const modalContentRef = useRef<HTMLDivElement>(null);

  // Guided auto-scroll step-by-step navigation helper
  const scrollToStep = (stepId: string) => {
    setTimeout(() => {
      const container = modalContentRef.current;
      const target = document.getElementById(stepId);
      if (container && target) {
        const containerRect = container.getBoundingClientRect();
        const targetRect = target.getBoundingClientRect();
        const relativeTop = targetRect.top - containerRect.top + container.scrollTop - 24;
        container.scrollTo({
          top: Math.max(0, relativeTop),
          behavior: 'smooth',
        });
      }
    }, 120);
  };

  const selectedFabricObj = cushionFabrics.find(f => f.id === selectedFabricId) || cushionFabrics[0];
  const isTextalina = Boolean(
    selectedFabricObj?.typeMode === 'textalina' ||
    selectedFabricId?.toLowerCase().includes('textalina') ||
    selectedFabricObj?.name?.toLowerCase().includes('textalina')
  );
  const isPatternFabric = Boolean(
    selectedFabricObj?.typeMode === 'pattern' ||
    selectedFabricId?.toLowerCase().includes('estamp') ||
    selectedFabricObj?.name?.toLowerCase().includes('estamp')
  );
  const selectedPatternObj = isPatternFabric
    ? (availablePatterns.find(p => p.id === selectedPatternId) || availablePatterns[0])
    : null;
  const selectedTextalinaObj = (isTextalina || cushionCategoryFilter === 'Textalina')
    ? (availableTextalinaOptions.find(t => t.name.toLowerCase() === selectedCushionColor.toLowerCase()) || availableTextalinaOptions[0])
    : null;
  const fabricPriceDiff = selectedFabricObj ? (selectedFabricObj.priceDiff || 0) : 0;
  const currentUnitPrice = product.price + (isCushionOnly ? fabricPriceDiff : 0);

  const filteredCushionColors = useMemo(() => {
    if (isTextalina || cushionCategoryFilter === 'Textalina') return TEXTALINA_CUSHION_COLORS;
    if (cushionCategoryFilter === 'Todos') return availableCushionColors;
    return availableCushionColors.filter(c => c.category === cushionCategoryFilter);
  }, [isTextalina, availableCushionColors, cushionCategoryFilter]);

  // If textalina is selected, ensure the selected color is strictly one of the allowed textalina colors
  useEffect(() => {
    if (isTextalina) {
      const isValid = availableTextalinaOptions.some(
        (c) => c.name.toLowerCase() === selectedCushionColor.toLowerCase()
      );
      if (!isValid && availableTextalinaOptions.length > 0) {
        setSelectedCushionColor(availableTextalinaOptions[0].name);
      }
    }
  }, [isTextalina, selectedFabricId, availableTextalinaOptions]);

  // Track product detail modal view
  useEffect(() => {
    if (product?.id) {
      api.recordAnalyticsEvent({
        type: 'product_modal_open',
        productId: product.id,
        productName: product.name,
        categoryId: product.categoryId,
        price: product.price,
        metadata: { source: 'product_detail_modal' }
      });
    }
  }, [product?.id]);

  const touchStartX = useRef<number | null>(null);

  const discountPercent = product.previousPrice && product.previousPrice > product.price
    ? Math.round(((product.previousPrice - product.price) / product.previousPrice) * 100)
    : null;

  // Find compatible cushions
  const compatibleCushions = product.compatibleCushionIds
    ? allProducts.filter((p) => product.compatibleCushionIds?.includes(p.id))
    : allProducts.filter((p) => p.categoryId === 'cojines').slice(0, 2);

  const handleTouchStart = (e: React.TouchEvent) => {
    touchStartX.current = e.targetTouches[0].clientX;
  };

  const handleTouchEnd = (e: React.TouchEvent) => {
    if (!touchStartX.current) return;
    const diff = touchStartX.current - e.changedTouches[0].clientX;
    if (diff > 40 && images.length > 1) {
      setSelectedImageIdx((prev) => (prev + 1) % images.length);
    } else if (diff < -40 && images.length > 1) {
      setSelectedImageIdx((prev) => (prev - 1 + images.length) % images.length);
    }
    touchStartX.current = null;
  };

  const handleAddToCart = () => {
    onAddToCart(product, quantity, {
      color: isCushionOnly ? undefined : selectedColor,
      cushionColor: isPatternFabric ? undefined : selectedCushionColor,
      borderColor: customBorderEnabled ? selectedBorderColor : undefined,
      backrestStyle: selectedBackrestStyle,
      fabricType: selectedFabricObj ? selectedFabricObj.name : undefined,
      fabricPriceDiff: isCushionOnly ? fabricPriceDiff : 0,
      patternName: isPatternFabric && selectedPatternObj ? selectedPatternObj.name : undefined,
      patternImage: isPatternFabric && selectedPatternObj ? selectedPatternObj.image : undefined,
      selectedTextalinaImage: (isTextalina || cushionCategoryFilter === 'Textalina') && selectedTextalinaObj ? selectedTextalinaObj.image : undefined,
      finish: selectedFinish,
      upholstery: selectedUpholstery,
      size: selectedSize,
    });

    confetti({
      particleCount: 40,
      spread: 60,
      origin: { y: 0.8 },
      colors: ['#8a532b', '#25D366', '#d4af37'],
    });

    setAddedToast(true);
    setTimeout(() => setAddedToast(false), 2500);
  };

  const handleWhatsAppOrder = () => {
    api.recordAnalyticsEvent({
      type: 'whatsapp_order',
      productId: product.id,
      productName: product.name,
      categoryId: product.categoryId,
      price: currentUnitPrice * quantity,
      metadata: {
        quantity,
        color: isCushionOnly ? undefined : selectedColor,
        cushionColor: isPatternFabric ? undefined : selectedCushionColor,
        borderColor: customBorderEnabled ? selectedBorderColor : undefined,
        backrestStyle: selectedBackrestStyle,
        fabricType: selectedFabricObj ? selectedFabricObj.name : undefined,
        fabricPriceDiff: isCushionOnly ? fabricPriceDiff : 0,
        patternName: isPatternFabric && selectedPatternObj ? selectedPatternObj.name : undefined,
        selectedTextalina: (isTextalina || cushionCategoryFilter === 'Textalina') && selectedTextalinaObj ? selectedTextalinaObj.name : undefined,
        finish: selectedFinish,
        upholstery: selectedUpholstery,
        size: selectedSize,
      }
    });

    const url = generateSingleProductWhatsAppUrl(product, settings, {
      quantity,
      color: isCushionOnly ? undefined : selectedColor,
      cushionColor: isPatternFabric ? undefined : selectedCushionColor,
      borderColor: customBorderEnabled ? selectedBorderColor : undefined,
      backrestStyle: selectedBackrestStyle,
      fabricType: selectedFabricObj ? selectedFabricObj.name : undefined,
      fabricPriceDiff: isCushionOnly ? fabricPriceDiff : 0,
      patternName: isPatternFabric && selectedPatternObj ? selectedPatternObj.name : undefined,
      patternImage: isPatternFabric && selectedPatternObj ? selectedPatternObj.image : undefined,
      finish: selectedFinish,
      upholstery: selectedUpholstery,
      size: selectedSize,
    });
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  return (
    <div
      id="product-detail-modal-backdrop"
      className="fixed inset-0 z-50 overflow-y-auto bg-black/70 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4 md:p-6 animate-fadeIn"
      onClick={onClose}
    >
      <div
        id="product-detail-modal-container"
        className="relative bg-[#FDFCFB] rounded-2xl sm:rounded-3xl max-w-4xl w-full max-h-[92vh] flex flex-col border border-[#E8E2DC] shadow-2xl animate-scaleUp overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Sticky Close Button */}
        <button
          onClick={onClose}
          className="absolute top-3 right-3 sm:top-4 sm:right-4 z-20 p-2 sm:p-2.5 rounded-full bg-white/90 text-[#2C1810] hover:bg-[#F0EBE6] transition-all shadow-md cursor-pointer"
          aria-label="Cerrar modal"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Scrollable Content Body */}
        <div ref={modalContentRef} className="flex-1 overflow-y-auto scroll-smooth">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-0 md:gap-8">
            
            {/* LEFT: Complete Interactive Gallery */}
            <div className="p-4 sm:p-6 md:p-8 bg-[#FDFCFB] border-b md:border-b-0 md:border-r border-[#F0EBE6] flex flex-col justify-between">
              <div>
                {/* Main Image Stage */}
                <div
                  className="relative aspect-square w-full rounded-2xl overflow-hidden bg-[#F0EBE6] card-shadow group cursor-zoom-in flex items-center justify-center"
                  onTouchStart={handleTouchStart}
                  onTouchEnd={handleTouchEnd}
                  onClick={() => setIsZoomed(!isZoomed)}
                >
                  {failedImageIndices[selectedImageIdx] ? (
                    <div className="w-full h-full bg-stone-100 flex flex-col items-center justify-center text-stone-400 p-6 text-center">
                      <ImageIcon className="w-12 h-12 mb-2 text-stone-300" />
                      <p className="text-xs font-semibold text-stone-500">Imagen no disponible</p>
                      <p className="text-[10px] text-stone-400 mt-0.5">Foto {selectedImageIdx + 1} de {images.length}</p>
                    </div>
                  ) : (
                    <img
                      src={images[selectedImageIdx] || FALLBACK_PRODUCT_IMAGE}
                      alt={`${product.name} - Imagen ${selectedImageIdx + 1}`}
                      referrerPolicy="no-referrer"
                      className={`w-full h-full object-cover object-center transition-transform duration-300 ${
                        isZoomed ? 'scale-150' : 'scale-100'
                      }`}
                      onError={() => {
                        setFailedImageIndices((prev) => ({ ...prev, [selectedImageIdx]: true }));
                      }}
                    />
                  )}

                  {/* Badge tags */}
                  <div className="absolute top-3 left-3 flex flex-col gap-1.5 z-10 pointer-events-none">
                    {product.isOffer && discountPercent && (
                      <span className="bg-[#9C2727] text-white text-xs font-extrabold px-3 py-1 rounded-full shadow-md tracking-wider">
                        -{discountPercent}% DESCUENTO
                      </span>
                    )}
                    {product.isNew && (
                      <span className="bg-[#2C1810] text-[#FDFCFB] text-xs font-semibold px-3 py-1 rounded-full shadow-md">
                        NUEVA COLECCIÓN
                      </span>
                    )}
                  </div>

                  {/* Gallery arrows */}
                  {images.length > 1 && (
                    <>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setSelectedImageIdx((prev) => (prev - 1 + images.length) % images.length);
                        }}
                        className="absolute left-2 top-1/2 -translate-y-1/2 p-2 rounded-full bg-black/50 text-white hover:bg-black/80 transition-all z-10 cursor-pointer"
                        aria-label="Foto anterior"
                      >
                        <ChevronLeft className="w-5 h-5" />
                      </button>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setSelectedImageIdx((prev) => (prev + 1) % images.length);
                        }}
                        className="absolute right-2 top-1/2 -translate-y-1/2 p-2 rounded-full bg-black/50 text-white hover:bg-black/80 transition-all z-10 cursor-pointer"
                        aria-label="Foto siguiente"
                      >
                        <ChevronRight className="w-5 h-5" />
                      </button>
                    </>
                  )}

                  {/* Zoom icon */}
                  <div className="absolute bottom-3 right-3 p-1.5 rounded-lg bg-black/40 text-white backdrop-blur-xs">
                    <Maximize2 className="w-4 h-4" />
                  </div>
                </div>

                {/* Thumbnails Gallery */}
                {images.length > 1 && (
                  <div className="flex items-center gap-2 overflow-x-auto mt-4 pb-1">
                    {images.map((img, idx) => {
                      const isFailed = failedImageIndices[idx];
                      return (
                        <button
                          key={`${product.id}-thumb-${idx}-${img.slice(-25)}`}
                          type="button"
                          onClick={() => setSelectedImageIdx(idx)}
                          className={`relative w-16 h-16 rounded-xl overflow-hidden border-2 transition-all shrink-0 cursor-pointer bg-stone-100 ${
                            selectedImageIdx === idx
                              ? 'border-[#8a532b] ring-2 ring-[#8a532b]/20 scale-95'
                              : 'border-transparent opacity-75 hover:opacity-100'
                          }`}
                        >
                          {isFailed ? (
                            <div className="w-full h-full bg-stone-200/70 flex flex-col items-center justify-center p-1 text-stone-500">
                              <ImageIcon className="w-4 h-4 text-stone-400" />
                              <span className="text-[9px] font-bold">Foto {idx + 1}</span>
                            </div>
                          ) : (
                            <img
                              src={img}
                              alt={`Miniatura ${idx + 1}`}
                              referrerPolicy="no-referrer"
                              className="w-full h-full object-cover"
                              onError={() => {
                                setFailedImageIndices((prev) => ({ ...prev, [idx]: true }));
                              }}
                            />
                          )}
                          <span className="absolute bottom-0.5 right-0.5 px-1 rounded bg-black/60 text-white text-[9px] font-bold pointer-events-none">
                            {idx + 1}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>

            {/* RIGHT: Specs, Variants & Ordering */}
            <div className="p-5 sm:p-6 md:p-8 flex flex-col justify-between space-y-5">
              <div className="space-y-4">
                
                {/* 1. Category & Status */}
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold uppercase tracking-widest text-[#5C4033]">
                    {product.categoryId.replace('-', ' ')}
                  </span>
                  <span className="inline-flex items-center gap-1 text-xs font-semibold text-emerald-800 bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-200">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                    {product.stock > 0 ? `Stock Disponible (${product.stock} unid.)` : 'Fabricación por encargo'}
                  </span>
                </div>

                {/* 2. NOMBRE DEL PRODUCTO */}
                <div>
                  <h1 className="font-serif text-2xl sm:text-3xl font-bold text-[#2C1810] leading-tight">
                    {product.name}
                  </h1>
                  
                  {/* 3. CALIFICACIÓN (Rating Stars & Reseñas) */}
                  <div className="flex items-center gap-2 mt-1.5">
                    <div className="flex items-center text-amber-400">
                      {Array.from({ length: 5 }).map((_, i) => (
                        <Star
                          key={i}
                          className={`w-4 h-4 ${
                            i < Math.round(product.rating || 5) ? 'fill-amber-400 text-amber-400' : 'text-[#D6CCC2]'
                          }`}
                        />
                      ))}
                    </div>
                    <span className="text-xs font-bold text-[#2C1810]">
                      {product.rating ? product.rating.toFixed(1) : '5.0'}
                    </span>
                    <span className="text-xs text-[#8C7A70]">
                      ({reviews.filter(r => r.productId === product.id).length || product.reviewCount || 0} reseñas verificadas)
                    </span>
                  </div>
                </div>

                {/* 4. PRECIO (Seguido del nombre y calificación) */}
                <div className="flex flex-wrap items-baseline gap-3 py-1 border-b border-[#F0EBE6] pb-3">
                  <span className="text-2xl sm:text-3xl font-extrabold text-[#2C1810]">
                    {formatPrice(currentUnitPrice, settings.currency)}
                  </span>
                  {product.previousPrice && (
                    <span className="text-base text-[#9A8A80] line-through">
                      {formatPrice(product.previousPrice + fabricPriceDiff, settings.currency)}
                    </span>
                  )}
                  {fabricPriceDiff > 0 && isCushionOnly && (
                    <span className="text-xs font-semibold text-[#8a532b] bg-[#8a532b]/10 px-2.5 py-0.5 rounded-md border border-[#8a532b]/20">
                      Incluye tela {selectedFabricObj?.name} (+{formatPrice(fabricPriceDiff, settings.currency)})
                    </span>
                  )}
                  {product.isOffer && discountPercent && (
                    <span className="text-xs font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-md">
                      Ahorras {discountPercent}%
                    </span>
                  )}
                </div>

                {/* 5. DESCRIPCIÓN */}
                <p className="text-sm text-[#5C4033] leading-relaxed">
                  {product.description}
                </p>

                {/* 6. OPCIONES CONDICIONALES: Cojines vs Mecedoras */}
                {isCushionOnly ? (
                  <div className="space-y-4 pt-1">
                    {/* PASO 1: SELECCIÓN DE TELA DEL COJÍN (CATEGORÍA DE TELA) */}
                    <div id="step-cushion-fabric" className="space-y-2 scroll-mt-4">
                      <div className="flex items-center justify-between text-xs">
                        <span className="font-bold text-[#2C1810] flex items-center gap-1.5">
                          <span className="px-1.5 py-0.5 rounded bg-[#8a532b]/10 text-[#8a532b] text-[10px] font-extrabold">PASO 1</span>
                          <Layers className="w-3.5 h-3.5 text-[#8a532b]" />
                          Tipo de Tela: <span className="text-[#8a532b] font-extrabold">{selectedFabricObj?.name || (cushionFabrics.length === 0 ? 'Sin stock' : 'Por seleccionar')}</span>
                        </span>
                        <span className="text-[10px] text-[#8C7A70]">Elige el tipo de tejido</span>
                      </div>
                      
                      {cushionFabrics.length === 0 ? (
                        <div className="p-4 rounded-2xl bg-amber-50 border border-dashed border-amber-200 text-center space-y-1">
                          <p className="text-xs font-bold text-amber-900">Actualmente no hay telas registradas en inventario</p>
                          <p className="text-[11px] text-amber-700">Estado de sin stock de telas activo. Puedes consultar confección especial por WhatsApp.</p>
                        </div>
                      ) : (
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                        {cushionFabrics.map((fabric) => {
                          const isSelected = selectedFabricId === fabric.id;
                          return (
                            <div
                              key={fabric.id}
                              onClick={() => {
                                setSelectedFabricId(fabric.id);
                                scrollToStep('step-cushion-colors');
                              }}
                              className={`p-3 rounded-2xl border text-left transition-all cursor-pointer flex flex-col justify-between gap-2 ${
                                isSelected
                                  ? 'border-[#8a532b] bg-[#FAF5F0] ring-2 ring-[#8a532b]/20 shadow-xs'
                                  : 'border-[#E8E2DC] bg-white hover:border-[#C8BEB5]'
                              }`}
                            >
                              <div className="flex items-start gap-2.5">
                                {fabric.image && (
                                  <div className="relative w-12 h-12 rounded-xl overflow-hidden bg-stone-100 border border-stone-300 shrink-0 shadow-2xs">
                                    <img
                                      src={fabric.image}
                                      alt={fabric.name}
                                      referrerPolicy="no-referrer"
                                      className="w-full h-full object-cover"
                                    />
                                  </div>
                                )}

                                <div className="flex-1 min-w-0">
                                  <div className="flex items-start justify-between gap-1">
                                    <div className="flex items-center gap-1.5 min-w-0">
                                      <div className={`w-4 h-4 rounded-full border shrink-0 flex items-center justify-center ${
                                        isSelected ? 'border-[#8a532b] bg-[#8a532b]' : 'border-[#C8BEB5] bg-white'
                                      }`}>
                                        {isSelected && <Check className="w-2.5 h-2.5 text-white" />}
                                      </div>
                                      <span className="font-bold text-xs text-[#2C1810] truncate">{fabric.name}</span>
                                    </div>
                                    <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded-md shrink-0 ${
                                      fabric.priceDiff === 0 
                                        ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' 
                                        : 'bg-[#8a532b]/10 text-[#8a532b] border border-[#8a532b]/20'
                                    }`}>
                                      {fabric.priceDiff === 0 ? 'Base' : `+${formatPrice(fabric.priceDiff, settings.currency)}`}
                                    </span>
                                  </div>

                                  <p className="text-[11px] text-[#7A6A60] leading-snug mt-1 line-clamp-2">
                                    {fabric.description}
                                  </p>
                                </div>
                              </div>

                              <div className="flex items-center justify-between gap-1 pt-1.5 border-t border-[#F0EBE6] text-[10px]">
                                <div className="flex items-center gap-1 overflow-hidden flex-wrap">
                                  {fabric.badges && fabric.badges.slice(0, 2).map((b, bIdx) => (
                                    <span
                                      key={bIdx}
                                      className="px-1.5 py-0.5 rounded-md bg-[#FAF8F5] border border-[#E8E2DC] text-[#7A6A60] font-medium"
                                    >
                                      {b}
                                    </span>
                                  ))}
                                  {fabric.badges && fabric.badges.length > 2 && (
                                    <span className="text-[9px] text-[#8C7A70] font-bold">
                                      +{fabric.badges.length - 2}
                                    </span>
                                  )}
                                </div>

                                <button
                                  type="button"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    setActiveFabricInfoModal(fabric);
                                  }}
                                  className="text-[#8a532b] hover:text-[#5C3D2E] font-bold flex items-center gap-1 hover:underline p-0.5 shrink-0"
                                >
                                  <Info className="w-3 h-3" />
                                  <span>Ficha</span>
                                </button>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                      )}
                    </div>

                    {/* PASO 2: PALETA DE COLORES O CUADROS DE TELAS ESTAMPADAS */}
                    {isPatternFabric ? (
                      <div id="step-cushion-colors" className="space-y-2 pt-2 border-t border-[#F0EBE6] scroll-mt-4">
                        <div className="flex items-center justify-between text-xs">
                          <span className="font-bold text-[#2C1810] flex items-center gap-1.5">
                            <span className="px-1.5 py-0.5 rounded bg-[#8a532b]/10 text-[#8a532b] text-[10px] font-extrabold">PASO 2</span>
                            <ImageIcon className="w-3.5 h-3.5 text-[#8a532b]" />
                            Diseño Estampado: <span className="text-[#8a532b] font-extrabold">{selectedPatternObj?.name || 'Selecciona un patrón'}</span>
                          </span>
                          <span className="text-[10px] text-[#8C7A70]">
                            {availablePatterns.length} diseños disponibles
                          </span>
                        </div>

                        {/* Banner explicativo para estampados */}
                        <div className="flex items-start gap-2 p-2.5 bg-[#8a532b]/10 rounded-xl border border-[#8a532b]/20 text-[11px] text-[#5C3D2E] leading-tight shadow-2xs">
                          <Sparkles className="w-4 h-4 text-[#8a532b] shrink-0 mt-0.5" />
                          <div>
                            <p className="font-bold text-[#8a532b]">Catálogo Visual de Telas Estampadas:</p>
                            <p className="text-[10.5px] text-[#7A6A60] mt-0.5">
                              Selecciona el cuadro con la muestra textil que deseas para tu cojín. Confeccionado con tela decorativa suave de alta durabilidad.
                            </p>
                          </div>
                        </div>

                        {/* Grid de cuadros pequeños con imágenes de las telas disponibles */}
                        {availablePatterns.length === 0 ? (
                          <div className="p-4 rounded-2xl bg-amber-50 border border-dashed border-amber-200 text-center space-y-1">
                            <p className="text-xs font-bold text-amber-900">Actualmente no hay estampados disponibles</p>
                            <p className="text-[11px] text-amber-700">Estado de sin stock de telas estampadas activo. Puedes elegir otra categoría de tela como lino o microfibra.</p>
                          </div>
                        ) : (
                          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 max-h-56 overflow-y-auto p-2 bg-[#FAF8F5] rounded-xl border border-[#E8E2DC]">
                            {availablePatterns.map((pat) => {
                              const isSelected = selectedPatternObj?.id === pat.id;
                              return (
                                <button
                                  key={pat.id}
                                  type="button"
                                  onClick={() => {
                                    setSelectedPatternId(pat.id);
                                    scrollToStep('step-cushion-borders');
                                  }}
                                  className={`group flex flex-col items-center p-1.5 rounded-xl border text-left transition-all cursor-pointer bg-white ${
                                    isSelected
                                      ? 'border-[#8a532b] ring-2 ring-[#8a532b]/30 shadow-md scale-[1.02]'
                                      : 'border-[#E8E2DC] hover:border-[#8a532b]/50 hover:shadow-xs'
                                  }`}
                                >
                                  <div className="relative aspect-square w-full rounded-lg overflow-hidden bg-stone-100 border border-stone-200">
                                    <img
                                      src={pat.image}
                                      alt={pat.name}
                                      referrerPolicy="no-referrer"
                                      className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-110"
                                    />
                                    {isSelected && (
                                      <div className="absolute top-1 right-1 w-5 h-5 bg-[#8a532b] text-white rounded-full flex items-center justify-center shadow-xs">
                                        <Check className="w-3 h-3 stroke-[3]" />
                                      </div>
                                    )}
                                    <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-colors pointer-events-none" />
                                  </div>
                                  <span className="w-full text-center text-[11px] font-bold text-[#2C1810] truncate mt-1.5 px-0.5">
                                    {pat.name}
                                  </span>
                                  {pat.description && (
                                    <span className="w-full text-center text-[9.5px] text-[#7A6A60] truncate px-0.5">
                                      {pat.description}
                                    </span>
                                  )}
                                </button>
                              );
                            })}
                          </div>
                        )}
                      </div>
                    ) : (
                      /* PALETA DE COLORES O CUADROS DE TEXTALINA */
                      <div id="step-cushion-colors" className="space-y-2 pt-2 border-t border-[#F0EBE6] scroll-mt-4">
                        <div className="flex items-center justify-between text-xs">
                          <span className="font-bold text-[#2C1810] flex items-center gap-1.5">
                            <span className="px-1.5 py-0.5 rounded bg-[#8a532b]/10 text-[#8a532b] text-[10px] font-extrabold">PASO 2</span>
                            <Palette className="w-3.5 h-3.5 text-[#8a532b]" />
                            {isTextalina ? 'Muestra Textalina:' : 'Color del Cojín:'}{' '}
                            <span className="text-[#8a532b] font-extrabold">{selectedCushionColor}</span>
                          </span>
                          <span className="text-[10px] text-[#8C7A70]">
                            {isTextalina 
                              ? `${availableTextalinaOptions.length} tonos con foto de muestra` 
                              : `${availableCushionColors.length} colores disponibles`}
                          </span>
                        </div>

                        {/* Notificación informativa para Textalina */}
                        {isTextalina && (
                          <div className="flex items-start gap-2 p-2.5 bg-amber-50/90 rounded-xl border border-amber-200/80 text-[11px] text-[#5C3D2E] leading-tight shadow-2xs">
                            <Sparkles className="w-4 h-4 text-[#8a532b] shrink-0 mt-0.5" />
                            <div>
                              <p className="font-bold text-[#8a532b]">Tela Textalina Premium (Exterior e Interior):</p>
                              <p className="text-[10.5px] text-[#7A6A60] mt-0.5">
                                Tejido transpirable de alta resistencia al sol y humedad. Haz clic en la muestra para seleccionarla o en la lupa para ampliarla.
                              </p>
                            </div>
                          </div>
                        )}

                        {/* Cuadros visuales con fotos para Textalina */}
                        {isTextalina ? (
                          availableTextalinaOptions.length === 0 ? (
                            <div className="p-4 rounded-2xl bg-amber-50 border border-dashed border-amber-200 text-center space-y-1">
                              <p className="text-xs font-bold text-amber-900">Actualmente no hay tonos de Textalina en inventario</p>
                              <p className="text-[11px] text-amber-700">Estado de sin stock de Textalina activo. Puedes consultar nuevos tonos bajo pedido por WhatsApp.</p>
                            </div>
                          ) : (
                          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 p-2 bg-[#FAF8F5] rounded-xl border border-[#E8E2DC]">
                            {availableTextalinaOptions.map((tex) => {
                              const isSelected = selectedCushionColor.toLowerCase() === tex.name.toLowerCase();
                              return (
                                <div
                                  key={tex.id}
                                  onClick={() => {
                                    setSelectedCushionColor(tex.name);
                                    scrollToStep('step-cushion-borders');
                                  }}
                                  className={`group relative flex flex-col p-1.5 rounded-xl border text-left transition-all cursor-pointer bg-white ${
                                    isSelected
                                      ? 'border-[#8a532b] ring-2 ring-[#8a532b]/30 shadow-md scale-[1.02]'
                                      : 'border-[#E8E2DC] hover:border-[#8a532b]/50 hover:shadow-xs'
                                  }`}
                                >
                                  <div className="relative aspect-square w-full rounded-lg overflow-hidden bg-stone-100 border border-stone-200">
                                    <img
                                      src={tex.image}
                                      alt={tex.name}
                                      referrerPolicy="no-referrer"
                                      className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-110"
                                    />
                                    {isSelected && (
                                      <div className="absolute top-1 right-1 w-5 h-5 bg-[#8a532b] text-white rounded-full flex items-center justify-center shadow-xs z-10">
                                        <Check className="w-3 h-3 stroke-[3]" />
                                      </div>
                                    )}
                                    {tex.hex && (
                                      <div
                                        className="absolute bottom-1 left-1 w-3.5 h-3.5 rounded-full border border-white shadow-2xs z-10"
                                        style={{ backgroundColor: tex.hex }}
                                        title={`Tono: ${tex.name}`}
                                      />
                                    )}
                                    <button
                                      type="button"
                                      onClick={(e) => {
                                        e.stopPropagation();
                                        setPreviewSampleModal({
                                          isOpen: true,
                                          title: `Textalina ${tex.name}`,
                                          image: tex.image,
                                          description: tex.description || 'Tejido Textalina de alta resistencia con protección para exteriores e interiores.',
                                          hex: tex.hex,
                                        });
                                      }}
                                      className="absolute bottom-1 right-1 p-1 rounded-md bg-black/60 hover:bg-black/80 text-white transition-opacity opacity-80 hover:opacity-100 z-10 cursor-pointer"
                                      title="Ver foto ampliada de la tela"
                                    >
                                      <ZoomIn className="w-3 h-3" />
                                    </button>
                                  </div>
                                  <span className="w-full text-center text-[11.5px] font-bold text-[#2C1810] truncate mt-1.5 px-0.5">
                                    {tex.name}
                                  </span>
                                  {tex.description && (
                                    <span className="w-full text-center text-[9.5px] text-[#7A6A60] truncate px-0.5">
                                      {tex.description}
                                    </span>
                                  )}
                                </div>
                              );
                            })}
                          </div>
                          )
                        ) : (
                          <>
                            {/* Filtros de Categoría de Color (solo para telas con paleta amplia) */}
                            <div className="flex items-center gap-1 overflow-x-auto pb-1 scrollbar-none text-[11px]">
                              {['Todos', 'Neutros', 'Cálidos', 'Azules', 'Verdes', 'Vivos'].map((cat) => (
                                <button
                                  key={cat}
                                  type="button"
                                  onClick={() => setCushionCategoryFilter(cat)}
                                  className={`px-2.5 py-1 rounded-lg font-medium transition-all whitespace-nowrap cursor-pointer ${
                                    cushionCategoryFilter === cat
                                      ? 'bg-[#2C1810] text-white font-bold shadow-xs'
                                      : 'bg-[#F0EBE6] text-[#5C4033] hover:bg-[#E2DAD2]'
                                  }`}
                                >
                                  {cat}
                                </button>
                              ))}
                            </div>

                            {/* Grid de colores lisos */}
                            <div className="grid grid-cols-3 sm:grid-cols-4 gap-2 max-h-48 overflow-y-auto p-1.5 bg-[#FAF8F5] rounded-xl border border-[#E8E2DC]">
                              {filteredCushionColors.map((c) => {
                                const isSelected = selectedCushionColor === c.name;
                                return (
                                  <button
                                    key={c.name}
                                    type="button"
                                    onClick={() => {
                                      setSelectedCushionColor(c.name);
                                      scrollToStep('step-cushion-borders');
                                    }}
                                    className={`flex items-center gap-2 p-1.5 rounded-lg border text-left text-xs transition-all cursor-pointer ${
                                      isSelected
                                        ? 'border-[#2C1810] bg-white ring-2 ring-[#2C1810]/20 shadow-xs'
                                        : 'border-[#E8E2DC] bg-white hover:border-[#C8BEB5]'
                                    }`}
                                  >
                                    <span
                                      className="w-4 h-4 rounded-full border border-black/20 shrink-0 shadow-2xs"
                                      style={{ backgroundColor: c.hex }}
                                    />
                                    <span className="truncate text-[11px] font-semibold text-[#2C1810]">
                                      {c.name}
                                    </span>
                                  </button>
                                );
                              })}
                            </div>
                          </>
                        )}
                      </div>
                    )}

                    {/* PASO 3: COLOR DE BORDES / RIBETE DEL COJÍN */}
                    <div id="step-cushion-borders" className="pt-2.5 border-t border-[#F0EBE6] space-y-2.5 scroll-mt-4">
                      <div className="flex items-center justify-between text-xs">
                        <span className="font-bold text-[#2C1810] flex items-center gap-1.5">
                          <span className="px-1.5 py-0.5 rounded bg-[#8a532b]/10 text-[#8a532b] text-[10px] font-extrabold">PASO 3</span>
                          <Scissors className="w-3.5 h-3.5 text-[#8a532b]" />
                          <span>Bordes y Ribete (Vivo):</span>
                        </span>
                        <button
                          type="button"
                          onClick={() => setShowBorderExamplesModal(true)}
                          className="inline-flex items-center gap-1 text-[11px] font-bold text-[#8a532b] hover:text-[#6e4121] hover:underline cursor-pointer bg-[#8a532b]/10 px-2 py-0.5 rounded-md transition-colors"
                        >
                          <Eye className="w-3 h-3" />
                          <span>Ver comparación visual</span>
                        </button>
                      </div>

                      {/* Cuadro Visual de Comparación de Bordes (Sin Bordes vs Con Ribete) */}
                      <div className="grid grid-cols-2 gap-2.5">
                        {/* Opción 1: Sin Bordes de Contraste (Mismo color) */}
                        <div
                          onClick={() => {
                            setCustomBorderEnabled(false);
                            scrollToStep('step-cushion-backrest');
                          }}
                          className={`relative group p-2.5 rounded-2xl border-2 transition-all cursor-pointer flex flex-col justify-between ${
                            !customBorderEnabled
                              ? 'border-[#8a532b] bg-white ring-2 ring-[#8a532b]/20 shadow-xs'
                              : 'border-[#E8E2DC] bg-[#FAF8F5] hover:border-[#C8BEB5] hover:bg-white'
                          }`}
                        >
                          <div className="space-y-1.5">
                            <div className="relative aspect-16/10 rounded-xl overflow-hidden bg-stone-100 border border-stone-200 shadow-2xs">
                              <img
                                src={borderStyleExamples.sinBordesImage}
                                alt="Sin Bordes (Mismo Color)"
                                referrerPolicy="no-referrer"
                                className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                              />
                              <button
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setPreviewSampleModal({
                                    isOpen: true,
                                    title: borderStyleExamples.sinBordesTitle || 'Sin Bordes de Contraste (Mismo Tono)',
                                    image: borderStyleExamples.sinBordesImage,
                                    description: borderStyleExamples.sinBordesDescription || 'Acabado sobrio y uniforme donde las costuras y ribetes se elaboran exactamente en la misma tela y color del cojín.',
                                  });
                                }}
                                title="Ampliar foto"
                                className="absolute bottom-1.5 right-1.5 p-1 rounded-full bg-black/60 hover:bg-black/80 text-white backdrop-blur-xs transition-colors cursor-pointer shadow-xs"
                              >
                                <ZoomIn className="w-3.5 h-3.5" />
                              </button>
                              <span className="absolute top-1.5 left-1.5 px-2 py-0.5 rounded-full bg-black/60 backdrop-blur-xs text-white text-[9.5px] font-bold">
                                Mismo Tono
                              </span>
                            </div>

                            <div>
                              <div className="flex items-center justify-between">
                                <h4 className="text-xs font-bold text-[#2C1810] leading-tight">
                                  Sin Bordes de Contraste
                                </h4>
                                {!customBorderEnabled && (
                                  <span className="w-4 h-4 rounded-full bg-[#8a532b] text-white flex items-center justify-center shrink-0">
                                    <Check className="w-2.5 h-2.5 stroke-[3]" />
                                  </span>
                                )}
                              </div>
                              <p className="text-[10px] text-stone-500 mt-0.5 leading-snug line-clamp-2">
                                Ribete en la misma tela. Look liso y uniforme.
                              </p>
                            </div>
                          </div>

                          <div className={`mt-2 pt-1.5 border-t text-center text-[10px] font-bold transition-colors ${
                            !customBorderEnabled ? 'border-[#8a532b]/20 text-[#8a532b]' : 'border-stone-200 text-stone-600'
                          }`}>
                            {!customBorderEnabled ? '✓ Seleccionado' : 'Elegir Mismo Color'}
                          </div>
                        </div>

                        {/* Opción 2: Con Bordes / Ribete en Contraste (Vivo) */}
                        <div
                          onClick={() => setCustomBorderEnabled(true)}
                          className={`relative group p-2.5 rounded-2xl border-2 transition-all cursor-pointer flex flex-col justify-between ${
                            customBorderEnabled
                              ? 'border-[#8a532b] bg-white ring-2 ring-[#8a532b]/20 shadow-xs'
                              : 'border-[#E8E2DC] bg-[#FAF8F5] hover:border-[#C8BEB5] hover:bg-white'
                          }`}
                        >
                          <div className="space-y-1.5">
                            <div className="relative aspect-16/10 rounded-xl overflow-hidden bg-stone-100 border border-stone-200 shadow-2xs">
                              <img
                                src={borderStyleExamples.conBordesImage}
                                alt="Con Bordes en Contraste"
                                referrerPolicy="no-referrer"
                                className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                              />
                              <button
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setPreviewSampleModal({
                                    isOpen: true,
                                    title: borderStyleExamples.conBordesTitle || 'Con Bordes / Ribete en Contraste (Vivo)',
                                    image: borderStyleExamples.conBordesImage,
                                    description: borderStyleExamples.conBordesDescription || 'Cordón perimetral decorativo (vivo) en un color de contraste que resalta y perfila la silueta del cojín.',
                                  });
                                }}
                                title="Ampliar foto"
                                className="absolute bottom-1.5 right-1.5 p-1 rounded-full bg-black/60 hover:bg-black/80 text-white backdrop-blur-xs transition-colors cursor-pointer shadow-xs"
                              >
                                <ZoomIn className="w-3.5 h-3.5" />
                              </button>
                              <span className="absolute top-1.5 left-1.5 px-2 py-0.5 rounded-full bg-[#8a532b] text-white text-[9.5px] font-bold">
                                Con Ribete (Vivo)
                              </span>
                            </div>

                            <div>
                              <div className="flex items-center justify-between">
                                <h4 className="text-xs font-bold text-[#2C1810] leading-tight">
                                  Con Ribete en Contraste
                                </h4>
                                {customBorderEnabled && (
                                  <span className="w-4 h-4 rounded-full bg-[#8a532b] text-white flex items-center justify-center shrink-0">
                                    <Check className="w-2.5 h-2.5 stroke-[3]" />
                                  </span>
                                )}
                              </div>
                              <p className="text-[10px] text-stone-500 mt-0.5 leading-snug line-clamp-2">
                                Cordón perimetral en color que resalta la forma.
                              </p>
                            </div>
                          </div>

                          <div className={`mt-2 pt-1.5 border-t text-center text-[10px] font-bold transition-colors ${
                            customBorderEnabled ? 'border-[#8a532b]/20 text-[#8a532b]' : 'border-stone-200 text-stone-600'
                          }`}>
                            {customBorderEnabled ? `✓ ${selectedBorderColor}` : 'Elegir Con Ribete'}
                          </div>
                        </div>
                      </div>

                      {/* Paleta de colores para los bordes cuando está activado */}
                      {customBorderEnabled && (
                        <div className="space-y-1.5 pt-1 animate-fadeIn">
                          <div className="flex items-center justify-between">
                            <span className="text-[10px] uppercase font-bold text-[#8C7A70] block">
                              Elige el color del ribete / bordes:
                            </span>
                            <span className="text-[10.5px] font-bold text-[#8a532b]">
                              Color: {selectedBorderColor}
                            </span>
                          </div>
                          <div className="grid grid-cols-3 sm:grid-cols-4 gap-1.5 max-h-36 overflow-y-auto p-1.5 bg-[#FAF8F5] rounded-xl border border-[#E8E2DC]">
                            {borderColors.map((bc) => {
                              const isSelected = selectedBorderColor === bc.name;
                              return (
                                <button
                                  key={bc.name}
                                  type="button"
                                  onClick={() => {
                                    setSelectedBorderColor(bc.name);
                                    scrollToStep('step-cushion-backrest');
                                  }}
                                  className={`flex items-center gap-1.5 p-1.5 rounded-lg border text-left text-xs transition-all cursor-pointer ${
                                    isSelected
                                      ? 'border-[#8a532b] bg-white ring-2 ring-[#8a532b]/20 shadow-xs'
                                      : 'border-[#E8E2DC] bg-white hover:border-[#C8BEB5]'
                                  }`}
                                >
                                  <span
                                    className="w-3.5 h-3.5 rounded-full border border-black/25 shrink-0 shadow-2xs"
                                    style={{ backgroundColor: bc.hex }}
                                  />
                                  <span className="truncate text-[10.5px] font-semibold text-[#2C1810]">
                                    {bc.name}
                                  </span>
                                </button>
                              );
                            })}
                          </div>
                        </div>
                      )}
                    </div>

                    {/* PASO 4: ESTILO DE ESPALDAR / RESPALDO (COSTURA VS CAPITONEADO CON BOTONES) */}
                    <div id="step-cushion-backrest" className="pt-2 border-t border-[#F0EBE6] space-y-2 scroll-mt-4">
                      <div className="flex items-center justify-between text-xs">
                        <span className="font-bold text-[#2C1810] flex items-center gap-1.5">
                          <span className="px-1.5 py-0.5 rounded bg-[#8a532b]/10 text-[#8a532b] text-[10px] font-extrabold">PASO 4</span>
                          <Sparkles className="w-3.5 h-3.5 text-[#8a532b]" />
                          Estilo de Respaldo / Espaldar:
                        </span>
                        <button
                          type="button"
                          onClick={() => setShowStyleExamplesModal(true)}
                          className="flex items-center gap-1 text-[11px] font-bold text-[#8a532b] hover:text-[#5C3D2E] underline underline-offset-2 cursor-pointer transition-colors"
                        >
                          <Eye className="w-3.5 h-3.5" />
                          <span>Ver fotos de ejemplo</span>
                        </button>
                      </div>

                      {/* Tarjetas interactivas de selección */}
                      <div className="grid grid-cols-2 gap-2.5">
                        {/* Opción 1: Con Costura */}
                        <button
                          type="button"
                          onClick={() => {
                            setSelectedBackrestStyle('costura');
                            scrollToStep('step-order-actions');
                          }}
                          className={`flex items-center gap-2.5 p-2 rounded-xl border text-left transition-all cursor-pointer ${
                            selectedBackrestStyle === 'costura'
                              ? 'border-[#8a532b] bg-[#8a532b]/5 ring-2 ring-[#8a532b]/30 shadow-xs'
                              : 'border-[#E8E2DC] bg-white hover:border-[#C8BEB5]'
                          }`}
                        >
                          <div className="w-11 h-11 rounded-lg overflow-hidden shrink-0 bg-stone-100 border border-stone-200">
                            <img
                              src={styleExamples.costuraImage}
                              alt="Con Costura"
                              referrerPolicy="no-referrer"
                              className="w-full h-full object-cover"
                            />
                          </div>
                          <div className="min-w-0 flex-1">
                            <div className="flex items-center justify-between">
                              <span className="text-xs font-bold text-[#2C1810] truncate">Con Costura</span>
                              {selectedBackrestStyle === 'costura' && (
                                <Check className="w-3.5 h-3.5 text-[#8a532b] stroke-[3]" />
                              )}
                            </div>
                            <p className="text-[10px] text-[#7A6A60] leading-tight mt-0.5">Líneas acolchadas</p>
                          </div>
                        </button>

                        {/* Opción 2: Capitoneado (Con Botones) */}
                        <button
                          type="button"
                          onClick={() => {
                            setSelectedBackrestStyle('botones');
                            scrollToStep('step-order-actions');
                          }}
                          className={`flex items-center gap-2.5 p-2 rounded-xl border text-left transition-all cursor-pointer ${
                            selectedBackrestStyle === 'botones'
                              ? 'border-[#8a532b] bg-[#8a532b]/5 ring-2 ring-[#8a532b]/30 shadow-xs'
                              : 'border-[#E8E2DC] bg-white hover:border-[#C8BEB5]'
                          }`}
                        >
                          <div className="w-11 h-11 rounded-lg overflow-hidden shrink-0 bg-stone-100 border border-stone-200">
                            <img
                              src={styleExamples.botonesImage}
                              alt="Capitoneado con Botones"
                              referrerPolicy="no-referrer"
                              className="w-full h-full object-cover"
                            />
                          </div>
                          <div className="min-w-0 flex-1">
                            <div className="flex items-center justify-between">
                              <span className="text-xs font-bold text-[#2C1810] truncate">Capitoneado</span>
                              {selectedBackrestStyle === 'botones' && (
                                <Check className="w-3.5 h-3.5 text-[#8a532b] stroke-[3]" />
                              )}
                            </div>
                            <p className="text-[10px] text-[#7A6A60] leading-tight mt-0.5">Con Botones</p>
                          </div>
                        </button>
                      </div>
                    </div>
                  </div>
                ) : (
                  /* 6. OPCIÓN MECEDORAS: Color de la mecedora y Personalización del Cojín Incluido */
                  <div className="space-y-3 pt-1">
                    {/* PASO 1: Color de la mecedora */}
                    <div id="step-rocker-color" className="space-y-1.5 scroll-mt-4">
                      <div className="flex items-center justify-between text-xs">
                        <span className="font-bold text-[#2C1810] flex items-center gap-1.5">
                          <span className="px-1.5 py-0.5 rounded bg-[#8a532b]/10 text-[#8a532b] text-[10px] font-extrabold">PASO 1</span>
                          Color de la mecedora: <span className="text-[#8a532b] font-extrabold">{selectedColor}</span>
                        </span>
                        <span className="text-[10px] text-[#8C7A70]">Colores de fábrica</span>
                      </div>
                      <div className="grid grid-cols-3 gap-2">
                        {rockerColors.map((c) => {
                          const isSelected = selectedColor === c.name;
                          return (
                            <button
                              key={c.name}
                              type="button"
                              onClick={() => {
                                setSelectedColor(c.name);
                                scrollToStep('step-rocker-fabric');
                              }}
                              className={`flex items-center justify-center gap-2 px-2.5 py-2 rounded-xl border text-xs font-semibold transition-all cursor-pointer ${
                                isSelected
                                  ? 'border-[#2C1810] bg-[#2C1810] text-white shadow-xs'
                                  : 'border-[#E8E2DC] bg-white hover:border-[#C8BEB5] text-[#5C4033]'
                              }`}
                            >
                              <span
                                className="w-4 h-4 rounded-full border border-black/25 shrink-0 shadow-2xs"
                                style={{ backgroundColor: c.hex }}
                              />
                              <span className="truncate">{c.name}</span>
                            </button>
                          );
                        })}
                      </div>
                    </div>

                    {/* PERSONALIZACIÓN COMPLETA DEL COJÍN INCLUIDO EN LA MECEDORA */}
                    <div className="p-3 bg-[#FAF8F5] rounded-2xl border border-[#E8E2DC] space-y-3">
                      <div className="flex items-center justify-between text-xs border-b border-[#E8E2DC] pb-2">
                        <span className="font-bold text-[#2C1810] flex items-center gap-1.5">
                          <Sparkle className="w-3.5 h-3.5 text-[#8a532b]" />
                          Personalización del Cojín Incluido:
                        </span>
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200">
                          Cojín Incluido
                        </span>
                      </div>

                      {/* PASO 2: TIPO DE TELA DEL COJÍN */}
                      <div id="step-rocker-fabric" className="space-y-1.5 scroll-mt-4">
                        <div className="flex items-center justify-between text-xs">
                          <span className="font-bold text-[#2C1810] flex items-center gap-1.5">
                            <span className="px-1.5 py-0.5 rounded bg-[#8a532b]/10 text-[#8a532b] text-[10px] font-extrabold">PASO 2</span>
                            <Layers className="w-3.5 h-3.5 text-[#8a532b]" />
                            Tipo de Tela del Cojín: <span className="text-[#8a532b] font-extrabold">{selectedFabricObj?.name || (cushionFabrics.length === 0 ? 'Sin stock' : 'Por seleccionar')}</span>
                          </span>
                          <span className="text-[10px] text-[#8C7A70]">Elige el tipo de tejido</span>
                        </div>
                        
                        {cushionFabrics.length === 0 ? (
                          <div className="p-4 rounded-2xl bg-amber-50 border border-dashed border-amber-200 text-center space-y-1">
                            <p className="text-xs font-bold text-amber-900">Actualmente no hay telas registradas en inventario</p>
                            <p className="text-[11px] text-amber-700">Estado de sin stock de telas activo. Puedes consultar confección especial por WhatsApp.</p>
                          </div>
                        ) : (
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                            {cushionFabrics.map((fabric) => {
                            const isSelected = selectedFabricId === fabric.id;
                            return (
                              <div
                                key={fabric.id}
                                onClick={() => {
                                  setSelectedFabricId(fabric.id);
                                  scrollToStep('step-rocker-cushion-colors');
                                }}
                                className={`p-3 rounded-2xl border text-left transition-all cursor-pointer flex flex-col justify-between gap-2 ${
                                  isSelected
                                    ? 'border-[#8a532b] bg-[#FAF5F0] ring-2 ring-[#8a532b]/20 shadow-xs'
                                    : 'border-[#E8E2DC] bg-white hover:border-[#C8BEB5]'
                                }`}
                              >
                                <div className="flex items-start gap-2.5">
                                  {fabric.image && (
                                    <div className="relative w-12 h-12 rounded-xl overflow-hidden bg-stone-100 border border-stone-300 shrink-0 shadow-2xs">
                                      <img
                                        src={fabric.image}
                                        alt={fabric.name}
                                        referrerPolicy="no-referrer"
                                        className="w-full h-full object-cover"
                                      />
                                    </div>
                                  )}

                                  <div className="flex-1 min-w-0">
                                    <div className="flex items-start justify-between gap-1">
                                      <div className="flex items-center gap-1.5 min-w-0">
                                        <div className={`w-4 h-4 rounded-full border shrink-0 flex items-center justify-center ${
                                          isSelected ? 'border-[#8a532b] bg-[#8a532b]' : 'border-[#C8BEB5] bg-white'
                                        }`}>
                                          {isSelected && <Check className="w-2.5 h-2.5 text-white" />}
                                        </div>
                                        <span className="font-bold text-xs text-[#2C1810] truncate">{fabric.name}</span>
                                      </div>
                                      <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded-md shrink-0 ${
                                        fabric.priceDiff === 0 
                                          ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' 
                                          : 'bg-[#8a532b]/10 text-[#8a532b] border border-[#8a532b]/20'
                                      }`}>
                                        {fabric.priceDiff === 0 ? 'Incluido' : `+${formatPrice(fabric.priceDiff, settings.currency)}`}
                                      </span>
                                    </div>

                                    <p className="text-[11px] text-[#7A6A60] leading-snug mt-1 line-clamp-2">
                                      {fabric.description}
                                    </p>
                                  </div>
                                </div>

                                <div className="flex items-center justify-between gap-1 pt-1.5 border-t border-[#F0EBE6] text-[10px]">
                                  <div className="flex items-center gap-1 overflow-hidden flex-wrap">
                                    {fabric.badges && fabric.badges.slice(0, 2).map((b, bIdx) => (
                                      <span
                                        key={bIdx}
                                        className="px-1.5 py-0.5 rounded-md bg-[#FAF8F5] border border-[#E8E2DC] text-[#7A6A60] font-medium"
                                      >
                                        {b}
                                      </span>
                                    ))}
                                    {fabric.badges && fabric.badges.length > 2 && (
                                      <span className="text-[9px] text-[#8C7A70] font-bold">
                                        +{fabric.badges.length - 2}
                                      </span>
                                    )}
                                  </div>

                                  <button
                                    type="button"
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      setActiveFabricInfoModal(fabric);
                                    }}
                                    className="text-[#8a532b] hover:text-[#5C3D2E] font-bold flex items-center gap-1 hover:underline p-0.5 shrink-0"
                                  >
                                    <Info className="w-3 h-3" />
                                    <span>Ficha</span>
                                  </button>
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      )}
                    </div>

                      {/* PASO 3: PALETA DE COLORES O CUADROS DE TELAS ESTAMPADAS */}
                      {isPatternFabric ? (
                        <div id="step-rocker-cushion-colors" className="space-y-2 pt-2 border-t border-[#E8E2DC] scroll-mt-4">
                          <div className="flex items-center justify-between text-xs">
                            <span className="font-bold text-[#2C1810] flex items-center gap-1.5">
                              <span className="px-1.5 py-0.5 rounded bg-[#8a532b]/10 text-[#8a532b] text-[10px] font-extrabold">PASO 3</span>
                              <ImageIcon className="w-3.5 h-3.5 text-[#8a532b]" />
                              Diseño Estampado: <span className="text-[#8a532b] font-extrabold">{selectedPatternObj?.name || 'Selecciona un patrón'}</span>
                            </span>
                            <span className="text-[10px] text-[#8C7A70]">
                              {availablePatterns.length} diseños disponibles
                            </span>
                          </div>

                          {/* Banner explicativo para estampados */}
                          <div className="flex items-start gap-2 p-2.5 bg-[#8a532b]/10 rounded-xl border border-[#8a532b]/20 text-[11px] text-[#5C3D2E] leading-tight shadow-2xs">
                            <Sparkles className="w-4 h-4 text-[#8a532b] shrink-0 mt-0.5" />
                            <div>
                              <p className="font-bold text-[#8a532b]">Catálogo Visual de Telas Estampadas:</p>
                              <p className="text-[10.5px] text-[#7A6A60] mt-0.5">
                                Selecciona el cuadro con la muestra textil que deseas para los cojines de tu mecedora. Confeccionado con tela decorativa suave de alta durabilidad.
                              </p>
                            </div>
                          </div>

                          {/* Grid de cuadros con imágenes de las telas estampadas disponibles */}
                          {availablePatterns.length === 0 ? (
                            <div className="p-4 rounded-2xl bg-amber-50 border border-dashed border-amber-200 text-center space-y-1">
                              <p className="text-xs font-bold text-amber-900">Actualmente no hay estampados disponibles</p>
                              <p className="text-[11px] text-amber-700">Estado de sin stock de estampados activo. Puedes elegir otra categoría de tela.</p>
                            </div>
                          ) : (
                            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 max-h-56 overflow-y-auto p-2 bg-white rounded-xl border border-[#E8E2DC]">
                              {availablePatterns.map((pat) => {
                                const isSelected = selectedPatternObj?.id === pat.id;
                                return (
                                  <button
                                    key={pat.id}
                                    type="button"
                                    onClick={() => {
                                      setSelectedPatternId(pat.id);
                                      scrollToStep('step-rocker-cushion-borders');
                                    }}
                                    className={`group flex flex-col items-center p-1.5 rounded-xl border text-left transition-all cursor-pointer bg-white ${
                                      isSelected
                                        ? 'border-[#8a532b] ring-2 ring-[#8a532b]/30 shadow-md scale-[1.02]'
                                        : 'border-[#E8E2DC] hover:border-[#8a532b]/50 hover:shadow-xs'
                                    }`}
                                  >
                                    <div className="relative aspect-square w-full rounded-lg overflow-hidden bg-stone-100 border border-stone-200">
                                      <img
                                        src={pat.image}
                                        alt={pat.name}
                                        referrerPolicy="no-referrer"
                                        className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-110"
                                      />
                                      {isSelected && (
                                        <div className="absolute top-1 right-1 w-5 h-5 bg-[#8a532b] text-white rounded-full flex items-center justify-center shadow-xs">
                                          <Check className="w-3 h-3 stroke-[3]" />
                                        </div>
                                      )}
                                      <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-colors pointer-events-none" />
                                    </div>
                                    <span className="w-full text-center text-[11px] font-bold text-[#2C1810] truncate mt-1.5 px-0.5">
                                      {pat.name}
                                    </span>
                                    {pat.description && (
                                      <span className="w-full text-center text-[9.5px] text-[#7A6A60] truncate px-0.5">
                                        {pat.description}
                                      </span>
                                    )}
                                  </button>
                                );
                              })}
                            </div>
                          )}
                        </div>
                      ) : (
                        /* PALETA DE COLORES O CUADROS DE TEXTALINA */
                        <div id="step-rocker-cushion-colors" className="space-y-2 pt-2 border-t border-[#E8E2DC] scroll-mt-4">
                          <div className="flex items-center justify-between text-xs">
                            <span className="font-bold text-[#2C1810] flex items-center gap-1.5">
                              <span className="px-1.5 py-0.5 rounded bg-[#8a532b]/10 text-[#8a532b] text-[10px] font-extrabold">PASO 3</span>
                              <Palette className="w-3.5 h-3.5 text-[#8a532b]" />
                              {isTextalina ? 'Muestra Textalina:' : 'Color del Cojín:'}{' '}
                              <span className="text-[#8a532b] font-extrabold">{selectedCushionColor}</span>
                            </span>
                            <span className="text-[10px] text-[#8C7A70]">
                              {isTextalina 
                                ? `${availableTextalinaOptions.length} tonos con foto de muestra` 
                                : `${availableCushionColors.length} colores disponibles`}
                            </span>
                          </div>

                          {/* Notificación informativa para Textalina */}
                          {isTextalina && (
                            <div className="flex items-start gap-2 p-2.5 bg-amber-50/90 rounded-xl border border-amber-200/80 text-[11px] text-[#5C3D2E] leading-tight shadow-2xs">
                              <Sparkles className="w-4 h-4 text-[#8a532b] shrink-0 mt-0.5" />
                              <div>
                                <p className="font-bold text-[#8a532b]">Tela Textalina Premium (Exterior e Interior):</p>
                                <p className="text-[10.5px] text-[#7A6A60] mt-0.5">
                                  Tejido transpirable de alta resistencia al sol y humedad. Haz clic en la muestra para seleccionarla o en la lupa para ampliarla.
                                </p>
                              </div>
                            </div>
                          )}

                          {/* Cuadros visuales con fotos para Textalina */}
                          {isTextalina ? (
                            availableTextalinaOptions.length === 0 ? (
                              <div className="p-4 rounded-2xl bg-amber-50 border border-dashed border-amber-200 text-center space-y-1">
                                <p className="text-xs font-bold text-amber-900">Actualmente no hay muestras de Textalina disponibles</p>
                                <p className="text-[11px] text-amber-700">Estado de sin stock de textalina activo. Puedes elegir otra tela o consultar por WhatsApp.</p>
                              </div>
                            ) : (
                              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 p-2 bg-white rounded-xl border border-[#E8E2DC]">
                                {availableTextalinaOptions.map((tex) => {
                                  const isSelected = selectedCushionColor.toLowerCase() === tex.name.toLowerCase();
                                  return (
                                    <div
                                      key={tex.id}
                                      onClick={() => {
                                        setSelectedCushionColor(tex.name);
                                        scrollToStep('step-rocker-cushion-borders');
                                      }}
                                      className={`group relative flex flex-col p-1.5 rounded-xl border text-left transition-all cursor-pointer bg-white ${
                                        isSelected
                                          ? 'border-[#8a532b] ring-2 ring-[#8a532b]/30 shadow-md scale-[1.02]'
                                          : 'border-[#E8E2DC] hover:border-[#8a532b]/50 hover:shadow-xs'
                                      }`}
                                    >
                                      <div className="relative aspect-square w-full rounded-lg overflow-hidden bg-stone-100 border border-stone-200">
                                        <img
                                          src={tex.image}
                                          alt={tex.name}
                                          referrerPolicy="no-referrer"
                                          className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-110"
                                        />
                                        {isSelected && (
                                          <div className="absolute top-1 right-1 w-5 h-5 bg-[#8a532b] text-white rounded-full flex items-center justify-center shadow-xs z-10">
                                            <Check className="w-3 h-3 stroke-[3]" />
                                          </div>
                                        )}
                                        {tex.hex && (
                                          <div
                                            className="absolute bottom-1 left-1 w-3.5 h-3.5 rounded-full border border-white shadow-2xs z-10"
                                            style={{ backgroundColor: tex.hex }}
                                            title={`Tono: ${tex.name}`}
                                          />
                                        )}
                                        <button
                                          type="button"
                                          onClick={(e) => {
                                            e.stopPropagation();
                                            setPreviewSampleModal({
                                              isOpen: true,
                                              title: `Textalina ${tex.name}`,
                                              image: tex.image,
                                              description: tex.description || 'Tejido Textalina de alta resistencia con protección para exteriores e interiores.',
                                              hex: tex.hex,
                                            });
                                          }}
                                          className="absolute bottom-1 right-1 p-1 rounded-md bg-black/60 hover:bg-black/80 text-white transition-opacity opacity-80 hover:opacity-100 z-10 cursor-pointer"
                                          title="Ver foto ampliada de la tela"
                                        >
                                          <ZoomIn className="w-3 h-3" />
                                        </button>
                                      </div>
                                      <span className="w-full text-center text-[11.5px] font-bold text-[#2C1810] truncate mt-1.5 px-0.5">
                                        {tex.name}
                                      </span>
                                      {tex.description && (
                                        <span className="w-full text-center text-[9.5px] text-[#7A6A60] truncate px-0.5">
                                          {tex.description}
                                        </span>
                                      )}
                                    </div>
                                  );
                                })}
                              </div>
                            )
                          ) : (
                            <>
                              {/* Filtros de Categoría de Color */}
                              <div className="flex items-center gap-1 overflow-x-auto pb-1 scrollbar-none text-[11px]">
                                {['Todos', 'Neutros', 'Cálidos', 'Azules', 'Verdes', 'Vivos'].map((cat) => (
                                  <button
                                    key={cat}
                                    type="button"
                                    onClick={() => setCushionCategoryFilter(cat)}
                                    className={`px-2.5 py-1 rounded-lg font-medium transition-all whitespace-nowrap cursor-pointer ${
                                      cushionCategoryFilter === cat
                                        ? 'bg-[#2C1810] text-white font-bold shadow-xs'
                                        : 'bg-white text-[#5C4033] border border-[#E8E2DC] hover:bg-[#FAF8F5]'
                                    }`}
                                  >
                                    {cat}
                                  </button>
                                ))}
                              </div>

                              {/* Grid de colores lisos */}
                              <div className="grid grid-cols-3 sm:grid-cols-4 gap-2 max-h-48 overflow-y-auto p-1.5 bg-white rounded-xl border border-[#E8E2DC]">
                                {filteredCushionColors.map((c) => {
                                  const isSelected = selectedCushionColor === c.name;
                                  return (
                                    <button
                                      key={c.name}
                                      type="button"
                                      onClick={() => {
                                        setSelectedCushionColor(c.name);
                                        scrollToStep('step-rocker-cushion-borders');
                                      }}
                                      className={`flex items-center gap-2 p-1.5 rounded-lg border text-left text-xs transition-all cursor-pointer ${
                                        isSelected
                                          ? 'border-[#2C1810] bg-white ring-2 ring-[#2C1810]/20 shadow-xs'
                                          : 'border-[#E8E2DC] bg-white hover:border-[#C8BEB5]'
                                      }`}
                                    >
                                      <span
                                        className="w-4 h-4 rounded-full border border-black/20 shrink-0 shadow-2xs"
                                        style={{ backgroundColor: c.hex }}
                                      />
                                      <span className="truncate text-[11px] font-semibold text-[#2C1810]">
                                        {c.name}
                                      </span>
                                    </button>
                                  );
                                })}
                              </div>
                            </>
                          )}
                        </div>
                      )}

                      {/* PASO 4: COLOR DE BORDES / RIBETE DEL COJÍN */}
                      <div id="step-rocker-cushion-borders" className="pt-2.5 border-t border-[#E8E2DC] space-y-2.5 scroll-mt-4">
                        <div className="flex items-center justify-between text-xs">
                          <span className="font-bold text-[#2C1810] flex items-center gap-1.5">
                            <span className="px-1.5 py-0.5 rounded bg-[#8a532b]/10 text-[#8a532b] text-[10px] font-extrabold">PASO 4</span>
                            <Scissors className="w-3.5 h-3.5 text-[#8a532b]" />
                            <span>Bordes y Ribete (Vivo):</span>
                          </span>
                          <button
                            type="button"
                            onClick={() => setShowBorderExamplesModal(true)}
                            className="inline-flex items-center gap-1 text-[11px] font-bold text-[#8a532b] hover:text-[#6e4121] hover:underline cursor-pointer bg-[#8a532b]/10 px-2 py-0.5 rounded-md transition-colors"
                          >
                            <Eye className="w-3 h-3" />
                            <span>Ver comparación visual</span>
                          </button>
                        </div>

                        {/* Cuadro Visual de Comparación de Bordes (Sin Bordes vs Con Ribete) */}
                        <div className="grid grid-cols-2 gap-2.5">
                          {/* Opción 1: Sin Bordes de Contraste (Mismo color) */}
                          <div
                            onClick={() => {
                              setCustomBorderEnabled(false);
                              scrollToStep('step-rocker-backrest');
                            }}
                            className={`relative group p-2.5 rounded-2xl border-2 transition-all cursor-pointer flex flex-col justify-between ${
                              !customBorderEnabled
                                ? 'border-[#8a532b] bg-white ring-2 ring-[#8a532b]/20 shadow-xs'
                                : 'border-[#E8E2DC] bg-[#FAF8F5] hover:border-[#C8BEB5] hover:bg-white'
                            }`}
                          >
                            <div className="space-y-1.5">
                              <div className="relative aspect-16/10 rounded-xl overflow-hidden bg-stone-100 border border-stone-200 shadow-2xs">
                                <img
                                  src={borderStyleExamples.sinBordesImage}
                                  alt="Sin Bordes (Mismo Color)"
                                  referrerPolicy="no-referrer"
                                  className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                                />
                                <button
                                  type="button"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    setPreviewSampleModal({
                                      isOpen: true,
                                      title: borderStyleExamples.sinBordesTitle || 'Sin Bordes de Contraste (Mismo Tono)',
                                      image: borderStyleExamples.sinBordesImage,
                                      description: borderStyleExamples.sinBordesDescription || 'Acabado sobrio y uniforme donde las costuras y ribetes se elaboran exactamente en la misma tela y color del cojín.',
                                    });
                                  }}
                                  title="Ampliar foto"
                                  className="absolute bottom-1.5 right-1.5 p-1 rounded-full bg-black/60 hover:bg-black/80 text-white backdrop-blur-xs transition-colors cursor-pointer shadow-xs"
                                >
                                  <ZoomIn className="w-3.5 h-3.5" />
                                </button>
                                <span className="absolute top-1.5 left-1.5 px-2 py-0.5 rounded-full bg-black/60 backdrop-blur-xs text-white text-[9.5px] font-bold">
                                  Mismo Tono
                                </span>
                              </div>

                              <div>
                                <div className="flex items-center justify-between">
                                  <h4 className="text-xs font-bold text-[#2C1810] leading-tight">
                                    Sin Bordes de Contraste
                                  </h4>
                                  {!customBorderEnabled && (
                                    <span className="w-4 h-4 rounded-full bg-[#8a532b] text-white flex items-center justify-center shrink-0">
                                      <Check className="w-2.5 h-2.5 stroke-[3]" />
                                    </span>
                                  )}
                                </div>
                                <p className="text-[10px] text-stone-500 mt-0.5 leading-snug line-clamp-2">
                                  Ribete en la misma tela. Look liso y uniforme.
                                </p>
                              </div>
                            </div>

                            <div className={`mt-2 pt-1.5 border-t text-center text-[10px] font-bold transition-colors ${
                              !customBorderEnabled ? 'border-[#8a532b]/20 text-[#8a532b]' : 'border-stone-200 text-stone-600'
                            }`}>
                              {!customBorderEnabled ? '✓ Seleccionado' : 'Elegir Mismo Color'}
                            </div>
                          </div>

                          {/* Opción 2: Con Bordes / Ribete en Contraste (Vivo) */}
                          <div
                            onClick={() => setCustomBorderEnabled(true)}
                            className={`relative group p-2.5 rounded-2xl border-2 transition-all cursor-pointer flex flex-col justify-between ${
                              customBorderEnabled
                                ? 'border-[#8a532b] bg-white ring-2 ring-[#8a532b]/20 shadow-xs'
                                : 'border-[#E8E2DC] bg-[#FAF8F5] hover:border-[#C8BEB5] hover:bg-white'
                            }`}
                          >
                            <div className="space-y-1.5">
                              <div className="relative aspect-16/10 rounded-xl overflow-hidden bg-stone-100 border border-stone-200 shadow-2xs">
                                <img
                                  src={borderStyleExamples.conBordesImage}
                                  alt="Con Bordes en Contraste"
                                  referrerPolicy="no-referrer"
                                  className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                                />
                                <button
                                  type="button"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    setPreviewSampleModal({
                                      isOpen: true,
                                      title: borderStyleExamples.conBordesTitle || 'Con Bordes / Ribete en Contraste (Vivo)',
                                      image: borderStyleExamples.conBordesImage,
                                      description: borderStyleExamples.conBordesDescription || 'Cordón perimetral decorativo (vivo) en un color de contraste que resalta y perfila la silueta del cojín.',
                                    });
                                  }}
                                  title="Ampliar foto"
                                  className="absolute bottom-1.5 right-1.5 p-1 rounded-full bg-black/60 hover:bg-black/80 text-white backdrop-blur-xs transition-colors cursor-pointer shadow-xs"
                                >
                                  <ZoomIn className="w-3.5 h-3.5" />
                                </button>
                                <span className="absolute top-1.5 left-1.5 px-2 py-0.5 rounded-full bg-[#8a532b] text-white text-[9.5px] font-bold">
                                  Con Ribete (Vivo)
                                </span>
                              </div>

                              <div>
                                <div className="flex items-center justify-between">
                                  <h4 className="text-xs font-bold text-[#2C1810] leading-tight">
                                    Con Ribete en Contraste
                                  </h4>
                                  {customBorderEnabled && (
                                    <span className="w-4 h-4 rounded-full bg-[#8a532b] text-white flex items-center justify-center shrink-0">
                                      <Check className="w-2.5 h-2.5 stroke-[3]" />
                                    </span>
                                  )}
                                </div>
                                <p className="text-[10px] text-stone-500 mt-0.5 leading-snug line-clamp-2">
                                  Cordón perimetral en color que resalta la forma.
                                </p>
                              </div>
                            </div>

                            <div className={`mt-2 pt-1.5 border-t text-center text-[10px] font-bold transition-colors ${
                              customBorderEnabled ? 'border-[#8a532b]/20 text-[#8a532b]' : 'border-stone-200 text-stone-600'
                            }`}>
                              {customBorderEnabled ? `✓ ${selectedBorderColor}` : 'Elegir Con Ribete'}
                            </div>
                          </div>
                        </div>

                        {/* Paleta de colores para los bordes cuando está activado */}
                        {customBorderEnabled && (
                          <div className="space-y-1.5 pt-1 animate-fadeIn">
                            <div className="flex items-center justify-between">
                              <span className="text-[10px] uppercase font-bold text-[#8C7A70] block">
                                Elige el color del ribete / bordes:
                              </span>
                              <span className="text-[10.5px] font-bold text-[#8a532b]">
                                Color: {selectedBorderColor}
                              </span>
                            </div>
                            {borderColors.length === 0 ? (
                              <div className="p-3 rounded-xl bg-amber-50 border border-dashed border-amber-200 text-center space-y-0.5">
                                <p className="text-xs font-bold text-amber-900">Sin colores de ribete registrados</p>
                                <p className="text-[10.5px] text-amber-700">Se elaborará el ribete al mismo tono de la tela seleccionada.</p>
                              </div>
                            ) : (
                              <div className="grid grid-cols-3 sm:grid-cols-4 gap-1.5 max-h-36 overflow-y-auto p-1.5 bg-white rounded-xl border border-[#E8E2DC]">
                                {borderColors.map((bc) => {
                                  const isSelected = selectedBorderColor === bc.name;
                                  return (
                                    <button
                                      key={bc.name}
                                      type="button"
                                      onClick={() => {
                                        setSelectedBorderColor(bc.name);
                                        scrollToStep('step-rocker-backrest');
                                      }}
                                      className={`flex items-center gap-1.5 p-1.5 rounded-lg border text-left text-xs transition-all cursor-pointer ${
                                        isSelected
                                          ? 'border-[#8a532b] bg-white ring-2 ring-[#8a532b]/20 shadow-xs font-bold'
                                          : 'border-[#E8E2DC] bg-white hover:border-[#C8BEB5]'
                                      }`}
                                    >
                                      <span
                                        className="w-3.5 h-3.5 rounded-full border border-black/25 shrink-0 shadow-2xs"
                                        style={{ backgroundColor: bc.hex }}
                                      />
                                      <span className="truncate text-[10.5px] font-semibold text-[#2C1810]">
                                        {bc.name}
                                      </span>
                                    </button>
                                  );
                                })}
                              </div>
                            )}
                          </div>
                        )}
                      </div>

                      {/* PASO 5: ESTILO DE ESPALDAR / RESPALDO (COSTURA VS CAPITONEADO CON BOTONES) */}
                      <div id="step-rocker-backrest" className="pt-2 border-t border-[#E8E2DC] space-y-2 scroll-mt-4">
                        <div className="flex items-center justify-between text-xs">
                          <span className="font-bold text-[#2C1810] flex items-center gap-1.5">
                            <span className="px-1.5 py-0.5 rounded bg-[#8a532b]/10 text-[#8a532b] text-[10px] font-extrabold">PASO 5</span>
                            <Sparkles className="w-3.5 h-3.5 text-[#8a532b]" />
                            Estilo de Respaldo / Espaldar:
                          </span>
                          <button
                            type="button"
                            onClick={() => setShowStyleExamplesModal(true)}
                            className="flex items-center gap-1 text-[11px] font-bold text-[#8a532b] hover:text-[#5C3D2E] underline underline-offset-2 cursor-pointer transition-colors"
                          >
                            <Eye className="w-3.5 h-3.5" />
                            <span>Ver fotos de ejemplo</span>
                          </button>
                        </div>

                        {/* Tarjetas interactivas de selección */}
                        <div className="grid grid-cols-2 gap-2.5">
                          {/* Opción 1: Con Costura */}
                          <button
                            type="button"
                            onClick={() => {
                              setSelectedBackrestStyle('costura');
                              scrollToStep('step-order-actions');
                            }}
                            className={`flex items-center gap-2.5 p-2 rounded-xl border text-left transition-all cursor-pointer ${
                              selectedBackrestStyle === 'costura'
                                ? 'border-[#8a532b] bg-[#8a532b]/5 ring-2 ring-[#8a532b]/30 shadow-xs'
                                : 'border-[#E8E2DC] bg-white hover:border-[#C8BEB5]'
                            }`}
                          >
                            <div className="w-11 h-11 rounded-lg overflow-hidden shrink-0 bg-stone-100 border border-stone-200">
                              <img
                                src={styleExamples.costuraImage}
                                alt="Con Costura"
                                referrerPolicy="no-referrer"
                                className="w-full h-full object-cover"
                              />
                            </div>
                            <div className="min-w-0 flex-1">
                              <div className="flex items-center justify-between">
                                <span className="text-xs font-bold text-[#2C1810] truncate">Con Costura</span>
                                {selectedBackrestStyle === 'costura' && (
                                  <Check className="w-3.5 h-3.5 text-[#8a532b] stroke-[3]" />
                                )}
                              </div>
                              <p className="text-[10px] text-[#7A6A60] leading-tight mt-0.5">Líneas acolchadas</p>
                            </div>
                          </button>

                          {/* Opción 2: Capitoneado (Con Botones) */}
                          <button
                            type="button"
                            onClick={() => {
                              setSelectedBackrestStyle('botones');
                              scrollToStep('step-order-actions');
                            }}
                            className={`flex items-center gap-2.5 p-2 rounded-xl border text-left transition-all cursor-pointer ${
                              selectedBackrestStyle === 'botones'
                                ? 'border-[#8a532b] bg-[#8a532b]/5 ring-2 ring-[#8a532b]/30 shadow-xs'
                                : 'border-[#E8E2DC] bg-white hover:border-[#C8BEB5]'
                            }`}
                          >
                            <div className="w-11 h-11 rounded-lg overflow-hidden shrink-0 bg-stone-100 border border-stone-200">
                              <img
                                src={styleExamples.botonesImage}
                                alt="Capitoneado con Botones"
                                referrerPolicy="no-referrer"
                                className="w-full h-full object-cover"
                              />
                            </div>
                            <div className="min-w-0 flex-1">
                              <div className="flex items-center justify-between">
                                <span className="text-xs font-bold text-[#2C1810] truncate">Capitoneado</span>
                                {selectedBackrestStyle === 'botones' && (
                                  <Check className="w-3.5 h-3.5 text-[#8a532b] stroke-[3]" />
                                )}
                              </div>
                              <p className="text-[10px] text-[#7A6A60] leading-tight mt-0.5">Con Botones</p>
                            </div>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {/* 7. PASO FINAL: CONTROL DE CANTIDAD Y BOTONES DE ACCIÓN */}
                <div id="step-order-actions" className="pt-3 border-t border-[#F0EBE6] space-y-3 bg-[#FAF8F5] p-3.5 rounded-2xl border border-[#E8E2DC] scroll-mt-4">
                  {/* Step Header */}
                  <div className="flex items-center justify-between border-b border-[#E8E2DC] pb-2">
                    <span className="text-xs font-bold text-[#2C1810] flex items-center gap-1.5">
                      <span className="px-1.5 py-0.5 rounded bg-[#2C1810] text-white text-[10px] font-extrabold">PASO FINAL</span>
                      <span>Resumen y Realizar Pedido</span>
                    </span>
                    <span className="text-[11px] font-extrabold text-[#8a532b]">
                      {formatPrice(currentUnitPrice * quantity, settings.currency)}
                    </span>
                  </div>

                  {/* Quantity Controls */}
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-[#2C1810]">Cantidad a ordenar:</span>
                    <div className="flex items-center border border-[#E8E2DC] rounded-xl bg-white overflow-hidden shadow-2xs">
                      <button
                        onClick={() => setQuantity((prev) => Math.max(1, prev - 1))}
                        className="px-3 py-1.5 text-[#2C1810] hover:bg-[#F0EBE6] font-bold cursor-pointer transition-colors"
                      >
                        -
                      </button>
                      <span className="px-4 py-1.5 text-xs font-bold text-[#2C1810] min-w-[36px] text-center">
                        {quantity}
                      </span>
                      <button
                        onClick={() => setQuantity((prev) => prev + 1)}
                        className="px-3 py-1.5 text-[#2C1810] hover:bg-[#F0EBE6] font-bold cursor-pointer transition-colors"
                      >
                        +
                      </button>
                    </div>
                  </div>

                  {/* Main Action Buttons: Agregar al Carrito & Pedir por WhatsApp */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    <button
                      id="modal-add-to-cart-btn"
                      onClick={handleAddToCart}
                      className="w-full py-3.5 px-4 rounded-xl sm:rounded-2xl bg-[#2C1810] hover:bg-[#3E2723] text-white font-bold text-xs sm:text-sm flex items-center justify-center gap-2 transition-all shadow-md active:scale-95 cursor-pointer"
                    >
                      <ShoppingBag className="w-4 h-4" />
                      <span>Agregar al Carrito</span>
                    </button>

                    <button
                      id="modal-whatsapp-order-btn"
                      onClick={handleWhatsAppOrder}
                      className="w-full py-3.5 px-4 rounded-xl sm:rounded-2xl bg-[#25D366] hover:bg-[#20BD5A] text-white font-bold text-xs sm:text-sm flex items-center justify-center gap-2 transition-all shadow-md active:scale-95 cursor-pointer"
                    >
                      <MessageCircle className="w-4 h-4 fill-current" />
                      <span>Pedir por WhatsApp</span>
                    </button>
                  </div>

                  {/* Added Toast Notification */}
                  {addedToast && (
                    <div className="p-2.5 rounded-xl bg-emerald-100 text-emerald-900 text-xs font-semibold text-center animate-fadeIn flex items-center justify-center gap-2 border border-emerald-300">
                      <Check className="w-4 h-4 text-emerald-700" />
                      <span>¡Producto agregado al carrito exitosamente!</span>
                    </div>
                  )}
                </div>

                {/* 8. ENVÍO Y GARANTÍAS (MÁS ABAJO) */}
                <div className="pt-2">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs text-[#5C4033]">
                    <div className="flex items-start gap-2.5 bg-[#FAF7F2] p-3 rounded-xl border border-[#E8E2DC]">
                      <ShieldCheck className="w-4 h-4 text-[#8a532b] shrink-0 mt-0.5" />
                      <div>
                        <strong className="block text-[#2C1810]">Garantía 100%</strong>
                        <span className="text-[#7A6A60] text-[11px]">12 meses de garantía directa de taller en fibra de vidrio.</span>
                      </div>
                    </div>
                    <div className="flex items-start gap-2.5 bg-[#FAF7F2] p-3 rounded-xl border border-[#E8E2DC]">
                      <Truck className="w-4 h-4 text-[#8a532b] shrink-0 mt-0.5" />
                      <div>
                        <strong className="block text-[#2C1810]">Envíos Disponibles</strong>
                        <span className="text-[#7A6A60] text-[11px]">Entrega cuidada y segura directo a tu hogar.</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* 9. DETALLES ADICIONALES: Incluidos en conjunto y Especificaciones */}
                {product.includedItems && product.includedItems.length > 0 && (
                  <div className="p-3.5 rounded-2xl bg-[#F0EBE6]/80 border border-[#E8E2DC] space-y-2">
                    <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-[#2C1810]">
                      <Layers className="w-4 h-4 text-[#8a532b]" />
                      <span>Este conjunto incluye</span>
                    </div>
                    <ul className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 text-xs text-[#2C1810]">
                      {product.includedItems.map((item, i) => (
                        <li key={i} className="flex items-center gap-2">
                          <Check className="w-3.5 h-3.5 text-emerald-700 shrink-0" />
                          <span>{item}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

                {/* Specs Table */}
                <div className="grid grid-cols-2 gap-2.5 pt-1">
                  <div className="p-2.5 rounded-xl bg-white border border-[#E8E2DC]">
                    <span className="text-[10px] uppercase font-bold text-[#8C7A70] block">Material</span>
                    <span className="text-xs font-semibold text-[#2C1810]">
                      {isCushionOnly ? 'Textil Ergonómico' : (product.material || 'Fibra de Vidrio')}
                    </span>
                  </div>
                  {product.cushionStyle && (
                    <div className="p-2.5 rounded-xl bg-white border border-[#E8E2DC]">
                      <span className="text-[10px] uppercase font-bold text-[#8C7A70] block">Estilo Cojín</span>
                      <span className="text-xs font-semibold text-[#2C1810]">{product.cushionStyle}</span>
                    </div>
                  )}
                </div>

                {/* Compatible Cushions Recommendations */}
                {compatibleCushions.length > 0 && product.categoryId !== 'cojines' && (
                  <div className="pt-3 border-t border-[#F0EBE6] space-y-2.5">
                    <span className="text-xs font-bold text-[#2C1810] uppercase tracking-wide flex items-center gap-1.5">
                      <Sparkles className="w-3.5 h-3.5 text-[#8a532b]" />
                      <span>Cojines compatibles recomendados:</span>
                    </span>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {compatibleCushions.map((cushion) => (
                        <div
                          key={cushion.id}
                          className="flex items-center gap-2.5 p-2 rounded-xl bg-[#FDFCFB] border border-[#E8E2DC] hover:border-[#D6CCC2] transition-all cursor-pointer"
                          onClick={() => onSelectProduct(cushion)}
                        >
                          <img
                            src={cushion.mainImage}
                            alt={cushion.name}
                            className="w-12 h-12 rounded-lg object-cover"
                          />
                          <div className="flex-1 min-w-0">
                            <p className="text-xs font-bold text-[#2C1810] truncate">{cushion.name}</p>
                            <p className="text-xs font-semibold text-[#5C4033]">
                              {formatPrice(cushion.price, settings.currency)}
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

              </div>
            </div>

          </div>

          {/* REVIEWS & RATINGS SECTION */}
          <div className="p-4 sm:p-6 md:p-8 bg-white border-t border-[#E8E2DC]">
            <ReviewsSection
              product={product}
              reviews={reviews}
              onReviewAdded={onReviewAdded}
            />
          </div>

        </div>

      </div>

      {/* MODAL COMPARATIVO DE FOTOS: CON COSTURA VS CAPITONEADO (CON BOTONES) */}
      {showStyleExamplesModal && (
        <div
          className="fixed inset-0 z-60 bg-black/80 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 animate-fadeIn"
          onClick={() => setShowStyleExamplesModal(false)}
        >
          <div
            className="bg-white max-w-2xl w-full rounded-3xl shadow-2xl overflow-hidden border border-[#E8E2DC] animate-scaleUp"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Modal Header */}
            <div className="p-4 sm:p-5 bg-[#2C1810] text-white flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-[#8a532b]">
                  <Sparkles className="w-4 h-4 text-white" />
                </div>
                <div>
                  <h3 className="font-serif text-base sm:text-lg font-bold">
                    Estilos de Confección en el Respaldo
                  </h3>
                  <p className="text-[11px] text-[#D6CCC2]">
                    Compara el acabado con costura y capitoneado con botones
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setShowStyleExamplesModal(false)}
                className="p-2 text-stone-300 hover:text-white rounded-xl hover:bg-white/10 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Body: 2 Visual Comparison Cards */}
            <div className="p-4 sm:p-6 bg-[#FAF8F5] space-y-4 max-h-[75vh] overflow-y-auto">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* Opción 1: Con Costura */}
                <div
                  className={`bg-white p-3.5 rounded-2xl border-2 transition-all flex flex-col justify-between ${
                    selectedBackrestStyle === 'costura'
                      ? 'border-[#8a532b] shadow-md ring-2 ring-[#8a532b]/20'
                      : 'border-[#E8E2DC] hover:border-[#C8BEB5]'
                  }`}
                >
                  <div className="space-y-2.5">
                    <div className="relative aspect-4/3 rounded-xl overflow-hidden bg-stone-100 border border-stone-200 shadow-xs">
                      <img
                        src={styleExamples.costuraImage}
                        alt="Con Costura"
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover"
                      />
                      <span className="absolute top-2 left-2 px-2.5 py-1 rounded-full bg-black/60 backdrop-blur-xs text-white text-[10.5px] font-bold">
                        Líneas Acolchadas
                      </span>
                    </div>

                    <div>
                      <h4 className="text-sm font-bold text-[#2C1810]">
                        {styleExamples.costuraTitle || '1. Con Costura'}
                      </h4>
                      <p className="text-xs text-[#5C4033] mt-1 leading-relaxed">
                        {styleExamples.costuraDescription ||
                          'Acabado moderno y uniforme con líneas de costura continuas. Ideal para un look minimalista y limpieza rápida.'}
                      </p>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => {
                      setSelectedBackrestStyle('costura');
                      setShowStyleExamplesModal(false);
                    }}
                    className={`mt-3 w-full py-2.5 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                      selectedBackrestStyle === 'costura'
                        ? 'bg-[#8a532b] text-white shadow-xs'
                        : 'bg-[#F0EBE6] hover:bg-[#E2DAD2] text-[#2C1810]'
                    }`}
                  >
                    {selectedBackrestStyle === 'costura' ? (
                      <>
                        <Check className="w-3.5 h-3.5 stroke-[3]" />
                        <span>Estilo Seleccionado</span>
                      </>
                    ) : (
                      <span>Elegir Con Costura</span>
                    )}
                  </button>
                </div>

                {/* Opción 2: Capitoneado con Botones */}
                <div
                  className={`bg-white p-3.5 rounded-2xl border-2 transition-all flex flex-col justify-between ${
                    selectedBackrestStyle === 'botones'
                      ? 'border-[#8a532b] shadow-md ring-2 ring-[#8a532b]/20'
                      : 'border-[#E8E2DC] hover:border-[#C8BEB5]'
                  }`}
                >
                  <div className="space-y-2.5">
                    <div className="relative aspect-4/3 rounded-xl overflow-hidden bg-stone-100 border border-stone-200 shadow-xs">
                      <img
                        src={styleExamples.botonesImage}
                        alt="Capitoneado con Botones"
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover"
                      />
                      <span className="absolute top-2 left-2 px-2.5 py-1 rounded-full bg-black/60 backdrop-blur-xs text-white text-[10.5px] font-bold">
                        Con Botones Clásicos
                      </span>
                    </div>

                    <div>
                      <h4 className="text-sm font-bold text-[#2C1810]">
                        {styleExamples.botonesTitle || '2. Capitoneado (Con Botones)'}
                      </h4>
                      <p className="text-xs text-[#5C4033] mt-1 leading-relaxed">
                        {styleExamples.botonesDescription ||
                          'Diseño elegante tradicional con botones forrados a juego que crean volumen y rombos decorativos mullidos.'}
                      </p>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => {
                      setSelectedBackrestStyle('botones');
                      setShowStyleExamplesModal(false);
                    }}
                    className={`mt-3 w-full py-2.5 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                      selectedBackrestStyle === 'botones'
                        ? 'bg-[#8a532b] text-white shadow-xs'
                        : 'bg-[#F0EBE6] hover:bg-[#E2DAD2] text-[#2C1810]'
                    }`}
                  >
                    {selectedBackrestStyle === 'botones' ? (
                      <>
                        <Check className="w-3.5 h-3.5 stroke-[3]" />
                        <span>Estilo Seleccionado</span>
                      </>
                    ) : (
                      <span>Elegir Capitoneado (Botones)</span>
                    )}
                  </button>
                </div>
              </div>

              <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 text-xs text-[#5C3D2E] flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-[#8a532b] shrink-0" />
                <span>Ambos estilos se confeccionan con materiales de alta densidad y durabilidad garantizada.</span>
              </div>
            </div>

            {/* Modal Footer */}
            <div className="p-3.5 bg-white border-t border-[#E8E2DC] flex justify-end">
              <button
                type="button"
                onClick={() => setShowStyleExamplesModal(false)}
                className="py-2 px-5 rounded-xl bg-[#2C1810] text-white font-bold text-xs hover:bg-[#43281C] transition-colors cursor-pointer"
              >
                Cerrar y Continuar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL DE COMPARACIÓN VISUAL: COJÍN SIN BORDES VS CON RIBETE EN CONTRASTE */}
      {showBorderExamplesModal && (
        <div
          className="fixed inset-0 z-60 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4 animate-fadeIn"
          onClick={() => setShowBorderExamplesModal(false)}
        >
          <div
            className="bg-white rounded-3xl max-w-2xl w-full overflow-hidden shadow-2xl border border-[#E8E2DC] animate-scaleUp"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Modal Header */}
            <div className="p-4 sm:p-5 border-b border-[#E8E2DC] flex items-center justify-between bg-[#FAF8F5]">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-full bg-[#8a532b]/10 flex items-center justify-center text-[#8a532b]">
                  <Scissors className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-serif font-bold text-base sm:text-lg text-[#2C1810]">
                    Comparación Visual de Bordes y Ribetes
                  </h3>
                  <p className="text-xs text-[#5C4033]">
                    Elige entre un acabado liso en el mismo tono o con ribete decorativo en contraste.
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowBorderExamplesModal(false)}
                className="p-2 rounded-full hover:bg-stone-200 text-stone-600 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Body: 2 Visual Comparison Cards */}
            <div className="p-4 sm:p-6 bg-[#FAF8F5] space-y-4 max-h-[75vh] overflow-y-auto">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* Opción 1: Sin Bordes (Mismo Color) */}
                <div
                  className={`bg-white p-3.5 rounded-2xl border-2 transition-all flex flex-col justify-between ${
                    !customBorderEnabled
                      ? 'border-[#8a532b] shadow-md ring-2 ring-[#8a532b]/20'
                      : 'border-[#E8E2DC] hover:border-[#C8BEB5]'
                  }`}
                >
                  <div className="space-y-2.5">
                    <div className="relative aspect-4/3 rounded-xl overflow-hidden bg-stone-100 border border-stone-200 shadow-xs group">
                      <img
                        src={borderStyleExamples.sinBordesImage}
                        alt="Sin Bordes (Mismo Color)"
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover"
                      />
                      <span className="absolute top-2 left-2 px-2.5 py-1 rounded-full bg-black/60 backdrop-blur-xs text-white text-[10.5px] font-bold">
                        Mismo Tono / Liso
                      </span>
                    </div>

                    <div>
                      <h4 className="text-sm font-bold text-[#2C1810]">
                        {borderStyleExamples.sinBordesTitle || '1. Sin Bordes de Contraste (Mismo Tono)'}
                      </h4>
                      <p className="text-xs text-[#5C4033] mt-1 leading-relaxed">
                        {borderStyleExamples.sinBordesDescription ||
                          'Costuras y ribete en la misma tela y color del cojín. Un acabado liso, sobrio y uniforme ideal para estilos modernos.'}
                      </p>
                      <ul className="mt-2.5 space-y-1 text-[11px] text-stone-600">
                        <li className="flex items-center gap-1.5">
                          <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                          <span>Acabado continuo y limpio</span>
                        </li>
                        <li className="flex items-center gap-1.5">
                          <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                          <span>Misma textura en toda la superficie</span>
                        </li>
                      </ul>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => {
                      setCustomBorderEnabled(false);
                      setShowBorderExamplesModal(false);
                      scrollToStep(isCushionOnly ? 'step-cushion-backrest' : 'step-rocker-backrest');
                    }}
                    className={`mt-3 w-full py-2.5 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                      !customBorderEnabled
                        ? 'bg-[#8a532b] text-white shadow-xs'
                        : 'bg-[#F0EBE6] hover:bg-[#E2DAD2] text-[#2C1810]'
                    }`}
                  >
                    {!customBorderEnabled ? (
                      <>
                        <Check className="w-3.5 h-3.5 stroke-[3]" />
                        <span>Estilo Seleccionado</span>
                      </>
                    ) : (
                      <span>Elegir Sin Bordes (Mismo Color)</span>
                    )}
                  </button>
                </div>

                {/* Opción 2: Con Bordes / Ribete en Contraste */}
                <div
                  className={`bg-white p-3.5 rounded-2xl border-2 transition-all flex flex-col justify-between ${
                    customBorderEnabled
                      ? 'border-[#8a532b] shadow-md ring-2 ring-[#8a532b]/20'
                      : 'border-[#E8E2DC] hover:border-[#C8BEB5]'
                  }`}
                >
                  <div className="space-y-2.5">
                    <div className="relative aspect-4/3 rounded-xl overflow-hidden bg-stone-100 border border-stone-200 shadow-xs group">
                      <img
                        src={borderStyleExamples.conBordesImage}
                        alt="Con Bordes en Contraste"
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover"
                      />
                      <span className="absolute top-2 left-2 px-2.5 py-1 rounded-full bg-[#8a532b] text-white text-[10.5px] font-bold">
                        Con Ribete Decorativo
                      </span>
                    </div>

                    <div>
                      <h4 className="text-sm font-bold text-[#2C1810]">
                        {borderStyleExamples.conBordesTitle || '2. Con Ribete en Contraste (Vivo)'}
                      </h4>
                      <p className="text-xs text-[#5C4033] mt-1 leading-relaxed">
                        {borderStyleExamples.conBordesDescription ||
                          'Cordón perimetral decorativo (vivo) en un color de contraste que resalta y perfila con gran elegancia la silueta del cojín.'}
                      </p>
                      <ul className="mt-2.5 space-y-1 text-[11px] text-stone-600">
                        <li className="flex items-center gap-1.5">
                          <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                          <span>Resalta las curvas y el volumen</span>
                        </li>
                        <li className="flex items-center gap-1.5">
                          <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                          <span>Personalizable en múltiples colores</span>
                        </li>
                      </ul>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => {
                      setCustomBorderEnabled(true);
                      setShowBorderExamplesModal(false);
                    }}
                    className={`mt-3 w-full py-2.5 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                      customBorderEnabled
                        ? 'bg-[#8a532b] text-white shadow-xs'
                        : 'bg-[#F0EBE6] hover:bg-[#E2DAD2] text-[#2C1810]'
                    }`}
                  >
                    {customBorderEnabled ? (
                      <>
                        <Check className="w-3.5 h-3.5 stroke-[3]" />
                        <span>Estilo Seleccionado ({selectedBorderColor})</span>
                      </>
                    ) : (
                      <span>Elegir Con Ribete en Contraste</span>
                    )}
                  </button>
                </div>
              </div>

              <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 text-xs text-[#5C3D2E] flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-[#8a532b] shrink-0" />
                <span>Ambos acabados se confeccionan con telas premium de alta durabilidad y costuras reforzadas.</span>
              </div>
            </div>

            {/* Modal Footer */}
            <div className="p-3.5 bg-white border-t border-[#E8E2DC] flex justify-end">
              <button
                type="button"
                onClick={() => setShowBorderExamplesModal(false)}
                className="py-2 px-5 rounded-xl bg-[#2C1810] text-white font-bold text-xs hover:bg-[#43281C] transition-colors cursor-pointer"
              >
                Cerrar y Continuar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL DE VISUALIZACIÓN / AMPLIACIÓN DE MUESTRA DE TELA / TEXTALINA */}
      {previewSampleModal && previewSampleModal.isOpen && (
        <div
          className="fixed inset-0 z-60 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4 animate-fadeIn"
          onClick={() => setPreviewSampleModal(null)}
        >
          <div
            className="bg-white rounded-3xl max-w-md w-full overflow-hidden shadow-2xl border border-stone-200 animate-scaleUp"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="p-4 border-b border-[#E8E2DC] flex items-center justify-between bg-[#FAF8F5]">
              <div className="flex items-center gap-2">
                {previewSampleModal.hex && (
                  <span
                    className="w-4 h-4 rounded-full border border-black/20 shadow-2xs"
                    style={{ backgroundColor: previewSampleModal.hex }}
                  />
                )}
                <h3 className="font-serif font-bold text-base text-[#2C1810]">
                  {previewSampleModal.title}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setPreviewSampleModal(null)}
                className="p-1.5 rounded-full hover:bg-stone-200 text-stone-600 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-4 space-y-3">
              <div className="relative aspect-4/3 rounded-2xl overflow-hidden bg-stone-100 border border-stone-200 shadow-inner">
                <img
                  src={previewSampleModal.image}
                  alt={previewSampleModal.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
              </div>

              {previewSampleModal.description && (
                <div className="p-3 bg-[#FAF8F5] rounded-xl border border-[#E8E2DC] text-xs text-[#5C4033] leading-relaxed">
                  <p className="font-semibold text-[#2C1810] mb-0.5">Detalles del material:</p>
                  <p>{previewSampleModal.description}</p>
                </div>
              )}
            </div>

            <div className="p-3.5 bg-white border-t border-[#E8E2DC] flex justify-end">
              <button
                type="button"
                onClick={() => setPreviewSampleModal(null)}
                className="py-2 px-5 rounded-xl bg-[#8a532b] text-white font-bold text-xs hover:bg-[#5C3D2E] transition-colors cursor-pointer"
              >
                Listo
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL DE FICHA TÉCNICA Y DETALLES DE TELA */}
      {activeFabricInfoModal && (
        <div
          className="fixed inset-0 z-60 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4 animate-fadeIn"
          onClick={() => setActiveFabricInfoModal(null)}
        >
          <div
            className="bg-white rounded-3xl max-w-lg w-full overflow-hidden shadow-2xl border border-stone-200 animate-scaleUp space-y-0"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Header */}
            <div className="p-4 border-b border-[#E8E2DC] flex items-center justify-between bg-[#FAF8F5]">
              <div className="flex items-center gap-2">
                <span className="p-1.5 rounded-xl bg-[#8a532b]/10 text-[#8a532b]">
                  <Layers className="w-4 h-4" />
                </span>
                <div>
                  <h3 className="font-serif font-bold text-base text-[#2C1810]">
                    {activeFabricInfoModal.name}
                  </h3>
                  <span className="text-[10px] text-[#8C7A70]">Ficha técnica y características</span>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setActiveFabricInfoModal(null)}
                className="p-1.5 rounded-full hover:bg-stone-200 text-stone-600 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Body */}
            <div className="p-5 space-y-4 max-h-[75vh] overflow-y-auto">
              {/* Image Preview */}
              {activeFabricInfoModal.image && (
                <div className="relative aspect-16/9 rounded-2xl overflow-hidden bg-stone-100 border border-stone-200 shadow-inner">
                  <img
                    src={activeFabricInfoModal.image}
                    alt={activeFabricInfoModal.name}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover"
                  />
                  <span className="absolute bottom-2 right-2 px-2.5 py-1 rounded-lg bg-black/60 backdrop-blur-xs text-white text-[10.5px] font-bold">
                    {activeFabricInfoModal.priceDiff === 0 
                      ? 'Sin costo adicional' 
                      : `+${formatPrice(activeFabricInfoModal.priceDiff, settings.currency)}`}
                  </span>
                </div>
              )}

              {/* Description */}
              {activeFabricInfoModal.description && (
                <p className="text-xs text-[#5C4033] leading-relaxed">
                  {activeFabricInfoModal.description}
                </p>
              )}

              {/* Badges */}
              {activeFabricInfoModal.badges && activeFabricInfoModal.badges.length > 0 && (
                <div>
                  <h4 className="font-bold text-[11px] text-[#2C1810] uppercase tracking-wider mb-1.5 flex items-center gap-1">
                    <Sparkles className="w-3.5 h-3.5 text-[#8a532b]" />
                    <span>Propiedades Destacadas</span>
                  </h4>
                  <div className="flex flex-wrap gap-1.5">
                    {activeFabricInfoModal.badges.map((b, bIdx) => (
                      <span
                        key={bIdx}
                        className="px-2.5 py-1 rounded-lg bg-[#FAF8F5] border border-[#E8E2DC] text-[#7A6A60] text-xs font-semibold"
                      >
                        {b}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {/* Technical specs grid */}
              <div className="bg-[#FAF8F5] p-3.5 rounded-2xl border border-[#E8E2DC] space-y-2 text-xs">
                {activeFabricInfoModal.material && (
                  <div className="flex flex-col">
                    <span className="font-bold text-[#2C1810]">Composición / Tejido:</span>
                    <span className="text-[#5C4033]">{activeFabricInfoModal.material}</span>
                  </div>
                )}
                {activeFabricInfoModal.usage && (
                  <div className="flex flex-col pt-1 border-t border-[#E8E2DC]/60">
                    <span className="font-bold text-[#2C1810]">Recomendación de Uso:</span>
                    <span className="text-[#5C4033]">{activeFabricInfoModal.usage}</span>
                  </div>
                )}
                {activeFabricInfoModal.cleaningInfo && (
                  <div className="flex flex-col pt-1 border-t border-[#E8E2DC]/60">
                    <span className="font-bold text-[#2C1810]">Cuidado y Limpieza:</span>
                    <span className="text-[#5C4033]">{activeFabricInfoModal.cleaningInfo}</span>
                  </div>
                )}
              </div>
            </div>

            {/* Footer */}
            <div className="p-3.5 bg-white border-t border-[#E8E2DC] flex items-center justify-between">
              <span className="text-xs font-bold text-[#8a532b]">
                {activeFabricInfoModal.priceDiff === 0 
                  ? 'Precio estándar incluido' 
                  : `+${formatPrice(activeFabricInfoModal.priceDiff, settings.currency)} por confección`}
              </span>

              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setSelectedFabricId(activeFabricInfoModal.id);
                    setActiveFabricInfoModal(null);
                  }}
                  className="py-2 px-4 rounded-xl bg-[#8a532b] text-white font-bold text-xs hover:bg-[#5C3D2E] transition-colors cursor-pointer flex items-center gap-1"
                >
                  <Check className="w-3.5 h-3.5" />
                  <span>Elegir esta Tela</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
