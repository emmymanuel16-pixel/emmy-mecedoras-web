import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { CustomizerColorOption, CustomizerFabricOption } from '../../types';

interface FiberglassRocker3DViewerProps {
  rockerColor: CustomizerColorOption;
  fabric?: CustomizerFabricOption;
  hasCushion: boolean;
  finishType?: 'brillante' | 'satinado' | 'mate';
  environment?: 'studio' | 'terrace' | 'warm';
  customModelUrl?: string;
  onWebGLError?: () => void;
}

export const FiberglassRocker3DViewer: React.FC<FiberglassRocker3DViewerProps> = ({
  rockerColor,
  fabric,
  hasCushion,
  finishType = 'brillante',
  environment = 'studio',
  onWebGLError
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  
  // Meshes & Materials references for dynamic updates
  const shellMeshRef = useRef<THREE.Mesh | null>(null);
  const cushionGroupRef = useRef<THREE.Group | null>(null);
  const cushionMaterialRef = useRef<THREE.MeshStandardMaterial | null>(null);
  const shellMaterialRef = useRef<THREE.MeshPhysicalMaterial | null>(null);
  const textureLoaderRef = useRef<THREE.TextureLoader | null>(null);

  // Controls state
  const isDraggingRef = useRef<boolean>(false);
  const previousMousePosition = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  const [autoRotate, setAutoRotate] = useState<boolean>(true);
  const [zoomLevel, setZoomLevel] = useState<number>(1);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [renderError, setRenderError] = useState<boolean>(false);

  // Spherical camera angles
  const cameraAngle = useRef<{ theta: number; phi: number; radius: number }>({
    theta: 0.6,
    phi: 1.2,
    radius: 3.4
  });

  // Check WebGL support
  const isWebGLSupported = () => {
    try {
      const canvas = document.createElement('canvas');
      return !!(window.WebGLRenderingContext && (canvas.getContext('webgl') || canvas.getContext('experimental-webgl')));
    } catch {
      return false;
    }
  };

  // Helper to generate a procedural fabric canvas texture if no image is supplied
  const createProceduralFabricTexture = (hexColor: string, type?: string) => {
    const canvas = document.createElement('canvas');
    canvas.width = 256;
    canvas.height = 256;
    const ctx = canvas.getContext('2d');
    if (!ctx) return null;

    ctx.fillStyle = hexColor;
    ctx.fillRect(0, 0, 256, 256);

    // Subtle weave pattern
    ctx.fillStyle = 'rgba(255, 255, 255, 0.08)';
    for (let x = 0; x < 256; x += 4) {
      ctx.fillRect(x, 0, 2, 256);
    }
    ctx.fillStyle = 'rgba(0, 0, 0, 0.06)';
    for (let y = 0; y < 256; y += 4) {
      ctx.fillRect(0, y, 256, 2);
    }

    if (type === 'estampado') {
      ctx.fillStyle = 'rgba(255, 255, 255, 0.25)';
      for (let x = 0; x < 256; x += 32) {
        ctx.fillRect(x, 0, 16, 256);
      }
    }

    const texture = new THREE.CanvasTexture(canvas);
    texture.wrapS = THREE.RepeatWrapping;
    texture.wrapT = THREE.RepeatWrapping;
    texture.repeat.set(4, 4);
    return texture;
  };

  useEffect(() => {
    if (!isWebGLSupported()) {
      setRenderError(true);
      if (onWebGLError) onWebGLError();
      return;
    }

    const container = containerRef.current;
    if (!container) return;

    // 1. Scene
    const scene = new THREE.Scene();
    sceneRef.current = scene;

    // Set background with subtle radial gradient tone
    scene.background = new THREE.Color(
      environment === 'terrace' ? 0xebe8e1 : environment === 'warm' ? 0xfdf6ee : 0xf4f1eb
    );

    // 2. Camera
    const width = container.clientWidth || 400;
    const height = container.clientHeight || 350;
    const camera = new THREE.PerspectiveCamera(42, width / height, 0.1, 50);
    cameraRef.current = camera;
    updateCameraPosition();

    // 3. Renderer
    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: 'high-performance' });
      renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
      renderer.setSize(width, height);
      renderer.shadowMap.enabled = true;
      renderer.shadowMap.type = THREE.PCFSoftShadowMap;
      renderer.toneMapping = THREE.ACESFilmicToneMapping;
      renderer.toneMappingExposure = 1.15;
      
      // Clean previous canvases
      while (container.firstChild) {
        container.removeChild(container.firstChild);
      }
      container.appendChild(renderer.domElement);
      rendererRef.current = renderer;
    } catch {
      setRenderError(true);
      if (onWebGLError) onWebGLError();
      return;
    }

    // 4. Lights
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.85);
    scene.add(ambientLight);

    const mainLight = new THREE.DirectionalLight(0xfffaed, 1.4);
    mainLight.position.set(3, 5, 4);
    mainLight.castShadow = true;
    mainLight.shadow.mapSize.width = 1024;
    mainLight.shadow.mapSize.height = 1024;
    mainLight.shadow.bias = -0.0005;
    scene.add(mainLight);

    const fillLight = new THREE.DirectionalLight(0xe0f2fe, 0.6);
    fillLight.position.set(-4, 3, -2);
    scene.add(fillLight);

    const rimLight = new THREE.DirectionalLight(0xffffff, 0.7);
    rimLight.position.set(0, 4, -4);
    scene.add(rimLight);

    // 5. Floor & Contact Shadow
    const floorGeo = new THREE.PlaneGeometry(12, 12);
    const floorMat = new THREE.ShadowMaterial({ opacity: 0.14 });
    const floor = new THREE.Mesh(floorGeo, floorMat);
    floor.rotation.x = -Math.PI / 2;
    floor.position.y = -0.98;
    floor.receiveShadow = true;
    scene.add(floor);

    // Subtle floor pedestal ring
    const pedestalGeo = new THREE.CylinderGeometry(1.6, 1.7, 0.04, 32);
    const pedestalMat = new THREE.MeshStandardMaterial({
      color: 0xdfd9ce,
      roughness: 0.8,
      metalness: 0.1
    });
    const pedestal = new THREE.Mesh(pedestalGeo, pedestalMat);
    pedestal.position.y = -1.0;
    pedestal.receiveShadow = true;
    scene.add(pedestal);

    // 6. Build Procedural Fiberglass Rocking Chair
    buildProceduralFiberglassRocker(scene);

    setIsLoading(false);

    // 7. Animation Loop
    let animationFrameId: number;
    const animate = () => {
      animationFrameId = requestAnimationFrame(animate);

      if (autoRotate && !isDraggingRef.current) {
        cameraAngle.current.theta += 0.004;
        updateCameraPosition();
      }

      renderer.render(scene, camera);
    };
    animate();

    // 8. Resize Observer
    const resizeObserver = new ResizeObserver(() => {
      if (!container || !renderer || !camera) return;
      const newW = container.clientWidth;
      const newH = container.clientHeight;
      if (newW > 0 && newH > 0) {
        camera.aspect = newW / newH;
        camera.updateProjectionMatrix();
        renderer.setSize(newW, newH);
      }
    });
    resizeObserver.observe(container);

    return () => {
      resizeObserver.disconnect();
      cancelAnimationFrame(animationFrameId);
      renderer.dispose();
    };
  }, [environment]);

  // Update Camera based on spherical coordinates
  const updateCameraPosition = () => {
    if (!cameraRef.current) return;
    const { theta, phi, radius } = cameraAngle.current;
    const r = radius * (1 / zoomLevel);

    const x = r * Math.sin(phi) * Math.sin(theta);
    const y = r * Math.cos(phi);
    const z = r * Math.sin(phi) * Math.cos(theta);

    cameraRef.current.position.set(x, y + 0.1, z);
    cameraRef.current.lookAt(0, -0.05, 0);
  };

  // Build the 3D Fiberglass Rocker Geometry
  const buildProceduralFiberglassRocker = (scene: THREE.Scene) => {
    const chairGroup = new THREE.Group();
    chairGroup.name = 'rocker-group';

    // A. FIBERGLASS SHELL MATERIAL
    const roughnessVal = finishType === 'brillante' ? 0.12 : finishType === 'mate' ? 0.65 : 0.28;
    const clearcoatVal = finishType === 'brillante' ? 0.95 : finishType === 'satinado' ? 0.5 : 0.0;

    const shellMat = new THREE.MeshPhysicalMaterial({
      color: new THREE.Color(rockerColor.hex),
      roughness: roughnessVal,
      metalness: 0.05,
      clearcoat: clearcoatVal,
      clearcoatRoughness: 0.1,
      reflectivity: 0.8,
      envMapIntensity: 1.2
    });
    shellMaterialRef.current = shellMat;

    // 1. Molded Fiberglass Seat & Curved Shell
    // Use an ergonomic smooth lathe / extrude / composite mesh
    const shellGroup = new THREE.Group();

    // 1.1 Ergonomic Seat Base Shell
    const seatGeo = new THREE.CylinderGeometry(0.55, 0.48, 0.12, 32);
    seatGeo.scale(1, 0.7, 1.1);
    const seatMesh = new THREE.Mesh(seatGeo, shellMat);
    seatMesh.position.set(0, -0.15, 0.05);
    seatMesh.castShadow = true;
    seatMesh.receiveShadow = true;
    shellGroup.add(seatMesh);

    // 1.2 Ergonomic High Backrest Shell (Curved Molded Fiberglass)
    const backGeo = new THREE.BoxGeometry(0.72, 0.95, 0.08, 12, 12, 4);
    // Add ergonomic curvature to vertices
    const pos = backGeo.attributes.position;
    for (let i = 0; i < pos.count; i++) {
      const y = pos.getY(i);
      const x = pos.getX(i);
      // Curve horizontally around occupant
      const curveZ = Math.pow(x / 0.36, 2) * 0.08;
      // Slight recline curve at top
      const reclineZ = Math.sin((y + 0.4) * 1.5) * 0.12;
      pos.setZ(i, pos.getZ(i) - curveZ - reclineZ);
    }
    backGeo.computeVertexNormals();

    const backMesh = new THREE.Mesh(backGeo, shellMat);
    backMesh.position.set(0, 0.32, -0.32);
    backMesh.rotation.x = 0.18;
    backMesh.castShadow = true;
    backMesh.receiveShadow = true;
    shellGroup.add(backMesh);

    // 1.3 Molded Armrests (Pair)
    const armShape = new THREE.CurvePath<THREE.Vector3>();
    const armGeo = new THREE.TubeGeometry(
      new THREE.CatmullRomCurve3([
        new THREE.Vector3(0.42, -0.12, 0.28),
        new THREE.Vector3(0.44, 0.08, 0.1),
        new THREE.Vector3(0.42, 0.14, -0.15),
        new THREE.Vector3(0.36, 0.18, -0.32),
      ]),
      24,
      0.04,
      12,
      false
    );
    const rightArm = new THREE.Mesh(armGeo, shellMat);
    rightArm.castShadow = true;
    shellGroup.add(rightArm);

    const leftArmGeo = new THREE.TubeGeometry(
      new THREE.CatmullRomCurve3([
        new THREE.Vector3(-0.42, -0.12, 0.28),
        new THREE.Vector3(-0.44, 0.08, 0.1),
        new THREE.Vector3(-0.42, 0.14, -0.15),
        new THREE.Vector3(-0.36, 0.18, -0.32),
      ]),
      24,
      0.04,
      12,
      false
    );
    const leftArm = new THREE.Mesh(leftArmGeo, shellMat);
    leftArm.castShadow = true;
    shellGroup.add(leftArm);

    chairGroup.add(shellGroup);
    shellMeshRef.current = seatMesh;

    // B. STRUCTURE & LEGS (Black Steel / Chromed Spindles)
    const metalMat = new THREE.MeshStandardMaterial({
      color: 0x1a1a1a,
      metalness: 0.85,
      roughness: 0.25
    });

    const legPoints = [
      [-0.32, -0.18, 0.25, -0.36, -0.82, 0.35],
      [0.32, -0.18, 0.25, 0.36, -0.82, 0.35],
      [-0.28, -0.18, -0.25, -0.32, -0.82, -0.35],
      [0.28, -0.18, -0.25, 0.32, -0.82, -0.35],
      // Cross supports
      [-0.34, -0.5, 0.1, 0.34, -0.5, -0.1],
      [0.34, -0.5, 0.1, -0.34, -0.5, -0.1]
    ];

    legPoints.forEach(([x1, y1, z1, x2, y2, z2]) => {
      const v1 = new THREE.Vector3(x1, y1, z1);
      const v2 = new THREE.Vector3(x2, y2, z2);
      const distance = v1.distanceTo(v2);
      const legGeo = new THREE.CylinderGeometry(0.014, 0.014, distance, 12);
      const legMesh = new THREE.Mesh(legGeo, metalMat);

      const mid = v1.clone().add(v2).multiplyScalar(0.5);
      legMesh.position.copy(mid);
      legMesh.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), v2.clone().sub(v1).normalize());
      legMesh.castShadow = true;
      chairGroup.add(legMesh);
    });

    // C. WOODEN ROCKERS / RUNNERS (Patines Curvos de Madera)
    const woodMat = new THREE.MeshStandardMaterial({
      color: 0x3d1f14, // Rich natural hardwood
      roughness: 0.45,
      metalness: 0.05
    });

    const createRockerRunner = (isLeft: boolean) => {
      const curve = new THREE.CatmullRomCurve3([
        new THREE.Vector3(0, -0.72, 0.72),
        new THREE.Vector3(0, -0.88, 0.35),
        new THREE.Vector3(0, -0.92, 0.0),
        new THREE.Vector3(0, -0.88, -0.35),
        new THREE.Vector3(0, -0.76, -0.68),
      ]);
      const runnerGeo = new THREE.TubeGeometry(curve, 32, 0.038, 12, false);
      // Flatten tube slightly to look like wooden runner strip
      runnerGeo.scale(0.8, 1.4, 1);
      const runnerMesh = new THREE.Mesh(runnerGeo, woodMat);
      runnerMesh.position.x = isLeft ? -0.36 : 0.36;
      runnerMesh.castShadow = true;
      runnerMesh.receiveShadow = true;
      return runnerMesh;
    };

    chairGroup.add(createRockerRunner(true));
    chairGroup.add(createRockerRunner(false));

    // D. CUSHION GROUP (Seat Cushion + Back Cushion)
    const cushionGroup = new THREE.Group();
    cushionGroup.name = 'cushions';

    const initialFabricHex = fabric ? fabric.hex : '#D8C8B8';
    const cushionMat = new THREE.MeshStandardMaterial({
      color: new THREE.Color(initialFabricHex),
      roughness: 0.85,
      metalness: 0.02,
      map: createProceduralFabricTexture(initialFabricHex, fabric?.type)
    });
    cushionMaterialRef.current = cushionMat;

    // Seat Cushion (Tufted & Plump)
    const seatCushionGeo = new THREE.BoxGeometry(0.58, 0.11, 0.54, 8, 4, 8);
    const seatCushion = new THREE.Mesh(seatCushionGeo, cushionMat);
    seatCushion.position.set(0, -0.06, 0.04);
    seatCushion.castShadow = true;
    seatCushion.receiveShadow = true;
    cushionGroup.add(seatCushion);

    // Backrest Cushion (Ergonomic contoured)
    const backCushionGeo = new THREE.BoxGeometry(0.56, 0.72, 0.1, 8, 8, 4);
    const backCushion = new THREE.Mesh(backCushionGeo, cushionMat);
    backCushion.position.set(0, 0.32, -0.28);
    backCushion.rotation.x = 0.18;
    backCushion.castShadow = true;
    backCushion.receiveShadow = true;
    cushionGroup.add(backCushion);

    // Tufted buttons on backrest
    const buttonMat = new THREE.MeshStandardMaterial({
      color: 0x2c1810,
      roughness: 0.5
    });
    const buttonPositions = [
      [-0.14, 0.44, -0.23], [0.14, 0.44, -0.23],
      [-0.14, 0.22, -0.27], [0.14, 0.22, -0.27]
    ];
    buttonPositions.forEach(([bx, by, bz]) => {
      const btnGeo = new THREE.SphereGeometry(0.018, 8, 8);
      const btnMesh = new THREE.Mesh(btnGeo, buttonMat);
      btnMesh.position.set(bx, by, bz);
      cushionGroup.add(btnMesh);
    });

    cushionGroup.visible = hasCushion;
    chairGroup.add(cushionGroup);
    cushionGroupRef.current = cushionGroup;

    scene.add(chairGroup);
  };

  // Dynamic updates when Rocker Color or Finish changes
  useEffect(() => {
    if (shellMaterialRef.current) {
      shellMaterialRef.current.color.set(rockerColor.hex);

      const roughnessVal = finishType === 'brillante' ? 0.12 : finishType === 'mate' ? 0.65 : 0.28;
      const clearcoatVal = finishType === 'brillante' ? 0.95 : finishType === 'satinado' ? 0.5 : 0.0;
      shellMaterialRef.current.roughness = roughnessVal;
      shellMaterialRef.current.clearcoat = clearcoatVal;
      shellMaterialRef.current.needsUpdate = true;
    }
  }, [rockerColor, finishType]);

  // Dynamic updates when Fabric or Texture changes
  useEffect(() => {
    if (cushionMaterialRef.current) {
      const hex = fabric ? fabric.hex : '#D8C8B8';
      cushionMaterialRef.current.color.set(hex);

      if (fabric?.textureUrl) {
        if (!textureLoaderRef.current) {
          textureLoaderRef.current = new THREE.TextureLoader();
        }
        textureLoaderRef.current.load(
          fabric.textureUrl,
          (loadedTex) => {
            loadedTex.wrapS = THREE.RepeatWrapping;
            loadedTex.wrapT = THREE.RepeatWrapping;
            loadedTex.repeat.set(3, 3);
            if (cushionMaterialRef.current) {
              cushionMaterialRef.current.map = loadedTex;
              cushionMaterialRef.current.needsUpdate = true;
            }
          },
          undefined,
          () => {
            // Fallback to procedural pattern if URL fails
            if (cushionMaterialRef.current) {
              cushionMaterialRef.current.map = createProceduralFabricTexture(hex, fabric.type);
              cushionMaterialRef.current.needsUpdate = true;
            }
          }
        );
      } else {
        cushionMaterialRef.current.map = createProceduralFabricTexture(hex, fabric?.type);
        cushionMaterialRef.current.needsUpdate = true;
      }
    }
  }, [fabric]);

  // Toggle Cushion Visibility
  useEffect(() => {
    if (cushionGroupRef.current) {
      cushionGroupRef.current.visible = hasCushion;
    }
  }, [hasCushion]);

  // Touch & Mouse Orbit Handlers
  const handleMouseDown = (e: React.MouseEvent) => {
    isDraggingRef.current = true;
    previousMousePosition.current = { x: e.clientX, y: e.clientY };
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDraggingRef.current) return;
    const deltaX = e.clientX - previousMousePosition.current.x;
    const deltaY = e.clientY - previousMousePosition.current.y;

    cameraAngle.current.theta -= deltaX * 0.008;
    cameraAngle.current.phi = Math.max(0.3, Math.min(Math.PI / 2 + 0.1, cameraAngle.current.phi - deltaY * 0.008));
    
    updateCameraPosition();
    previousMousePosition.current = { x: e.clientX, y: e.clientY };
  };

  const handleMouseUp = () => {
    isDraggingRef.current = false;
  };

  const handleTouchStart = (e: React.TouchEvent) => {
    if (e.touches.length === 1) {
      isDraggingRef.current = true;
      previousMousePosition.current = { x: e.touches[0].clientX, y: e.touches[0].clientY };
    }
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (!isDraggingRef.current || e.touches.length !== 1) return;
    const deltaX = e.touches[0].clientX - previousMousePosition.current.x;
    const deltaY = e.touches[0].clientY - previousMousePosition.current.y;

    cameraAngle.current.theta -= deltaX * 0.01;
    cameraAngle.current.phi = Math.max(0.3, Math.min(Math.PI / 2 + 0.1, cameraAngle.current.phi - deltaY * 0.01));
    
    updateCameraPosition();
    previousMousePosition.current = { x: e.touches[0].clientX, y: e.touches[0].clientY };
  };

  const handleWheel = (e: React.WheelEvent) => {
    e.preventDefault();
    const zoomFactor = e.deltaY < 0 ? 1.08 : 0.92;
    setZoomLevel(prev => {
      const next = Math.max(0.65, Math.min(1.7, prev * zoomFactor));
      return next;
    });
  };

  useEffect(() => {
    updateCameraPosition();
  }, [zoomLevel]);

  const handleResetView = () => {
    cameraAngle.current = { theta: 0.6, phi: 1.2, radius: 3.4 };
    setZoomLevel(1);
    setAutoRotate(false);
    updateCameraPosition();
  };

  if (renderError) {
    return (
      <div className="w-full h-full flex flex-col items-center justify-center p-6 text-center bg-stone-100 rounded-2xl">
        <p className="text-sm font-bold text-stone-700">Modo 3D no compatible con este navegador</p>
        <p className="text-xs text-stone-500 mt-1">Se ha activado el visor 2D fotorrealista alternativo.</p>
      </div>
    );
  }

  return (
    <div className="relative w-full h-full min-h-[360px] sm:min-h-[420px] rounded-2xl overflow-hidden select-none bg-radial from-[#F9F7F4] to-[#EBE6DF]">
      {/* 3D Canvas Mount Point */}
      <div
        ref={containerRef}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleMouseUp}
        onWheel={handleWheel}
        className="w-full h-full cursor-grab active:cursor-grabbing"
      />

      {/* Loading Overlay */}
      {isLoading && (
        <div className="absolute inset-0 flex items-center justify-center bg-white/70 backdrop-blur-xs z-10">
          <div className="flex flex-col items-center gap-2">
            <div className="w-8 h-8 border-3 border-[#8a532b] border-t-transparent rounded-full animate-spin" />
            <span className="text-xs font-bold text-[#2C1810]">Renderizando modelo 3D...</span>
          </div>
        </div>
      )}

      {/* 3D Controls Floating Bar */}
      <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between pointer-events-none z-10">
        <div className="flex items-center gap-1.5 p-1 rounded-xl bg-black/40 backdrop-blur-md text-white pointer-events-auto shadow-md">
          <button
            type="button"
            onClick={() => setAutoRotate(!autoRotate)}
            className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition-all cursor-pointer ${
              autoRotate ? 'bg-[#8a532b] text-white shadow-xs' : 'text-stone-300 hover:text-white'
            }`}
            title="Giro automático"
          >
            {autoRotate ? '⏸ Detener Giro' : '▶ Girar 360°'}
          </button>

          <button
            type="button"
            onClick={handleResetView}
            className="px-2 py-1 rounded-lg text-[11px] font-semibold text-stone-300 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
            title="Centrar vista"
          >
            ↺ Centrar
          </button>
        </div>

        <div className="flex items-center gap-1 p-1 rounded-xl bg-black/40 backdrop-blur-md text-white pointer-events-auto shadow-md">
          <button
            type="button"
            onClick={() => setZoomLevel(prev => Math.min(1.7, prev * 1.15))}
            className="w-7 h-7 rounded-lg text-xs font-bold flex items-center justify-center hover:bg-white/15 transition-colors cursor-pointer"
            title="Acercar"
          >
            +
          </button>
          <span className="text-[10px] font-mono px-1 text-stone-300">
            {Math.round(zoomLevel * 100)}%
          </span>
          <button
            type="button"
            onClick={() => setZoomLevel(prev => Math.max(0.65, prev * 0.85))}
            className="w-7 h-7 rounded-lg text-xs font-bold flex items-center justify-center hover:bg-white/15 transition-colors cursor-pointer"
            title="Alejar"
          >
            -
          </button>
        </div>
      </div>

      {/* Interaction Hint */}
      <div className="absolute top-3 left-3 px-2.5 py-1 rounded-lg bg-black/30 backdrop-blur-xs text-white text-[10px] font-medium pointer-events-none flex items-center gap-1.5 shadow-xs">
        <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
        <span>Arrastra para rotar en 3D</span>
      </div>
    </div>
  );
};
