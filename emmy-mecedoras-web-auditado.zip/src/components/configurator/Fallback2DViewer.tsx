import React from 'react';
import { CustomizerColorOption, CustomizerFabricOption } from '../../types';

interface Fallback2DViewerProps {
  rockerColor: CustomizerColorOption;
  fabric?: CustomizerFabricOption;
  hasCushion: boolean;
  productName: string;
  finishType?: string;
}

export const Fallback2DViewer: React.FC<Fallback2DViewerProps> = ({
  rockerColor,
  fabric,
  hasCushion,
  productName,
  finishType = 'brillante',
}) => {
  const isWhite = rockerColor.hex.toLowerCase() === '#ffffff' || rockerColor.hex.toLowerCase() === '#f8fafc';
  const isMahogany = rockerColor.name.toLowerCase().includes('caoba') || rockerColor.hex === '#4a150e' || rockerColor.hex === '#4a1515';

  return (
    <div className="relative w-full h-full min-h-[360px] sm:min-h-[420px] rounded-2xl overflow-hidden bg-radial from-[#FDFCFB] to-[#EBE4DC] flex flex-col items-center justify-center p-6 border border-[#E8E2DC] shadow-inner">
      {/* 2D Realistic Render Canvas Vector/SVG Mockup */}
      <div className="relative w-64 h-64 sm:w-76 sm:h-76 flex items-center justify-center">
        {/* Soft Drop Shadow under rockers */}
        <div className="absolute -bottom-2 w-48 h-6 bg-black/15 rounded-full blur-md" />

        {/* Dynamic Styled Rocker SVG Studio Model */}
        <svg
          viewBox="0 0 300 300"
          className="w-full h-full drop-shadow-xl transition-all duration-500 ease-out"
        >
          <defs>
            {/* Fiberglass Shell Gradient */}
            <linearGradient id="fiberglassGrad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor={rockerColor.hex} stopOpacity="1" />
              <stop
                offset="70%"
                stopColor={
                  isWhite
                    ? '#E2E8F0'
                    : isMahogany
                    ? '#350E09'
                    : rockerColor.hex
                }
                stopOpacity="1"
              />
              <stop offset="100%" stopColor={isWhite ? '#CBD5E1' : '#111827'} stopOpacity="0.85" />
            </linearGradient>

            {/* Gloss Reflection Overlay */}
            {finishType === 'brillante' && (
              <linearGradient id="glossHighlight" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#FFFFFF" stopOpacity="0.6" />
                <stop offset="30%" stopColor="#FFFFFF" stopOpacity="0.1" />
                <stop offset="100%" stopColor="#FFFFFF" stopOpacity="0.0" />
              </linearGradient>
            )}

            {/* Wood Runner Gradient */}
            <linearGradient id="woodGrad" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#5D2E17" />
              <stop offset="50%" stopColor="#783C1D" />
              <stop offset="100%" stopColor="#4A220F" />
            </linearGradient>

            {/* Fabric Cushion Pattern */}
            <pattern
              id="cushionPattern"
              width="10"
              height="10"
              patternUnits="userSpaceOnUse"
            >
              <rect width="10" height="10" fill={fabric ? fabric.hex : '#D8C8B8'} />
              <path
                d="M0 0h10v1H0zm0 4h10v1H0zm0 4h10v1H0z"
                fill="#ffffff"
                fillOpacity="0.08"
              />
            </pattern>
          </defs>

          {/* Wooden Rocker Runners (Patines) */}
          <path
            d="M 35 240 Q 150 270 265 240 Q 255 252 150 278 Q 45 252 35 240 Z"
            fill="url(#woodGrad)"
            stroke="#2C1810"
            strokeWidth="1.5"
          />

          {/* Steel Frame Spindles */}
          <g stroke="#1E293B" strokeWidth="3" strokeLinecap="round">
            <line x1="85" y1="180" x2="65" y2="245" />
            <line x1="125" y1="180" x2="105" y2="252" />
            <line x1="175" y1="180" x2="195" y2="252" />
            <line x1="215" y1="180" x2="235" y2="245" />
            {/* Cross brace */}
            <line x1="75" y1="215" x2="225" y2="215" strokeWidth="2" />
            <line x1="95" y1="230" x2="205" y2="230" strokeWidth="1.5" />
          </g>

          {/* Molded Fiberglass Shell Body */}
          {/* Seat Base */}
          <path
            d="M 60 175 C 60 195, 240 195, 240 175 C 240 155, 60 155, 60 175 Z"
            fill="url(#fiberglassGrad)"
            stroke={isWhite ? '#CBD5E1' : '#000000'}
            strokeWidth="1.5"
          />

          {/* Backrest Ergonomic Shell */}
          <path
            d="M 80 170 C 75 120, 85 60, 110 40 C 130 25, 170 25, 190 40 C 215 60, 225 120, 220 170 C 200 178, 100 178, 80 170 Z"
            fill="url(#fiberglassGrad)"
            stroke={isWhite ? '#CBD5E1' : '#000000'}
            strokeWidth="1.5"
          />

          {/* Molded Side Armrests */}
          <path
            d="M 65 160 C 55 140, 65 115, 85 120 C 95 122, 90 145, 78 165 Z"
            fill="url(#fiberglassGrad)"
            stroke={isWhite ? '#CBD5E1' : '#000000'}
            strokeWidth="1"
          />
          <path
            d="M 235 160 C 245 140, 235 115, 215 120 C 205 122, 210 145, 222 165 Z"
            fill="url(#fiberglassGrad)"
            stroke={isWhite ? '#CBD5E1' : '#000000'}
            strokeWidth="1"
          />

          {/* Gloss Reflection Layer */}
          {finishType === 'brillante' && (
            <path
              d="M 115 48 C 130 38, 170 38, 185 48 C 195 62, 195 95, 180 100 C 160 90, 140 90, 120 100 C 105 95, 105 62, 115 48 Z"
              fill="url(#glossHighlight)"
            />
          )}

          {/* Ergonomic Cushion Layer (Removable) */}
          {hasCushion && (
            <g className="transition-opacity duration-300">
              {/* Back Cushion */}
              <path
                d="M 95 160 C 90 120, 95 70, 118 55 C 132 45, 168 45, 182 55 C 205 70, 210 120, 205 160 C 190 166, 110 166, 95 160 Z"
                fill="url(#cushionPattern)"
                stroke="#2C1810"
                strokeWidth="1.5"
                strokeOpacity="0.4"
              />

              {/* Seat Cushion */}
              <path
                d="M 75 174 C 75 190, 225 190, 225 174 C 225 160, 75 160, 75 174 Z"
                fill="url(#cushionPattern)"
                stroke="#2C1810"
                strokeWidth="1.5"
                strokeOpacity="0.4"
              />

              {/* Tufted Button Accents */}
              <circle cx="130" cy="90" r="3.5" fill="#2C1810" />
              <circle cx="170" cy="90" r="3.5" fill="#2C1810" />
              <circle cx="130" cy="125" r="3.5" fill="#2C1810" />
              <circle cx="170" cy="125" r="3.5" fill="#2C1810" />
            </g>
          )}
        </svg>
      </div>

      {/* 2D Badges Info */}
      <div className="mt-4 flex flex-wrap items-center justify-center gap-2 text-xs">
        <span className="px-2.5 py-1 rounded-full bg-white border border-[#E8E2DC] font-semibold text-[#2C1810] shadow-xs">
          Mecedora: <strong>{rockerColor.name}</strong>
        </span>
        {hasCushion && fabric ? (
          <span className="px-2.5 py-1 rounded-full bg-white border border-[#E8E2DC] font-semibold text-[#8a532b] shadow-xs">
            Cojín: <strong>{fabric.name}</strong>
          </span>
        ) : (
          <span className="px-2.5 py-1 rounded-full bg-stone-100 text-stone-600 font-medium">
            Sin cojines
          </span>
        )}
      </div>
    </div>
  );
};
