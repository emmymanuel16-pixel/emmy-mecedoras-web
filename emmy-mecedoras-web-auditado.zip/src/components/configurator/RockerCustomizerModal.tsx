import React, { useState, useMemo } from 'react';
import { 
  X, ShoppingBag, MessageCircle, Check, Sparkles, 
  ShieldCheck, Palette, Layers, CheckCircle2, ChevronRight, 
  Info, Plus, Scissors, Rotate3d, HelpCircle, HeartHandshake
} from 'lucide-react';
import { 
  CustomizerAccessoryOption, 
  CustomizerColorOption, 
  CustomizerFabricOption, 
  Product, 
  ProductCustomization, 
  StoreSettings 
} from '../../types';
import { Cushion2DViewer } from './Cushion2DViewer';
import { 
  INITIAL_CUSTOMIZER_MAIN_FABRICS, 
  INITIAL_CUSTOMIZER_TRIM_COLORS, 
  INITIAL_CUSTOMIZER_ACCESSORIES 
} from '../../data/initialData';
import { formatPrice, generateCustomizedProductWhatsAppUrl } from '../../utils/whatsapp';
import confetti from 'canvas-confetti';

interface RockerCustomizerModalProps {
  product: Product;
  settings: StoreSettings;
  onClose: () => void;
  onAddToCart: (product: Product, quantity: number, customization: ProductCustomization) => void;
}

export const RockerCustomizerModal: React.FC<RockerCustomizerModalProps> = ({
  product,
  settings,
  onClose,
  onAddToCart,
}) => {
  const config = settings.configurator;

  // Main fabrics for cushion surface (seat & backrest)
  const mainFabrics: CustomizerFabricOption[] = useMemo(() => {
    if (config?.mainFabrics && config.mainFabrics.length > 0) {
      return config.mainFabrics.filter(f => f.isActive !== false);
    }
    if (config?.cushionFabrics && config.cushionFabrics.length > 0) {
      return config.cushionFabrics.filter(f => f.isActive !== false);
    }
    return INITIAL_CUSTOMIZER_MAIN_FABRICS;
  }, [config]);

  // Trim & Piping Colors (Perimeter cord and boxing)
  const trimColors: CustomizerColorOption[] = useMemo(() => {
    if (config?.trimColors && config.trimColors.length > 0) {
      return config.trimColors.filter(c => c.isActive !== false);
    }
    if (config?.rockerColors && config.rockerColors.length > 0) {
      return config.rockerColors.filter(c => c.isActive !== false);
    }
    return INITIAL_CUSTOMIZER_TRIM_COLORS;
  }, [config]);

  // Treatments and Tailoring Accessories
  const accessoriesList: CustomizerAccessoryOption[] = useMemo(() => {
    if (config?.accessories && config.accessories.length > 0) {
      return config.accessories.filter(a => a.isActive !== false);
    }
    return INITIAL_CUSTOMIZER_ACCESSORIES;
  }, [config]);

  // State selections
  const [selectedMainFabric, setSelectedMainFabric] = useState<CustomizerFabricOption>(mainFabrics[0]);
  const [selectedTrimColor, setSelectedTrimColor] = useState<CustomizerColorOption>(trimColors[0]);
  const [selectedFabricType, setSelectedFabricType] = useState<'terciopelo' | 'lino' | 'chenille' | 'impermeable'>('terciopelo');
  const [selectedAccessories, setSelectedAccessories] = useState<string[]>([]);
  const [customNotes, setCustomNotes] = useState<string>('');
  const [quantity, setQuantity] = useState<number>(1);
  const [addedToast, setAddedToast] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<'surface' | 'trim' | 'texture' | 'extras'>('surface');

  // Toggle accessories
  const handleToggleAccessory = (accId: string) => {
    setSelectedAccessories(prev =>
      prev.includes(accId) ? prev.filter(id => id !== accId) : [...prev, accId]
    );
  };

  // Price calculations
  const basePrice = product.price;
  const fabricExtra = selectedMainFabric?.priceDiff || 0;
  const trimExtra = selectedTrimColor?.priceDiff || 0;
  
  const chosenAccessories = accessoriesList.filter(a => selectedAccessories.includes(a.id));
  const accessoriesTotal = chosenAccessories.reduce((sum, a) => sum + a.price, 0);

  const extrasPrice = fabricExtra + trimExtra + accessoriesTotal;
  const totalUnitPrice = Math.max(0, basePrice + extrasPrice);
  const totalPrice = totalUnitPrice * quantity;

  // Build the complete customization object
  const currentCustomization: ProductCustomization = {
    mainFabric: selectedMainFabric,
    trimColor: selectedTrimColor,
    fabricType: selectedFabricType,
    // Backward compatibility mappings
    rockerColor: selectedTrimColor,
    fabric: selectedMainFabric,
    hasCushion: true,
    selectedAccessories: chosenAccessories,
    customFinish: `Confección en ${selectedFabricType.toUpperCase()} con ribete contrastante`,
    customNotes: customNotes.trim() || undefined,
    basePrice,
    extrasPrice,
    totalUnitPrice
  };

  const handleAddToCart = () => {
    onAddToCart(product, quantity, currentCustomization);
    
    confetti({
      particleCount: 55,
      spread: 70,
      origin: { y: 0.8 },
      colors: ['#5C4033', '#1B365D', '#D4AF37', '#25D366'],
    });

    setAddedToast(true);
    setTimeout(() => setAddedToast(false), 2500);
  };

  const handleWhatsAppOrder = () => {
    const url = generateCustomizedProductWhatsAppUrl(
      product,
      currentCustomization,
      quantity,
      settings,
      customNotes
    );
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  return (
    <div
      id="cushion-customizer-modal-backdrop"
      className="fixed inset-0 z-50 overflow-y-auto bg-black/80 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4 md:p-6 animate-fadeIn"
      onClick={onClose}
    >
      <div
        id="cushion-customizer-modal-container"
        className="relative bg-[#FDFCFB] rounded-2xl sm:rounded-3xl max-w-5xl w-full max-h-[94vh] flex flex-col border border-[#E8E2DC] shadow-2xl overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header Bar */}
        <div className="px-4 sm:px-6 py-3.5 bg-white border-b border-[#E8E2DC] flex items-center justify-between z-20 shrink-0">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="p-2 rounded-xl bg-[#5C4033]/10 text-[#5C4033] shrink-0">
              <Scissors className="w-5 h-5" />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <h2 className="font-serif text-base sm:text-lg font-bold text-[#2C1810] truncate">
                  Personalizador 2D de Cojín Ergonómico
                </h2>
                <span className="text-[10px] bg-amber-100 text-amber-900 border border-amber-300 font-extrabold px-2 py-0.5 rounded-full shrink-0">
                  Modelo Artesanal
                </span>
              </div>
              <p className="text-[11px] sm:text-xs text-[#7A6A60] truncate">
                {product.name} — Configuración visual de color, vivos y textura en tiempo real
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-full hover:bg-[#F0EBE6] text-[#7A6A60] hover:text-[#2C1810] transition-colors cursor-pointer shrink-0 ml-2"
            title="Cerrar personalizador"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Main Body */}
        <div className="flex-1 overflow-y-auto grid grid-cols-1 lg:grid-cols-12 min-h-0">
          
          {/* Left Column: 2D Interactive Cushion Model */}
          <div className="lg:col-span-6 p-4 sm:p-6 bg-[#F8F5F0] border-b lg:border-b-0 lg:border-r border-[#E8E2DC] flex flex-col justify-between">
            <div className="w-full flex-1 min-h-[340px] sm:min-h-[420px] flex items-center justify-center">
              <Cushion2DViewer
                mainFabric={selectedMainFabric}
                trimColor={selectedTrimColor}
                fabricType={selectedFabricType}
                environment="studio"
              />
            </div>

            {/* Quick Live Palette Recap */}
            <div className="mt-4 p-3 rounded-2xl bg-white border border-[#E8E2DC] shadow-2xs flex items-center justify-between gap-3 text-xs">
              <div className="flex items-center gap-2">
                <div 
                  className="w-5 h-5 rounded-full border border-stone-300 shadow-2xs shrink-0" 
                  style={{ backgroundColor: selectedMainFabric.hex }} 
                />
                <div className="min-w-0">
                  <span className="text-[10px] text-[#7A6A60] block uppercase font-bold">Superficie Principal</span>
                  <span className="font-semibold text-[#2C1810] truncate block text-[11px] sm:text-xs">
                    {selectedMainFabric.name}
                  </span>
                </div>
              </div>

              <div className="w-px h-6 bg-[#E8E2DC] shrink-0" />

              <div className="flex items-center gap-2">
                <div 
                  className="w-5 h-5 rounded-full border border-stone-300 shadow-2xs shrink-0" 
                  style={{ backgroundColor: selectedTrimColor.hex }} 
                />
                <div className="min-w-0">
                  <span className="text-[10px] text-[#7A6A60] block uppercase font-bold">Vivo & Laterales</span>
                  <span className="font-semibold text-[#2C1810] truncate block text-[11px] sm:text-xs">
                    {selectedTrimColor.name}
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Customization Controls & Tabs */}
          <div className="lg:col-span-6 p-4 sm:p-6 flex flex-col justify-between overflow-y-auto bg-white space-y-6">
            
            <div className="space-y-5">
              {/* Category Step Navigation Tabs */}
              <div className="flex items-center gap-1.5 p-1 bg-[#F5F2EC] rounded-2xl border border-[#E8E2DC] overflow-x-auto no-scrollbar">
                <button
                  type="button"
                  onClick={() => setActiveTab('surface')}
                  className={`flex-1 min-w-[90px] py-2 px-2.5 rounded-xl text-xs font-bold transition-all text-center cursor-pointer ${
                    activeTab === 'surface'
                      ? 'bg-white text-[#2C1810] shadow-xs'
                      : 'text-[#7A6A60] hover:text-[#2C1810]'
                  }`}
                >
                  1. Color Principal
                </button>
                <button
                  type="button"
                  onClick={() => setActiveTab('trim')}
                  className={`flex-1 min-w-[90px] py-2 px-2.5 rounded-xl text-xs font-bold transition-all text-center cursor-pointer ${
                    activeTab === 'trim'
                      ? 'bg-white text-[#2C1810] shadow-xs'
                      : 'text-[#7A6A60] hover:text-[#2C1810]'
                  }`}
                >
                  2. Ribete / Vivo
                </button>
                <button
                  type="button"
                  onClick={() => setActiveTab('texture')}
                  className={`flex-1 min-w-[90px] py-2 px-2.5 rounded-xl text-xs font-bold transition-all text-center cursor-pointer ${
                    activeTab === 'texture'
                      ? 'bg-white text-[#2C1810] shadow-xs'
                      : 'text-[#7A6A60] hover:text-[#2C1810]'
                  }`}
                >
                  3. Tejido
                </button>
                <button
                  type="button"
                  onClick={() => setActiveTab('extras')}
                  className={`flex-1 min-w-[90px] py-2 px-2.5 rounded-xl text-xs font-bold transition-all text-center cursor-pointer ${
                    activeTab === 'extras'
                      ? 'bg-white text-[#2C1810] shadow-xs'
                      : 'text-[#7A6A60] hover:text-[#2C1810]'
                  }`}
                >
                  4. Extras & Notas
                </button>
              </div>

              {/* TAB 1: Main Fabric Surface (Seat & Backrest) */}
              {activeTab === 'surface' && (
                <div className="space-y-4 animate-fadeIn">
                  <div>
                    <h3 className="font-serif text-sm font-bold text-[#2C1810] flex items-center gap-1.5">
                      <span>Superficie Acolchada Principal (Asiento y Respaldo)</span>
                    </h3>
                    <p className="text-xs text-[#7A6A60] mt-0.5">
                      Elige el tono frontal que estará en contacto directo con tu espalda y asiento.
                    </p>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                    {mainFabrics.map((fab) => {
                      const isSelected = selectedMainFabric.id === fab.id;
                      return (
                        <button
                          key={fab.id}
                          type="button"
                          onClick={() => setSelectedMainFabric(fab)}
                          className={`p-2.5 rounded-2xl border text-left transition-all flex items-center gap-2.5 cursor-pointer ${
                            isSelected
                              ? 'border-[#5C4033] bg-[#FDFBF7] ring-2 ring-[#5C4033]/20 shadow-xs'
                              : 'border-[#E8E2DC] hover:border-stone-400 bg-white'
                          }`}
                        >
                          <div
                            className="w-8 h-8 rounded-full border border-stone-300 shadow-2xs shrink-0 flex items-center justify-center"
                            style={{ backgroundColor: fab.hex }}
                          >
                            {isSelected && (
                              <Check className={`w-4 h-4 ${fab.hex.toLowerCase() === '#ffffff' || fab.hex.toLowerCase() === '#f3efe6' ? 'text-stone-900' : 'text-white'}`} />
                            )}
                          </div>
                          <div className="min-w-0">
                            <span className="text-xs font-bold text-[#2C1810] block truncate">
                              {fab.name}
                            </span>
                            <span className="text-[10px] text-[#7A6A60] block capitalize">
                              {fab.priceDiff ? `+${formatPrice(fab.priceDiff, settings.currency)}` : 'Incluido'}
                            </span>
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* TAB 2: Trim, Piping & Boxing (Borde, Ribete y Laterales) */}
              {activeTab === 'trim' && (
                <div className="space-y-4 animate-fadeIn">
                  <div>
                    <h3 className="font-serif text-sm font-bold text-[#2C1810] flex items-center gap-1.5">
                      <span>Borde, Ribete Perimetral y Laterales (Vivo)</span>
                    </h3>
                    <p className="text-xs text-[#7A6A60] mt-0.5">
                      Define el color de los vivos de costura y la franja perimetral como en el modelo artesanal.
                    </p>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                    {trimColors.map((trim) => {
                      const isSelected = selectedTrimColor.id === trim.id;
                      return (
                        <button
                          key={trim.id}
                          type="button"
                          onClick={() => setSelectedTrimColor(trim)}
                          className={`p-2.5 rounded-2xl border text-left transition-all flex items-center gap-2.5 cursor-pointer ${
                            isSelected
                              ? 'border-[#5C4033] bg-[#FDFBF7] ring-2 ring-[#5C4033]/20 shadow-xs'
                              : 'border-[#E8E2DC] hover:border-stone-400 bg-white'
                          }`}
                        >
                          <div
                            className="w-8 h-8 rounded-full border border-stone-300 shadow-2xs shrink-0 flex items-center justify-center"
                            style={{ backgroundColor: trim.hex }}
                          >
                            {isSelected && (
                              <Check className={`w-4 h-4 ${trim.hex.toLowerCase() === '#ffffff' || trim.hex.toLowerCase() === '#e8e0d5' ? 'text-stone-900' : 'text-white'}`} />
                            )}
                          </div>
                          <div className="min-w-0">
                            <span className="text-xs font-bold text-[#2C1810] block truncate">
                              {trim.name}
                            </span>
                            <span className="text-[10px] text-[#7A6A60] block">
                              {trim.priceDiff ? `+${formatPrice(trim.priceDiff, settings.currency)}` : 'Incluido'}
                            </span>
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* TAB 3: Texture & Fabric Material */}
              {activeTab === 'texture' && (
                <div className="space-y-4 animate-fadeIn">
                  <div>
                    <h3 className="font-serif text-sm font-bold text-[#2C1810] flex items-center gap-1.5">
                      <span>Tipo de Tejido y Sensación al Tacto</span>
                    </h3>
                    <p className="text-xs text-[#7A6A60] mt-0.5">
                      Selecciona la textura textil adecuada según tu ambiente (interior o terraza).
                    </p>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {[
                      {
                        type: 'terciopelo' as const,
                        name: 'Terciopelo Soft Velvet (Recomendado)',
                        desc: 'Tacto afelpado ultrasuave y lustre aterciopelado idéntico al modelo de referencia.',
                        badge: 'Favorito',
                      },
                      {
                        type: 'lino' as const,
                        name: 'Lino Rústico Transpirable',
                        desc: 'Tejido fresco, natural y ligero, ideal para climas cálidos y ventilados.',
                        badge: 'Fresco',
                      },
                      {
                        type: 'chenille' as const,
                        name: 'Chenille Acolchado Resistente',
                        desc: 'Fibra de alta durabilidad, trama gruesa y excelente resistencia al uso diario.',
                        badge: 'Duradero',
                      },
                      {
                        type: 'impermeable' as const,
                        name: 'Lona Impermeable Outdoor',
                        desc: 'Tratamiento hidrófugo náutico que repele agua y rayos UV para exteriores.',
                        badge: 'Intemperie',
                      },
                    ].map((item) => {
                      const isSelected = selectedFabricType === item.type;
                      return (
                        <div
                          key={item.type}
                          onClick={() => setSelectedFabricType(item.type)}
                          className={`p-3.5 rounded-2xl border transition-all cursor-pointer ${
                            isSelected
                              ? 'border-[#5C4033] bg-[#FDFBF7] ring-2 ring-[#5C4033]/20 shadow-xs'
                              : 'border-[#E8E2DC] hover:border-stone-400 bg-white'
                          }`}
                        >
                          <div className="flex items-center justify-between mb-1">
                            <span className="text-xs font-bold text-[#2C1810]">{item.name}</span>
                            <span className={`text-[10px] font-extrabold px-2 py-0.5 rounded-full ${
                              isSelected ? 'bg-[#5C4033] text-white' : 'bg-stone-100 text-stone-600'
                            }`}>
                              {item.badge}
                            </span>
                          </div>
                          <p className="text-[11px] text-[#7A6A60] leading-relaxed">
                            {item.desc}
                          </p>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* TAB 4: Extras, Treatments & Custom Notes */}
              {activeTab === 'extras' && (
                <div className="space-y-4 animate-fadeIn">
                  <div>
                    <h3 className="font-serif text-sm font-bold text-[#2C1810] flex items-center gap-1.5">
                      <span>Tratamientos y Mejoras de Confección</span>
                    </h3>
                    <p className="text-xs text-[#7A6A60] mt-0.5">
                      Opciones adicionales para el taller de tapicería artesanal.
                    </p>
                  </div>

                  <div className="space-y-2.5">
                    {accessoriesList.map((acc) => {
                      const isSelected = selectedAccessories.includes(acc.id);
                      return (
                        <label
                          key={acc.id}
                          onClick={() => handleToggleAccessory(acc.id)}
                          className={`p-3 rounded-2xl border flex items-start gap-3 transition-all cursor-pointer ${
                            isSelected
                              ? 'border-[#5C4033] bg-[#FDFBF7] ring-1 ring-[#5C4033]/20'
                              : 'border-[#E8E2DC] hover:border-stone-400 bg-white'
                          }`}
                        >
                          <div className={`mt-0.5 w-4 h-4 rounded-md border flex items-center justify-center shrink-0 ${
                            isSelected ? 'bg-[#5C4033] border-[#5C4033] text-white' : 'border-stone-300 bg-white'
                          }`}>
                            {isSelected && <Check className="w-3 h-3" />}
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center justify-between gap-2">
                              <span className="text-xs font-bold text-[#2C1810]">{acc.name}</span>
                              <span className="text-xs font-bold text-[#5C4033] shrink-0">
                                +{formatPrice(acc.price, settings.currency)}
                              </span>
                            </div>
                            {acc.description && (
                              <p className="text-[11px] text-[#7A6A60] mt-0.5">{acc.description}</p>
                            )}
                          </div>
                        </label>
                      );
                    })}
                  </div>

                  {/* Notes for sewing workshop */}
                  <div className="pt-2">
                    <label className="text-xs font-bold text-[#2C1810] block mb-1">
                      Instrucciones Especiales para el Taller de Costura (Opcional)
                    </label>
                    <textarea
                      value={customNotes}
                      onChange={(e) => setCustomNotes(e.target.value)}
                      placeholder="Ej. Añadir 2 pares extra de lazos para sujetar al respaldo alto de mi mecedora..."
                      rows={2}
                      className="w-full text-xs p-3 bg-stone-50 border border-[#E8E2DC] rounded-xl focus:outline-hidden focus:ring-2 focus:ring-[#5C4033]/20 text-[#2C1810]"
                    />
                  </div>
                </div>
              )}
            </div>

            {/* Bottom Actions Bar & Price Total */}
            <div className="pt-4 border-t border-[#E8E2DC] space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <span className="text-[10px] uppercase font-bold text-[#7A6A60] block tracking-wider">
                    Total Cojín Personalizado
                  </span>
                  <div className="flex items-baseline gap-1.5">
                    <span className="font-serif text-xl sm:text-2xl font-bold text-[#2C1810]">
                      {formatPrice(totalPrice, settings.currency)}
                    </span>
                    {extrasPrice > 0 && (
                      <span className="text-[11px] text-emerald-700 font-semibold">
                        (+{formatPrice(extrasPrice * quantity, settings.currency)} en mejoras)
                      </span>
                    )}
                  </div>
                </div>

                {/* Quantity selector */}
                <div className="flex items-center border border-[#E8E2DC] rounded-xl bg-stone-50 p-1">
                  <button
                    type="button"
                    onClick={() => setQuantity(q => Math.max(1, q - 1))}
                    className="w-7 h-7 rounded-lg bg-white border border-stone-200 text-stone-700 flex items-center justify-center font-bold text-sm hover:bg-stone-100 transition-colors cursor-pointer"
                  >
                    -
                  </button>
                  <span className="w-8 text-center text-xs font-bold text-[#2C1810]">
                    {quantity}
                  </span>
                  <button
                    type="button"
                    onClick={() => setQuantity(q => q + 1)}
                    className="w-7 h-7 rounded-lg bg-white border border-stone-200 text-stone-700 flex items-center justify-center font-bold text-sm hover:bg-stone-100 transition-colors cursor-pointer"
                  >
                    +
                  </button>
                </div>
              </div>

              {/* Action buttons */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                <button
                  type="button"
                  onClick={handleAddToCart}
                  className="w-full py-3 px-4 rounded-xl bg-[#2C1810] hover:bg-[#3E2723] text-white font-bold text-xs sm:text-sm flex items-center justify-center gap-2 transition-all shadow-md cursor-pointer"
                >
                  <ShoppingBag className="w-4 h-4" />
                  <span>{addedToast ? '¡Agregado al Carrito!' : 'Agregar Cojín al Carrito'}</span>
                </button>

                <button
                  type="button"
                  onClick={handleWhatsAppOrder}
                  className="w-full py-3 px-4 rounded-xl bg-[#25D366] hover:bg-[#20bd5a] text-white font-bold text-xs sm:text-sm flex items-center justify-center gap-2 transition-all shadow-md cursor-pointer"
                >
                  <MessageCircle className="w-4 h-4" />
                  <span>Ordenar por WhatsApp</span>
                </button>
              </div>
            </div>

          </div>

        </div>
      </div>
    </div>
  );
};
