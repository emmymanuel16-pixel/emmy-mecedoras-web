import React, { useState } from 'react';
import { 
  CustomizerColorOption, 
  CustomizerFabricOption, 
  ConfiguratorSettings 
} from '../../types';
import { 
  Maximize2, Minimize2, Sun, Sparkles, 
  Palette, Layers, Check, Info, ZoomIn, ZoomOut
} from 'lucide-react';

interface Smart2DRockerViewerProps {
  rockerColor: CustomizerColorOption;
  fabric?: CustomizerFabricOption;
  hasCushion: boolean;
  productName: string;
  finishType?: 'brillante' | 'satinado' | 'mate';
  baseImageUrl?: string;
  config?: ConfiguratorSettings;
  className?: string;
}

export const Smart2DRockerViewer: React.FC<Smart2DRockerViewerProps> = ({
  rockerColor,
  fabric,
  hasCushion,
  productName,
  finishType = 'brillante',
  baseImageUrl,
  config,
  className = '',
}) => {
  const [lightingMode, setLightingMode] = useState<'studio' | 'terrace' | 'warm'>('studio');
  const [zoomLevel, setZoomLevel] = useState<number>(1);
  const [isHovered, setIsHovered] = useState<boolean>(false);

  // Default high-res frontal photograph if none specified
  const mainImage = baseImageUrl || config?.baseImageUrl || 'https://images.unsplash.com/photo-1598300042247-d088f8ab3a91?auto=format&fit=crop&w=1200&q=90';

  const isWhite = rockerColor.hex.toLowerCase() === '#ffffff' || rockerColor.hex.toLowerCase() === '#f8fafc';
  const isBlack = rockerColor.hex.toLowerCase() === '#1c1c1c' || rockerColor.hex.toLowerCase() === '#000000' || rockerColor.hex.toLowerCase() === '#1e293b';
  const isMahogany = rockerColor.name.toLowerCase().includes('caoba') || rockerColor.hex.toLowerCase() === '#4a1515' || rockerColor.hex.toLowerCase() === '#4a150e';

  // Calculate dynamic structure shadow and gradient tint
  const structurePrimaryColor = rockerColor.hex;
  const structureDarkAccent = isWhite
    ? '#CBD5E1'
    : isMahogany
    ? '#2D0A05'
    : isBlack
    ? '#09090B'
    : '#1E293B';

  const structureLightAccent = isWhite
    ? '#FFFFFF'
    : isMahogany
    ? '#7A2215'
    : isBlack
    ? '#3F3F46'
    : rockerColor.hex;

  // Background lighting tone
  const lightingBgClass = 
    lightingMode === 'studio' 
      ? 'from-[#FDFBF7] via-[#F4EDE4] to-[#E5DDD2]' 
      : lightingMode === 'terrace'
      ? 'from-[#FFFDF5] via-[#FDF3D8] to-[#E8DCB8]'
      : 'from-[#FDF6ED] via-[#F5E6D3] to-[#DEC5A6]';

  return (
    <div 
      className={`relative w-full h-full min-h-[420px] sm:min-h-[480px] lg:min-h-[540px] rounded-3xl overflow-hidden bg-gradient-to-b ${lightingBgClass} flex flex-col items-center justify-center p-4 sm:p-8 border border-[#E8E2DC] shadow-inner select-none transition-colors duration-500 ${className}`}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Dynamic Lighting Ambiance Glow */}
      <div 
        className="absolute inset-0 pointer-events-none transition-opacity duration-700"
        style={{
          background: lightingMode === 'terrace' 
            ? 'radial-gradient(circle at 80% 20%, rgba(253, 224, 71, 0.25) 0%, transparent 60%)'
            : lightingMode === 'warm'
            ? 'radial-gradient(circle at 50% 10%, rgba(249, 115, 22, 0.18) 0%, transparent 70%)'
            : 'radial-gradient(circle at 50% 30%, rgba(255, 255, 255, 0.8) 0%, transparent 70%)'
        }}
      />

      {/* Lighting & Environment Switcher Pill */}
      <div className="absolute top-4 left-4 z-20 flex items-center gap-1.5 p-1 bg-white/85 backdrop-blur-md rounded-2xl border border-stone-200/80 shadow-xs">
        <button
          type="button"
          onClick={() => setLightingMode('studio')}
          title="Iluminación de Estudio Fotográfico"
          className={`px-2.5 py-1 rounded-xl text-[11px] font-bold flex items-center gap-1 transition-all ${
            lightingMode === 'studio'
              ? 'bg-[#8a532b] text-white shadow-xs'
              : 'text-stone-600 hover:text-stone-900 hover:bg-stone-100'
          }`}
        >
          <Sparkles className="w-3 h-3" />
          <span className="hidden sm:inline">Estudio</span>
        </button>
        <button
          type="button"
          onClick={() => setLightingMode('terrace')}
          title="Luz Solar de Terraza / Exterior"
          className={`px-2.5 py-1 rounded-xl text-[11px] font-bold flex items-center gap-1 transition-all ${
            lightingMode === 'terrace'
              ? 'bg-amber-600 text-white shadow-xs'
              : 'text-stone-600 hover:text-stone-900 hover:bg-stone-100'
          }`}
        >
          <Sun className="w-3 h-3" />
          <span className="hidden sm:inline">Terraza</span>
        </button>
        <button
          type="button"
          onClick={() => setLightingMode('warm')}
          title="Luz Cálida de Sala"
          className={`px-2.5 py-1 rounded-xl text-[11px] font-bold flex items-center gap-1 transition-all ${
            lightingMode === 'warm'
              ? 'bg-[#B45309] text-white shadow-xs'
              : 'text-stone-600 hover:text-stone-900 hover:bg-stone-100'
          }`}
        >
          <Palette className="w-3 h-3" />
          <span className="hidden sm:inline">Cálido</span>
        </button>
      </div>

      {/* Zoom / Full Inspection Controls */}
      <div className="absolute top-4 right-4 z-20 flex items-center gap-1 p-1 bg-white/85 backdrop-blur-md rounded-2xl border border-stone-200/80 shadow-xs">
        <button
          type="button"
          onClick={() => setZoomLevel(prev => prev === 1 ? 1.25 : prev === 1.25 ? 1.5 : 1)}
          title="Aumentar zoom de textura"
          className="p-1.5 rounded-xl text-stone-600 hover:text-stone-900 hover:bg-stone-100 transition-colors flex items-center gap-1 text-[11px] font-bold"
        >
          {zoomLevel > 1 ? <ZoomOut className="w-3.5 h-3.5" /> : <ZoomIn className="w-3.5 h-3.5" />}
          <span className="text-[10px] font-mono px-1">{zoomLevel}x</span>
        </button>
      </div>

      {/* Main Photographic Smart Stage Canvas */}
      <div 
        className="relative w-full max-w-[440px] aspect-square flex items-center justify-center transition-transform duration-500 ease-out"
        style={{ transform: `scale(${zoomLevel})` }}
      >
        {/* Soft Multi-layered Floor Shadow */}
        <div className="absolute -bottom-4 w-[75%] h-8 bg-black/25 rounded-full blur-xl transform scale-y-50" />
        <div className="absolute -bottom-2 w-[55%] h-4 bg-[#2C1810]/40 rounded-full blur-md" />

        {/* Photorealistic Smart Vector / Overlay Render */}
        <svg
          viewBox="0 0 500 500"
          className="w-full h-full drop-shadow-2xl overflow-visible transition-all duration-300"
        >
          <defs>
            {/* Fiberglass Shell Gradient */}
            <linearGradient id="smartFiberglassGrad" x1="15%" y1="0%" x2="85%" y2="100%">
              <stop offset="0%" stopColor={structureLightAccent} stopOpacity="1" />
              <stop offset="45%" stopColor={structurePrimaryColor} stopOpacity="1" />
              <stop offset="85%" stopColor={structureDarkAccent} stopOpacity="1" />
              <stop offset="100%" stopColor={structureDarkAccent} stopOpacity="0.95" />
            </linearGradient>

            {/* Armrest Reflection Gradient */}
            <linearGradient id="armrestGrad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor={structureLightAccent} />
              <stop offset="50%" stopColor={structurePrimaryColor} />
              <stop offset="100%" stopColor={structureDarkAccent} />
            </linearGradient>

            {/* Wooden Runners Curved Base */}
            <linearGradient id="runnerWoodGrad" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#451A03" />
              <stop offset="35%" stopColor="#78350F" />
              <stop offset="70%" stopColor="#92400E" />
              <stop offset="100%" stopColor="#451A03" />
            </linearGradient>

            {/* High-Gloss Specular Highlight */}
            {finishType === 'brillante' && (
              <linearGradient id="glossSweepHighlight" x1="30%" y1="0%" x2="70%" y2="100%">
                <stop offset="0%" stopColor="#FFFFFF" stopOpacity="0.75" />
                <stop offset="25%" stopColor="#FFFFFF" stopOpacity="0.3" />
                <stop offset="60%" stopColor="#FFFFFF" stopOpacity="0.0" />
              </linearGradient>
            )}

            {/* Satin Finish Soft Highlight */}
            {finishType === 'satinado' && (
              <linearGradient id="satinSoftHighlight" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#FFFFFF" stopOpacity="0.35" />
                <stop offset="50%" stopColor="#FFFFFF" stopOpacity="0.1" />
                <stop offset="100%" stopColor="#FFFFFF" stopOpacity="0.0" />
              </linearGradient>
            )}

            {/* Cushion Fabric Texture Pattern / Colors */}
            <pattern
              id="cushionRealTexture"
              width="60"
              height="60"
              patternUnits="userSpaceOnUse"
            >
              {fabric?.textureUrl ? (
                <image
                  href={fabric.textureUrl}
                  width="60"
                  height="60"
                  preserveAspectRatio="xMidYMid slice"
                />
              ) : (
                <>
                  <rect width="60" height="60" fill={fabric ? fabric.hex : '#D8C8B8'} />
                  {/* Textile micro-weave simulation */}
                  <path
                    d="M0 10h60v2H0zm0 20h60v2H0zm0 20h60v2H0z"
                    fill="#000000"
                    fillOpacity="0.06"
                  />
                  <path
                    d="M10 0v60h2V0zm20 0v60h2V0zm20 0v60h2V0z"
                    fill="#ffffff"
                    fillOpacity="0.08"
                  />
                </>
              )}
            </pattern>

            {/* Cushion Shadow Depth Overlay */}
            <linearGradient id="cushionDepthGrad" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#000000" stopOpacity="0.0" />
              <stop offset="70%" stopColor="#000000" stopOpacity="0.15" />
              <stop offset="100%" stopColor="#000000" stopOpacity="0.35" />
            </linearGradient>

            {/* Tufted Button Shadow */}
            <radialGradient id="tuftShadow" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="#000000" stopOpacity="0.6" />
              <stop offset="50%" stopColor="#000000" stopOpacity="0.25" />
              <stop offset="100%" stopColor="#000000" stopOpacity="0" />
            </radialGradient>
          </defs>

          {/* ================= 1. WOODEN RUNNERS (PATINES) ================= */}
          <g id="rocker-runners">
            {/* Left/Back runner shadow */}
            <path
              d="M 60 415 Q 250 470 440 415 Q 430 432 250 460 Q 70 432 60 415 Z"
              fill="#291205"
              opacity="0.8"
            />
            {/* Front Runner with rich woodgrain contour */}
            <path
              d="M 50 410 Q 250 468 450 410 Q 438 430 250 455 Q 62 430 50 410 Z"
              fill="url(#runnerWoodGrad)"
              stroke="#2C1810"
              strokeWidth="2"
            />
          </g>

          {/* ================= 2. REINFORCED BASE SUPPORTS ================= */}
          <g id="rocker-base-supports" stroke="#1E293B" strokeWidth="4.5" strokeLinecap="round">
            {/* Rear upright legs */}
            <line x1="140" y1="310" x2="100" y2="418" />
            <line x1="360" y1="310" x2="400" y2="418" />
            {/* Front support legs */}
            <line x1="200" y1="310" x2="170" y2="435" />
            <line x1="300" y1="310" x2="330" y2="435" />
            {/* Geometric Cross Bracing */}
            <line x1="120" y1="365" x2="380" y2="365" strokeWidth="3" />
            <line x1="150" y1="390" x2="350" y2="390" strokeWidth="2.5" />
          </g>

          {/* ================= 3. MOLDED FIBERGLASS BODY (ESTRUCTURA) ================= */}
          <g id="fiberglass-shell" className="transition-all duration-300 ease-out">
            {/* Outer Ergonomic Backrest Shell */}
            <path
              d="M 125 300 C 110 200, 130 90, 180 55 C 215 30, 285 30, 320 55 C 370 90, 390 200, 375 300 C 340 315, 160 315, 125 300 Z"
              fill="url(#smartFiberglassGrad)"
              stroke={isWhite ? '#CBD5E1' : '#0F172A'}
              strokeWidth="2"
            />

            {/* Inner Molded Seat Shell Base */}
            <path
              d="M 95 305 C 95 350, 405 350, 405 305 C 405 265, 95 265, 95 305 Z"
              fill="url(#smartFiberglassGrad)"
              stroke={isWhite ? '#CBD5E1' : '#0F172A'}
              strokeWidth="2"
            />

            {/* Curved Molded Armrests (Fibra de Vidrio con Brillo) */}
            {/* Left Armrest */}
            <path
              d="M 105 275 C 80 235, 95 185, 135 195 C 150 198, 140 240, 122 280 Z"
              fill="url(#armrestGrad)"
              stroke={isWhite ? '#CBD5E1' : '#0F172A'}
              strokeWidth="1.8"
            />
            {/* Right Armrest */}
            <path
              d="M 395 275 C 420 235, 405 185, 365 195 C 350 198, 360 240, 378 280 Z"
              fill="url(#armrestGrad)"
              stroke={isWhite ? '#CBD5E1' : '#0F172A'}
              strokeWidth="1.8"
            />

            {/* High-Gloss Specular Reflections (Gelcoat Brillante) */}
            {finishType === 'brillante' && (
              <g className="pointer-events-none">
                {/* Backrest Gloss Arch */}
                <path
                  d="M 185 68 C 220 50, 280 50, 315 68 C 330 95, 330 145, 305 155 C 270 140, 230 140, 195 155 C 170 145, 170 95, 185 68 Z"
                  fill="url(#glossSweepHighlight)"
                />
                {/* Armrest Edge Highlights */}
                <path
                  d="M 112 250 C 96 220, 106 195, 130 200"
                  stroke="#FFFFFF"
                  strokeWidth="3.5"
                  strokeLinecap="round"
                  opacity="0.8"
                />
                <path
                  d="M 388 250 C 404 220, 394 195, 370 200"
                  stroke="#FFFFFF"
                  strokeWidth="3.5"
                  strokeLinecap="round"
                  opacity="0.8"
                />
              </g>
            )}

            {/* Satin Soft Diffused Highlight */}
            {finishType === 'satinado' && (
              <path
                d="M 185 68 C 220 50, 280 50, 315 68 C 330 95, 330 145, 305 155 C 270 140, 230 140, 195 155 C 170 145, 170 95, 185 68 Z"
                fill="url(#satinSoftHighlight)"
                className="pointer-events-none"
              />
            )}
          </g>

          {/* ================= 4. CUSHIONS LAYER (COJINES CON TELAS Y TEXTURAS) ================= */}
          {hasCushion ? (
            <g 
              id="cushions-group" 
              className="transition-all duration-300 ease-out animate-fadeIn"
            >
              {/* Backrest Cushion with Ergonomic Contours */}
              <path
                d="M 150 280 C 140 200, 150 100, 190 75 C 220 58, 280 58, 310 75 C 350 100, 360 200, 350 280 C 315 292, 185 292, 150 280 Z"
                fill="url(#cushionRealTexture)"
                stroke="#2C1810"
                strokeWidth="2"
                strokeOpacity="0.4"
              />
              {/* Backrest Depth Shadow Overlay */}
              <path
                d="M 150 280 C 140 200, 150 100, 190 75 C 220 58, 280 58, 310 75 C 350 100, 360 200, 350 280 C 315 292, 185 292, 150 280 Z"
                fill="url(#cushionDepthGrad)"
              />

              {/* Seat Cushion (Thick Padded Base) */}
              <path
                d="M 120 300 C 120 338, 380 338, 380 300 C 380 270, 120 270, 120 300 Z"
                fill="url(#cushionRealTexture)"
                stroke="#2C1810"
                strokeWidth="2"
                strokeOpacity="0.4"
              />
              {/* Seat Depth Shadow */}
              <path
                d="M 120 300 C 120 338, 380 338, 380 300 C 380 270, 120 270, 120 300 Z"
                fill="url(#cushionDepthGrad)"
              />

              {/* Tufted Buttons and Crease Folds (Botones Capitronados) */}
              {/* Top Row Tufts */}
              <g className="tufts">
                <circle cx="210" cy="130" r="10" fill="url(#tuftShadow)" />
                <circle cx="210" cy="130" r="4" fill="#2C1810" opacity="0.75" />
                <path d="M 200 130 Q 210 125 220 130" stroke="#000000" strokeWidth="1.2" opacity="0.4" fill="none" />

                <circle cx="290" cy="130" r="10" fill="url(#tuftShadow)" />
                <circle cx="290" cy="130" r="4" fill="#2C1810" opacity="0.75" />
                <path d="M 280 130 Q 290 125 300 130" stroke="#000000" strokeWidth="1.2" opacity="0.4" fill="none" />

                {/* Middle Row Tufts */}
                <circle cx="250" cy="185" r="12" fill="url(#tuftShadow)" />
                <circle cx="250" cy="185" r="4.5" fill="#2C1810" opacity="0.8" />
                <path d="M 235 185 Q 250 178 265 185" stroke="#000000" strokeWidth="1.5" opacity="0.45" fill="none" />

                {/* Bottom Row Tufts */}
                <circle cx="210" cy="240" r="10" fill="url(#tuftShadow)" />
                <circle cx="210" cy="240" r="4" fill="#2C1810" opacity="0.75" />
                <path d="M 200 240 Q 210 235 220 240" stroke="#000000" strokeWidth="1.2" opacity="0.4" fill="none" />

                <circle cx="290" cy="240" r="10" fill="url(#tuftShadow)" />
                <circle cx="290" cy="240" r="4" fill="#2C1810" opacity="0.75" />
                <path d="M 280 240 Q 290 235 300 240" stroke="#000000" strokeWidth="1.2" opacity="0.4" fill="none" />

                {/* Seat Cushion Tufts */}
                <circle cx="200" cy="298" r="8" fill="url(#tuftShadow)" />
                <circle cx="200" cy="298" r="3.5" fill="#2C1810" opacity="0.7" />

                <circle cx="250" cy="302" r="9" fill="url(#tuftShadow)" />
                <circle cx="250" cy="302" r="3.5" fill="#2C1810" opacity="0.7" />

                <circle cx="300" cy="298" r="8" fill="url(#tuftShadow)" />
                <circle cx="300" cy="298" r="3.5" fill="#2C1810" opacity="0.7" />
              </g>

              {/* Natural Fold Lines */}
              <g stroke="#000000" strokeWidth="1.2" strokeOpacity="0.25" fill="none">
                <path d="M 210 130 Q 250 185 210 240" />
                <path d="M 290 130 Q 250 185 290 240" />
                <path d="M 210 130 Q 250 120 290 130" />
                <path d="M 210 240 Q 250 250 290 240" />
              </g>
            </g>
          ) : (
            /* Bare Molded Fiberglass Seat when cushion is removed */
            <g id="bare-seat-interior" className="transition-all duration-300 ease-out animate-fadeIn">
              <path
                d="M 160 270 C 160 160, 180 90, 250 90 C 320 90, 340 160, 340 270 C 310 280, 190 280, 160 270 Z"
                fill={structureDarkAccent}
                opacity="0.35"
              />
              <path
                d="M 130 295 C 130 325, 370 325, 370 295 C 370 275, 130 275, 130 295 Z"
                fill={structureDarkAccent}
                opacity="0.4"
              />
              {/* Ergonomic spinal ribs */}
              <g stroke={structureLightAccent} strokeWidth="1.5" strokeOpacity="0.4" strokeLinecap="round">
                <line x1="200" y1="140" x2="300" y2="140" />
                <line x1="190" y1="180" x2="310" y2="180" />
                <line x1="185" y1="220" x2="315" y2="220" />
              </g>
            </g>
          )}
        </svg>
      </div>

      {/* Floating Status Badge at Bottom */}
      <div className="absolute bottom-3 left-4 right-4 z-20 flex items-center justify-between pointer-events-none">
        <div className="bg-white/90 backdrop-blur-md px-3 py-1.5 rounded-2xl border border-stone-200/80 shadow-xs flex items-center gap-2">
          <div 
            className="w-3.5 h-3.5 rounded-full border border-black/10 shrink-0 shadow-2xs"
            style={{ backgroundColor: rockerColor.hex }}
          />
          <span className="text-[11px] font-bold text-stone-800 truncate max-w-[130px] sm:max-w-[200px]">
            {rockerColor.name} ({finishType})
          </span>
          <span className="text-stone-300">|</span>
          <span className="text-[11px] font-semibold text-stone-600 truncate max-w-[120px] sm:max-w-[180px]">
            {hasCushion && fabric ? fabric.name : 'Sin Cojín'}
          </span>
        </div>

        <div className="bg-[#2C1810]/80 backdrop-blur-md px-2.5 py-1 rounded-xl text-white text-[10px] font-bold tracking-wider uppercase hidden sm:flex items-center gap-1.5 shadow-xs">
          <Sparkles className="w-3 h-3 text-amber-400" />
          <span>Vista 2D Real</span>
        </div>
      </div>
    </div>
  );
};
