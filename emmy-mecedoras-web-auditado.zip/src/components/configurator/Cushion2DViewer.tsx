import React, { useState } from 'react';
import { CustomizerColorOption, CustomizerFabricOption } from '../../types';
import { 
  ZoomIn, ZoomOut, Sparkles, Sun, RefreshCw, 
  Layers, ShieldCheck, CheckCircle2, Eye, Image as ImageIcon
} from 'lucide-react';

interface Cushion2DViewerProps {
  mainFabric: CustomizerFabricOption;
  trimColor: CustomizerColorOption;
  fabricType?: 'terciopelo' | 'lino' | 'chenille' | 'impermeable';
  environment?: 'studio' | 'warm';
  className?: string;
}

export const Cushion2DViewer: React.FC<Cushion2DViewerProps> = ({
  mainFabric,
  trimColor,
  fabricType = 'terciopelo',
  environment = 'studio',
  className = '',
}) => {
  const [zoomLevel, setZoomLevel] = useState<number>(1);
  const [currentEnv, setCurrentEnv] = useState<'studio' | 'warm'>(environment);
  const [showOriginalRef, setShowOriginalRef] = useState<boolean>(false);

  const isWarm = currentEnv === 'warm';

  return (
    <div 
      className={`relative w-full h-full min-h-[390px] sm:min-h-[470px] rounded-3xl overflow-hidden flex flex-col items-center justify-center p-3 sm:p-4 select-none transition-all duration-300 border border-[#E8E2DC] shadow-inner ${className}`}
      style={{
        background: isWarm 
          ? 'radial-gradient(circle at 50% 35%, #FFFDF8 0%, #F5EDE0 65%, #E5DAC9 100%)'
          : 'radial-gradient(circle at 50% 35%, #FBFBFB 0%, #F0EAE4 65%, #DFD7CF 100%)'
      }}
    >
      {/* Top Lighting Controls */}
      <div className="absolute top-3 left-3 z-20 flex items-center gap-1 p-1 bg-white/90 backdrop-blur-md rounded-2xl border border-stone-200 shadow-xs">
        <button
          type="button"
          onClick={() => setCurrentEnv('studio')}
          className={`px-2.5 py-1 rounded-xl text-[11px] font-bold flex items-center gap-1 transition-all cursor-pointer ${
            currentEnv === 'studio' ? 'bg-[#5C4033] text-white shadow-xs' : 'text-stone-600 hover:text-stone-900'
          }`}
          title="Luz de Estudio Neutra"
        >
          <Sparkles className="w-3 h-3" />
          <span className="hidden sm:inline">Estudio</span>
        </button>
        <button
          type="button"
          onClick={() => setCurrentEnv('warm')}
          className={`px-2.5 py-1 rounded-xl text-[11px] font-bold flex items-center gap-1 transition-all cursor-pointer ${
            currentEnv === 'warm' ? 'bg-[#5C4033] text-white shadow-xs' : 'text-stone-600 hover:text-stone-900'
          }`}
          title="Luz Cálida Hogar"
        >
          <Sun className="w-3 h-3" />
          <span className="hidden sm:inline">Cálida</span>
        </button>
      </div>

      {/* Top Right: Status Pill & Toggle Photo Comparison */}
      <div className="absolute top-3 right-3 z-20 flex items-center gap-2">
        <button
          type="button"
          onClick={() => setShowOriginalRef(!showOriginalRef)}
          className={`px-3 py-1.5 backdrop-blur-md rounded-2xl border text-xs font-semibold flex items-center gap-1.5 shadow-xs transition-all cursor-pointer ${
            showOriginalRef
              ? 'bg-[#1B365D] border-[#1B365D] text-white'
              : 'bg-white/90 border-stone-200 text-[#2C1810] hover:bg-stone-50'
          }`}
          title="Ver foto de referencia original"
        >
          <Eye className="w-3.5 h-3.5" />
          <span className="text-[11px]">{showOriginalRef ? 'Ver Modelo 2D' : 'Ver Foto Taller'}</span>
        </button>

        <div className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 bg-white/90 backdrop-blur-md rounded-2xl border border-stone-200 shadow-xs text-xs font-semibold text-[#2C1810]">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
          <span className="text-[11px]">2D Foto Real</span>
        </div>
      </div>

      {/* Main Display: 2D Photo Model or Reference Photo Mode */}
      <div 
        className="w-full max-w-[340px] sm:max-w-[400px] h-[370px] sm:h-[440px] flex items-center justify-center transition-transform duration-300 ease-out"
        style={{ transform: `scale(${zoomLevel})` }}
      >
        {showOriginalRef ? (
          /* Reference Photo Mode view */
          <div className="relative w-full h-full flex flex-col items-center justify-center p-2 animate-fadeIn">
            <div className="relative max-h-[380px] w-auto rounded-2xl overflow-hidden shadow-2xl border-4 border-white bg-stone-100 flex items-center justify-center">
              <svg viewBox="0 0 380 500" className="w-full max-h-[360px] drop-shadow-xl" xmlns="http://www.w3.org/2000/svg">
                {/* Visual recreation of the original reference photo */}
                <ellipse cx="190" cy="460" rx="150" ry="25" fill="#1C1B1A" fillOpacity="0.3" />
                
                {/* Backrest dark navy shell */}
                <path
                  d="M 95 340 C 78 260 74 150 90 95 C 102 52 130 38 160 55 C 176 66 186 60 198 42 C 210 60 220 66 236 55 C 266 38 294 52 306 95 C 322 150 318 260 301 340 Z"
                  fill="#1B365D"
                />
                
                {/* Backrest cream velvet face */}
                <path
                  d="M 110 330 C 98 255 94 155 106 108 C 116 70 138 56 164 72 C 178 82 188 76 198 62 C 208 76 218 82 232 72 C 258 56 280 70 290 108 C 302 155 298 255 286 330 Z"
                  fill="#F3EFE6"
                />

                {/* Scalloped Gathers & Ruched folds */}
                <g stroke="#8C827A" strokeWidth="1.8" strokeLinecap="round" opacity="0.45">
                  <path d="M 198 150 Q 198 100 198 65" />
                  <path d="M 186 152 Q 178 105 174 76" />
                  <path d="M 210 152 Q 218 105 222 76" />
                  <path d="M 172 160 Q 155 115 142 86" />
                  <path d="M 224 160 Q 241 115 254 86" />
                  <path d="M 162 175 Q 138 135 122 108" />
                  <path d="M 234 175 Q 258 135 274 108" />
                  <path d="M 156 195 Q 130 160 114 138" />
                  <path d="M 240 195 Q 266 160 282 138" />
                </g>

                {/* Central Lumbar Arch */}
                <path
                  d="M 152 325 L 152 195 C 152 135 244 135 244 195 L 244 325 Z"
                  fill="#F3EFE6"
                />
                <path
                  d="M 152 325 L 152 195 C 152 135 244 135 244 195 L 244 325"
                  fill="none"
                  stroke="#7A6F66"
                  strokeWidth="2.5"
                  strokeOpacity="0.4"
                />

                {/* Backrest Piping Cord */}
                <path
                  d="M 108 330 C 96 255 92 155 104 108 C 114 70 136 56 162 72 C 176 82 186 76 198 60 C 210 76 220 82 234 72 C 260 56 282 70 292 108 C 304 155 300 255 288 330"
                  fill="none"
                  stroke="#1B365D"
                  strokeWidth="5"
                  strokeLinecap="round"
                />

                {/* Seat boxing navy */}
                <path
                  d="M 75 400 C 68 440 85 468 130 474 L 266 474 C 311 468 328 440 321 400 L 311 338 L 85 338 Z"
                  fill="#1B365D"
                />

                {/* Seat top face cream */}
                <path
                  d="M 85 338 L 311 338 C 328 378 314 415 266 425 L 130 425 C 82 415 68 378 85 338 Z"
                  fill="#F3EFE6"
                />

                {/* Seat piping */}
                <path
                  d="M 85 338 C 68 378 82 415 130 425 L 266 425 C 314 415 328 378 311 338 L 85 338"
                  fill="none"
                  stroke="#1B365D"
                  strokeWidth="5"
                />
              </svg>
            </div>
            <span className="mt-2 text-[11px] font-bold text-stone-600 bg-white/80 px-3 py-1 rounded-full border border-stone-200 shadow-2xs">
              Foto Real de Taller: Terciopelo Crema & Azul Marino
            </span>
          </div>
        ) : (
          /* 2D Interactive Configurable Cushion */
          <svg
            viewBox="0 0 420 560"
            className="w-full h-full drop-shadow-xl"
            xmlns="http://www.w3.org/2000/svg"
          >
            <defs>
              {/* Floor Shadow */}
              <radialGradient id="cushionFloorShadow" cx="50%" cy="50%" r="50%">
                <stop offset="0%" stopColor="#1A120B" stopOpacity="0.45" />
                <stop offset="45%" stopColor="#1A120B" stopOpacity="0.2" />
                <stop offset="85%" stopColor="#1A120B" stopOpacity="0.04" />
                <stop offset="100%" stopColor="#1A120B" stopOpacity="0" />
              </radialGradient>

              {/* Surface Light & Specular Shading */}
              <linearGradient id="mainSurfaceShade" x1="15%" y1="10%" x2="85%" y2="90%">
                <stop offset="0%" stopColor="#FFFFFF" stopOpacity="0.35" />
                <stop offset="40%" stopColor="#FFFFFF" stopOpacity="0.08" />
                <stop offset="75%" stopColor="#000000" stopOpacity="0.05" />
                <stop offset="100%" stopColor="#000000" stopOpacity="0.2" />
              </linearGradient>

              <linearGradient id="trimBolsterShade" x1="0%" y1="30%" x2="100%" y2="70%">
                <stop offset="0%" stopColor="#FFFFFF" stopOpacity="0.25" />
                <stop offset="45%" stopColor="#000000" stopOpacity="0.0" />
                <stop offset="100%" stopColor="#000000" stopOpacity="0.4" />
              </linearGradient>

              <linearGradient id="seatBoxingShade" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#FFFFFF" stopOpacity="0.15" />
                <stop offset="25%" stopColor="#000000" stopOpacity="0.05" />
                <stop offset="100%" stopColor="#000000" stopOpacity="0.48" />
              </linearGradient>

              <linearGradient id="pipingWeltHighlight" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stopColor="#FFFFFF" stopOpacity="0.4" />
                <stop offset="50%" stopColor="#FFFFFF" stopOpacity="0.1" />
                <stop offset="100%" stopColor="#000000" stopOpacity="0.3" />
              </linearGradient>

              <radialGradient id="lumbarRadialDepth" cx="50%" cy="40%" r="55%">
                <stop offset="0%" stopColor="#000000" stopOpacity="0.0" />
                <stop offset="70%" stopColor="#000000" stopOpacity="0.12" />
                <stop offset="100%" stopColor="#000000" stopOpacity="0.35" />
              </radialGradient>

              {/* Texture patterns */}
              <pattern id="texWeave" width="6" height="6" patternUnits="userSpaceOnUse">
                {fabricType === 'lino' && (
                  <>
                    <path d="M 0 3 L 6 3" stroke="#000000" strokeWidth="0.5" strokeOpacity="0.08" />
                    <path d="M 3 0 L 3 6" stroke="#000000" strokeWidth="0.5" strokeOpacity="0.08" />
                  </>
                )}
                {fabricType === 'chenille' && (
                  <circle cx="3" cy="3" r="1.5" fill="#000000" fillOpacity="0.07" />
                )}
                {fabricType === 'terciopelo' && (
                  <>
                    <rect width="6" height="6" fill="#FFFFFF" fillOpacity="0.04" />
                    <circle cx="1.5" cy="1.5" r="0.8" fill="#FFFFFF" fillOpacity="0.1" />
                  </>
                )}
              </pattern>
            </defs>

            {/* 1. Ground Contact Shadow */}
            <ellipse cx="210" cy="495" rx="175" ry="32" fill="url(#cushionFloorShadow)" />
            <ellipse cx="210" cy="485" rx="135" ry="18" fill="url(#cushionFloorShadow)" opacity="0.8" />

            {/* 2. BACKREST - OUTER WRAP / TRIM COLOR */}
            <g id="cushion-back-wrap">
              <path
                d="
                  M 105 350
                  C 92 280, 88 175, 102 125
                  C 114 85, 138 68, 168 85
                  C 185 96, 196 90, 210 74
                  C 224 90, 235 96, 252 85
                  C 282 68, 306 85, 318 125
                  C 332 175, 328 280, 315 350
                  Z
                "
                fill={trimColor.hex}
              />
              <path
                d="
                  M 105 350
                  C 92 280, 88 175, 102 125
                  C 114 85, 138 68, 168 85
                  C 185 96, 196 90, 210 74
                  C 224 90, 235 96, 252 85
                  C 282 68, 306 85, 318 125
                  C 332 175, 328 280, 315 350
                  Z
                "
                fill="url(#trimBolsterShade)"
              />
            </g>

            {/* 3. BACKREST - INNER FRONT FACE (MAIN FABRIC) */}
            <g id="cushion-back-face">
              <path
                d="
                  M 118 340
                  C 108 275, 104 180, 116 135
                  C 126 98, 146 84, 172 98
                  C 188 107, 198 102, 210 88
                  C 222 102, 232 107, 248 98
                  C 274 84, 294 98, 304 135
                  C 316 180, 312 275, 302 340
                  Z
                "
                fill={mainFabric.hex}
              />
              <path
                d="
                  M 118 340
                  C 108 275, 104 180, 116 135
                  C 126 98, 146 84, 172 98
                  C 188 107, 198 102, 210 88
                  C 222 102, 232 107, 248 98
                  C 274 84, 294 98, 304 135
                  C 316 180, 312 275, 302 340
                  Z
                "
                fill="url(#texWeave)"
              />
              <path
                d="
                  M 118 340
                  C 108 275, 104 180, 116 135
                  C 126 98, 146 84, 172 98
                  C 188 107, 198 102, 210 88
                  C 222 102, 232 107, 248 98
                  C 274 84, 294 98, 304 135
                  C 316 180, 312 275, 302 340
                  Z
                "
                fill="url(#mainSurfaceShade)"
              />

              {/* Radial Gather Pleats from Photo */}
              <g opacity="0.3" stroke="#000000" strokeWidth="1.6" strokeLinecap="round">
                <path d="M 210 160 Q 210 120 210 90" />
                <path d="M 200 163 Q 192 125 186 98" />
                <path d="M 220 163 Q 228 125 234 98" />
                <path d="M 188 172 Q 172 135 158 106" />
                <path d="M 180 185 Q 156 150 138 125" />
                <path d="M 175 205 Q 148 180 128 158" />
                <path d="M 172 230 Q 145 210 122 195" />
                <path d="M 232 172 Q 248 135 262 106" />
                <path d="M 240 185 Q 264 150 282 125" />
                <path d="M 245 205 Q 272 180 292 158" />
                <path d="M 248 230 Q 275 210 298 195" />
              </g>

              {/* Subtle Highlight Lines on Fold Ridges */}
              <g opacity="0.4" stroke="#FFFFFF" strokeWidth="1.2" strokeLinecap="round">
                <path d="M 208 158 Q 208 120 208 92" />
                <path d="M 198 161 Q 190 125 184 100" />
                <path d="M 222 161 Q 230 125 236 100" />
                <path d="M 186 170 Q 170 135 156 108" />
                <path d="M 234 170 Q 250 135 264 108" />
              </g>

              {/* Central Inverted-U Lumbar Pillow */}
              <path
                d="M 162 335 L 162 215 C 162 160, 258 160, 258 215 L 258 335 Z"
                fill={mainFabric.hex}
              />
              <path
                d="M 162 335 L 162 215 C 162 160, 258 160, 258 215 L 258 335 Z"
                fill="url(#lumbarRadialDepth)"
              />
              <path
                d="M 162 335 L 162 215 C 162 160, 258 160, 258 215 L 258 335 Z"
                fill="url(#texWeave)"
              />
              <path
                d="M 162 335 L 162 215 C 162 160, 258 160, 258 215 L 258 335"
                fill="none"
                stroke="#000000"
                strokeWidth="2"
                strokeOpacity="0.22"
              />
              <path
                d="M 164 335 L 164 215 C 164 162, 256 162, 256 215 L 256 335"
                fill="none"
                stroke="#FFFFFF"
                strokeWidth="1.2"
                strokeOpacity="0.35"
              />

              {/* Backrest Welt / Piping Cord (Trim Color) */}
              <path
                d="
                  M 116 340
                  C 106 275, 102 180, 114 135
                  C 124 98, 144 84, 170 98
                  C 186 107, 196 102, 210 86
                  C 224 102, 234 107, 250 98
                  C 276 84, 296 98, 306 135
                  C 318 180, 314 275, 304 340
                "
                fill="none"
                stroke={trimColor.hex}
                strokeWidth="5"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
              <path
                d="
                  M 116 340
                  C 106 275, 102 180, 114 135
                  C 124 98, 144 84, 170 98
                  C 186 107, 196 102, 210 86
                  C 224 102, 234 107, 250 98
                  C 276 84, 296 98, 306 135
                  C 318 180, 314 275, 304 340
                "
                fill="none"
                stroke="url(#pipingWeltHighlight)"
                strokeWidth="4"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </g>

            {/* 4. SEAT CUSHION - BOXING SIDES & BOTTOM (TRIM COLOR) */}
            <g id="cushion-seat-boxing">
              <path
                d="
                  M 85 410
                  C 78 450, 95 478, 140 484
                  L 280 484
                  C 325 478, 342 450, 335 410
                  L 325 348
                  L 95 348
                  Z
                "
                fill={trimColor.hex}
              />
              <path
                d="
                  M 85 410
                  C 78 450, 95 478, 140 484
                  L 280 484
                  C 325 478, 342 450, 335 410
                  L 325 348
                  L 95 348
                  Z
                "
                fill="url(#seatBoxingShade)"
              />
            </g>

            {/* 5. SEAT CUSHION - TOP PLUSH FACE (MAIN FABRIC) */}
            <g id="cushion-seat-face">
              <path
                d="
                  M 95 348
                  L 325 348
                  C 342 388, 328 425, 280 435
                  L 140 435
                  C 92 425, 78 388, 95 348
                  Z
                "
                fill={mainFabric.hex}
              />
              <path
                d="
                  M 95 348
                  L 325 348
                  C 342 388, 328 425, 280 435
                  L 140 435
                  C 92 425, 78 388, 95 348
                  Z
                "
                fill="url(#texWeave)"
              />
              <path
                d="
                  M 95 348
                  L 325 348
                  C 342 388, 328 425, 280 435
                  L 140 435
                  C 92 425, 78 388, 95 348
                  Z
                "
                fill="url(#mainSurfaceShade)"
              />

              {/* Seat Perimeter Piping Welt Cord (Trim Color) */}
              <path
                d="
                  M 95 348
                  C 78 388, 92 425, 140 435
                  L 280 435
                  C 328 425, 342 388, 325 348
                  L 95 348
                "
                fill="none"
                stroke={trimColor.hex}
                strokeWidth="5"
                strokeLinejoin="round"
              />
              <path
                d="
                  M 95 348
                  C 78 388, 92 425, 140 435
                  L 280 435
                  C 328 425, 342 388, 325 348
                  L 95 348
                "
                fill="none"
                stroke="url(#pipingWeltHighlight)"
                strokeWidth="3.5"
                strokeLinejoin="round"
              />

              {/* Bottom welt cord */}
              <path
                d="
                  M 86 420
                  C 80 455, 98 480, 140 484
                  L 280 484
                  C 322 480, 340 455, 334 420
                "
                fill="none"
                stroke={trimColor.hex}
                strokeWidth="4"
                strokeOpacity="0.85"
              />
              <path
                d="
                  M 86 420
                  C 80 455, 98 480, 140 484
                  L 280 484
                  C 322 480, 340 455, 334 420
                "
                fill="none"
                stroke="url(#pipingWeltHighlight)"
                strokeWidth="2.5"
              />
            </g>

            {/* Specular sheen */}
            <ellipse cx="210" cy="220" rx="90" ry="120" fill="#FFFFFF" fillOpacity="0.08" />
          </svg>
        )}
      </div>

      {/* Bottom Zoom & Reset Controls */}
      <div className="absolute bottom-3 left-1/2 -translate-x-1/2 z-20 flex items-center gap-1.5 p-1.5 bg-white/90 backdrop-blur-md rounded-2xl border border-stone-200 shadow-md">
        <button
          type="button"
          onClick={() => setZoomLevel((z) => Math.min(1.4, z + 0.15))}
          className="p-1.5 rounded-xl hover:bg-stone-100 text-stone-700 transition-all cursor-pointer"
          title="Acercar (Zoom +)"
        >
          <ZoomIn className="w-3.5 h-3.5" />
        </button>
        <button
          type="button"
          onClick={() => setZoomLevel((z) => Math.max(0.75, z - 0.15))}
          className="p-1.5 rounded-xl hover:bg-stone-100 text-stone-700 transition-all cursor-pointer"
          title="Alejar (Zoom -)"
        >
          <ZoomOut className="w-3.5 h-3.5" />
        </button>
        <div className="w-px h-3.5 bg-stone-300 mx-0.5" />
        <button
          type="button"
          onClick={() => setZoomLevel(1)}
          className="px-2 py-1 rounded-xl hover:bg-stone-100 text-stone-700 text-[10px] font-bold transition-all flex items-center gap-1 cursor-pointer"
          title="Restablecer tamaño normal"
        >
          <RefreshCw className="w-3 h-3" />
          <span>Restablecer</span>
        </button>
      </div>
    </div>
  );
};
