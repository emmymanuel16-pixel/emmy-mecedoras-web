import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { CustomizerColorOption, CustomizerFabricOption } from '../../types';
import { 
  RotateCw, ZoomIn, ZoomOut, Sparkles, Sun, 
  Eye, RefreshCw, Layers, CheckCircle2, ShieldCheck 
} from 'lucide-react';

interface Cushion3DViewerProps {
  mainFabric: CustomizerFabricOption;
  trimColor: CustomizerColorOption;
  fabricType?: 'terciopelo' | 'lino' | 'chenille' | 'impermeable';
  environment?: 'studio' | 'warm' | 'natural';
  className?: string;
  onWebGLError?: () => void;
}

export const Cushion3DViewer: React.FC<Cushion3DViewerProps> = ({
  mainFabric,
  trimColor,
  fabricType = 'terciopelo',
  environment = 'studio',
  className = '',
  onWebGLError,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const animFrameId = useRef<number | null>(null);

  // Materials refs
  const mainMaterialRef = useRef<THREE.MeshPhysicalMaterial | null>(null);
  const trimMaterialRef = useRef<THREE.MeshPhysicalMaterial | null>(null);
  const mainTextureRef = useRef<THREE.CanvasTexture | null>(null);
  const trimTextureRef = useRef<THREE.CanvasTexture | null>(null);

  // Interaction state
  const isDragging = useRef(false);
  const prevMousePos = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  const [autoRotate, setAutoRotate] = useState<boolean>(true);
  const [currentEnv, setCurrentEnv] = useState<'studio' | 'warm' | 'natural'>(environment);
  const [zoomScale, setZoomScale] = useState<number>(1);
  const [isHovered, setIsHovered] = useState<boolean>(false);
  const [viewMode, setViewMode] = useState<'3d' | 'reference'>('3d');

  // Spherical camera coordinate state
  const cameraAngles = useRef<{ theta: number; phi: number; radius: number }>({
    theta: 0.55, // 3/4 beauty perspective matching reference photo
    phi: 1.15,
    radius: 3.2,
  });

  // Create procedural bump canvas texture for velvet / fabric grain
  const generateFabricBumpTexture = (type: string) => {
    const canvas = document.createElement('canvas');
    canvas.width = 256;
    canvas.height = 256;
    const ctx = canvas.getContext('2d');
    if (!ctx) return null;

    ctx.fillStyle = '#808080';
    ctx.fillRect(0, 0, 256, 256);

    // Micro-fibers / velvet noise
    const imgData = ctx.getImageData(0, 0, 256, 256);
    const data = imgData.data;
    for (let i = 0; i < data.length; i += 4) {
      const noise = (Math.random() - 0.5) * 35;
      const v = Math.min(255, Math.max(0, 128 + noise));
      data[i] = v;
      data[i + 1] = v;
      data[i + 2] = v;
      data[i + 3] = 255;
    }
    ctx.putImageData(imgData, 0, 0);

    // Weave pattern if lino or chenille
    if (type === 'lino' || type === 'chenille') {
      ctx.fillStyle = 'rgba(255, 255, 255, 0.12)';
      for (let x = 0; x < 256; x += 4) {
        ctx.fillRect(x, 0, 2, 256);
      }
      ctx.fillStyle = 'rgba(0, 0, 0, 0.12)';
      for (let y = 0; y < 256; y += 4) {
        ctx.fillRect(0, y, 256, 2);
      }
    }

    const texture = new THREE.CanvasTexture(canvas);
    texture.wrapS = THREE.RepeatWrapping;
    texture.wrapT = THREE.RepeatWrapping;
    texture.repeat.set(type === 'terciopelo' ? 8 : 12, type === 'terciopelo' ? 8 : 12);
    return texture;
  };

  const updateCameraPosition = () => {
    if (!cameraRef.current) return;
    const { theta, phi, radius } = cameraAngles.current;
    const r = radius / zoomScale;

    cameraRef.current.position.x = r * Math.sin(phi) * Math.sin(theta);
    cameraRef.current.position.y = r * Math.cos(phi) + 0.15;
    cameraRef.current.position.z = r * Math.sin(phi) * Math.cos(theta);
    cameraRef.current.lookAt(0, 0.1, 0);
  };

  // Build the 3D Cushion Model according to the reference photo
  const buildCushionModel = (
    scene: THREE.Scene, 
    mainMat: THREE.MeshPhysicalMaterial, 
    trimMat: THREE.MeshPhysicalMaterial
  ) => {
    const cushionGroup = new THREE.Group();
    cushionGroup.position.set(0, -0.2, 0);

    // ─────────────────────────────────────────────────────────────
    // 1. SEAT CUSHION (ASIENTO DE CAJA GRUESO)
    // ─────────────────────────────────────────────────────────────
    const seatWidth = 0.95;
    const seatDepth = 0.92;
    const seatHeight = 0.22;
    const seatCornerRadius = 0.18;

    // 1a. Seat Top Face (Plush Cream/Custom color)
    const seatShape = new THREE.Shape();
    const hw = seatWidth / 2;
    const hd = seatDepth / 2;
    const cr = seatCornerRadius;

    // Rounded rectangle shape with front curve
    seatShape.moveTo(-hw + cr, -hd);
    seatShape.lineTo(hw - cr, -hd);
    seatShape.quadraticCurveTo(hw, -hd, hw, -hd + cr);
    seatShape.lineTo(hw, hd - cr);
    seatShape.quadraticCurveTo(hw, hd, hw - cr, hd);
    seatShape.lineTo(-hw + cr, hd);
    seatShape.quadraticCurveTo(-hw, hd, -hw, hd - cr);
    seatShape.lineTo(-hw, -hd + cr);
    seatShape.quadraticCurveTo(-hw, -hd, -hw + cr, -hd);

    const seatExtrudeSettings: THREE.ExtrudeGeometryOptions = {
      depth: 0.05,
      bevelEnabled: true,
      bevelSegments: 8,
      steps: 2,
      bevelSize: 0.04,
      bevelThickness: 0.035,
    };

    const seatTopGeo = new THREE.ExtrudeGeometry(seatShape, seatExtrudeSettings);
    seatTopGeo.rotateX(Math.PI / 2);
    seatTopGeo.center();

    // Displace vertices to create a soft convex pillowy top
    const posAttr = seatTopGeo.attributes.position;
    for (let i = 0; i < posAttr.count; i++) {
      const x = posAttr.getX(i);
      const y = posAttr.getY(i);
      const z = posAttr.getZ(i);

      if (y > 0.01) {
        const distFromCenter = Math.sqrt((x / hw) ** 2 + (z / hd) ** 2);
        const domeHeight = Math.max(0, 1 - distFromCenter * 0.7) * 0.045;
        posAttr.setY(i, y + domeHeight);
      }
    }
    seatTopGeo.computeVertexNormals();

    const seatTopMesh = new THREE.Mesh(seatTopGeo, mainMat);
    seatTopMesh.position.set(0, seatHeight / 2 - 0.01, 0.08);
    seatTopMesh.castShadow = true;
    seatTopMesh.receiveShadow = true;
    cushionGroup.add(seatTopMesh);

    // 1b. Seat Boxing Sides (Navy Velvet/Trim material)
    const seatBoxShape = new THREE.Shape();
    seatBoxShape.moveTo(-hw + cr, -hd);
    seatBoxShape.lineTo(hw - cr, -hd);
    seatBoxShape.quadraticCurveTo(hw, -hd, hw, -hd + cr);
    seatBoxShape.lineTo(hw, hd - cr);
    seatBoxShape.quadraticCurveTo(hw, hd, hw - cr, hd);
    seatBoxShape.lineTo(-hw + cr, hd);
    seatBoxShape.quadraticCurveTo(-hw, hd, -hw, hd - cr);
    seatBoxShape.lineTo(-hw, -hd + cr);
    seatBoxShape.quadraticCurveTo(-hw, -hd, -hw + cr, -hd);

    const seatBoxExtrude: THREE.ExtrudeGeometryOptions = {
      depth: seatHeight - 0.04,
      bevelEnabled: true,
      bevelSegments: 4,
      steps: 2,
      bevelSize: 0.02,
      bevelThickness: 0.02,
    };
    const seatBoxGeo = new THREE.ExtrudeGeometry(seatBoxShape, seatBoxExtrude);
    seatBoxGeo.rotateX(Math.PI / 2);
    seatBoxGeo.center();
    seatBoxGeo.computeVertexNormals();

    const seatBoxMesh = new THREE.Mesh(seatBoxGeo, trimMat);
    seatBoxMesh.position.set(0, 0, 0.08);
    seatBoxMesh.castShadow = true;
    seatBoxMesh.receiveShadow = true;
    cushionGroup.add(seatBoxMesh);

    // 1c. Seat Welt / Piping Cord (Perimeter cord)
    const seatPathPoints: THREE.Vector3[] = [];
    const segments = 64;
    for (let i = 0; i <= segments; i++) {
      const t = (i / segments) * Math.PI * 2;
      const cosT = Math.cos(t);
      const sinT = Math.sin(t);
      const px = Math.sign(cosT) * Math.pow(Math.abs(cosT), 0.8) * (hw + 0.015);
      const pz = Math.sign(sinT) * Math.pow(Math.abs(sinT), 0.8) * (hd + 0.015);
      seatPathPoints.push(new THREE.Vector3(px, seatHeight / 2 + 0.025, pz + 0.08));
    }
    const seatCurve = new THREE.CatmullRomCurve3(seatPathPoints, true);
    const seatPipingGeo = new THREE.TubeGeometry(seatCurve, 72, 0.014, 8, true);
    const seatPipingMesh = new THREE.Mesh(seatPipingGeo, trimMat);
    seatPipingMesh.castShadow = true;
    cushionGroup.add(seatPipingMesh);

    // ─────────────────────────────────────────────────────────────
    // 2. BACKREST CUSHION (RESPALDO CON CORONA ONDULADA Y ARCO)
    // ─────────────────────────────────────────────────────────────
    const backWidth = 0.84;
    const backHeight = 1.05;
    const backReclineAngle = -0.18; // ~10° recline matching photo
    const backZOffset = -0.32;
    const backYOffset = 0.55;

    // 2a. Sculpted Crown Backrest Outer Shape (3 Scalloped Lobes on top)
    const backShape = new THREE.Shape();
    const bhw = backWidth / 2;

    // Start at bottom center
    backShape.moveTo(-bhw + 0.05, -0.5);
    backShape.lineTo(bhw - 0.05, -0.5);
    // Right side slightly bowing out
    backShape.quadraticCurveTo(bhw + 0.03, 0.0, bhw, 0.35);
    // Right shoulder crest
    backShape.quadraticCurveTo(bhw - 0.02, 0.48, bhw - 0.12, 0.49);
    // Center valley right
    backShape.quadraticCurveTo(bhw - 0.22, 0.46, 0.15, 0.54);
    // Center Top Crown Arch (highest peak)
    backShape.quadraticCurveTo(0, 0.57, -0.15, 0.54);
    // Center valley left
    backShape.quadraticCurveTo(-bhw + 0.22, 0.46, -bhw + 0.12, 0.49);
    // Left shoulder crest
    backShape.quadraticCurveTo(-bhw + 0.02, 0.48, -bhw, 0.35);
    // Left side
    backShape.quadraticCurveTo(-bhw - 0.03, 0.0, -bhw + 0.05, -0.5);

    // Backrest Shell (Navy Velvet Outer wrap & Back)
    const backBoxExtrude: THREE.ExtrudeGeometryOptions = {
      depth: 0.14,
      bevelEnabled: true,
      bevelSegments: 6,
      steps: 2,
      bevelSize: 0.03,
      bevelThickness: 0.03,
    };
    const backBoxGeo = new THREE.ExtrudeGeometry(backShape, backBoxExtrude);
    backBoxGeo.center();
    backBoxGeo.computeVertexNormals();

    const backBoxMesh = new THREE.Mesh(backBoxGeo, trimMat);
    backBoxMesh.position.set(0, backYOffset, backZOffset);
    backBoxMesh.rotation.x = backReclineAngle;
    backBoxMesh.castShadow = true;
    backBoxMesh.receiveShadow = true;
    cushionGroup.add(backBoxMesh);

    // Backrest Front Plush Face (Main Cream/Custom fabric)
    const backFaceExtrude: THREE.ExtrudeGeometryOptions = {
      depth: 0.05,
      bevelEnabled: true,
      bevelSegments: 8,
      steps: 2,
      bevelSize: 0.035,
      bevelThickness: 0.035,
    };
    const backFaceGeo = new THREE.ExtrudeGeometry(backShape, backFaceExtrude);
    backFaceGeo.center();

    // Displace vertices to create the deep perimeter crease and outer bolster
    const backPos = backFaceGeo.attributes.position;
    for (let i = 0; i < backPos.count; i++) {
      const x = backPos.getX(i);
      const y = backPos.getY(i);
      const z = backPos.getZ(i);

      if (z > 0.01) {
        // Inner arch area vs outer bolster roll
        const normalizedX = x / 0.32;
        const normalizedY = (y + 0.05) / 0.45;
        const insideArch = (normalizedX * normalizedX + Math.max(0, normalizedY) * Math.max(0, normalizedY)) < 1.0;

        if (insideArch) {
          // Center pillow puff
          const archBulge = Math.cos(Math.min(1.4, Math.sqrt(normalizedX * normalizedX + normalizedY * normalizedY))) * 0.03;
          backPos.setZ(i, z + archBulge);
        } else {
          // Outer bolster puff
          backPos.setZ(i, z + 0.02);
        }
      }
    }
    backFaceGeo.computeVertexNormals();

    const backFaceMesh = new THREE.Mesh(backFaceGeo, mainMat);
    backFaceMesh.position.set(0, backYOffset, backZOffset + 0.06);
    backFaceMesh.rotation.x = backReclineAngle;
    backFaceMesh.castShadow = true;
    backFaceMesh.receiveShadow = true;
    cushionGroup.add(backFaceMesh);

    // 2b. Inner Arched Lumbar Cushion Puff (Center Arch with soft radial stitches)
    const innerArchShape = new THREE.Shape();
    const aw = 0.26;
    const ah = 0.38;

    innerArchShape.moveTo(-aw, -0.42);
    innerArchShape.lineTo(aw, -0.42);
    innerArchShape.lineTo(aw, 0.05);
    innerArchShape.quadraticCurveTo(aw, ah, 0, ah + 0.02);
    innerArchShape.quadraticCurveTo(-aw, ah, -aw, 0.05);
    innerArchShape.lineTo(-aw, -0.42);

    const innerArchExtrude: THREE.ExtrudeGeometryOptions = {
      depth: 0.04,
      bevelEnabled: true,
      bevelSegments: 8,
      steps: 2,
      bevelSize: 0.035,
      bevelThickness: 0.03,
    };
    const innerArchGeo = new THREE.ExtrudeGeometry(innerArchShape, innerArchExtrude);
    innerArchGeo.center();

    // Add soft pillow convexity
    const archPos = innerArchGeo.attributes.position;
    for (let i = 0; i < archPos.count; i++) {
      const x = archPos.getX(i);
      const y = archPos.getY(i);
      const z = archPos.getZ(i);
      if (z > 0.01) {
        const d = Math.sqrt((x / aw) ** 2 + ((y + 0.05) / ah) ** 2);
        archPos.setZ(i, z + Math.max(0, (1 - d * 0.7) * 0.035));
      }
    }
    innerArchGeo.computeVertexNormals();

    const innerArchMesh = new THREE.Mesh(innerArchGeo, mainMat);
    innerArchMesh.position.set(0, backYOffset - 0.04, backZOffset + 0.08);
    innerArchMesh.rotation.x = backReclineAngle;
    innerArchMesh.castShadow = true;
    cushionGroup.add(innerArchMesh);

    // 2c. Backrest Welt / Piping Cord around the Scalloped Crown
    const backPoints: THREE.Vector3[] = [
      new THREE.Vector3(-bhw + 0.05, -0.5, 0.08),
      new THREE.Vector3(-bhw - 0.02, 0.0, 0.085),
      new THREE.Vector3(-bhw, 0.35, 0.085),
      new THREE.Vector3(-bhw + 0.12, 0.49, 0.085),
      new THREE.Vector3(-0.15, 0.54, 0.09),
      new THREE.Vector3(0, 0.575, 0.095),
      new THREE.Vector3(0.15, 0.54, 0.09),
      new THREE.Vector3(bhw - 0.12, 0.49, 0.085),
      new THREE.Vector3(bhw, 0.35, 0.085),
      new THREE.Vector3(bhw + 0.02, 0.0, 0.085),
      new THREE.Vector3(bhw - 0.05, -0.5, 0.08),
    ];
    const backCurve = new THREE.CatmullRomCurve3(backPoints, false);
    const backPipingGeo = new THREE.TubeGeometry(backCurve, 64, 0.013, 8, false);
    const backPipingMesh = new THREE.Mesh(backPipingGeo, trimMat);
    backPipingMesh.position.set(0, backYOffset, backZOffset);
    backPipingMesh.rotation.x = backReclineAngle;
    backPipingMesh.castShadow = true;
    cushionGroup.add(backPipingMesh);

    // ─────────────────────────────────────────────────────────────
    // 3. CONTACT SHADOW PLANE & SUBTLE FLOOR AMBIENCE
    // ─────────────────────────────────────────────────────────────
    const shadowGeo = new THREE.PlaneGeometry(2.4, 2.4);
    const shadowCanvas = document.createElement('canvas');
    shadowCanvas.width = 256;
    shadowCanvas.height = 256;
    const sCtx = shadowCanvas.getContext('2d');
    if (sCtx) {
      const grad = sCtx.createRadialGradient(128, 128, 10, 128, 128, 120);
      grad.addColorStop(0, 'rgba(30, 20, 15, 0.45)');
      grad.addColorStop(0.4, 'rgba(30, 20, 15, 0.2)');
      grad.addColorStop(0.8, 'rgba(30, 20, 15, 0.05)');
      grad.addColorStop(1, 'rgba(30, 20, 15, 0)');
      sCtx.fillStyle = grad;
      sCtx.fillRect(0, 0, 256, 256);
    }
    const shadowTexture = new THREE.CanvasTexture(shadowCanvas);
    const shadowMat = new THREE.MeshBasicMaterial({
      map: shadowTexture,
      transparent: true,
      depthWrite: false,
      opacity: 0.85,
    });
    const shadowMesh = new THREE.Mesh(shadowGeo, shadowMat);
    shadowMesh.rotation.x = -Math.PI / 2;
    shadowMesh.position.set(0, -seatHeight / 2 - 0.015, 0.05);
    cushionGroup.add(shadowMesh);

    scene.add(cushionGroup);
  };

  // Initialize Three.js Scene
  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    // Check WebGL
    try {
      const testCanvas = document.createElement('canvas');
      const gl = testCanvas.getContext('webgl') || testCanvas.getContext('experimental-webgl');
      if (!gl) {
        if (onWebGLError) onWebGLError();
        return;
      }
    } catch {
      if (onWebGLError) onWebGLError();
      return;
    }

    // 1. Scene
    const scene = new THREE.Scene();
    sceneRef.current = scene;

    // Background color based on environment
    const bgColors = {
      studio: 0xFAF8F5,
      warm: 0xFDF6EE,
      natural: 0xF4F6F8,
    };
    scene.background = new THREE.Color(bgColors[currentEnv]);

    // 2. Camera
    const width = container.clientWidth || 500;
    const height = container.clientHeight || 450;
    const camera = new THREE.PerspectiveCamera(40, width / height, 0.1, 50);
    cameraRef.current = camera;
    updateCameraPosition();

    // 3. Renderer
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: 'high-performance' });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.setSize(width, height);
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.18;

    while (container.firstChild) {
      container.removeChild(container.firstChild);
    }
    container.appendChild(renderer.domElement);
    rendererRef.current = renderer;

    // 4. Lighting Rig
    const ambientLight = new THREE.AmbientLight(0xFFFFFF, 0.85);
    scene.add(ambientLight);

    // Key Light (Main soft light from upper right front)
    const keyLight = new THREE.DirectionalLight(
      currentEnv === 'warm' ? 0xFFF1D8 : 0xFFFAFA, 
      1.4
    );
    keyLight.position.set(2.8, 4.2, 3.5);
    keyLight.castShadow = true;
    keyLight.shadow.mapSize.width = 1024;
    keyLight.shadow.mapSize.height = 1024;
    keyLight.shadow.bias = -0.0004;
    scene.add(keyLight);

    // Soft Fill Light (Left side)
    const fillLight = new THREE.DirectionalLight(0xE2E8F0, 0.65);
    fillLight.position.set(-3.2, 2.5, 1.8);
    scene.add(fillLight);

    // Rim / Backlight for luscious fabric edge highlights
    const rimLight = new THREE.DirectionalLight(
      currentEnv === 'warm' ? 0xFFE0B2 : 0xFFFFFF, 
      0.75
    );
    rimLight.position.set(0, 3.0, -3.2);
    scene.add(rimLight);

    // 5. Materials Setup
    const mainBump = generateFabricBumpTexture(fabricType);
    mainTextureRef.current = mainBump;

    const mainMat = new THREE.MeshPhysicalMaterial({
      color: new THREE.Color(mainFabric.hex),
      roughness: 0.82,
      metalness: 0.02,
      sheen: 0.95,
      sheenRoughness: 0.35,
      sheenColor: new THREE.Color(mainFabric.hex).offsetHSL(0, 0, 0.15),
      bumpMap: mainBump || undefined,
      bumpScale: fabricType === 'terciopelo' ? 0.003 : 0.008,
      clearcoat: 0.0,
    });
    mainMaterialRef.current = mainMat;

    const trimBump = generateFabricBumpTexture('terciopelo');
    trimTextureRef.current = trimBump;

    const trimMat = new THREE.MeshPhysicalMaterial({
      color: new THREE.Color(trimColor.hex),
      roughness: 0.7,
      metalness: 0.03,
      sheen: 1.0,
      sheenRoughness: 0.25,
      sheenColor: new THREE.Color(trimColor.hex).offsetHSL(0, 0, 0.2),
      bumpMap: trimBump || undefined,
      bumpScale: 0.004,
    });
    trimMaterialRef.current = trimMat;

    // 6. Build the 3D Cushion
    buildCushionModel(scene, mainMat, trimMat);

    // 7. Animation & Render Loop
    const animate = () => {
      animFrameId.current = requestAnimationFrame(animate);

      if (autoRotate && !isDragging.current) {
        cameraAngles.current.theta += 0.0045;
        updateCameraPosition();
      }

      renderer.render(scene, camera);
    };
    animate();

    // 8. Resize Observer
    const resizeObserver = new ResizeObserver((entries) => {
      for (const entry of entries) {
        const { width: newWidth, height: newHeight } = entry.contentRect;
        if (newWidth > 0 && newHeight > 0 && cameraRef.current && rendererRef.current) {
          cameraRef.current.aspect = newWidth / newHeight;
          cameraRef.current.updateProjectionMatrix();
          rendererRef.current.setSize(newWidth, newHeight);
          updateCameraPosition();
        }
      }
    });
    resizeObserver.observe(container);

    return () => {
      if (animFrameId.current) cancelAnimationFrame(animFrameId.current);
      resizeObserver.disconnect();
      renderer.dispose();
      while (container.firstChild) {
        container.removeChild(container.firstChild);
      }
    };
  }, [currentEnv, fabricType]);

  // Update Main Fabric & Trim Colors smoothly when changed
  useEffect(() => {
    if (mainMaterialRef.current) {
      mainMaterialRef.current.color.setStyle(mainFabric.hex);
      mainMaterialRef.current.sheenColor.setStyle(mainFabric.hex).offsetHSL(0, 0, 0.15);
      mainMaterialRef.current.needsUpdate = true;
    }
  }, [mainFabric]);

  useEffect(() => {
    if (trimMaterialRef.current) {
      trimMaterialRef.current.color.setStyle(trimColor.hex);
      trimMaterialRef.current.sheenColor.setStyle(trimColor.hex).offsetHSL(0, 0, 0.2);
      trimMaterialRef.current.needsUpdate = true;
    }
  }, [trimColor]);

  // Update zoom
  useEffect(() => {
    updateCameraPosition();
  }, [zoomScale]);

  // Mouse & Touch Controls
  const handleMouseDown = (e: React.MouseEvent) => {
    isDragging.current = true;
    prevMousePos.current = { x: e.clientX, y: e.clientY };
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging.current) return;
    const deltaX = e.clientX - prevMousePos.current.x;
    const deltaY = e.clientY - prevMousePos.current.y;

    cameraAngles.current.theta -= deltaX * 0.007;
    cameraAngles.current.phi = Math.max(0.3, Math.min(Math.PI / 2 + 0.15, cameraAngles.current.phi - deltaY * 0.007));

    prevMousePos.current = { x: e.clientX, y: e.clientY };
    updateCameraPosition();
  };

  const handleMouseUp = () => {
    isDragging.current = false;
  };

  const handleTouchStart = (e: React.TouchEvent) => {
    if (e.touches.length === 1) {
      isDragging.current = true;
      prevMousePos.current = { x: e.touches[0].clientX, y: e.touches[0].clientY };
    }
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (!isDragging.current || e.touches.length !== 1) return;
    const deltaX = e.touches[0].clientX - prevMousePos.current.x;
    const deltaY = e.touches[0].clientY - prevMousePos.current.y;

    cameraAngles.current.theta -= deltaX * 0.008;
    cameraAngles.current.phi = Math.max(0.3, Math.min(Math.PI / 2 + 0.15, cameraAngles.current.phi - deltaY * 0.008));

    prevMousePos.current = { x: e.touches[0].clientX, y: e.touches[0].clientY };
    updateCameraPosition();
  };

  const handleTouchEnd = () => {
    isDragging.current = false;
  };

  const handleResetView = () => {
    cameraAngles.current = {
      theta: 0.55,
      phi: 1.15,
      radius: 3.2,
    };
    setZoomScale(1);
    updateCameraPosition();
  };

  return (
    <div 
      className={`relative w-full h-full min-h-[380px] sm:min-h-[460px] rounded-3xl overflow-hidden bg-gradient-to-b from-[#FAF8F5] via-[#F3EFE9] to-[#E8E2D9] border border-[#E8E2DC] shadow-inner select-none transition-all duration-300 ${className}`}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* 3D WebGL Canvas Container */}
      <div
        ref={containerRef}
        className={`w-full h-full cursor-grab active:cursor-grabbing transition-opacity duration-300 ${
          viewMode === '3d' ? 'opacity-100' : 'opacity-0 pointer-events-none'
        }`}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
      />

      {/* Reference Photo View (User reference photo toggle) */}
      {viewMode === 'reference' && (
        <div className="absolute inset-0 z-10 flex flex-col items-center justify-center p-4 bg-stone-900/95 animate-fadeIn text-white">
          <div className="relative max-w-xs sm:max-w-sm rounded-2xl overflow-hidden shadow-2xl border border-white/20 bg-stone-800">
            {/* Embedded SVG representation of the exact user reference cushion photo */}
            <div className="p-4 flex flex-col items-center">
              <div className="w-48 h-64 relative rounded-xl overflow-hidden bg-gradient-to-b from-stone-200 to-stone-300 flex items-center justify-center shadow-inner">
                {/* Visual representation of the cushion reference */}
                <svg viewBox="0 0 200 280" className="w-full h-full drop-shadow-md">
                  {/* Cushion Backrest */}
                  <path
                    d="M 50 180 Q 40 100 48 55 Q 65 30 85 45 Q 100 35 115 45 Q 135 30 152 55 Q 160 100 150 180 Z"
                    fill="#1B365D"
                  />
                  {/* Backrest plush cream face */}
                  <path
                    d="M 56 175 Q 48 105 54 62 Q 68 40 85 52 Q 100 42 115 52 Q 132 40 146 62 Q 152 105 144 175 Z"
                    fill="#F3EFE6"
                  />
                  {/* Lumbar inner arch */}
                  <path
                    d="M 72 175 L 72 115 Q 72 80 100 80 Q 128 80 128 115 L 128 175 Z"
                    fill="#EFEAE0"
                    stroke="#D8D0C0"
                    strokeWidth="1.5"
                  />
                  {/* Seat Cushion Boxing Navy */}
                  <path
                    d="M 38 215 Q 35 240 55 248 L 145 248 Q 165 240 162 215 L 155 178 L 45 178 Z"
                    fill="#1B365D"
                  />
                  {/* Seat Cushion Top Cream */}
                  <path
                    d="M 45 178 L 155 178 Q 162 205 148 218 L 52 218 Q 38 205 45 178 Z"
                    fill="#F3EFE6"
                  />
                  {/* Piping Highlight */}
                  <path
                    d="M 45 178 Q 38 205 52 218 L 148 218 Q 162 205 155 178"
                    fill="none"
                    stroke="#1B365D"
                    strokeWidth="2.5"
                  />
                </svg>
              </div>
              <div className="mt-3 text-center">
                <span className="text-xs font-bold text-amber-300 block">Modelo Base de Referencia</span>
                <p className="text-[11px] text-stone-300 mt-0.5">
                  Confección artesanal de cojín ergonómico con costura ribeteada y vivos contrastantes.
                </p>
              </div>
            </div>
          </div>
          <button
            type="button"
            onClick={() => setViewMode('3d')}
            className="mt-3 px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-stone-950 text-xs font-bold transition-all shadow-lg flex items-center gap-1.5 cursor-pointer"
          >
            <RotateCw className="w-3.5 h-3.5" />
            <span>Volver a la Vista 3D 360°</span>
          </button>
        </div>
      )}

      {/* Top Left: Environment / Lighting Switcher */}
      <div className="absolute top-3 left-3 z-20 flex items-center gap-1 p-1 bg-white/90 backdrop-blur-md rounded-2xl border border-stone-200 shadow-xs">
        <button
          type="button"
          onClick={() => setCurrentEnv('studio')}
          title="Luz de Estudio Neutra"
          className={`px-2.5 py-1 rounded-xl text-[11px] font-bold flex items-center gap-1 transition-all cursor-pointer ${
            currentEnv === 'studio' ? 'bg-[#5C4033] text-white shadow-xs' : 'text-stone-600 hover:text-stone-900'
          }`}
        >
          <Sparkles className="w-3 h-3" />
          <span className="hidden sm:inline">Estudio</span>
        </button>
        <button
          type="button"
          onClick={() => setCurrentEnv('warm')}
          title="Luz Cálida Hogar"
          className={`px-2.5 py-1 rounded-xl text-[11px] font-bold flex items-center gap-1 transition-all cursor-pointer ${
            currentEnv === 'warm' ? 'bg-[#5C4033] text-white shadow-xs' : 'text-stone-600 hover:text-stone-900'
          }`}
        >
          <Sun className="w-3 h-3" />
          <span className="hidden sm:inline">Cálida</span>
        </button>
      </div>

      {/* Top Right: Reference Photo Toggle & Auto-rotate */}
      <div className="absolute top-3 right-3 z-20 flex items-center gap-1.5">
        <button
          type="button"
          onClick={() => setViewMode(viewMode === '3d' ? 'reference' : '3d')}
          className={`p-2 rounded-xl text-xs font-bold flex items-center gap-1.5 backdrop-blur-md border shadow-xs transition-all cursor-pointer ${
            viewMode === 'reference'
              ? 'bg-amber-500 text-stone-950 border-amber-400'
              : 'bg-white/90 text-stone-700 hover:text-stone-900 border-stone-200'
          }`}
          title="Ver foto de referencia artesanal"
        >
          <Eye className="w-3.5 h-3.5" />
          <span className="text-[11px] font-semibold hidden sm:inline">Foto Real</span>
        </button>

        <button
          type="button"
          onClick={() => setAutoRotate(!autoRotate)}
          className={`p-2 rounded-xl backdrop-blur-md border shadow-xs transition-all cursor-pointer ${
            autoRotate
              ? 'bg-[#5C4033] text-white border-[#5C4033]'
              : 'bg-white/90 text-stone-700 hover:text-stone-900 border-stone-200'
          }`}
          title={autoRotate ? 'Pausar rotación 360°' : 'Activar rotación 360°'}
        >
          <RotateCw className={`w-3.5 h-3.5 ${autoRotate ? 'animate-spin' : ''}`} style={{ animationDuration: '6s' }} />
        </button>
      </div>

      {/* Bottom Center 3D Controls Pill */}
      {viewMode === '3d' && (
        <div className="absolute bottom-3 left-1/2 -translate-x-1/2 z-20 flex items-center gap-1.5 p-1.5 bg-white/90 backdrop-blur-md rounded-2xl border border-stone-200 shadow-md">
          <button
            type="button"
            onClick={() => setZoomScale((z) => Math.min(1.6, z + 0.15))}
            className="p-1.5 rounded-xl hover:bg-stone-100 text-stone-700 transition-all cursor-pointer"
            title="Acercar (Zoom +)"
          >
            <ZoomIn className="w-3.5 h-3.5" />
          </button>
          <button
            type="button"
            onClick={() => setZoomScale((z) => Math.max(0.65, z - 0.15))}
            className="p-1.5 rounded-xl hover:bg-stone-100 text-stone-700 transition-all cursor-pointer"
            title="Alejar (Zoom -)"
          >
            <ZoomOut className="w-3.5 h-3.5" />
          </button>
          <div className="w-px h-3.5 bg-stone-300 mx-0.5" />
          <button
            type="button"
            onClick={handleResetView}
            className="px-2 py-1 rounded-xl hover:bg-stone-100 text-stone-700 text-[10px] font-bold transition-all flex items-center gap-1 cursor-pointer"
            title="Restablecer posición inicial"
          >
            <RefreshCw className="w-3 h-3" />
            <span>Centrar</span>
          </button>
        </div>
      )}

      {/* 360 Drag Interaction Hint Overlay */}
      <div className="absolute bottom-3 right-3 pointer-events-none text-[10px] font-medium text-stone-500 bg-white/70 backdrop-blur-xs px-2 py-1 rounded-lg border border-stone-200/60 hidden sm:block">
        Arrastra para girar 360°
      </div>
    </div>
  );
};
