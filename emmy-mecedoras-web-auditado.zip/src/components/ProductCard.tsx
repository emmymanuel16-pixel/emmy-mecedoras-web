import React, { useState, useRef, useEffect } from 'react';
import { ChevronLeft, ChevronRight, MessageCircle, Eye, CheckCircle2, Sparkles, Layers, Star, Image as ImageIcon } from 'lucide-react';
import { Product, StoreSettings } from '../types';
import { formatPrice, generateSingleProductWhatsAppUrl } from '../utils/whatsapp';
import { api } from '../services/api';

interface ProductCardProps {
  product: Product;
  settings: StoreSettings;
  onSelectProduct: (product: Product) => void;
  onQuickAddToCart?: (product: Product) => void;
}

export const ProductCard = React.memo<ProductCardProps>(({
  product,
  settings,
  onSelectProduct,
}) => {
  const [currentImageIdx, setCurrentImageIdx] = useState(0);
  const [failedImages, setFailedImages] = useState<Record<number, boolean>>({});

  // Reset image failure cache and index whenever product or image list changes
  useEffect(() => {
    setFailedImages({});
    setCurrentImageIdx(0);
  }, [product.id, product.images]);

  const images = React.useMemo(() => {
    const list: string[] = [];
    const seen = new Set<string>();

    const addImg = (imgStr: any) => {
      if (typeof imgStr === 'string') {
        const trimmed = imgStr.trim();
        if (trimmed.length > 0 && !seen.has(trimmed)) {
          seen.add(trimmed);
          list.push(trimmed);
        }
      }
    };

    if (product.mainImage) {
      addImg(product.mainImage);
    }
    if (Array.isArray(product.images)) {
      product.images.forEach(addImg);
    }
    return list.length > 0 ? list : ['https://images.unsplash.com/photo-1586023492125-27b2c045efd7?auto=format&fit=crop&w=800&q=80'];
  }, [product.mainImage, product.images]);
  const touchStartX = useRef<number | null>(null);
  const autoPlayTimerRef = useRef<NodeJS.Timeout | null>(null);

  const discountPercent = product.previousPrice && product.previousPrice > product.price
    ? Math.round(((product.previousPrice - product.price) / product.previousPrice) * 100)
    : null;

  // Rotación automática cada 5 segundos de forma fluida
  useEffect(() => {
    if (images.length <= 1) return;

    const startTimer = () => {
      if (autoPlayTimerRef.current) clearInterval(autoPlayTimerRef.current);
      autoPlayTimerRef.current = setInterval(() => {
        setCurrentImageIdx((prev) => (prev + 1) % images.length);
      }, 5000);
    };

    startTimer();

    return () => {
      if (autoPlayTimerRef.current) {
        clearInterval(autoPlayTimerRef.current);
      }
    };
  }, [images.length]);

  const resetTimer = () => {
    if (images.length <= 1) return;
    if (autoPlayTimerRef.current) clearInterval(autoPlayTimerRef.current);
    autoPlayTimerRef.current = setInterval(() => {
      setCurrentImageIdx((prev) => (prev + 1) % images.length);
    }, 5000);
  };

  const handleNextPhoto = (e: React.MouseEvent) => {
    e.stopPropagation();
    setCurrentImageIdx((prev) => (prev + 1) % images.length);
    resetTimer();
  };

  const handlePrevPhoto = (e: React.MouseEvent) => {
    e.stopPropagation();
    setCurrentImageIdx((prev) => (prev - 1 + images.length) % images.length);
    resetTimer();
  };

  const handleDotClick = (e: React.MouseEvent, idx: number) => {
    e.stopPropagation();
    setCurrentImageIdx(idx);
    resetTimer();
  };

  const handleTouchStart = (e: React.TouchEvent) => {
    touchStartX.current = e.targetTouches[0].clientX;
  };

  const handleTouchEnd = (e: React.TouchEvent) => {
    if (!touchStartX.current) return;
    const diff = touchStartX.current - e.changedTouches[0].clientX;
    if (diff > 40 && images.length > 1) {
      setCurrentImageIdx((prev) => (prev + 1) % images.length);
      resetTimer();
    } else if (diff < -40 && images.length > 1) {
      setCurrentImageIdx((prev) => (prev - 1 + images.length) % images.length);
      resetTimer();
    }
    touchStartX.current = null;
  };

  const handleDirectWhatsApp = (e: React.MouseEvent) => {
    e.stopPropagation();
    api.recordAnalyticsEvent({
      type: 'whatsapp_direct_inquiry',
      productId: product.id,
      productName: product.name,
      categoryId: product.categoryId,
      price: product.price,
      metadata: { source: 'product_card_button' }
    });
    const url = generateSingleProductWhatsAppUrl(product, settings);
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  return (
    <div
      id={`product-card-${product.id}`}
      onClick={() => onSelectProduct(product)}
      className="group bg-white rounded-2xl sm:rounded-3xl overflow-hidden card-shadow card-shadow-hover transition-all duration-300 flex flex-col h-full border border-[#F0EBE6] cursor-pointer select-none relative will-change-transform"
    >
      {/* Mini Image Carousel Container with Crossfade */}
      <div
        className="relative aspect-4/3 sm:aspect-square w-full bg-[#F0EBE6]/60 overflow-hidden"
        onTouchStart={handleTouchStart}
        onTouchEnd={handleTouchEnd}
      >
        {images.map((imgUrl, idx) => {
          const isFailed = Boolean(failedImages[idx]);
          const stableKey = `${product.id}-card-img-${idx}-${imgUrl.slice(-25)}`;
          return isFailed ? (
            <div
              key={stableKey}
              className={`absolute inset-0 w-full h-full bg-[#F5F2ED] flex flex-col items-center justify-center p-3 text-center transition-all duration-300 ${
                idx === currentImageIdx
                  ? 'opacity-100 scale-100 z-1'
                  : 'opacity-0 scale-100 z-0 pointer-events-none'
              }`}
            >
              <div className="w-9 h-9 rounded-full bg-[#E8E2DC] flex items-center justify-center mb-1 text-[#8A7568]">
                <ImageIcon className="w-4 h-4" />
              </div>
              <span className="text-[11px] font-semibold text-[#5C4033]">Imagen no disponible</span>
              <span className="text-[10px] text-[#8A7568]">Vista {idx + 1} de {images.length}</span>
            </div>
          ) : (
            <img
              key={stableKey}
              src={imgUrl}
              alt={`${product.name} - Vista ${idx + 1}`}
              referrerPolicy="no-referrer"
              className={`absolute inset-0 w-full h-full object-cover object-center group-hover:scale-105 transition-all duration-700 ease-in-out ${
                idx === currentImageIdx
                  ? 'opacity-100 scale-100 z-1'
                  : 'opacity-0 scale-100 z-0 pointer-events-none'
              }`}
              loading={idx === 0 ? 'eager' : 'lazy'}
              decoding="async"
              onError={() => setFailedImages((prev) => ({ ...prev, [idx]: true }))}
            />
          );
        })}

        {/* Badges Overlay */}
        <div className="absolute top-2.5 left-2.5 flex flex-col gap-1.5 z-10">
          {product.isOffer && discountPercent && (
            <span className="bg-[#9C2727] text-white text-[10px] sm:text-xs font-extrabold px-2.5 py-0.5 rounded-full shadow-xs tracking-wider">
              -{discountPercent}%
            </span>
          )}
          {product.isNew && (
            <span className="bg-[#2C1810] text-[#FDFCFB] text-[10px] sm:text-xs font-semibold px-2.5 py-0.5 rounded-full shadow-xs">
              NUEVO
            </span>
          )}
          {product.isFeatured && !product.isNew && (
            <span className="bg-[#5C4033] text-white text-[10px] sm:text-xs font-semibold px-2.5 py-0.5 rounded-full shadow-xs flex items-center gap-1">
              <Sparkles className="w-2.5 h-2.5" />
              DESTACADO
            </span>
          )}
        </div>

        {/* Stock Badge */}
        <div className="absolute top-2.5 right-2.5 z-10">
          {product.stock > 0 ? (
            <span className="bg-emerald-700/90 text-white text-[10px] font-medium px-2 py-0.5 rounded-full backdrop-blur-xs flex items-center gap-1 shadow-xs">
              <CheckCircle2 className="w-2.5 h-2.5" />
              Disponible
            </span>
          ) : (
            <span className="bg-[#2C1810]/90 text-[#FDFCFB] text-[10px] font-medium px-2 py-0.5 rounded-full backdrop-blur-xs shadow-xs">
              Bajo pedido
            </span>
          )}
        </div>

        {/* Mini Carousel Navigation Arrows (Visible if > 1 image) */}
        {images.length > 1 && (
          <>
            <button
              onClick={handlePrevPhoto}
              className="absolute left-1.5 top-1/2 -translate-y-1/2 p-1.5 rounded-full bg-black/40 text-white hover:bg-black/70 transition-all opacity-0 group-hover:opacity-100 sm:flex hidden items-center justify-center z-10"
              aria-label="Foto anterior"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              onClick={handleNextPhoto}
              className="absolute right-1.5 top-1/2 -translate-y-1/2 p-1.5 rounded-full bg-black/40 text-white hover:bg-black/70 transition-all opacity-0 group-hover:opacity-100 sm:flex hidden items-center justify-center z-10"
              aria-label="Foto siguiente"
            >
              <ChevronRight className="w-4 h-4" />
            </button>

            {/* Indicator Dots */}
            <div className="absolute bottom-2 left-1/2 -translate-x-1/2 z-10 flex items-center gap-1 bg-black/30 px-2 py-1 rounded-full backdrop-blur-xs">
              {images.map((_, i) => (
                <button
                  key={`${product.id}-dot-${i}`}
                  type="button"
                  onClick={(e) => handleDotClick(e, i)}
                  className={`rounded-full transition-all cursor-pointer ${
                    i === currentImageIdx ? 'w-3.5 h-1.5 bg-white' : 'w-1.5 h-1.5 bg-white/50 hover:bg-white/80'
                  }`}
                  aria-label={`Ver foto ${i + 1}`}
                />
              ))}
            </div>
          </>
        )}
      </div>

      {/* Product Content Details */}
      <div className="p-3.5 sm:p-4 flex-1 flex flex-col justify-between space-y-2.5">
        <div>
          {/* Category / Material / Rating Bar */}
          <div className="flex items-center justify-between text-[11px] font-semibold text-[#5C4033] uppercase tracking-wider mb-1">
            <span className="truncate">{product.categoryId === 'cojines' ? 'Cojinería' : 'Fibra de Vidrio'}</span>
            {product.rating && (
              <span className="flex items-center gap-1 text-[#2C1810] font-bold text-xs bg-[#F0EBE6] px-1.5 py-0.5 rounded-md">
                <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
                <span>{product.rating.toFixed(1)}</span>
                {product.reviewCount ? (
                  <span className="text-[10px] text-[#8C7A70] font-normal">({product.reviewCount})</span>
                ) : null}
              </span>
            )}
          </div>

          {/* Product Name */}
          <h3 className="font-serif text-sm sm:text-base font-bold text-[#2C1810] line-clamp-2 leading-snug pt-0.5 group-hover:text-[#5C4033] transition-colors">
            {product.name}
          </h3>

          {/* Cushion Style Tag */}
          {product.cushionStyle && (
            <div className="mt-1.5 flex items-center gap-1">
              <span className="text-[10px] font-medium bg-[#8a532b]/10 text-[#8a532b] px-2 py-0.5 rounded-full">
                ✨ Cojín: {product.cushionStyle}
              </span>
            </div>
          )}

          {/* Included Items Box for Medio Juegos & Combinados con Sofá */}
          {product.includedItems && product.includedItems.length > 0 && (
            <div className="mt-2 p-2 rounded-xl bg-[#F0EBE6]/70 border border-[#E8E2DC] text-[11px] text-[#5C4033] flex items-start gap-1.5">
              <Layers className="w-3.5 h-3.5 shrink-0 mt-0.5 text-[#5C4033]" />
              <span className="line-clamp-2 font-medium">
                <strong className="text-[#2C1810]">Incluye:</strong> {product.includedItems.join(' + ')}
              </span>
            </div>
          )}

          {/* Color Swatches */}
          {product.colors && product.colors.length > 0 && (
            <div className="flex items-center gap-1.5 mt-2 pt-0.5">
              <span className="text-[10px] text-[#8C7A70] font-medium">Tonos:</span>
              <div className="flex items-center gap-1">
                {product.colors.slice(0, 4).map((c, i) => (
                  <span
                    key={i}
                    title={c.name}
                    className="w-3.5 h-3.5 rounded-full border border-[#D6CCC2] shrink-0 shadow-2xs"
                    style={{ backgroundColor: c.hex }}
                  />
                ))}
                {product.colors.length > 4 && (
                  <span className="text-[9px] font-bold text-[#8C7A70]">+{product.colors.length - 4}</span>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Pricing & Actions */}
        <div className="pt-2 border-t border-[#F0EBE6] flex flex-col gap-2.5">
          <div className="flex items-baseline justify-between">
            <div className="flex items-baseline gap-2">
              <span className="text-base sm:text-lg font-bold text-[#2C1810]">
                {formatPrice(product.price, settings.currency)}
              </span>
              {product.previousPrice && (
                <span className="text-xs text-[#9A8A80] line-through">
                  {formatPrice(product.previousPrice, settings.currency)}
                </span>
              )}
            </div>
          </div>

          {/* Action Buttons */}
          <div className="grid grid-cols-2 gap-1.5">
            <button
              onClick={(e) => {
                e.stopPropagation();
                onSelectProduct(product);
              }}
              className="py-2 px-2 rounded-xl bg-[#F0EBE6] hover:bg-[#E8E2DC] text-[#2C1810] text-xs font-semibold flex items-center justify-center gap-1 transition-colors cursor-pointer"
            >
              <Eye className="w-3.5 h-3.5" />
              <span>Ver detalle</span>
            </button>

            <button
              onClick={handleDirectWhatsApp}
              className="py-2 px-2 rounded-xl bg-[#25D366] hover:bg-[#20BD5A] text-white text-xs font-bold flex items-center justify-center gap-1 transition-all shadow-xs active:scale-95 cursor-pointer"
            >
              <MessageCircle className="w-3.5 h-3.5 fill-current" />
              <span>WhatsApp</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
});

