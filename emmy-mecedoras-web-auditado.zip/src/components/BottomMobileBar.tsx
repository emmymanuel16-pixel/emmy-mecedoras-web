import React from 'react';
import { MessageCircle, ShoppingBag } from 'lucide-react';
import { CartItem, StoreSettings } from '../types';
import { formatPrice, generateCartWhatsAppUrl, generateSupportWhatsAppUrl } from '../utils/whatsapp';

interface BottomMobileBarProps {
  cartItems: CartItem[];
  settings: StoreSettings;
  onOpenCart: () => void;
}

export const BottomMobileBar: React.FC<BottomMobileBarProps> = ({
  cartItems,
  settings,
  onOpenCart,
}) => {
  const totalCount = cartItems.reduce((acc, item) => acc + item.quantity, 0);
  const totalAmount = cartItems.reduce((acc, item) => acc + item.unitPrice * item.quantity, 0);

  const handleAction = () => {
    if (totalCount > 0) {
      onOpenCart();
    } else {
      window.open(generateSupportWhatsAppUrl(settings), '_blank', 'noopener,noreferrer');
    }
  };

  return (
    <div className="fixed bottom-0 left-0 right-0 z-40 bg-[#FDFCFB]/95 backdrop-blur-md border-t border-[#F0EBE6] p-3 sm:hidden bottom-bar-shadow">
      <div className="flex items-center gap-2">
        {/* Cart Quick Shortcut */}
        <button
          onClick={onOpenCart}
          className="relative p-3 rounded-2xl bg-[#F0EBE6] text-[#2C1810] flex items-center justify-center shrink-0 border border-[#E8E2DC]"
          aria-label="Abrir carrito"
        >
          <ShoppingBag className="w-5 h-5 text-[#5C4033]" />
          {totalCount > 0 && (
            <span className="absolute -top-1 -right-1 bg-[#25D366] text-white text-[10px] font-bold rounded-full h-4.5 min-w-[18px] px-1 flex items-center justify-center shadow-xs">
              {totalCount}
            </span>
          )}
        </button>

        {/* Iconic Green WhatsApp Button */}
        <button
          id="mobile-bottom-whatsapp-btn"
          onClick={handleAction}
          className="flex-1 py-3.5 px-4 rounded-2xl bg-[#25D366] hover:bg-[#20BD5A] text-white font-extrabold text-xs tracking-wider flex items-center justify-center gap-2 shadow-md active:scale-98 transition-transform uppercase"
        >
          <MessageCircle className="w-5 h-5 fill-current shrink-0" />
          <span>
            {totalCount > 0
              ? `PEDIR POR WHATSAPP (${formatPrice(totalAmount, settings.currency)})`
              : 'PEDIR POR WHATSAPP'}
          </span>
        </button>
      </div>
    </div>
  );
};
