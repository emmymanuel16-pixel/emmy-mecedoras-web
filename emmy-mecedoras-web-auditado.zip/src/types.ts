export type ProductCategory = 
  | 'mecedoras-grandes'
  | 'mecedoras-medianas'
  | 'medio-juegos'
  | 'combinados-sofa'
  | 'cojines'
  | string;

export interface ColorOption {
  name: string;
  hex: string;
}

export interface CushionColorOption {
  id: string;
  name: string;
  hex: string;
  category?: string;
  isActive?: boolean;
}

export interface CushionPatternOption {
  id: string;
  name: string;
  image: string;
  storagePath?: string;
  description?: string;
  isActive?: boolean;
  createdAt?: string;
  updatedAt?: string;
}

export interface CushionTextalinaOption {
  id: string;
  name: string;
  hex: string;
  image: string;
  storagePath?: string;
  description?: string;
  isActive?: boolean;
  createdAt?: string;
  updatedAt?: string;
}

export interface CushionBackrestStyleSettings {
  costuraImage: string;
  costuraTitle?: string;
  costuraDescription?: string;
  costuraStoragePath?: string;
  botonesImage: string;
  botonesTitle?: string;
  botonesDescription?: string;
  botonesStoragePath?: string;
}

export interface CushionBorderStyleSettings {
  sinBordesImage: string;
  sinBordesTitle?: string;
  sinBordesDescription?: string;
  sinBordesStoragePath?: string;
  conBordesImage: string;
  conBordesTitle?: string;
  conBordesDescription?: string;
  conBordesStoragePath?: string;
}

export interface CushionFabricCategory {
  id: string;
  name: string; // 'Textalina' | 'Tela o Kiwi' | 'Vinil' | 'Estampados' | etc.
  description: string;
  priceDiff: number;
  typeMode?: 'solid' | 'textalina' | 'pattern' | 'custom';
  image?: string;
  storagePath?: string;
  badges?: string[];
  material?: string;
  usage?: string;
  cleaningInfo?: string;
  isActive?: boolean;
  order?: number;
  createdAt?: string;
  updatedAt?: string;
}

export interface ProductVariant {
  id: string;
  name: string;
  type: 'color' | 'size' | 'fabric' | 'finish' | 'other';
  option: string;
  priceDiff?: number;
}

export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  previousPrice?: number;
  categoryId: ProductCategory;
  productType: 'mecedora-grande' | 'mecedora-mediana' | 'medio-juego' | 'combinado-sofa' | 'cojin' | 'otro';
  stock: number;
  material: string;
  dimensions?: string;
  weightCapacity?: string;
  colors: ColorOption[]; // Rocker colors: Blanco, Negro, Caoba
  finishes?: string[];
  upholstery?: string;
  cushionStyle?: string;
  cushionColors?: string[];
  cushionPatterns?: CushionPatternOption[];
  variants?: ProductVariant[];
  includedItems?: string[];
  compatibleCushionIds?: string[];
  images: string[];
  mainImage: string;
  isActive: boolean;
  isFeatured: boolean;
  isNew: boolean;
  isOffer: boolean;
  rating?: number;
  reviewCount?: number;
  viewsCount?: number;
  ordersCount?: number;
  whatsappClicksCount?: number;
  lastViewedAt?: string;
  lastOrderedAt?: string;
  createdAt?: string;
  updatedAt?: string;
}

export interface Review {
  id: string;
  productId: string;
  productName?: string;
  userName: string;
  userEmail?: string;
  rating: number; // 1 to 5
  title?: string;
  comment: string;
  isVerifiedBuyer: boolean;
  orderNumber?: string;
  status: 'approved' | 'pending' | 'rejected';
  createdAt: string;
  helpfulCount?: number;
  adminReply?: string;
  adminRepliedAt?: string;
}

export interface CatalogFilterState {
  categoryId: string;
  materials: string[];
  rockerColors: string[];
  cushionColors: string[];
  cushionStyles: string[];
  priceRange: [number, number];
  minRating: number;
  onlyOffers: boolean;
  onlyInStock: boolean;
  sortBy: 'featured' | 'price-asc' | 'price-desc' | 'rating' | 'newest';
}

export interface Category {
  id: string;
  name: string;
  description: string;
  image?: string;
  order: number;
  isActive: boolean;
}

export interface Banner {
  id: string;
  image: string;
  title: string;
  subtitle: string;
  buttonText: string;
  link?: string;
  order: number;
  isActive: boolean;
}

export interface CustomizerColorOption {
  id: string;
  name: string;
  hex: string;
  finish?: 'brillante' | 'satinado' | 'mate';
  priceDiff?: number;
  isActive?: boolean;
}

export interface CustomizerFabricOption {
  id: string;
  name: string;
  type: 'lino' | 'chenille' | 'impermeable' | 'estampado' | 'terciopelo' | 'otro';
  hex: string;
  textureUrl?: string;
  priceDiff?: number;
  isActive?: boolean;
}

export interface CustomizerAccessoryOption {
  id: string;
  name: string;
  description?: string;
  price: number;
  isActive?: boolean;
}

export interface ConfiguratorSettings {
  enabled: boolean;
  baseImageUrl?: string;
  mainFabrics?: CustomizerFabricOption[];
  trimColors?: CustomizerColorOption[];
  rockerColors?: CustomizerColorOption[]; // backward compatibility
  cushionFabrics?: CustomizerFabricOption[]; // backward compatibility
  accessories: CustomizerAccessoryOption[];
  allowCushionRemoval?: boolean;
  cushionRemovalDiscount?: number;
}

export interface ProductCustomization {
  mainFabric?: CustomizerFabricOption;
  trimColor?: CustomizerColorOption;
  fabricType?: 'terciopelo' | 'lino' | 'chenille' | 'impermeable';
  rockerColor?: CustomizerColorOption;
  fabric?: CustomizerFabricOption;
  hasCushion?: boolean;
  selectedAccessories: CustomizerAccessoryOption[];
  customFinish?: string;
  customNotes?: string;
  basePrice: number;
  extrasPrice: number;
  totalUnitPrice: number;
}

export interface StoreSettings {
  storeName: string;
  tagline: string;
  logo?: string;
  whatsapp: string;
  currency: string;
  socialNetworks: {
    instagram?: string;
    facebook?: string;
    tiktok?: string;
  };
  contactInformation: {
    phone?: string;
    email?: string;
    address?: string;
    mapsUrl?: string;
    schedule?: string;
  };
  cushionColors?: CushionColorOption[];
  cushionFabrics?: CushionFabricCategory[];
  cushionPatterns?: CushionPatternOption[];
  cushionTextalinaOptions?: CushionTextalinaOption[];
  cushionStyleExamples?: CushionBackrestStyleSettings;
  cushionBorderStyleExamples?: CushionBorderStyleSettings;
  cushionBorderColors?: ColorOption[];
  rockerColors?: ColorOption[];
  configurator?: ConfiguratorSettings;
  deliveryInformation: string;
  returnPolicy: string;
}

export interface CartItem {
  id: string;
  productId: string;
  product: Product;
  quantity: number;
  selectedColor?: string; // Color de mecedora: Blanco / Negro / Caoba
  selectedCushionColor?: string; // Color del cojín
  selectedBorderColor?: string; // Color de los bordes / ribete
  selectedBackrestStyle?: 'costura' | 'botones' | string; // 'costura' | 'botones'
  selectedFabricType?: string; // Tipo de tela: 'Textalina', 'Tela o Kiwi', 'Vinil', 'Estampados'
  selectedFabricPriceDiff?: number;
  selectedPatternName?: string; // Nombre del estampado seleccionado
  selectedPatternImage?: string; // URL o imagen del estampado seleccionado
  selectedTextalinaImage?: string; // URL o imagen de la muestra de textalina seleccionada
  selectedSize?: string;
  selectedFinish?: string;
  selectedUpholstery?: string;
  customNotes?: string;
  unitPrice: number;
  customization?: ProductCustomization;
}

export interface AuthState {
  isAuthenticated: boolean;
  token: string | null;
  username: string | null;
}

export interface AnalyticsEvent {
  id?: string;
  type: 'product_view' | 'product_modal_open' | 'whatsapp_order' | 'whatsapp_direct_inquiry' | 'search_performed' | 'category_view';
  productId?: string;
  productName?: string;
  categoryId?: string;
  price?: number;
  customerPhone?: string;
  timestamp: string;
  metadata?: Record<string, any>;
}

export interface DailyAnalyticsPoint {
  date: string;
  displayDate: string;
  views: number;
  orders: number;
  inquiries: number;
  estimatedRevenue: number;
}

export interface ProductAnalyticsStats {
  productId: string;
  name: string;
  categoryName: string;
  mainImage: string;
  price: number;
  stock: number;
  isActive: boolean;
  views: number;
  orders: number;
  conversionRate: number; // Percentage (orders / views * 100)
  estimatedValue: number;
  lastActivity?: string;
}


